# Schriften der Arbeitsseite

Gewählt im Stilvergleich Runde 5 (Lehrer, 2026-10-13: „V3“ — *„mehr
Video-Spiel-Style“*). Beide unter der SIL Open Font License 1.1 (Lizenztexte
daneben), bezogen über Google Fonts als woff2, Blöcke latin + latin-ext.
Die Seite lädt sie von `/_system/seite/fonts/`, nie aus dem Netz (CSP).

| Datei | Schrift | Autor | Rolle |
| --- | --- | --- | --- |
| RussoOne-400-*.woff2 | Russo One | Jovanny Lemonad | Titel (wuchtig wie ein Spiellogo) |
| Teko-400-700-*.woff2 | Teko (variabel) | Indian Type Foundry | Chips, Reiter, Zähler (Punktestand) |
| Exo2-100-900-*.woff2, …-italic-*.woff2 | Exo 2 (variabel) | Natanael Gama | Grundtext (Runde 6, Lehrer: „B1“) |

Code bleibt die System-Monospace; fehlt eine Schrift, fällt die Seite auf die
Systemschrift zurück (`--sans`, `--rund`, `--chip` tragen die Rückfallnamen).
Die übrigen Kandidaten der Vergleichsrunden liegen unter
`werkstatt/informatik/planung/stilvergleich/fonts/`.
