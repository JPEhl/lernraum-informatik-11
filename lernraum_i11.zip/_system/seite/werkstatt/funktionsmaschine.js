// Werkstatt "Funktionsmaschine" -- ein Aufruf als Maschine: oben die Karten (die Argumente), in der Maschine je
// Parameter ein Schlitz mit Namensschild, unten das Fach fuer die Rueckgabe. Fuer Thema 13 („Seil, Apfel und
// Kreide“, 23.10.) gebaut, als Antwort auf die Nadeln W1 (der erste Parameter war gleich eine Liste) und W2
// (die Regel „Mehrere Parameter“ ohne Beispiel, „am besten ein animiertes Video“).
// Lehrerwahl 23.10. aus drei Attrappen (werkstatt/informatik/planung/funktionsmaschine_werkstatt/): Fassung A
// „Maschine mit Schlitzen“ (seine Skizze aus dem Ideenfilm), Python daneben, innen zu und aufklappbar, die
// Pruefaufgabe nur als Hinweis (kein Stern), dazu aus Fassung B die Leiste „draussen“.
//   * ▸ Vorfuehren in drei Takten: Karten hinein (der Reihe nach, die erste in den ersten Schlitz) · der Rumpf
//     laeuft (zu: ein Satz, welcher Zweig passt; aufgeklappt: das Struktogramm, der Weg leuchtet) · Antwort ins
//     Fach. „Schritt“ macht dasselbe Stueck fuer Stueck. ⇄ tauscht Karte 1 und 2 -- bei ziel an die Wand.
//   * Gerechnet wird mit dem Kern der Werkstatt Struktogramm (Werkstaetten.struktogramm.kern: lesen, lauf,
//     signatur, argumente, alsPython) -- ein Rumpf, der dort laeuft, laeuft hier; kein zweiter Rechner.
//   * Das Struktogramm steht im Thema (```struktogramm Algorithmus ziel(raum, richtung) im Vortragsschritt),
//     die Argumente in aufruf='ziel("flur", "westen")' -- beides prueft bauen.py (K1).
// Optionen: quelle, algorithmus, aufruf; karten='"flur"|"keller"' (Vorrat zum Anklicken); draussen='raum =
// "keller"; rucksack = ["lampe"]' (die Leiste: Kaestchen des Spiels, ein Argument darf ein Name sein);
// leer="eine Wand" (was ein leerer Text bedeutet); vorhersagen='ziel(…)|ziel(…)' (Tisch „Vorhersagen“, nur im
// Reiter: erst tippen, was zurueckkommt, dann laeuft die Maschine). Im Reiter: tische: [{name, …}, …].
// Einbinden: Werkstaetten.funktionsmaschine(element, opt) -- braucht struktogramm.js davor.
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.funktionsmaschine = function (wurzel, opt) {
  opt = opt || {};
  const K = window.Werkstaetten.struktogramm && window.Werkstaetten.struktogramm.kern;
  const RUHIG = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const TAKT = RUHIG ? 0 : 1;
  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  let sofort = false;   // „◂ zurück“ spielt die Schritte bis einen davor ohne Pause nach
  const schlaf = ms => sofort ? Promise.resolve() : new Promise(r => setTimeout(r, ms * TAKT));
  const zeig = w => w === null || w === undefined ? "None" : typeof w === "string" ? '"' + w + '"' : K.zeig(w);
  // Takt 1 sagt, was Python beim Aufruf tut (Lehrer 24.10., T13 W7: „Was macht Python beim Aufruf der Funktion mit dem
  // Parameter?“): Es legt je Parameter ein Kaestchen an und weist ihm das Argument zu -- raum = "keller", wie in Thema 2
  const TAKTE = ["Python legt die Parameter an", "der Rumpf läuft", "Antwort ins Fach"];

  wurzel.textContent = "";
  wurzel.classList.add("fmaschine");
  if (!K) { wurzel.append(h("p", "meldung falsch", "Die Funktionsmaschine braucht die Werkstatt Struktogramm (struktogramm.js).")); return; }

  // ─── Tische ──────────────────────────────────────────────────────────────────────────
  const liste = t => String(t || "").split("|").map(x => x.trim()).filter(Boolean);
  const tische = (opt.tische && opt.tische.length ? opt.tische : [opt]).map((t, i) => {
    const sig = K.signatur(t.algorithmus || "");
    let baum = null, fehler = "";
    try { baum = K.lesen(t.quelle || ""); } catch (e) { fehler = "Das Struktogramm ist nicht lesbar: " + e.message; }
    if (!sig) fehler = fehler || "Der Titel „" + (t.algorithmus || "") + "“ nennt keine Parameter (Algorithmus name(a, b)).";
    return { name: t.name || (sig ? sig.name : "Tisch " + (i + 1)), sig, baum, fehler, aufruf: t.aufruf || "",
      karten: liste(t.karten), draussen: t.draussen || "", leer: t.leer || "", vorhersagen: liste(t.vorhersagen) };
  });
  let tisch = tische[0];

  // ─── Zustand ─────────────────────────────────────────────────────────────────────────
  let args = [];            // die Argumente als Text, wie sie im Aufruf stehen
  let gewaehlt = 0;         // die Karte, in die ein Klick auf den Vorrat legt
  let python = false, innen = false, draussenAn = true, beschaeftigt = false;
  let plan = null, pos = 0; // die Schritte eines Laufs und wie weit er ist
  let frage = 0, beantwortet = [], geprueft = false;   // Tisch Vorhersagen

  // ─── Aufbau ──────────────────────────────────────────────────────────────────────────
  const reiter = h("div", "tische");
  const vorh = h("div", "vorhersage-teil");
  const takte = h("ol", "takte");
  TAKTE.forEach((t, i) => takte.appendChild(h("li", "", (i + 1) + " · " + t)));
  const leiste = h("div", "draussen-leiste");
  const flaeche = h("div", "flaeche");
  const vorrat = h("div", "vorrat");
  const mitte = h("div", "mitte");
  const aufrufEl = h("div", "aufruf-zeile");
  const kartenEl = h("div", "reihe-karten");
  const gehaeuse = h("div", "gehaeuse");
  const schlitzeEl = h("div", "schlitze");
  const sigEl = h("div", "sig");
  const innenEl = h("div", "innen");
  const satzEl = h("ol", "satz");     // je Schritt des Rumpfs eine Zeile (Nadel W4, 24.10.)
  const bildEl = h("div", "strukto-innen");
  innenEl.append(satzEl, bildEl);
  const anlegenEl = h("p", "anlegen", "Python legt beim Aufruf an:");
  gehaeuse.append(anlegenEl, schlitzeEl, sigEl, innenEl);
  const rohr = h("div", "rohr");
  const fach = h("div", "fach");
  mitte.append(aufrufEl, kartenEl, gehaeuse, rohr, fach);
  const maschine = h("div", "maschine-teil");
  maschine.append(vorrat, mitte);
  const pyEl = h("pre", "py"); pyEl.hidden = true;
  flaeche.append(maschine, pyEl);
  const knoepfe = h("div", "knoepfe");
  const kVor = h("button", "primaer", "▸ Vorführen");
  const kZurueck = h("button", "", "◂ zurück");   // Lehrer 24.10. (T13 W10): Schritt zurueck und von vorn
  const kSchritt = h("button", "", "Schritt ▸");
  const kVorn = h("button", "", "↺ von vorn");
  const kTausch = h("button", "", "⇄ tauschen");
  const kInnen = h("button", "", "▾ innen aufklappen");
  const kPy = h("button", "", "als Python zeigen");
  const kDr = h("button", "", "draußen");
  knoepfe.append(kVor, kZurueck, kSchritt, kVorn, kTausch, kInnen, kPy, kDr);
  const meldung = h("p", "meldung");
  // Die Knoepfe stehen oben (Lehrer 24.10.: „damit sich deren Position nicht verschiebt beim Ausfuehren“) -- unter ihnen
  // waechst die Maschine beim Vorfuehren (Satz innen, Fach, Struktogramm), darueber nichts
  wurzel.append(reiter, knoepfe, vorh, takte, leiste, flaeche, meldung);

  tische.forEach(t => {
    const b = h("button", "", t.name);
    b.addEventListener("click", () => { if (beschaeftigt) return; tisch = t; tischStart(); });
    t.knopf = b; reiter.append(b);
  });
  reiter.hidden = tische.length < 2;

  // ─── Werte ───────────────────────────────────────────────────────────────────────────
  // draussen: „raum = "keller"; rucksack = ["lampe"]“ -> [[name, wert], …] (Semikolon trennt, nicht in Texten)
  function draussenWerte() {
    const aus = [];
    let akt = "", text = null;
    const teile = [];
    for (const c of tisch.draussen) {
      if (text) { if (c === text) text = null; akt += c; continue; }
      if (c === '"' || c === "'") { text = c; akt += c; continue; }
      if (c === ";") { teile.push(akt); akt = ""; continue; }
      akt += c;
    }
    teile.push(akt);
    teile.map(x => x.trim()).filter(Boolean).forEach(z => {
      const m = z.match(/^([A-Za-z_]\w*)\s*=\s*(.+)$/);
      if (m) aus.push([m[1], K.werten(K.ausdruck(m[2]), {})]);
    });
    return aus;
  }
  const umgebung = () => Object.fromEntries(tisch.draussen ? draussenWerte() : []);
  const istName = t => /^[A-Za-z_]\w*$/.test(String(t).trim()) && !["True", "False", "None"].includes(String(t).trim());
  function werten(argTexte) {
    const env = umgebung();
    return argTexte.map((a, i) => {
      const p = tisch.sig.parameter[i];
      if (!String(a).trim()) throw new Error("Für den Parameter " + p + " fehlt noch eine Karte.");
      if (istName(a) && !(a.trim() in env)) throw new Error("NameError: name '" + a.trim() + "' is not defined – draußen gibt es kein Kästchen " + a.trim() + ".");
      try { return K.werten(K.ausdruck(a), env); }
      catch (e) { throw new Error("Die Karte für " + p + " kann die Maschine nicht lesen: „" + a + "“ – " + e.message); }
    });
  }
  // Der ganze Lauf ohne Bild: die Ereignisse des Kerns und was zurueckkommt
  function laufen(werte) {
    const v = {};
    tisch.sig.parameter.forEach((p, i) => { v[p] = werte[i]; });
    const welt = { v, eingaben: [], ausgaben: [], gelesen: 0 };
    const ereignisse = [];
    let rueck = null, hat = false, n = 0;
    for (const e of K.lauf(tisch.baum, welt, null)) {
      if (++n > 400) throw new Error("Der Rumpf läuft und läuft – nach 400 Schritten angehalten.");
      ereignisse.push(e);
      if (e.art === "warte") throw new Error("Der Rumpf wartet auf eine Eingabe – das kann die Maschine nicht.");
      if (e.art === "ende" && e.rueckgabe) { rueck = e.wert; hat = true; }
    }
    return { ereignisse, rueck: hat ? rueck : null, ausgaben: welt.ausgaben.filter(a => !a.startsWith("Rückgabe: ")) };
  }

  // ─── Zeichnen ────────────────────────────────────────────────────────────────────────
  const kl = i => " p" + Math.min(i, 2);
  function zeichneKarten() {
    kartenEl.textContent = "";
    schlitzeEl.textContent = "";
    const n = tisch.sig.parameter.length;
    kartenEl.style.gridTemplateColumns = schlitzeEl.style.gridTemplateColumns = "repeat(" + n + ", minmax(9.5em, 1fr))";
    const fest = tisch.vorhersagen.length > 0;
    args.forEach((a, i) => {
      const spalte = h("div", "spalte");
      const karte = h("label", "karte" + kl(i) + (i === gewaehlt && tisch.karten.length && n > 1 ? " gewaehlt" : ""));
      karte.dataset.platz = i + 1;
      karte.append(h("span", "platz", String(i + 1)));
      const abgelesen = h("span", "abgelesen"); karte.append(abgelesen);
      const f = h("input"); f.value = a; f.spellcheck = false; f.readOnly = fest || beschaeftigt;
      f.setAttribute("aria-label", "Karte " + (i + 1) + " für " + tisch.sig.parameter[i]);
      const breit = () => { f.size = Math.max(3, f.value.length + 1); };
      breit();
      f.addEventListener("input", breit);
      f.addEventListener("focus", () => { gewaehlt = i; kartenEl.querySelectorAll(".karte").forEach((k, j) => k.classList.toggle("gewaehlt", j === i && tisch.karten.length > 0 && n > 1)); });
      f.addEventListener("change", () => { args[i] = f.value.trim(); neu(); });
      karte.append(f);
      spalte.append(karte, h("div", "fall" + kl(i)));
      kartenEl.append(spalte);
      const s = h("div", "schlitz fehlt");
      s.dataset.platz = i + 1;
      s.append(h("small", "", (i + 1) + ". " + tisch.sig.parameter[i]), h("span", "leer", "noch nicht angelegt"), h("code", "zuweisung"));
      schlitzeEl.append(s);
    });
    const esc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;");
    aufrufEl.innerHTML = '<span class="etikett">Aufruf</span> <code>' + tisch.sig.name + "(" + args.map((a, i) => '<span class="pp' + kl(i) + '">' + esc(a || "…") + "</span>").join(", ") + ")</code>";
    const ps = tisch.sig.parameter.map((p, i) => '<span class="pp' + kl(i) + '">' + p + "</span>").join(", ");
    sigEl.innerHTML = tisch.sig.name + "(" + ps + ")";
  }
  function zeichneVorrat() {
    vorrat.textContent = "";
    vorrat.hidden = !tisch.karten.length;
    if (!tisch.karten.length) return;
    vorrat.append(h("span", "etikett", "Karten"));
    tisch.karten.forEach(k => {
      const b = h("button", "karte klein", k);
      b.addEventListener("click", () => {
        if (beschaeftigt) return;
        args[gewaehlt] = k;
        if (args.length > 1) gewaehlt = (gewaehlt + 1) % args.length;
        neu();
      });
      vorrat.append(b);
    });
  }
  function zeichneLeiste() {
    leiste.textContent = "";
    leiste.hidden = !tisch.draussen || !draussenAn;
    kDr.hidden = !tisch.draussen;
    kDr.classList.toggle("an", draussenAn);   // „draußen“ blendet die Leiste ein und aus (kurz: sechs Knoepfe in einer Zeile)
    if (!tisch.draussen) return;
    leiste.append(h("span", "etikett", "draußen · das Spiel"));
    let werte = [];
    try { werte = draussenWerte(); } catch (e) { leiste.append(h("span", "falsch", e.message)); }
    werte.forEach(([n, w]) => {
      const k = h("div", "kasten"); k.dataset.name = n;
      k.append(h("span", "schild", n), h("span", "inhalt", zeig(w)));
      leiste.append(k);
    });
  }
  function zeichneBild() {
    bildEl.textContent = "";
    bildEl.hidden = !innen;
    kInnen.textContent = innen ? "▴ innen zuklappen" : "▾ innen aufklappen";
    if (!innen || !tisch.baum) return;
    bildEl.innerHTML = K.zeichnen(tisch.baum, { titel: tisch.sig ? "Algorithmus " + tisch.sig.name + "(" + tisch.sig.parameter.join(", ") + ")" : "" }).svg;
  }
  function setzeTakt(t) {
    takte.querySelectorAll("li").forEach((li, i) => { li.classList.toggle("jetzt", i === t); li.classList.toggle("war", t > i || t === 3); });
  }
  const typ = w => typeof w === "string" ? "str" : typeof w === "boolean" ? "bool" : typeof w === "number" ? (Number.isInteger(w) ? "int" : "float")
    : Array.isArray(w) ? (w.length && w.every(x => typeof x === "string") ? "list[str]" : w.length && w.every(x => typeof x === "number") ? "list[int]" : "list") : "";
  function zeichnePython() {
    pyEl.hidden = !python;
    kPy.textContent = python ? "Python ausblenden" : "als Python zeigen";
    if (!python) return;
    let zeilen = [];
    try { zeilen = K.alsPython(tisch.baum, null, null, { name: tisch.sig.name, parameter: tisch.sig.parameter, argumente: args }); }
    catch (e) { pyEl.textContent = "# (der Rumpf ist noch nicht lesbar)"; return; }
    let werte = null, rueck;
    try { werte = werten(args); rueck = laufen(werte).rueck; } catch (e) { werte = null; }
    const esc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const ps = tisch.sig.parameter.map((p, i) => '<span class="pp' + kl(i) + '">' + p + "</span>" + (werte && typ(werte[i]) ? ": " + typ(werte[i]) : ""));
    const rt = werte && rueck !== null && typ(rueck) ? " -&gt; " + typ(rueck) : "";
    const as = args.map((a, i) => '<span class="pp' + kl(i) + '">' + esc(a) + "</span>").join(", ");
    // die erste Zeile (def) und die letzte (der Aufruf) baut die Maschine selbst: mit Type Hints wie im Spiel und
    // den Farben der Plaetze -- Platz 1 in der Definition und im Aufruf in derselben Farbe
    const gibt = zeilen.some(z => /^return\b/.test(z.text));
    const aufruf = tisch.sig.name + "(" + as + ")";
    pyEl.innerHTML = zeilen.map((z, j) => {
      let t;
      if (j === 0) t = "def " + tisch.sig.name + "(" + ps.join(", ") + ")" + rt + ":";
      else if (j === zeilen.length - 1 && z.text) t = gibt ? "print(" + aufruf + ")" : aufruf;
      else t = esc("    ".repeat(z.tief) + z.text);
      return '<span class="z" data-id="' + z.id + '">' + (t || " ") + "</span>";
    }).join("");
    // der Aufruf steht nicht eingerueckt; def und Aufruf leuchten zusammen (sie gehoeren zusammen)
    const z = pyEl.querySelectorAll(".z");
    z[0].classList.add("paar"); z[z.length - 1].classList.add("paar");
  }

  // ─── Ein Lauf als Schritte ───────────────────────────────────────────────────────────
  function bauePlan() {
    const werte = werten(args);
    const env = umgebung();
    const lauf = laufen(werte);
    const schritte = [];
    args.forEach((a, i) => {
      if (istName(a)) schritte.push({ takt: 0, art: "ablesen", i, wert: werte[i], name: a.trim(), dauer: 650 });
      schritte.push({ takt: 0, art: "hinein", i, wert: werte[i], dauer: 750 });
    });
    lauf.ereignisse.forEach(e => schritte.push({ takt: 1, art: "lauf", e, dauer: 520 }));
    schritte.push({ takt: 2, art: "fach", rueck: lauf.rueck, ausgaben: lauf.ausgaben, dauer: 400 });
    return { schritte, env, lauf, werte };
  }
  // ein Schritt des Rumpfs als {frage, antwort, gut} (Frage und Antwort sehen verschieden aus) oder {rueck}
  // W11 (Lehrer 24.10.: „noch klarer sehen, dass die Parameter beim Funktionsaufruf durch die Werte ersetzt werden“):
  // in der Frage wird jeder Parameter durch seinen Wert ersetzt -- wie „rechts ablesen“ in Thema 2: der Name
  // durchgestrichen, daneben der Wert in der Farbe seiner Karte. Texte in Anfuehrungszeichen bleiben, wie sie sind.
  function ersetzt(text) {
    const esc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;");
    const werte = plan ? plan.werte : null;
    if (!werte) return esc(text);
    return String(text).split(/("[^"]*"|'[^']*')/).map((teil, j) => j % 2 ? esc(teil) : esc(teil).replace(/[A-Za-z_]\w*/g, w => {
      const i = tisch.sig.parameter.indexOf(w);
      return i < 0 ? w : '<span class="ersetzt' + kl(i) + '"><span class="alt">' + w + '</span><span class="neu">' + esc(zeig(werte[i])) + "</span></span>";
    })).join("");
  }
  function satzTeil(e) {
    if (e.art === "wenn") {
      const k = finde(tisch.baum, e.id);
      return k ? { frage: k.bed + "?", frageHtml: ersetzt(k.bed) + "?", antwort: e.wert ? "ja" : "nein", gut: e.wert } : null;
    }
    if (e.art === "kopf") return { frage: (finde(tisch.baum, e.id) || {}).kopf + "?", antwort: e.wert ? "wahr" : "falsch", gut: e.wert };
    if (e.art === "ende" && e.rueckgabe) return { rueck: "Rückgabe " + zeig(e.wert) };
    return null;
  }
  const satzText = t => !t ? "" : t.rueck ? "→ " + t.rueck : t.frage + " " + t.antwort;
  function satzZeile(t) {
    const li = h("li", t.rueck ? "rueck" : "");
    if (t.rueck) li.append(h("span", "pfeil", "→ "), h("span", "", t.rueck));
    else { const f = h("span", "frage"); f.innerHTML = t.frageHtml || t.frage; li.append(f, h("span", "antwort " + (t.gut ? "ja" : "nein"), t.antwort)); }
    satzEl.append(li);
  }
  function finde(kn, id) {
    for (const k of kn) {
      if (k.id === id) return k;
      const u = (k.rumpf && finde(k.rumpf, id)) || (k.ja && finde(k.ja, id)) || (k.nein && finde(k.nein, id));
      if (u) return u;
    }
    return null;
  }
  // Struktogramm (wenn aufgeklappt) und Python (wenn gezeigt) leuchten gleich: gelb, was dran ist, gruen, was lief,
  // rot eine Frage mit nein (Nadel W5, 24.10.: bis dahin leuchtete Python nur bei aufgeklapptem Innern)
  function leuchten(e) {
    const nein = e.art === "wenn" && !e.wert;
    const svg = innen && bildEl.querySelector("svg");
    if (svg) {
      svg.querySelectorAll(".flaechen > .an").forEach(x => { x.classList.remove("an"); x.classList.add("spur"); });
      const ziel = e.id && svg.querySelector('.flaechen > [data-id="' + e.id + '"]');
      if (ziel) { ziel.classList.remove("spur"); ziel.classList.add(nein ? "falsch" : "an"); }
    }
    pyEl.querySelectorAll(".z.an").forEach(x => { x.classList.remove("an"); x.classList.add("spur"); });
    if (e.id) pyEl.querySelectorAll('.z[data-id="' + e.id + '"]').forEach(x => { x.classList.remove("spur"); x.classList.add(nein ? "falsch" : "an"); });
  }
  async function flug(von, nach, text, klasse) {
    if (!TAKT || sofort || !von || !nach) return;
    const w = wurzel.getBoundingClientRect(), a = von.getBoundingClientRect(), b = nach.getBoundingClientRect();
    const f = h("span", "flug karte" + klasse, text);
    f.style.left = (a.left - w.left) + "px"; f.style.top = (a.top - w.top) + "px";
    wurzel.append(f);
    await new Promise(r => requestAnimationFrame(r));
    f.style.transform = "translate(" + (b.left + b.width / 2 - a.left - f.offsetWidth / 2) + "px," + (b.top + b.height / 2 - a.top - f.offsetHeight / 2) + "px)";
    await schlaf(560);
    f.remove();
  }
  async function eins(s) {
    setzeTakt(s.takt);
    if (s.art === "ablesen") {
      const k = leiste.querySelector('.kasten[data-name="' + s.name + '"]');
      if (k) { k.classList.add("liest"); await schlaf(300); }
      const karte = kartenEl.querySelectorAll(".karte")[s.i];
      karte.querySelector(".abgelesen").textContent = s.name + " →";
      const f = karte.querySelector("input"); f.value = zeig(s.wert); f.size = Math.max(3, f.value.length + 1);
      meldung.textContent = "Karte " + (s.i + 1) + ": Der Wert von " + s.name + " wird abgelesen – " + zeig(s.wert) + ". Das Kästchen draußen behält ihn.";
      if (k) { await schlaf(250); k.classList.remove("liest"); }
    } else if (s.art === "hinein") {
      const karte = kartenEl.querySelectorAll(".karte")[s.i];
      const schlitz = schlitzeEl.querySelectorAll(".schlitz")[s.i];
      karte.classList.add("geist");
      kartenEl.querySelectorAll(".fall")[s.i].classList.add("an");
      await flug(karte, schlitz, zeig(s.wert), kl(s.i));
      const leer = schlitz.querySelector(".leer, .karte"); if (leer) leer.remove();
      schlitz.insertBefore(h("span", "karte" + kl(s.i), zeig(s.wert)), schlitz.querySelector(".zuweisung"));
      schlitz.querySelector(".zuweisung").textContent = tisch.sig.parameter[s.i] + " = " + zeig(s.wert);
      schlitz.classList.remove("fehlt"); schlitz.classList.add("voll");
      anlegenEl.classList.add("an");
      meldung.textContent = "Python legt das Kästchen " + tisch.sig.parameter[s.i] + " an und weist ihm Karte " + (s.i + 1) + " zu: " + tisch.sig.parameter[s.i] + " = " + zeig(s.wert) + ".";
    } else if (s.art === "lauf") {
      leuchten(s.e);
      const t = satzTeil(s.e);
      if (t) satzZeile(t);
      satzEl.classList.add("laeuft");
      meldung.textContent = t ? "Der Rumpf läuft: " + satzText(t) : "Der Rumpf läuft.";
    } else if (s.art === "fach") {
      // der Kasten, der geantwortet hat, bleibt gelb (Attrappe I1: „gelb der Kasten, der antwortet“); die Parameter
      // gibt es nach dem Aufruf nicht mehr -- die Kaestchen verblassen
      rohr.classList.add("an");
      schlitzeEl.querySelectorAll(".schlitz").forEach(x => x.classList.add("weg"));
      anlegenEl.textContent = "Nach dem Aufruf sind die Kästchen wieder weg.";
      const r = s.rueck;
      fach.classList.add(r === "" && tisch.leer ? "wand" : "voll");
      fach.querySelector(".wert").textContent = r === null ? "None" : zeig(r) + (r === "" && tisch.leer ? "  → " + tisch.leer : "");
      if (s.ausgaben.length) fach.querySelector(".shell").textContent = "Shell: " + s.ausgaben.join(" · ");
      meldung.textContent = r === null ? "Der Rumpf ist durch, ohne Rückgabe: Ins Fach fällt None." : "Ins Fach fällt " + zeig(r) + (r === "" && tisch.leer ? " – " + tisch.leer + "." : ".");
      setzeTakt(3);
    }
  }
  function neu() {
    // jede Aenderung (Karte, Tausch, Tisch) raeumt die Maschine ab -- der naechste Lauf beginnt von vorn
    plan = null; pos = 0;
    zeichneKarten(); zeichneVorrat(); zeichneLeiste(); zeichneBild(); zeichnePython();
    satzEl.textContent = ""; satzEl.classList.remove("laeuft");
    anlegenEl.textContent = "Python legt beim Aufruf an:"; anlegenEl.classList.remove("an");
    fach.className = "fach"; fach.innerHTML = '<span class="lbl">Rückgabe</span><span class="wert"> </span><span class="shell"></span>';
    rohr.className = "rohr";
    setzeTakt(-1);
    meldung.className = "meldung"; meldung.textContent = "";
    kTausch.hidden = tisch.sig.parameter.length < 2 || tisch.vorhersagen.length > 0;
    kVor.disabled = kSchritt.disabled = tisch.vorhersagen.length > 0 && !geprueft;
    kZurueck.disabled = true;
  }
  function planHolen() {
    if (plan) return true;
    try { plan = bauePlan(); pos = 0; return true; }
    catch (e) { meldung.className = "meldung falsch"; meldung.textContent = e.message; return false; }
  }
  async function vorfuehren() {
    if (beschaeftigt) return;
    if (plan && pos >= plan.schritte.length) neu();
    if (!planHolen()) return;
    beschaeftigt = true; wurzel.classList.add("laeuft"); sperren(true);
    while (pos < plan.schritte.length) { const s = plan.schritte[pos++]; await eins(s); await schlaf(s.dauer); }
    beschaeftigt = false; wurzel.classList.remove("laeuft"); sperren(false);
  }
  async function schritt() {
    if (beschaeftigt) return;
    if (plan && pos >= plan.schritte.length) neu();
    if (!planHolen()) return;
    beschaeftigt = true; sperren(true);
    await eins(plan.schritte[pos++]);
    beschaeftigt = false; sperren(false);
  }
  async function zurueck() {
    if (beschaeftigt || !plan || !pos) return;
    const p = plan, ziel = pos - 1;
    neu(); plan = p;
    beschaeftigt = true; sofort = true;
    for (let i = 0; i < ziel; i++) await eins(p.schritte[i]);
    pos = ziel; sofort = false; beschaeftigt = false;
    if (!ziel) { plan = null; meldung.textContent = "Zurück am Anfang: Noch ist nichts angelegt."; }
    sperren(false);
  }
  function sperren(an) {
    [kVor, kZurueck, kSchritt, kVorn, kTausch, kInnen, kDr].forEach(b => { b.disabled = an; });
    if (!an) kZurueck.disabled = !plan || !pos;
    if (!an) kVor.disabled = kSchritt.disabled = tisch.vorhersagen.length > 0 && !geprueft;
    kartenEl.querySelectorAll("input").forEach(f => { f.readOnly = an || tisch.vorhersagen.length > 0; });
    vorrat.querySelectorAll("button").forEach(b => { b.disabled = an; });
  }
  async function tauschen() {
    if (beschaeftigt || args.length < 2) return;
    const karten = kartenEl.querySelectorAll(".karte");
    if (TAKT) {
      beschaeftigt = true; sperren(true);
      const a = karten[0].getBoundingClientRect(), b = karten[1].getBoundingClientRect();
      karten[0].style.transform = "translateX(" + (b.left - a.left) + "px)";
      karten[1].style.transform = "translateX(" + (a.left - b.left) + "px)";
      karten[0].classList.add("tauscht"); karten[1].classList.add("tauscht");
      await schlaf(520);
      beschaeftigt = false; sperren(false);
    }
    [args[0], args[1]] = [args[1], args[0]];
    neu();
    meldung.textContent = "Getauscht: Jetzt steht " + args[0] + " auf Platz 1 und " + args[1] + " auf Platz 2.";
  }

  // ─── Tisch Vorhersagen ───────────────────────────────────────────────────────────────
  function zeichneVorhersage() {
    vorh.textContent = "";
    vorh.hidden = !tisch.vorhersagen.length;
    if (!tisch.vorhersagen.length) return;
    const pillen = h("div", "fragen");
    tisch.vorhersagen.forEach((v, i) => {
      const p = h("span", beantwortet[i] === true ? "ok" : beantwortet[i] === false ? "nein" : i === frage ? "jetzt" : "", (i + 1) + " · " + v);
      pillen.append(p);
    });
    const zeile = h("div", "vorhersage");
    zeile.append(h("span", "frage", "Was kommt zurück bei"), h("code", "", tisch.vorhersagen[frage]), h("span", "", "?"));
    const feld = h("input"); feld.placeholder = '"keller"'; feld.spellcheck = false; feld.disabled = geprueft;
    const pruef = h("button", "primaer", "prüfen"); pruef.disabled = geprueft;
    const antwort = h("p", "antwort");
    const weiter = h("button", "", frage + 1 < tisch.vorhersagen.length ? "nächste Frage" : "noch einmal von vorn");
    weiter.hidden = !geprueft;
    pruef.addEventListener("click", () => pruefen(feld.value, antwort));
    feld.addEventListener("keydown", ev => { if (ev.key === "Enter") pruefen(feld.value, antwort); });
    weiter.addEventListener("click", () => {
      if (beschaeftigt) return;
      if (frage + 1 < tisch.vorhersagen.length) frage++; else { frage = 0; beantwortet = []; }
      geprueft = false; aufFrage();
    });
    zeile.append(feld, pruef, weiter);
    vorh.append(h("p", "auftrag", "Erst sagen, dann sehen: Was gibt die Funktion zurück? Schreibt den Wert, wie Python ihn zeigt – Text in Anführungszeichen, ein leerer Text ist \"\"."), pillen, zeile, antwort);
    const richtig = beantwortet.filter(x => x === true).length;
    if (beantwortet.length === tisch.vorhersagen.length && beantwortet.every(x => x !== undefined)) vorh.append(h("p", "meldung " + (richtig === beantwortet.length ? "wahr" : ""), richtig + " von " + beantwortet.length + " richtig vorhergesagt."));
  }
  function pruefen(text, antwort) {
    if (geprueft || beschaeftigt) return;
    let soll, ist;
    try { soll = laufen(werten(args)).rueck; } catch (e) { antwort.className = "antwort falsch"; antwort.textContent = e.message; return; }
    try { ist = K.werten(K.ausdruck(text.trim() || "None"), {}); }
    catch (e) { antwort.className = "antwort falsch"; antwort.textContent = "Das kann die Maschine nicht lesen. Text steht in Anführungszeichen: \"keller\" – ein leerer Text ist \"\"."; return; }
    if (text.trim() === "None") ist = null;
    const gleich = JSON.stringify(ist) === JSON.stringify(soll);
    beantwortet[frage] = gleich; geprueft = true;
    zeichneVorhersage();
    const a = vorh.querySelector(".antwort");
    a.className = "antwort " + (gleich ? "wahr" : "falsch");
    a.textContent = gleich ? "Stimmt. Sieh zu, wie es dazu kommt:" : "Nicht ganz. Sieh zu, wohin die Karten fallen:";
    vorh.querySelector("input").value = text;
    kVor.disabled = kSchritt.disabled = false;
    vorfuehren();
  }
  function aufFrage() {
    args = K.argumente(tisch.vorhersagen[frage]) || [];
    zeichneVorhersage(); neu();
  }

  // ─── Start ───────────────────────────────────────────────────────────────────────────
  function tischStart() {
    tische.forEach(t => t.knopf.classList.toggle("an", t === tisch));
    gewaehlt = 0; frage = 0; beantwortet = []; geprueft = false;
    if (tisch.fehler) {
      [takte, leiste, flaeche, knoepfe, vorh].forEach(e => { e.hidden = true; });
      meldung.className = "meldung falsch"; meldung.textContent = tisch.fehler; return;
    }
    [takte, flaeche, knoepfe].forEach(e => { e.hidden = false; });
    if (tisch.vorhersagen.length) { aufFrage(); return; }
    vorh.hidden = true;
    args = K.argumente(tisch.aufruf) || tisch.sig.parameter.map(() => "");
    while (args.length < tisch.sig.parameter.length) args.push("");
    args = args.slice(0, tisch.sig.parameter.length);
    neu();
  }
  kVor.addEventListener("click", vorfuehren);
  kSchritt.addEventListener("click", schritt);
  kZurueck.addEventListener("click", zurueck);
  kVorn.addEventListener("click", () => { if (beschaeftigt) return; neu(); sperren(false); });
  kTausch.addEventListener("click", tauschen);
  kInnen.addEventListener("click", () => { if (beschaeftigt) return; innen = !innen; const p = plan, q = pos; zeichneBild(); if (p && innen) p.schritte.slice(0, q).filter(s => s.art === "lauf").forEach(s => leuchten(s.e)); });
  kPy.addEventListener("click", () => { python = !python; zeichnePython(); if (plan) plan.schritte.slice(0, pos).filter(s => s.art === "lauf").forEach(s => leuchten(s.e)); });
  kDr.addEventListener("click", () => { if (beschaeftigt) return; draussenAn = !draussenAn; zeichneLeiste(); });
  tischStart();
  return { tische: () => tische.map(t => t.name), args: () => args.slice(), vorfuehren, schritt, tauschen };
};
window.Werkstaetten.funktionsmaschine.einleitung = "Eine Funktion als Maschine: Beim Aufruf legt Python je Parameter ein Kästchen an und legt die Karten (die Argumente) der Reihe nach hinein, die erste in das erste. Dann läuft der Rumpf, und die Antwort fällt ins Fach. Erst vorführen, dann tauschen, dann „als Python zeigen“.";
