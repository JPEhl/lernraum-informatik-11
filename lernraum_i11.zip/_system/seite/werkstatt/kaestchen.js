// Werkstatt "Kaestchen" -- eine Variable als Kaestchen mit Namensschild, darin eine Karte.
// Rolle A (Beschluss 07.10.): erst handeln ohne Code, dann "als Python zeigen" -- dieselben
// Handgriffe als Zuweisungen. Lehrerwahl 15.10.: Kaestchen statt Becher, weil Ablesen nichts
// wegnimmt (b = a kopiert; aus einem Becher gegossen waere er leer).
// Zwei Tische:
//   spielen  -- raum, zuege, punkte aus dem Spiel; jede Zuweisung in drei Takten, und zwar IN DER
//               ZEILE ueber den Kaestchen (Lehrerwahl 15.10., Fassung A -- vorher reiste die Karte
//               in eine Box "rechte Seite" und zurueck, das verwirrte): rechts ablesen (der Name
//               wird in der Zeile durch seinen Wert ersetzt, die Karte bleibt liegen) · ausrechnen
//               (die rechte Seite wird ein Wert) · hinein (er faellt ins Kaestchen, die alte Karte
//               fliegt sichtbar heraus). Ohne Python heisst die Zeile  zuege ← zuege − 1.
//   tauschen -- raum und vorher ("zurueck"): Kaestchen anklicken = Wert abschreiben, dann das
//               Ziel. Mit zwei Kaestchen geht ein Wert verloren; erst dann kommt merk dazu.
//               Ein leeres merk abschreiben = NameError (der haeufigste Fehler in Thema 2).
// Verraet keine Blattloesung: Der Tausch steht nie als fertige Folge da, nur was man selbst tut.
// Einbinden: Werkstaetten.kaestchen(element, {tisch: "spielen" | "tauschen"})
// Mit tisch steht NUR dieser Tisch da, ohne Umschalter (Vortrag, Lehrer 15.10. W1: Schritt 2 und 4
// sahen „fast gleich“ aus); ohne tisch beide (Reiter Werkstatt).
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.kaestchen = function (wurzel, opt) {
  opt = opt || {};
  const RUHIG = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const TAKT = RUHIG ? 0 : 1;
  const START = {
    spielen: [["raum", "flur"], ["zuege", 30], ["punkte", 0]],
    tauschen: [["raum", "keller"], ["vorher", "flur"]],
  };
  let tisch = opt.tisch === "tauschen" ? "tauschen" : "spielen";
  const fest = opt.tisch === "tauschen" || opt.tisch === "spielen";
  let python = false, beschaeftigt = false, auswahl = null, merkFrei = false, schritte = 0;
  let letzte = null;               // die zuletzt ausgefuehrte Zeile {ziel, ausdruck}
  let werte = new Map();           // Name -> Wert (undefined = Kaestchen ohne Wert)
  let protokoll = [];              // je Handgriff {py, ohne}
  let raus = [];                   // die zuletzt herausgeflogenen Karten (Name, Wert)

  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const schlaf = ms => new Promise(r => setTimeout(r, ms * TAKT));
  const zeig = w => w === undefined ? "" : (python && typeof w === "string" ? '"' + w + '"' : String(w));
  const roh = w => typeof w === "string" ? '"' + w + '"' : String(w);

  wurzel.textContent = "";
  wurzel.classList.add("kaestchen");
  const reiter = h("div", "tische");
  const knopfSpielen = h("button", "", "Spielen");
  const knopfTauschen = h("button", "", "Tauschen");
  reiter.append(knopfSpielen, knopfTauschen);
  if (fest) reiter.hidden = true;
  const auftrag = h("p", "auftrag");
  const buehne = h("div", "buehne");
  const reihe = h("div", "reihe");
  const oben = h("div", "oben");
  const zeileEl = h("div", "zeile-gross");
  const takte = h("ol", "takte");
  ["1 · rechts ablesen", "2 · ausrechnen", "3 · hinein"].forEach(t => takte.appendChild(h("li", "", t)));
  oben.append(zeileEl, takte);
  buehne.append(oben, reihe);
  const aktionen = h("div", "aktionen");
  const meldung = h("p", "meldung");
  const herausEl = h("div", "heraus");
  const protokollEl = h("pre", "protokoll"); protokollEl.hidden = true;
  const unten = h("div", "unten");
  const schalter = h("button", "", "als Python zeigen");
  const vonVorn = h("button", "ruhig", "von vorn");
  unten.append(schalter, vonVorn);
  wurzel.append(reiter, auftrag, buehne, aktionen, meldung, herausEl, unten, protokollEl);

  // ─── Zeichnen ───────────────────────────────────────────────────────────────────────
  function kastenEl(name) { return reihe.querySelector('.kasten[data-name="' + name + '"]'); }
  function zeichne() {
    knopfSpielen.classList.toggle("an", tisch === "spielen");
    knopfTauschen.classList.toggle("an", tisch === "tauschen");
    auftrag.textContent = tisch === "spielen"
      ? "Das Spiel merkt sich drei Dinge, je eins in einem Kästchen. Spiel ein paar Züge und sieh zu, was in den Kästchen passiert."
      : "Du gehst zurück: raum und vorher sollen ihre Werte tauschen. Klick erst das Kästchen, dessen Wert abgeschrieben wird, dann das Kästchen, in das er kommt.";
    reihe.textContent = "";
    werte.forEach((w, name) => {
      const k = h("div", "kasten" + (w === undefined ? " leer" : "") + (auswahl === name ? " gewaehlt" : ""));
      k.dataset.name = name;
      k.appendChild(h("span", "schild", name));
      const karte = h("span", "karte" + (typeof w === "string" ? " text" : ""), zeig(w));
      if (w === undefined) karte.classList.add("ohne");
      k.appendChild(karte);
      if (tisch === "tauschen") {
        k.tabIndex = 0; k.setAttribute("role", "button");
        k.title = auswahl ? (auswahl === name ? "Auswahl aufheben" : "hierhin abschreiben") : "diesen Wert abschreiben";
        k.addEventListener("click", () => kastenGeklickt(name));
        k.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); kastenGeklickt(name); } });
      }
      reihe.appendChild(k);
    });
    aktionen.textContent = "";
    if (tisch === "spielen") {
      const z = werte.get("zuege");
      knopf(python ? "zuege = zuege - 1" : "Ein Zug vergeht", () => zuweisen("zuege", ["zuege"], w => w.zuege - 1, "zuege - 1", "Ein Zug vergeht."), z <= 0);
      knopf(python ? "punkte = punkte + 10" : "Etwas finden (+10)", () => zuweisen("punkte", ["punkte"], w => w.punkte + 10, "punkte + 10", "Du findest etwas: 10 Punkte."));
      ["keller", "informatikraum", "flur"].forEach(r => {
        if (werte.get("raum") !== r) knopf(python ? 'raum = "' + r + '"' : "Gehe: " + r, () => zuweisen("raum", [], () => r, '"' + r + '"', "Du gehst: " + r + "."));
      });
      if (z <= 0) knopf(python ? "zuege = 30" : "Neue Lampe", () => zuweisen("zuege", [], () => 30, "30", "Eine neue Lampe: 30 Züge."));
    } else if (merkFrei && !werte.has("merk")) {
      knopf(python ? "merk" : "＋ drittes Kästchen merk", () => { werte.set("merk", undefined); meldung.textContent = "Ein drittes Kästchen, noch leer."; meldung.className = "meldung"; zeichne(); });
    }
    if (!beschaeftigt) {
      if (letzte) zeileBauen(letzte.ziel, letzte.ausdruck);
      else { zeileEl.textContent = tisch === "spielen" ? "Hier steht gleich, was passiert." : "Hier steht gleich, was du tust."; zeileEl.className = "zeile-gross leer"; }
    }
    herausEl.textContent = "";
    if (raus.length) {
      herausEl.appendChild(h("span", "", "herausgeflogen:"));
      raus.forEach(r => herausEl.appendChild(h("span", "alt", zeig(r.wert))));
    }
    protokollEl.hidden = !python;
    protokollEl.textContent = protokoll.map(z => z.py).join("\n");
    protokollEl.scrollTop = 1e6;
    schalter.textContent = python ? "ohne Python" : "als Python zeigen";
    sperren(beschaeftigt);
  }
  function knopf(text, tun, aus) {
    const b = h("button", python ? "code" : "", text);
    b.disabled = !!aus;
    b.addEventListener("click", () => { if (!beschaeftigt) tun(); });
    aktionen.appendChild(b);
  }
  // Waehrend eines Ablaufs ist alles gesperrt; die Aktionsknoepfe baut zeichne() danach neu
  function sperren(an) {
    wurzel.querySelectorAll(".unten button, .tische button").forEach(b => { b.disabled = an; });
    if (an) aktionen.querySelectorAll("button").forEach(b => { b.disabled = true; });
    wurzel.classList.toggle("laeuft", an);
  }
  function melde(text, art) { meldung.textContent = text; meldung.className = "meldung" + (art ? " " + art : ""); }

  // ─── Fliegen ────────────────────────────────────────────────────────────────────────
  function lage(el) { const a = wurzel.getBoundingClientRect(), b = el.getBoundingClientRect(); return { x: b.left - a.left, y: b.top - a.top, w: b.width, h: b.height }; }
  async function flieg(text, von, nach, cls, dauer) {
    const f = h("span", "flug karte" + (cls ? " " + cls : ""), text);
    const v = lage(von);
    f.style.left = v.x + "px"; f.style.top = v.y + "px";
    wurzel.appendChild(f);
    if (TAKT && f.animate) {
      const n = nach ? lage(nach) : { x: v.x + 30, y: v.y - 70 };
      const ziel = nach ? "translate(" + (n.x - v.x) + "px," + (n.y - v.y) + "px)" : "translate(30px,-70px) rotate(-22deg)";
      await f.animate([{ transform: "none", opacity: 1 }, { transform: ziel, opacity: nach ? 1 : 0 }], { duration: dauer, easing: "cubic-bezier(.3,.6,.3,1)", fill: "forwards" }).finished.catch(() => {});
    }
    f.remove();
  }

  // ─── Die Zeile ueber den Kaestchen ──────────────────────────────────────────────────
  // ohne Python: zuege ← zuege − 1 (Text ohne Anfuehrungszeichen); mit: zuege = zuege - 1
  function zeileBauen(ziel, ausdruck) {
    zeileEl.textContent = ""; zeileEl.className = "zeile-gross";
    const r = h("span", "rechts");
    (ausdruck.match(/"[^"]*"|\S+/g) || []).forEach(t => {
      const s = h("span", "tok", python ? t : t === "-" ? "−" : t.replace(/^"(.*)"$/, "$1"));
      if (/^[a-z_]\w*$/i.test(t)) s.dataset.name = t;
      r.appendChild(s);
    });
    zeileEl.append(h("span", "links", ziel), h("span", "gleich", python ? "=" : "←"), r);
    return r;
  }

  // ─── Zuweisen: rechts zuerst, dann hinein ───────────────────────────────────────────
  // ziel = Name links; lesen = Namen rechts; rechne(werte) = Ergebnis; ausdruck = rechte Seite in Python
  async function zuweisen(ziel, lesen, rechne, ausdruck, ohneText) {
    if (beschaeftigt) return;
    for (const n of lesen) {
      if (werte.get(n) === undefined) {
        protokoll.push({ py: ziel + " = " + ausdruck + "    # NameError" }); zeichne();
        zeileBauen(ziel, ausdruck).querySelectorAll('[data-name="' + n + '"]').forEach(t => t.classList.add("fehler"));
        melde(n + " hat noch keinen Wert. In Python bricht das Programm hier ab: NameError: name '" + n + "' is not defined", "fehler");
        return false;
      }
    }
    beschaeftigt = true; zeichne(); melde("");
    const w = Object.fromEntries(werte);
    const ergebnis = rechne(w);
    const li = takte.querySelectorAll("li");
    li.forEach(l => { l.className = ""; });
    const r = zeileBauen(ziel, ausdruck);
    zeileEl.classList.add("aktiv");
    // 1 · rechts ablesen: der Name in der Zeile wird durch seinen Wert ersetzt -- eine Abschrift
    //     steigt aus dem Kaestchen hoch, die Karte darin bleibt liegen
    li[0].className = "jetzt";
    await Promise.all(lesen.map(n => {
      const k = kastenEl(n); k.classList.add("liest");
      const toks = [...r.querySelectorAll('[data-name="' + n + '"]')];
      return flieg(zeig(w[n]), k.querySelector(".karte"), toks[0], "abschrift", 650)
        .then(() => toks.forEach(t => { t.textContent = zeig(w[n]); t.classList.add("wert"); }));
    }));
    reihe.querySelectorAll(".liest").forEach(k => k.classList.remove("liest"));
    await schlaf(lesen.length ? 450 : 200);
    // 2 · ausrechnen: die rechte Seite wird EIN Wert (beim blossen Abschreiben steht er schon da)
    li[0].className = "fertig"; li[1].className = "jetzt";
    const nurAblesen = !lesen.length || ausdruck === lesen[0];
    r.textContent = "";
    const erg = h("span", "tok wert ergebnis", zeig(ergebnis));
    r.appendChild(erg);
    await schlaf(nurAblesen ? 350 : 700);
    // 3 · hinein: der Wert faellt ins Kaestchen links, die alte Karte fliegt heraus
    li[1].className = "fertig"; li[2].className = "jetzt";
    zeileEl.classList.remove("aktiv"); zeileEl.classList.add("hinein");
    const k = kastenEl(ziel), alteKarte = k.querySelector(".karte");
    const alt = werte.get(ziel);
    const wege = [flieg(zeig(ergebnis), erg, alteKarte, "neu", 700)];
    erg.style.visibility = "hidden";
    if (alt !== undefined) { wege.push(flieg(zeig(alt), alteKarte, null, "raus", 750)); alteKarte.style.visibility = "hidden"; }
    await Promise.all(wege);
    werte.set(ziel, ergebnis);
    if (alt !== undefined) { raus.push({ name: ziel, wert: alt }); raus = raus.slice(-4); }
    protokoll.push({ py: ziel + " = " + ausdruck }); schritte++;
    letzte = { ziel, ausdruck };
    li[2].className = "fertig";
    await schlaf(250);
    beschaeftigt = false;
    zeichne();
    if (ohneText && tisch === "spielen") melde(ohneText + (alt !== undefined ? " Der alte Wert " + zeig(alt) + " ist weg." : ""));
    return true;
  }

  // ─── Tauschen ───────────────────────────────────────────────────────────────────────
  async function kastenGeklickt(name) {
    if (beschaeftigt) return;
    if (!auswahl) {
      if (werte.get(name) === undefined) { melde(name + " hat noch keinen Wert. In Python bricht das Programm ab: NameError: name '" + name + "' is not defined", "fehler"); return; }
      auswahl = name; melde("Abschreiben von " + name + " … in welches Kästchen?"); zeichne(); return;
    }
    if (auswahl === name) { auswahl = null; melde(""); zeichne(); return; }
    const quelle = auswahl; auswahl = null;
    await zuweisen(name, [quelle], w => w[quelle], quelle, null);
    pruefeTausch();
  }
  function pruefeTausch() {
    const s = new Map(START.tauschen);
    if (werte.get("raum") === s.get("vorher") && werte.get("vorher") === s.get("raum")) {
      melde("Getauscht – in " + schritte + " Schritten. Du bist zurück: raum ist " + zeig(werte.get("raum")) + ".", "gut"); return;
    }
    const da = new Set(werte.values());
    const weg = [...s.values()].filter(v => !da.has(v));
    if (weg.length) {
      melde(weg.map(v => "„" + v + "“").join(" und ") + " ist weg – kein Kästchen hat es mehr." + (werte.has("merk") ? "" : " Mit zwei Kästchen geht es nicht.") + " Mit „von vorn“ noch einmal.", "fehler");
      if (!merkFrei) { merkFrei = true; zeichne(); }
    }
  }

  // ─── Schalter ───────────────────────────────────────────────────────────────────────
  function neu(t) {
    tisch = t; auswahl = null; raus = []; protokoll = []; schritte = 0;
    werte = new Map(START[t]);
    if (t === "tauschen" && merkFrei) werte.set("merk", undefined);
    melde(""); letzte = null; takte.querySelectorAll("li").forEach(l => l.className = "");
    protokoll.push(...START[t].map(([n, w]) => ({ py: n + " = " + roh(w) })));
    zeichne();
  }
  knopfSpielen.addEventListener("click", () => { if (!beschaeftigt && tisch !== "spielen") neu("spielen"); });
  knopfTauschen.addEventListener("click", () => { if (!beschaeftigt && tisch !== "tauschen") neu("tauschen"); });
  schalter.addEventListener("click", () => { if (beschaeftigt) return; python = !python; zeichne(); });
  vonVorn.addEventListener("click", () => { if (!beschaeftigt) neu(tisch); });

  neu(tisch);
  return { get werte() { return werte; }, get python() { return python; }, protokoll: () => protokoll.map(z => z.py) };
};
window.Werkstaetten.kaestchen.einleitung = "Erst ohne Code: spielen und tauschen, zusehen, was in den Kästchen passiert. Dann „als Python zeigen“.";
