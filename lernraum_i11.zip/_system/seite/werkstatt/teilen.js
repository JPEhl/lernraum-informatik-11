// Werkstatt "Teilen" -- // und % als Bild: Dinge in gleich grosse Gruppen einteilen; // zaehlt die vollen Gruppen,
// % ist, was uebrig bleibt, / rechnet mit Komma. Fuer Thema 8 („Züge und Punkte“, 24.10.), aus der Lehrernotiz im
// Rueckblick T1–T12: „Ein kleines Applet, das z. B. Gruppen von Personen … in gleich große Gruppen einteilt.“
// Lehrerwahl aus drei Attrappen (werkstatt/informatik/planung/teilen_werkstatt/): Fassung A „Gruppen einteilen“,
// vor dem Code (gleich nach der Problemfolie), der Reiter „Werkstatt“ von T8 zeigt sie mit dem Bus-Beispiel der Uebung.
//   * erst vorhersagen (wie viele volle Gruppen, wie viele uebrig?), dann ▸ einteilen: die Dinge fallen der Reihe nach
//     in die Gruppen, der Rest bleibt rot; darunter die drei Rechnungen; die Vorhersage bekommt ✓ oder den Hinweis.
//   * grosse Zahlen (mehr als 60 Dinge) als Becher: jeder Becher eine volle Gruppe, der letzte nur zum Teil.
//   * Sekunden als Uhr (Lehrer 24.10.: „Die Sekunden lieber als Uhr animieren“): der Zeiger laeuft von 0 an, ein Zaehler
//     zaehlt die vollen Runden (//), am Ende steht er beim Rest (%); eine Runde hat k Sekunden.
//   * Busse als Busse (Lehrer 24.10.: „sonst unterscheidet es sich nicht von Gruppen und bringt keinen Mehrwert“): volle
//     Busse mit k Sitzen, der Rest wartet rot an der Haltestelle, daneben ein leerer Bus mit „?“ -- den Schluss „ein Bus
//     mehr“ zieht die Klasse selbst (Uebung T8, Aufgabe 4 fragt genau das; bei 48 wartet niemand).
//   * je Gruppe 0: ZeroDivisionError -- wie im Struktogramm „Durch null teilen“ des Themas.
//   * „als Python zeigen“: die drei print-Zeilen und was die Shell zeigt (kein Kommentar hinter dem Code).
// Optionen: tische='personen|sekunden|busse' (Auswahl und Reihenfolge; ohne: alle drei).
// Einbinden: Werkstaetten.teilen(element, opt)
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.teilen = function (wurzel, opt) {
  opt = opt || {};
  const ALLE = {
    personen: { name: "Personen", n: 23, k: 4, ding: "Personen", je: "je Gruppe", gruppe: "Gruppe", ganz: "volle Gruppen", rest: "übrig", var: ["personen", "je_gruppe"] },
    sekunden: { name: "Sekunden", n: 405, k: 60, ding: "Sekunden", je: "je Minute", gruppe: "Minute", ganz: "volle Minuten", rest: "Sekunden übrig", var: ["sekunden", "je_minute"], uhr: true },
    busse: { name: "Busse", n: 47, k: 12, ding: "Personen", je: "je Bus", gruppe: "Bus", ganz: "volle Busse", rest: "warten noch", var: ["personen", "je_bus"], bus: true },
  };
  const namen = String(opt.tische || "personen|sekunden|busse").split("|").map(x => x.trim()).filter(x => ALLE[x]);
  const tische = (namen.length ? namen : ["personen"]).map(x => Object.assign({}, ALLE[x]));
  let tisch = tische[0], python = false, uhrLauf = 0;
  const RUHIG = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const komma = x => String(Math.round(x * 10000) / 10000);

  wurzel.textContent = "";
  wurzel.classList.add("teilen-ws");
  // die Knoepfe oben (wie bei der Funktionsmaschine: nichts verschiebt sie beim Einteilen)
  const reiter = h("div", "tische");
  const kopf = h("div", "kopfzeile-ws");
  const fN = h("input"); fN.type = "number"; fN.min = 0; fN.max = 9999;
  const fK = h("input"); fK.type = "number"; fK.min = 0; fK.max = 999;
  const lN = h("label", "feld"); const lK = h("label", "feld");
  const kEin = h("button", "primaer", "▸ einteilen");
  const kPy = h("button", "", "als Python zeigen");
  kopf.append(lN, lK, kEin, kPy);
  const vorh = h("div", "vorhersage");
  const vG = h("input"); vG.type = "number"; vG.min = 0; vG.placeholder = "?";
  const vR = h("input"); vR.type = "number"; vR.min = 0; vR.placeholder = "?";
  const lG = h("label", "feld"), lR = h("label", "feld");
  vorh.append(h("span", "frage", "Erst sagen:"), lG, lR);
  const buehne = h("div", "buehne");
  const rechnung = h("div", "rechnung");
  const pyEl = h("pre", "py"); pyEl.hidden = true;
  const meldung = h("p", "meldung");
  wurzel.append(reiter, kopf, vorh, buehne, rechnung, pyEl, meldung);

  tische.forEach(t => { const b = h("button", "", t.name); b.addEventListener("click", () => { tisch = t; start(); }); t.knopf = b; reiter.append(b); });
  reiter.hidden = tische.length < 2;

  function beschriften() {
    lN.textContent = ""; lN.append(document.createTextNode(tisch.ding + " "), fN);
    lK.textContent = ""; lK.append(document.createTextNode(tisch.je + " "), fK);
    lG.textContent = ""; lG.append(document.createTextNode(tisch.ganz + ": "), vG);
    lR.textContent = ""; lR.append(document.createTextNode(tisch.rest.split(" – ")[0] + ": "), vR);
  }
  function leer() {
    uhrLauf++;   // eine laufende Uhr haelt an
    buehne.textContent = ""; rechnung.textContent = ""; meldung.textContent = ""; meldung.className = "meldung";
    buehne.append(h("p", "hinweis-leer", "Erst sagen, dann ▸ einteilen."));
    zeichnePython(false);
  }
  function werte() { return [Math.max(0, Math.min(9999, parseInt(fN.value, 10) || 0)), Math.max(0, Math.min(999, parseInt(fK.value, 10) || 0))]; }
  // Die Uhr: Zifferblatt mit k Schritten je Runde, Zeiger von 0 bis n, Rundenzaehler -- danach die Rechnungen
  function uhr(n, k, fertig) {
    // als Text gesetzt, ohne xmlns -- K5 duldet keine externe Adresse in der Seite (wie die Werkstatt Struktogramm)
    const R = 80, C = 100, f1 = x => x.toFixed(1);
    let striche = "", ziffern = "";
    for (let i = 0; i < 12; i++) { const a = i / 12 * 2 * Math.PI; striche += '<line class="strich" x1="' + f1(C + Math.sin(a) * (R - 6)) + '" y1="' + f1(C - Math.cos(a) * (R - 6)) + '" x2="' + f1(C + Math.sin(a) * R) + '" y2="' + f1(C - Math.cos(a) * R) + '"/>'; }
    [0, 1, 2, 3].forEach(q => { const a = q / 4 * 2 * Math.PI; ziffern += '<text class="ziffer" x="' + f1(C + Math.sin(a) * (R - 22)) + '" y="' + f1(C - Math.cos(a) * (R - 22) + 5) + '">' + Math.round(q * k / 4) + "</text>"; });
    const box = h("div", "uhr-zeile");
    box.innerHTML = '<svg class="uhr" viewBox="0 0 200 200" role="img" aria-label="Uhr"><circle class="blatt" cx="' + C + '" cy="' + C + '" r="' + (R + 10) + '"/>' + striche +
      '<line class="zeiger" x1="' + C + '" y1="' + C + '" x2="' + C + '" y2="' + (C - R + 12) + '"/><circle class="achse" cx="' + C + '" cy="' + C + '" r="6"/>' + ziffern + '</svg>';   // Ziffern ueber dem Zeiger
    const svg = box.querySelector("svg"), zeiger = svg.querySelector(".zeiger");
    const zahl = h("div", "uhr-zahlen");
    const runden = h("span", "u-runden", "Runden: 0"), steht = h("span", "u-steht", "steht bei 0"), zeit = h("span", "uhr-zeit", "0 " + tisch.ding);
    zahl.append(zeit, runden, steht);
    box.append(zahl);
    buehne.append(box);
    const setze = t => {
      const ganz = Math.floor(t / k), rest = Math.floor(t % k);
      zeiger.setAttribute("transform", "rotate(" + (t % k) / k * 360 + " " + C + " " + C + ")");
      runden.textContent = "Runden: " + ganz; steht.textContent = "steht bei " + rest; zeit.textContent = Math.floor(t) + " " + tisch.ding;
      svg.dataset.stand = ganz + "|" + rest;
    };
    const lauf = ++uhrLauf;
    if (RUHIG || !n) { setze(n); fertig(); return; }
    // eine Runde in etwa 0,7 s, hoechstens 5 s fuer alles
    const dauer = Math.min(5000, Math.max(800, n / k * 700)), t0 = performance.now();
    const schritt = jetzt => {
      if (lauf !== uhrLauf) return;
      const f = Math.min(1, (jetzt - t0) / dauer);
      setze(f * n);
      if (f < 1) requestAnimationFrame(schritt); else { setze(n); fertig(); }
    };
    requestAnimationFrame(schritt);
  }
  function einteilen() {
    const [n, k] = werte();
    uhrLauf++;
    buehne.textContent = ""; rechnung.textContent = ""; meldung.className = "meldung";
    if (k === 0) {
      meldung.className = "meldung falsch";
      meldung.textContent = "ZeroDivisionError: integer division or modulo by zero – in Gruppen zu 0 kann man nicht einteilen.";
      zeichnePython(true); return;
    }
    const g = Math.floor(n / k), r = n % k;
    if (tisch.uhr) { uhr(n, k, () => ergebnis(n, k, g, r)); return; }
    if (tisch.bus && g <= 12 && k <= 30) { busse(n, k, g, r); ergebnis(n, k, g, r); return; }
    if (!tisch.becher && n <= 60) {
      let nr = 0;
      const box = h("div", "gruppen");
      for (let i = 0; i <= g; i++) {
        const anz = i < g ? k : r; if (!anz) continue;
        const gr = h("div", "gruppe" + (i < g ? "" : " rest"));
        const leute = h("div", "leute"); leute.style.gridTemplateColumns = "repeat(" + Math.min(anz, k <= 4 ? 2 : Math.ceil(Math.sqrt(k))) + ", 1.6em)";
        for (let j = 0; j < anz; j++) { const p = h("span", "ding"); if (!RUHIG) p.style.animationDelay = (nr++ * 45) + "ms"; leute.append(p); }
        gr.append(leute, h("span", "nr", i < g ? tisch.gruppe + " " + (i + 1) : "übrig"));
        box.append(gr);
      }
      buehne.append(box);
    } else {
      // Becher: jede volle Gruppe ein Becher; mehr als 24 volle -- die ersten 24 und „… weitere“
      const reihe = h("div", "becher-reihe");
      const zeig = Math.min(g, 24);
      for (let i = 0; i < zeig; i++) { const b = h("div", "becher"); const f = h("div", "fuell"); f.style.height = "100%"; if (!RUHIG) f.style.animationDelay = (i * 60) + "ms"; b.append(f, h("span", "z", String(k))); reihe.append(b); }
      if (g > zeig) reihe.append(h("span", "mehr", "… und " + (g - zeig) + " weitere"));
      if (r) { const b = h("div", "becher rest"); const f = h("div", "fuell"); f.style.height = (r / k * 100) + "%"; if (!RUHIG) f.style.animationDelay = (zeig * 60) + "ms"; b.append(f, h("span", "z", String(r))); reihe.append(b); }
      buehne.append(reihe);
    }
    ergebnis(n, k, g, r);
  }
  function busse(n, k, g, r) {
    const reihe = h("div", "bus-reihe");
    let nr = 0;
    const bus = (besetzt, art, schild) => {
      const b = h("div", "bus" + (art ? " " + art : ""));
      const sitze = h("div", "sitze"); sitze.style.gridTemplateColumns = "repeat(" + Math.ceil(k / 2) + ", 1.1em)";
      for (let j = 0; j < k; j++) { const p = h("span", "sitz" + (j < besetzt ? " besetzt" : "")); if (j < besetzt && !RUHIG) p.style.animationDelay = (nr++ * 30) + "ms"; sitze.append(p); }
      b.append(h("span", "schild", schild), sitze, h("span", "rad v"), h("span", "rad h"));
      return b;
    };
    for (let i = 0; i < g; i++) reihe.append(bus(k, "", "Bus " + (i + 1)));
    if (r) {
      const halt = h("div", "haltestelle");
      const leute = h("div", "leute"); leute.style.gridTemplateColumns = "repeat(" + Math.min(r, 6) + ", 1.4em)";
      for (let j = 0; j < r; j++) { const d = h("span", "ding"); if (!RUHIG) d.style.animationDelay = (nr++ * 30) + "ms"; leute.append(d); }
      halt.append(h("span", "nr", "Haltestelle: " + r + " warten"), leute);
      reihe.append(halt, bus(0, "frage", "?"));
    } else reihe.append(h("span", "alle-sitzen", "Alle sitzen – niemand wartet."));
    buehne.append(reihe);
  }
  function ergebnis(n, k, g, r) {
    rechnung.textContent = "";
    rechnung.append(h("span", "r-ganz", n + " // " + k + " = " + g + "  " + tisch.ganz), h("span", "r-rest", n + " % " + k + " = " + r + "  " + tisch.rest), h("span", "r-komma", n + " / " + k + " = " + komma(n / k)));
    // die Vorhersage: nur ein Hinweis, kein Stern
    const sg = vG.value.trim(), sr = vR.value.trim();
    if (sg || sr) {
      const okG = sg === "" || parseInt(sg, 10) === g, okR = sr === "" || parseInt(sr, 10) === r;
      meldung.className = "meldung " + (okG && okR ? "wahr" : "falsch");
      meldung.textContent = okG && okR ? "✓ Stimmt." : "Nicht ganz: " + (!okG ? tisch.ganz + " sind es " + g + ". " : "") + (!okR ? (tisch.rest.split(" – ")[0]) + " bleiben " + r + "." : "");
    }
    zeichnePython(true);
  }
  function zeichnePython(gerechnet) {
    pyEl.hidden = !python;
    kPy.textContent = python ? "Python ausblenden" : "als Python zeigen";
    if (!python) return;
    const [n, k] = werte(), [a, b] = tisch.var;
    const zeilen = [a + " = " + n, b + " = " + k, "print(" + a + " // " + b + ")", "print(" + a + " % " + b + ")", "print(" + a + " / " + b + ")"];
    const shell = !gerechnet ? [] : k === 0 ? ["ZeroDivisionError: integer division or modulo by zero"] : [String(Math.floor(n / k)), String(n % k), komma(n / k)];
    pyEl.textContent = zeilen.join("\n") + "\n\n# Shell:\n" + (shell.length ? shell.join("\n") : "(erst ▸ einteilen)");
  }
  function start() {
    tische.forEach(t => t.knopf.classList.toggle("an", t === tisch));
    beschriften();
    fN.value = tisch.n; fK.value = tisch.k; vG.value = ""; vR.value = "";
    leer();
  }
  kEin.addEventListener("click", einteilen);
  [fN, fK].forEach(f => f.addEventListener("change", leer));
  kPy.addEventListener("click", () => { python = !python; zeichnePython(!!rechnung.textContent || meldung.classList.contains("falsch")); });
  start();
  return { einteilen, tische: () => tische.map(t => t.name) };
};
window.Werkstaetten.teilen.einleitung = "Teilen mit Rest: Erst sagen, wie viele volle Gruppen es gibt und wie viele übrig bleiben – dann einteilen. // zählt die vollen Gruppen, % ist der Rest, / rechnet mit Komma.";
