// Werkstatt "Struktogramm" -- ein Struktogramm laeuft Kasten fuer Kasten, die Variablen stehen als Kaestchen
// daneben. Fuer "Die Spielschleife" (Thema 7) gebaut; seit Thema 10 („Alle auf einmal“, 21.10.) auch die
// Zaehlschleife „für i = a bis b“ (bis schliesst ein, wie im Abitur: wiederhole für i = 0 bis 1439) und
// „für jedes x in liste“, dazu Listen [1, 2], liste[i], liste[i] = … und len(…). Seit Thema 12 („Das Tor,
// das nur redet“, 23.10.) der Kasten „Rückgabe <Ausdruck>“ (LA 2024: „Rückgabe 0“) -- der Wert steht als
// „Rückgabe: …“ in der Ausgabe, und der Lauf endet sofort, auch mitten in einer Schleife. Seit Thema 13
// („Seil, Apfel und Kreide“, 23.10.) Parameter: Heisst der Titel „Algorithmus ziel(raum, richtung)“, steht
// rechts eine Aufrufzeile ziel( … , … ) mit einem Feld je Argument; die Argumente kommen NACH PLATZ in die
// Parameter (das ist der Stolperstein des Themas), Startwerte aus aufruf="ziel(…)" im Thema oder aus dem Fall.
// „als Python zeigen“ setzt dann def ziel(raum, richtung): davor und den Aufruf darunter. Spaeter Zufall.
// Lehrerwahl 19.10. aus drei Attrappen (werkstatt/informatik/planung/struktogramm_werkstatt/): Fassung A
// „Die Lampe wandert“ mit der gruenen Spur aus C, dazu P1 -- also:
//   * Schritt fuer Schritt: gelb der Kasten, der dran ist; gruen, was in diesem Durchlauf schon lief.
//     Der Kopf der Schleife sagt bei jeder Pruefung „wahr: Rumpf“ oder „falsch: weiter“, die Zahl im Rand
//     zaehlt die Durchlaeufe. Genau der Moment, den der Debugger nicht zeigt: Die Bedingung wird OBEN
//     geprueft, bevor der Rumpf laeuft, und nach jedem Durchlauf wieder.
//   * Befehle vorab als Stapel (der naechste leuchtet, verbrauchte sind durchgestrichen) -- ein Lauf laesst
//     sich am Beamer wiederholen, und so sieht die Abiturform „mit gegebenen Eingaben durchlaufen“ aus.
//   * „als Python zeigen“ stellt den Code daneben, die laufende Zeile leuchtet mit (Regel T6: Wird nach
//     einem Bild getippt, steht das Bild neben dem Editor). Keine Tabelle (B), kein Eintippen (C).
// Die Struktogramme sind fest eingebaut (keine freie Eingabe der Klasse), in der Sprache von
// werkstatt/_scripts/struktogramm.py und mit dessen Massen gezeichnet (Abitur: = fuer beides, ∅ als Form,
// Kopfstrich ab dem Einzug, kuerzerer Zweig gestreckt). Das Python entsteht aus dem Struktogramm.
// Verraet keine Blattloesung: Die Analysieren-Aufgabe der Uebung hat hier keinen Reiter.
// BAUKASTEN (Runde 2, Lehrerwahl 19.10.: Fassung A „Kasten waehlen, Leiste darunter“; Attrappen B Ziehen
// und C Plus-in-der-Fuge verworfen): Oben „✎ Bauen | ▸ Laufen lassen“. Klick auf einen Kasten waehlt ihn,
// die Leiste darunter fuegt ein (Anweisung, Schleife, Verzweigung), schiebt (↑ ↓), loescht (✕), ✎ oder
// Doppelklick aendert den Text -- getippt wird in Abitur-Sprache direkt im Kasten. Ein leerer Zweig (∅)
// nimmt etwas auf. Reiter „Eigenes“ (Ort W1): im Browser dieses Rechners gemerkt, nicht abgegeben; die
// eingebauten Struktogramme darf man auch umbauen („↺ Original“ stellt sie wieder her). Was die Werkstatt
// nicht ausrechnen kann, sagt sie beim Bauen; ein Kasten in Worten laeuft als Platzhalter mit.
// Einbinden: Werkstaetten.struktogramm(element, {tisch: "spiel" | "zaehlen" | "endlos"})
// Mit tisch steht NUR dieses Struktogramm da, ohne Umschalter (wie beim Kaestchen); ohne tisch alle.
window.Werkstaetten = window.Werkstaetten || {};
(function () {
  // ─── Kern: Lesen, Zeichnen, Durchlaufen ──────────────────────────────────────────────
  const K = {};
  // Lesen wie struktogramm.py lesen(): Einrueckung je vier Leerzeichen, wiederhole/wenn/sonst
  K.lesen = function (quelle) {
    const zeilen = [];
    quelle.split("\n").forEach(roh => {
      if (!roh.trim() || roh.trim().startsWith("#")) return;
      const tief = roh.length - roh.replace(/^ +/, "").length;
      if (tief % 4) throw new Error("Einrückung kein Vielfaches von vier: " + roh);
      zeilen.push([tief / 4, roh.trim()]);
    });
    let pos = 0, nr = 0;
    function block(stufe) {
      const knoten = [];
      while (pos < zeilen.length) {
        const [s, text] = zeilen[pos];
        if (s < stufe) break;
        if (s > stufe) throw new Error("unerwartet tief: " + text);
        if (text === "sonst") break;
        pos++;
        if (text.startsWith("wiederhole ")) {
          const k = { art: "schleife", id: "k" + nr++, kopf: text.slice(11).trim() };
          k.rumpf = block(stufe + 1); knoten.push(k);
        } else if (text.startsWith("wenn ")) {
          const teile = text.slice(5).split("|").map(t => t.trim());
          // ohne Verhaeltnis („| 1:1“) teilt die Verzweigung ihre Breite nach dem Inhalt der Zweige (auto)
          const k = { art: "wenn", id: "k" + nr++, bed: teile[0], jaText: "ja", neinText: "nein", li: 1, re: 1, auto: !teile.slice(1).some(t => t.includes(":")) };
          teile.slice(1).forEach(t => {
            if (t.startsWith("ja=")) k.jaText = t.slice(3).trim();
            else if (t.startsWith("nein=")) k.neinText = t.slice(5).trim();
            else if (t.includes(":")) { const [a, b] = t.split(":").map(Number); k.li = a; k.re = b; }
          });
          k.ja = block(stufe + 1); k.nein = [];
          if (pos < zeilen.length && zeilen[pos][0] === stufe && zeilen[pos][1] === "sonst") { pos++; k.nein = block(stufe + 1); }
          knoten.push(k);
        } else knoten.push({ art: "anweisung", id: "k" + nr++, text });
      }
      return knoten;
    }
    const baum = block(0);
    if (pos !== zeilen.length) throw new Error("hängengeblieben bei: " + zeilen[pos][1]);
    return baum;
  };

  // (Ohne xmlns: Das SVG steht per innerHTML im HTML, und K5 duldet keine externe Adresse in der Seite.)
  // Zeichnen wie struktogramm.py SvgZeichner (38 px je cm, Schrift 15 px bei skala 1). Jeder Kasten hat
  // eine Flaeche mit data-id (darunter), Striche und Text liegen darueber -- so kann er leuchten.
  K.zeichnen = function (baum, opt) {
    ausgleichen(baum);
    const s = opt.skala || 1, PX = 38 * s;
    const ZEILE = 0.62 * PX, BED = 1.55 * PX, EINZUG = 0.42 * PX, POLSTER = 0.16 * PX, RAND = 6 * s, SCHRIFT = 15 * s;
    const breite = (opt.breite || breiteFuer(baum, opt.titel)) * PX;
    const hoehe = kn => kn.reduce((h, k) => h + (k.art === "anweisung" ? ZEILE
      : k.art === "schleife" ? ZEILE + Math.max(hoehe(k.rumpf), ZEILE)
      : BED + Math.max(hoehe(k.ja), hoehe(k.nein), ZEILE)), 0);
    const oben = RAND + (opt.titel ? SCHRIFT + 8 * s : 0);
    const flaechen = [], striche = [], texte = [], lage = {};
    const f1 = x => x.toFixed(1);
    const rect = (x, y, w, h, extra) => `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}"${extra || ""}/>`;
    const esc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    const textL = (x, y, t) => texte.push(`<text x="${f1(x + POLSTER)}" y="${f1(y)}" dominant-baseline="central">${esc(t)}</text>`);
    const textM = (x, y, t, cls) => texte.push(`<text x="${f1(x)}" y="${f1(y)}" text-anchor="middle" dominant-baseline="central"${cls ? ` class="${cls}"` : ""}>${esc(t)}</text>`);
    function block(kn, x, y, w, hSoll) {
      const extra = hSoll ? Math.max(hSoll - hoehe(kn), 0) : 0;
      kn.forEach((k, i) => {
        const mehr = i === kn.length - 1 ? extra : 0;
        if (k.art === "anweisung") {
          flaechen.push(rect(x, y, w, ZEILE + mehr, ` class="fl" data-id="${k.id}"`));
          striche.push(rect(x, y, w, ZEILE + mehr));
          textL(x, y + ZEILE / 2, k.text);
          lage[k.id] = { x, y, w, h: ZEILE + mehr };
          y += ZEILE + mehr;
        } else if (k.art === "schleife") {
          const hr = Math.max(hoehe(k.rumpf), ZEILE) + mehr;
          // der Kopf ist das umgedrehte L: Balken oben und Rand links leuchten zusammen
          flaechen.push(`<path class="fl" data-id="${k.id}" d="M${f1(x)},${f1(y)}h${f1(w)}v${f1(ZEILE)}H${f1(x + EINZUG)}v${f1(hr)}H${f1(x)}Z"/>`);
          striche.push(rect(x, y, w, ZEILE + hr));
          // der Strich unter dem Kopf beginnt erst am Einzug (kein Querbalken im L, Lehrer 09.09.)
          striche.push(`<line x1="${f1(x + EINZUG)}" y1="${f1(y + ZEILE)}" x2="${f1(x + w)}" y2="${f1(y + ZEILE)}"/>`);
          textL(x, y + ZEILE / 2, k.kopf);
          lage[k.id] = { x, y, w, h: ZEILE, rand: { x, y: y + ZEILE, w: EINZUG, h: hr } };
          if (k.rumpf.length) block(k.rumpf, x + EINZUG, y + ZEILE, w - EINZUG, hr);
          else striche.push(`<line x1="${f1(x + EINZUG)}" y1="${f1(y + ZEILE)}" x2="${f1(x + EINZUG)}" y2="${f1(y + ZEILE + hr)}"/>`);
          y += ZEILE + hr;
        } else {
          const hz = Math.max(hoehe(k.ja), hoehe(k.nein), ZEILE) + mehr;
          const wJa = w * k.li / (k.li + k.re), wNein = w - wJa, unten = y + BED;
          flaechen.push(rect(x, y, w, BED, ` class="fl" data-id="${k.id}"`));
          striche.push(rect(x, y, w, BED));
          striche.push(`<line x1="${f1(x)}" y1="${f1(y)}" x2="${f1(x + wJa)}" y2="${f1(unten)}"/>`, `<line x1="${f1(x + w)}" y1="${f1(y)}" x2="${f1(x + wJa)}" y2="${f1(unten)}"/>`);
          textM(x + w / 2, y + 0.30 * PX, k.bed);
          textM(x + wJa / 2, unten - 0.26 * PX, k.jaText, "zweig");
          textM(x + wJa + wNein / 2, unten - 0.26 * PX, k.neinText, "zweig");
          lage[k.id] = { x, y, w, h: BED };
          [[k.ja, x, wJa, "ja"], [k.nein, x + wJa, wNein, "nein"]].forEach(([inh, sx, sw, z]) => {
            if (inh.length) block(inh, sx, unten, sw, hz);
            else {
              // leerer Zweig: Rahmen und ∅ als Form (U+2205 fehlt in Schriften), keine Linie darin
              const zid = k.id + "." + z, cx = sx + sw / 2, cy = unten + hz / 2, r = 6 * s, d = 8 * s;
              flaechen.push(rect(sx, unten, sw, hz, ` class="fl" data-id="${zid}"`));
              striche.push(rect(sx, unten, sw, hz));
              texte.push(`<g class="leerzeichen"><circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(r)}"/><line x1="${f1(cx - d)}" y1="${f1(cy + d)}" x2="${f1(cx + d)}" y2="${f1(cy - d)}"/></g>`);
              lage[zid] = { x: sx, y: unten, w: sw, h: hz };
            }
          });
          y = unten + hz;
        }
      });
    }
    block(baum, RAND, oben, breite);
    const B = RAND * 2 + breite + (opt.rechts || 0), H = oben + hoehe(baum) + RAND;
    const titel = opt.titel ? `<text class="titel" x="${RAND}" y="${f1(RAND + SCHRIFT - 2)}">${esc(opt.titel)}</text>` : "";
    const svg = `<svg class="strukto" viewBox="0 0 ${B.toFixed(0)} ${H.toFixed(0)}" width="${B.toFixed(0)}" style="--schrift:${SCHRIFT}px" role="img" aria-label="${esc(opt.beschreibung || "Struktogramm " + (opt.titel || ""))}">${titel}<g class="flaechen">${flaechen.join("")}</g><g class="striche">${striche.join("")}</g><g class="texte">${texte.join("")}</g><g class="marken"></g></svg>`;
    return { svg, lage, ZEILE };
  };

  // Ausdruecke in Abitur-Sprache: oder · und · nicht · Vergleich (= ≠ < > ≤ ≥) · + − · * / // % · Zahl,
  // "Text", Name, ( ), seit T10 Liste [a, b], Platz liste[i] und len(…) (die einzige Funktion).
  // Ein = in einer Bedingung vergleicht (wie im Abitur), in einer Anweisung weist es zu.
  function zerlegen(t) {
    const re = /\s*("(?:[^"]*)"|\d+(?:\.\d+)?|\/\/|<=|>=|!=|[=≠<>≤≥+\-−*\/%()\[\],]|[A-Za-zÄÖÜäöüß_][\wÄÖÜäöüß]*)/y;
    const toks = []; let m, pos = 0;
    t = t.trim();
    while (pos < t.length) {
      re.lastIndex = pos;
      if (!(m = re.exec(t))) throw new Error("nicht lesbar: " + t.slice(pos));
      toks.push(m[1]); pos = re.lastIndex;
    }
    return toks;
  }
  // Python in einem Kasten (T6-Regie): die Struktogramm-Sprache sagen -- gleich in plan.py (_python_hinweis)
  const PYTHON_WORT = { and: "und", or: "oder", not: "nicht" };
  function pythonHinweis(toks) {
    toks.forEach((a, i) => {
      if (a === "=" && toks[i + 1] === "=") throw new Error("SyntaxError: Im Struktogramm vergleicht ein einfaches = (nicht ==)");
      if (PYTHON_WORT[a]) throw new Error("SyntaxError: Im Struktogramm heißt es „" + PYTHON_WORT[a] + "“ statt „" + a + "“");
    });
  }
  K.ausdruck = function (text) {
    const toks = zerlegen(text); let i = 0;
    pythonHinweis(toks);
    const sieh = () => toks[i], nimm = () => toks[i++];
    const erwarte = z => { if (nimm() !== z) throw new Error("SyntaxError: hier fehlt „" + z + "“: " + text); };
    function oder() { let a = und(); while (sieh() === "oder") { nimm(); a = { op: "oder", a, b: und() }; } return a; }
    function und() { let a = nicht(); while (sieh() === "und") { nimm(); a = { op: "und", a, b: nicht() }; } return a; }
    function nicht() { if (sieh() === "nicht") { nimm(); return { op: "nicht", a: nicht() }; } return vgl(); }
    function vgl() { let a = summe(); if (["=", "≠", "!=", "<", ">", "≤", "≥", "<=", ">="].includes(sieh())) { const op = nimm(); a = { op, a, b: summe() }; } return a; }
    function summe() { let a = produkt(); while (sieh() === "+" || sieh() === "-" || sieh() === "−") { const op = nimm() === "−" ? "-" : toks[i - 1]; a = { op, a, b: produkt() }; } return a; }
    function produkt() { let a = atom(); while (["*", "/", "//", "%"].includes(sieh())) { const op = nimm(); a = { op, a, b: atom() }; } return a; }
    function atom() {
      const t = nimm();
      if (t === undefined) throw new Error("Ausdruck endet zu früh: " + text);
      if (t === "-" || t === "−") return { op: "-", a: { wert: 0 }, b: atom(), vz: true };   // Vorzeichen: -7 ist 0 - 7 (wie plan.py)
      let a;
      if (t === "(") { a = { op: "klammer", a: oder() }; erwarte(")"); }
      else if (t === "[") {
        const items = [];
        if (sieh() !== "]") { items.push(oder()); while (sieh() === ",") { nimm(); items.push(oder()); } }
        erwarte("]"); a = { op: "liste", items };
      }
      else if (/^"/.test(t)) a = { wert: t.slice(1, -1) };
      else if (/^\d/.test(t)) a = { wert: Number(t) };
      else if (!/^[A-Za-zÄÖÜäöüß_]/.test(t)) throw new Error("SyntaxError: an dieser Stelle fehlt ein Wert oder Name (steht dort „" + t + "“)");
      else if (t === "wahr" || t === "True") a = { wert: true };
      else if (t === "falsch" || t === "False") a = { wert: false };
      else if (sieh() === "(") {
        if (t !== "len") throw new Error("SyntaxError: Die Werkstatt kennt als Funktion nur len(…), nicht „" + t + "(…)“");
        nimm(); a = { op: "aufruf", f: t, a: oder() }; erwarte(")");
      }
      else a = { name: t };
      while (sieh() === "[") { nimm(); a = { op: "index", a, i: oder() }; erwarte("]"); }
      return a;
    }
    const baum = oder();
    if (i < toks.length) throw new Error("übrig: " + toks.slice(i).join(" "));
    return baum;
  };
  // Ausgabe eines Werts -- GLEICH in laufzeit/kursserver/plan.py (zeig): True/False, ganze Zahl ohne „.0“
  // Eine Liste steht wie bei print in Python: ['lampe', 'stick'] (Text in ' ', mit ' darin in " ")
  const inListe = w => typeof w === "string" ? (w.includes("'") && !w.includes('"') ? '"' + w + '"' : "'" + w.replace(/'/g, "\\'") + "'") : K.zeig(w);
  K.zeig = w => typeof w === "boolean" ? (w ? "True" : "False") : Array.isArray(w) ? "[" + w.map(inListe).join(", ") + "]" : String(w);
  // Rechenregeln wie plan.py (der Server rechnet die Proben nach, test/plan_gleichlauf.py vergleicht):
  // Text + Zahl haengt an; Text mit Zahl vergleichen oder rechnen ist ein TypeError; durch 0 ein ZeroDivisionError
  const typFehler = (x, y, op) => { throw new Error("TypeError: " + K.zeig(x) + " und " + K.zeig(y) + " lassen sich nicht mit " + op + " verbinden"); };
  const zahl = w => typeof w === "number";
  const folge = w => Array.isArray(w) || typeof w === "string";
  // = vergleicht Listen Element fuer Element (wie Python), sonst wie ===
  const gleich = (p, q) => Array.isArray(p) && Array.isArray(q) ? p.length === q.length && p.every((x, j) => gleich(x, q[j])) : p === q;
  // Ein Platz in [ ]: ganze Zahl, von hinten mit -1 (wie Python); daneben ein IndexError
  K.platz = function (L, j, schreiben) {
    if (!folge(L)) throw new Error("TypeError: " + K.zeig(L) + " ist keine Liste – [ ] geht nur bei Listen und Text");
    if (!zahl(j) || !Number.isInteger(j)) throw new Error("TypeError: der Platz in [ ] muss eine ganze Zahl sein (steht dort " + K.zeig(j) + ")");
    if (j < -L.length || j >= L.length) throw new Error("IndexError: " + (typeof L === "string" ? "string" : "list") + (schreiben ? " assignment" : "") + " index out of range");
    return j < 0 ? j + L.length : j;
  };
  K.werten = function (a, v) {
    if ("wert" in a) return a.wert;
    if (a.name) { if (!(a.name in v)) throw new Error("NameError: name '" + a.name + "' is not defined"); return v[a.name]; }
    const x = () => K.werten(a.a, v), y = () => K.werten(a.b, v);
    switch (a.op) {
      case "klammer": return x();
      case "oder": return x() || y();
      case "und": return x() && y();
      case "nicht": return !x();
      case "=": return gleich(x(), y());
      case "≠": case "!=": return !gleich(x(), y());
      case "+": { const p = x(), q = y(); return typeof p === "string" || typeof q === "string" ? K.zeig(p) + K.zeig(q) : zahl(p) && zahl(q) ? p + q : Array.isArray(p) && Array.isArray(q) ? p.concat(q) : typFehler(p, q, "+"); }
      case "liste": return a.items.map(e => K.werten(e, v));
      case "index": { const L = x(); return L[K.platz(L, K.werten(a.i, v))]; }
      case "aufruf": { const L = x(); if (!folge(L)) throw new Error("TypeError: len geht nur bei Listen und Text (steht dort " + K.zeig(L) + ")"); return L.length; }
    }
    const p = x(), q = y();
    if (["<", ">", "≤", "≥", "<=", ">="].includes(a.op) && ((typeof p === "string") !== (typeof q === "string") || Array.isArray(p) || Array.isArray(q))) typFehler(p, q, a.op);
    if (["-", "*", "/", "//", "%"].includes(a.op) && !(zahl(p) && zahl(q))) typFehler(p, q, a.op);
    if (["/", "//", "%"].includes(a.op) && q === 0) throw new Error("ZeroDivisionError: division by zero");
    switch (a.op) {
      case "<": return p < q;
      case ">": return p > q;
      case "≤": case "<=": return p <= q;
      case "≥": case ">=": return p >= q;
      case "-": return p - q;
      case "*": return p * q;
      case "/": return p / q;
      case "//": return Math.floor(p / q);
      case "%": return ((p % q) + q) % q;
    }
  };
  // Python dazu: nicht a = b wird a != b (so steht es im Spiel), = im Vergleich wird ==
  // T = Arten der Namen (K.typen): fuer str() bei Text + Zahl
  K.python = function (a, oben, T) {
    T = T || {};
    const py = (x, o) => K.python(x, o, T);
    const P = { oder: 1, und: 2, nicht: 3 };
    if ("wert" in a) return typeof a.wert === "string" ? '"' + a.wert + '"' : a.wert === true ? "True" : a.wert === false ? "False" : String(a.wert);
    if (a.name) return a.name;
    if (a.op === "klammer") return "(" + py(a.a) + ")";
    if (a.op === "liste") return "[" + a.items.map(e => py(e)).join(", ") + "]";
    if (a.op === "index") return py(a.a, 9) + "[" + py(a.i) + "]";
    if (a.op === "aufruf") return a.f + "(" + py(a.a) + ")";
    if (a.vz) return "-" + py(a.b, 4);
    if (a.op === "nicht" && a.a.op === "=") return py(a.a.a) + " != " + py(a.a.b);
    if (a.op === "nicht") return "not " + py(a.a, 3);
    const op = { oder: "or", und: "and", "=": "==", "≠": "!=", "≤": "<=", "≥": ">=" }[a.op] || a.op;
    // Text + Zahl haengt im Struktogramm an („Noch " + zuege + " Züge.“); Python braucht dafuer str()
    // (Thema Worte und Werte) -- sonst stuende in „als Python zeigen“ ein TypeError (T7, 19.10.).
    // str() nur um das, was sicher KEIN Text ist (Zahl, Wahrheitswert, Liste): Seit T10 steht dort auch
    // "  - " + ding, und ding ist ein Text (vorher bekam jeder Name ein str()).
    if (a.op === "+" && K.art(a, T) === "text") {
      const teil = x => { const r = K.art(x, T); return r && r !== "text" ? "str(" + py(x.op === "klammer" ? x.a : x) + ")" : py(x, 0); };
      return teil(a.a) + " + " + teil(a.b);
    }
    const t = py(a.a, P[a.op]) + " " + op + " " + py(a.b, P[a.op]);
    return P[a.op] && oben && oben > P[a.op] ? "(" + t + ")" : t;
  };
  // Die Art eines Ausdrucks, soweit sie sicher ist: "text" · "zahl" · "wahr" · "liste" / "liste text" … · null
  K.art = function (a, T) {
    if ("wert" in a) return typeof a.wert === "string" ? "text" : typeof a.wert === "boolean" ? "wahr" : "zahl";
    if (a.name) return T[a.name] || null;
    switch (a.op) {
      case "klammer": return K.art(a.a, T);
      case "liste": { const e = a.items.map(x => K.art(x, T)); return "liste" + (e.length && e[0] && !e[0].startsWith("liste") && e.every(x => x === e[0]) ? " " + e[0] : ""); }
      case "index": { const r = K.art(a.a, T); return r === "text" ? "text" : r && r.startsWith("liste ") ? r.slice(6) : null; }
      case "aufruf": return "zahl";
      case "+": { const p = K.art(a.a, T), q = K.art(a.b, T); return p === "text" || q === "text" ? "text" : p === "zahl" && q === "zahl" ? "zahl" : null; }
      case "-": case "*": case "/": case "//": case "%": return "zahl";
    }
    return "wahr";
  };
  // Die Arten der Namen aus dem Struktogramm (Zuweisungen, Eingabe, Schleifenkoepfe) und den Startwerten
  // eines Falls. Widersprechen sich zwei Zuweisungen, ist die Art offen (null).
  K.typen = function (baum, werte) {
    const T = {}, wart = w => typeof w === "string" ? "text" : typeof w === "boolean" ? "wahr" : zahl(w) ? "zahl"
      : Array.isArray(w) ? "liste" + (w.length && !Array.isArray(w[0]) && w.every(x => typeof x === typeof w[0]) ? " " + wart(w[0]) : "") : null;
    Object.entries(werte || {}).forEach(([n, w]) => { T[n] = wart(w); });
    const offen = {};
    const setze = (n, r) => { if (!r || offen[n]) return; if (T[n] && T[n] !== r) { T[n] = null; offen[n] = true; } else T[n] = r; };
    const art = t => { try { return K.art(K.ausdruck(t), T); } catch (e) { return null; } };
    for (let runde = 0; runde < 3; runde++) (function block(kn) {
      kn.forEach(k => {
        let m, kp;
        if (k.art === "anweisung") {
          if ((m = k.text.match(/^([a-z_]\w*)\s*=\s*Eingabe\b/i))) setze(m[1], "text");
          else if ((m = k.text.match(/^([a-z_]\w*)\s*=\s*(.+)$/i))) setze(m[1], art(m[2]));
        } else if (k.art === "schleife") {
          try { kp = K.kopf(k.kopf); } catch (e) { kp = null; }
          if (kp && kp.art === "zaehl") setze(kp.name, "zahl");
          if (kp && kp.art === "jedes") { const r = K.art(kp.liste, T); setze(kp.name, r === "text" ? "text" : r && r.startsWith("liste ") ? r.slice(6) : null); }
          block(k.rumpf);
        } else { block(k.ja); block(k.nein); }
      });
    })(baum);
    return T;
  };

  // Der Kopf einer Schleife, drei Arten (T10, 21.10.):
  //   solange <Bedingung>              -> while          (ohne „solange“ gilt der Text als Bedingung)
  //   für i = <a> bis <b>              -> for i in range(a, b + 1)   „bis“ schliesst ein, wie im Abitur
  //   für jedes x in <Liste oder Text> -> for x in liste            (auch jede, jeden, jeder)
  const NAME = "[A-Za-zÄÖÜäöüß_][\\wÄÖÜäöüß]*";
  K.kopf = function (text) {
    const t = String(text).trim(); let m;
    if ((m = t.match(new RegExp("^für\\s+(?:jedes|jeden|jede|jeder)\\s+(" + NAME + ")\\s+in\\s+(.+)$"))))
      return { art: "jedes", name: m[1], liste: K.ausdruck(m[2]), listeText: m[2].trim() };
    if ((m = t.match(new RegExp("^für\\s+(" + NAME + ")\\s*(?:=|von)\\s*(.+?)\\s+bis\\s+(.+)$"))))
      return { art: "zaehl", name: m[1], von: K.ausdruck(m[2]), bis: K.ausdruck(m[3]) };
    if (/^für\b/.test(t)) throw new Error("SyntaxError: Ein Kopf mit „für“ heißt „für i = 0 bis 4“ oder „für jedes ding in rucksack“");
    return { art: "solange", bed: K.ausdruck(t.replace(/^solange\s+/, "")) };
  };
  // range(…) zu „für i = a bis b“: bis b - 1 wird range(b), bis 4 wird range(5), sonst b + 1
  K.range = function (kp, T) {
    let b = kp.bis; while (b.op === "klammer") b = b.a;
    const oben = b.op === "-" && !b.vz && "wert" in b.b && b.b.wert === 1 ? K.python(b.a, 0, T)
      : "wert" in b && zahl(b.wert) ? String(b.wert + 1) : K.python(b, 0, T) + " + 1";
    return "wert" in kp.von && kp.von.wert === 0 ? "range(" + oben + ")" : "range(" + K.python(kp.von, 0, T) + ", " + oben + ")";
  };
  // liste[i] = Wert: der Name, der Platz (Text in [ ]) und die rechte Seite -- oder null
  K.platzZuweisung = function (t) {
    const m = t.match(new RegExp("^(" + NAME + ")\\s*\\["));
    if (!m) return null;
    let tief = 0, j = m[0].length - 1, inText = false;
    for (; j < t.length; j++) {
      const c = t[j];
      if (c === '"') inText = !inText;
      else if (!inText && c === "[") tief++;
      else if (!inText && c === "]" && --tief === 0) break;
    }
    if (j >= t.length) return null;
    const r = t.slice(j + 1).match(/^\s*=(?!=)\s*(.+)$/);
    return r ? { name: m[1], platz: t.slice(m[0].length, j), rechts: r[1] } : null;
  };
  // „Rückgabe <Ausdruck>“ (T12, 23.10.; auch „Rückgabe: …“) -> der Ausdruck als Text, sonst null.
  // Ohne Ausdruck ein Fehler -- gleich in plan.py (rueckgabe); dort schon beim Lesen (Baufehler), hier erst
  // beim Laufen: Ein halb getipptes „Rückgabe“ im Baukasten darf das Gespeicherte nicht wegwerfen (laden()).
  const RUECKGABE = /^Rückgabe(?![\wÄÖÜäöüß])\s*:?\s*(.*)$/;
  K.rueckgabe = function (t) {
    const m = String(t).trim().match(RUECKGABE);
    if (!m) return null;
    if (!m[1].trim()) throw new Error("SyntaxError: Hinter „Rückgabe“ fehlt der Wert, der zurückgegeben wird – z. B. „Rückgabe summe“");
    return m[1].trim();
  };
  // „Algorithmus ziel(raum, richtung)“ (T13, 23.10.) -> {name, parameter: ["raum", "richtung"]}, sonst null.
  // Die Klammer haengt ohne Leerzeichen am Namen: „Algorithmus spiel (grob)“ ist ein Name mit Bemerkung.
  // Gleich in plan.py (signatur) -- dort prueft der Bau Faelle und Aufrufe dagegen.
  const NAME_P = "[A-Za-zÄÖÜäöüß_][\\wÄÖÜäöüß]*";
  const SIGNATUR = new RegExp("^Algorithmus\\s+(" + NAME_P + ")\\(([^()]*)\\)\\s*$");
  K.signatur = function (titel) {
    const m = String(titel || "").trim().match(SIGNATUR);
    if (!m) return null;
    const p = m[2].trim() ? m[2].split(",").map(x => x.trim()) : [];
    return p.every(x => new RegExp("^" + NAME_P + "$").test(x)) ? { name: m[1], parameter: p } : null;
  };
  // „ziel("flur", "westen")“ -> ['"flur"', '"westen"']: die Argumente als Text, getrennt an den Kommas der
  // obersten Ebene (nicht in Listen, Klammern, Texten). Ohne Klammer: null.
  K.argumente = function (aufruf) {
    const t = String(aufruf || "").trim(), a = t.indexOf("(");
    if (a < 0 || !t.endsWith(")")) return null;
    const innen = t.slice(a + 1, -1), teile = [];
    let tief = 0, text = null, akt = "";
    for (const c of innen) {
      if (text) { if (c === text) text = null; akt += c; continue; }
      if (c === '"' || c === "'") { text = c; akt += c; continue; }
      if ("([".includes(c)) tief++;
      if (")]".includes(c)) tief--;
      if (c === "," && tief === 0) { teile.push(akt.trim()); akt = ""; continue; }
      akt += c;
    }
    if (akt.trim() || teile.length) teile.push(akt.trim());
    return teile;
  };
  const ganz = (w, wo) => { if (!zahl(w) || !Number.isInteger(w)) throw new Error("TypeError: „für … bis“ braucht ganze Zahlen (" + wo + ": " + K.zeig(w) + ")"); return w; };

  // Durchlaufen: ein Generator, der VOR jedem Kasten anhaelt.
  //   {art: "anweisung"|"kopf"|"wenn"|"leer"|"warte"|"ende", id, wert?, durchlauf?}
  // Nach einer Rückgabe kommt sofort {art: "ende", id: der Rückgabe-Kasten, rueckgabe: true, wert} -- ohne
  // die Schleifenkoepfe und Kaesten, die sonst noch kaemen (welt.rueckgabe traegt den Wert).
  // welt = {v: Variablen, eingaben: [...], ausgaben: [...]}; aktionen: Text eines Kastens in Worten -> Wirkung
  K.lauf = function* (baum, welt, aktionen) {
    const v = welt.v, zaehler = {}, RUECK = {};
    let rk = null;
    function* block(kn) {
      for (const k of kn) {
        if (k.art === "anweisung") {
          yield { art: "anweisung", id: k.id };
          const t = k.text; let m;
          if ((m = t.match(/^Ausgabe:\s*(.*)$/))) welt.ausgaben.push(K.zeig(K.werten(K.ausdruck(m[1]), v)));
          else if ((m = K.rueckgabe(t)) !== null) {
            welt.rueckgabe = K.werten(K.ausdruck(m), v);
            welt.ausgaben.push("Rückgabe: " + K.zeig(welt.rueckgabe));
            rk = k.id; throw RUECK;       // durch alle Schleifen und Verzweigungen hindurch bis ans Ende
          }
          else if ((m = t.match(/^([a-z_]\w*)\s*=\s*Eingabe\b/i))) {
            while (!welt.eingaben.length) yield { art: "warte", id: k.id };
            v[m[1]] = welt.eingaben.shift(); welt.gelesen++;
          } else if ((m = t.match(/^([a-z_]\w*)\s*=\s*(.+)$/i))) v[m[1]] = K.werten(K.ausdruck(m[2]), v);
          else if ((m = K.platzZuweisung(t))) {
            if (!(m.name in v)) throw new Error("NameError: name '" + m.name + "' is not defined");
            const L = v[m.name];
            if (typeof L === "string") throw new Error("TypeError: In einem Text lässt sich kein Zeichen ersetzen");
            const j = K.platz(L, K.werten(K.ausdruck(m.platz), v), true);
            L[j] = K.werten(K.ausdruck(m.rechts), v);
          }
          else if (aktionen && aktionen[t]) aktionen[t](v, welt);
        } else if (k.art === "schleife") {
          const kp = K.kopf(k.kopf);
          zaehler[k.id] = 0;
          if (kp.art === "solange") {
            for (;;) {
              const w = !!K.werten(kp.bed, v);
              yield { art: "kopf", id: k.id, wert: w, durchlauf: zaehler[k.id] + (w ? 1 : 0) };
              if (!w) break;
              zaehler[k.id]++;
              yield* block(k.rumpf);
            }
          } else {
            // für: die Grenzen einmal am Anfang (wie range), die Liste beim Laufen (wie Python: wer
            // in der Schleife an der Liste aendert, aendert, was noch kommt -- „Lege alles!“)
            let a, b, L;
            if (kp.art === "zaehl") { a = ganz(K.werten(kp.von, v), "von"); b = ganz(K.werten(kp.bis, v), "bis"); }
            else { L = K.werten(kp.liste, v); if (!folge(L)) throw new Error("TypeError: „für jedes“ läuft nur über eine Liste oder einen Text (steht dort " + K.zeig(L) + ")"); }
            for (let j = 0; ; j++) {
              const w = kp.art === "zaehl" ? a + j <= b : j < L.length;
              if (w) v[kp.name] = kp.art === "zaehl" ? a + j : L[j];
              yield { art: "kopf", id: k.id, wert: w, durchlauf: zaehler[k.id] + (w ? 1 : 0), fuer: kp.art, name: kp.name, element: w ? v[kp.name] : undefined };
              if (!w) break;
              zaehler[k.id]++;
              yield* block(k.rumpf);
            }
          }
        } else {
          const w = !!K.werten(K.ausdruck(k.bed), v);
          yield { art: "wenn", id: k.id, wert: w };
          const zweig = w ? k.ja : k.nein;
          if (zweig.length) yield* block(zweig);
          else yield { art: "leer", id: k.id + (w ? ".ja" : ".nein") };
        }
      }
    }
    try { yield* block(baum); }
    catch (e) { if (e !== RUECK) throw e; yield { art: "ende", id: rk, rueckgabe: true, wert: welt.rueckgabe }; return; }
    yield { art: "ende" };
  };
  // Das Struktogramm als Python, eine Zeile je Kasten (Kopf und if je eine)
  // aufruf (T13): {name, parameter, argumente} -- dann steht der Rumpf eingerueckt unter def name(…):
  // und darunter der Aufruf (mit print, wenn der Algorithmus etwas zurueckgibt)
  K.alsPython = function (baum, aktionen, werte, aufruf) {
    const zeilen = [], T = K.typen(baum, werte);
    const py = (t, roh) => { try { return K.python(K.ausdruck(t), 0, T); } catch (e) { return roh != null ? roh : t; } };
    const kopf = t => {
      let kp; try { kp = K.kopf(t); } catch (e) { return "while " + t + ":"; }
      return kp.art === "zaehl" ? "for " + kp.name + " in " + K.range(kp, T) + ":"
        : kp.art === "jedes" ? "for " + kp.name + " in " + K.python(kp.liste, 0, T) + ":"
        : "while " + K.python(kp.bed, 0, T) + ":";
    };
    function block(kn, tief) {
      kn.forEach(k => {
        if (k.art === "anweisung") {
          const t = k.text; let m;
          let p;
          if ((m = t.match(/^Ausgabe:\s*(.*)$/))) p = "print(" + py(m[1]) + ")";
          else if ((m = (() => { try { return K.rueckgabe(t); } catch (e) { return ""; } })()) !== null) p = m ? "return " + py(m) : "return";
          else if ((m = t.match(/^([a-z_]\w*)\s*=\s*Eingabe\b/i))) p = m[1] + ' = input("> ")';
          else if ((m = t.match(/^([a-z_]\w*)\s*=\s*(.+)$/i))) p = m[1] + " = " + py(m[2]);
          else if ((m = K.platzZuweisung(t))) p = m.name + "[" + py(m.platz) + "] = " + py(m.rechts);
          else p = (aktionen && aktionen[t] && aktionen[t].python) || "# " + t;
          zeilen.push({ id: k.id, text: p, tief });
        } else if (k.art === "schleife") {
          zeilen.push({ id: k.id, text: kopf(k.kopf), tief });
          block(k.rumpf, tief + 1);
        } else {
          zeilen.push({ id: k.id, text: "if " + py(k.bed) + ":", tief });
          if (k.ja.length) block(k.ja, tief + 1); else zeilen.push({ id: k.id + ".ja", text: "pass", tief: tief + 1 });
          if (k.nein.length) { zeilen.push({ id: k.id + ".sonst", text: "else:", tief }); block(k.nein, tief + 1); }
        }
      });
    }
    if (!aufruf) { block(baum, 0); return zeilen; }
    zeilen.push({ id: "", text: "def " + aufruf.name + "(" + aufruf.parameter.join(", ") + "):", tief: 0 });
    block(baum, 1);
    if (!baum.length) zeilen.push({ id: "", text: "pass", tief: 1 });
    if (aufruf.argumente) {
      const gibt = zeilen.some(z => /^return\b/.test(z.text));
      const a = aufruf.name + "(" + aufruf.argumente.map(x => py(x)).join(", ") + ")";
      zeilen.push({ id: "", text: "", tief: 0 }, { id: "", text: gibt ? "print(" + a + ")" : a, tief: 0 });
    }
    return zeilen;
  };

  // Baum -> Text in der Sprache von struktogramm.py (fuer „Eigenes“, das Speichern und spaeter die Abgabe)
  K.schreiben = function (baum) {
    const z = [];
    (function block(kn, tief) {
      const e = "    ".repeat(tief);
      kn.forEach(k => {
        if (k.art === "anweisung") z.push(e + (k.text || "…"));
        else if (k.art === "schleife") { z.push(e + "wiederhole " + (k.kopf || "solange …")); block(k.rumpf, tief + 1); }
        else {
          z.push(e + "wenn " + (k.bed || "…") + (k.auto ? "" : " | " + k.li + ":" + k.re));
          block(k.ja, tief + 1);
          if (k.nein.length) { z.push(e + "sonst"); block(k.nein, tief + 1); }
        }
      });
    })(baum, 0);
    return z.join("\n");
  };
  // Ids neu vergeben (Vorordnung wie lesen()) -- nach jedem Umbau; gibt id -> {knoten, liste, index} zurueck
  K.nummern = function (baum) {
    const wo = {}; let nr = 0;
    (function block(kn) {
      kn.forEach((k, i) => {
        k.id = "k" + nr++; wo[k.id] = { k, liste: kn, i };
        if (k.art === "schleife") block(k.rumpf);
        else if (k.art === "wenn") { block(k.ja); block(k.nein); wo[k.id + ".ja"] = { leer: k.ja, wenn: k }; wo[k.id + ".nein"] = { leer: k.nein, wenn: k }; }
      });
    })(baum);
    return wo;
  };

  // ─── Die Struktogramme ─────────────────────────────────────────────────────────────
  // Spielschleife: der reparierte Plan aus dem Drehbuch T7 (abenteuer/planung/drehbuch_t07/struktogramme/
  // repariert.txt) -- nach der Schleife zuerst das Tor, sonst wenn zuege = 0 die Lampe, sonst nichts:
  // ende sagt seinen Satz schon im Zug. Darum liegt ende jetzt im Stapel (bis 19.10. nicht: die Skizze
  // las nach ende „Die Lampe geht aus.“).
  // „einen Zug ausführen“ ist ein Kasten in Worten -- er antwortet mit den Texten des Spiels (Stand nach
  // Thema 7, kurz wie auf den Folien) und merkt sich, was getragen wird (welt.traegt, am Anfang die Lampe):
  // ohne Lampe ist schau stockdunkel. Er gilt in jedem Struktogramm, auch im eigenen; jeder andere Kasten
  // in Worten laeuft als Platzhalter mit. DIESELBEN TEXTE in laufzeit/kursserver/plan.py (_zug) --
  // test/plan_gleichlauf.py laesst diesen Kasten selbst laufen.
  const RAUM_TEXT = { flur: "Der Flur. Nur deine Lampe leuchtet.", informatikraum: "Der Informatikraum. 24 Rechner schlafen.",
    lehrerzimmer: "Das Lehrerzimmer. Es riecht nach altem Kaffee.", keller: "Der Keller. Rohre, Staub, ein Schacht im Boden.",
    tor: "Das Haupttor. Draußen ist Nacht." };
  // Die Wege wie im Spiel (Lageplan, ohne Schlüssel): bis 25.10. kannte der Zug „gehe tor“, einen Befehl,
  // den es im Spiel nie gab (Reihensichtung Teil I).
  const RICHTUNGEN = ["norden", "osten", "süden", "westen"];
  const WEGE = { flur: { norden: "tor", osten: "informatikraum", "süden": "lehrerzimmer", westen: "keller" },
    informatikraum: { westen: "flur" }, lehrerzimmer: { norden: "flur" }, keller: { osten: "flur" } };
  const zug = Object.assign(function (v, welt) {
    const e = String(v.eingabe == null ? "" : v.eingabe), aus = welt.ausgaben;
    const traegt = welt.traegt || (welt.traegt = ["lampe"]);
    if (e === "ende") aus.push("Du setzt dich auf die Treppe und wartest auf den Morgen.");
    else if (RICHTUNGEN.includes(e)) {
      const ziel = (WEGE[v.raum] || {})[e];
      if (!ziel) aus.push("Da ist eine Wand.");
      else { v.raum = ziel; aus.push(ziel === "tor" ? "Du schließt das Tor auf." : "Du stehst jetzt im " + ziel + "."); }
    } else if (e.startsWith("nimm ")) { const d = e.slice(5).trim(); traegt.push(d); aus.push("Du nimmst: " + d); }
    else if (e.startsWith("lege ")) {
      const d = e.slice(5).trim(), i = traegt.indexOf(d);
      if (i < 0) aus.push("Das hast du nicht."); else { traegt.splice(i, 1); aus.push("Du legst weg: " + d); }
    } else if (e === "schau") {
      if (!traegt.includes("lampe")) aus.push("Stockdunkel. Du siehst nicht einmal, wo du die Lampe hingelegt hast.");
      else aus.push(RAUM_TEXT[v.raum] || "Du siehst dich um.");
    } else if (e === "hilfe") aus.push("Befehle: norden, osten, süden, westen, schau, nimm <ding>, lege <ding>, hilfe, ende");
    else aus.push("Das verstehe ich nicht. Tippe hilfe.");
  }, { python: "# einen Zug ausführen" });
  const AKTIONEN = { "einen Zug ausführen": zug };
  const BEFEHLE = ["schau", "nimm lampe", "norden", "ende"];
  const TISCHE = {
    spiel: { name: "Spielschleife", titel: "Algorithmus spiel (grob)", befehle: BEFEHLE,
      auftrag: "Das Spiel grob, als Struktogramm. Klick „Schritt“ und sag vorher, welcher Kasten als Nächstes leuchtet. Die Befehle rechts kommen der Reihe nach in eingabe.", quelle:
`zuege = 30
raum = "flur"
eingabe = ""
wiederhole solange zuege > 0 und nicht raum = "tor" und nicht eingabe = "ende"
    eingabe = Eingabe des Befehls
    zuege = zuege - 1
    einen Zug ausführen
wenn raum = "tor" | 2:3
    Ausgabe: "Du stehst draußen."
sonst
    wenn zuege = 0 | 3:1
        Ausgabe: "Die Lampe geht aus."
    sonst` },
    zaehlen: { name: "Zählen", titel: "Algorithmus countdown",
      auftrag: "Wie oft läuft der Rumpf? Erst vorhersagen, dann Schritt für Schritt nachsehen.", quelle:
`zuege = 3
wiederhole solange zuege > 0
    Ausgabe: zuege
    zuege = zuege - 1
Ausgabe: "Die Lampe geht aus."` },
    endlos: { name: "Endlos?", titel: "Algorithmus flur",
      auftrag: "Dasselbe noch einmal – fast. Lass es laufen. Wann geht die Lampe aus?", quelle:
`zuege = 30
wiederhole solange zuege > 0
    Ausgabe: "Du gehst weiter."
Ausgabe: "Die Lampe geht aus."` },
    // Baukasten (Lehrerwahl 19.10., Runde 2: Fassung A, Ort W1): das eigene Struktogramm, im Browser
    // dieses Rechners gemerkt, nicht abgegeben (die Abgabe kommt mit der Aufgabenart, W2)
    eigenes: { name: "Eigenes", titel: "Algorithmus mein_plan", eigen: true, befehle: BEFEHLE,
      auftrag: "Dein eigenes Struktogramm: Klick einen Kasten an – die Leiste darunter fügt etwas ein, verschiebt oder löscht. Doppelklick ändert den Text. Dann „▸ Laufen lassen“.",
      quelle: "…" },
  };
  const SCHILD_WERT = 14;  // so viele Zeichen eines Werts im Schild am für-Kopf, dann „…“ (die Meldung sagt ihn ganz)
  const kurz = t => t.length > SCHILD_WERT ? t.slice(0, SCHILD_WERT - 1) + "…" : t;
  const GRENZE = 60;      // „läuft allein“ haelt nach so vielen Durchlaeufen an (die Endlosschleife; bei 120 ms je Schritt gut 20 s)
  const SKALA = 1.15, RECHTS = 135;
  const SPEICHER = "lernraum-struktogramm-eigenes";
  // Breite in cm aus dem laengsten Text (≈ 0,47 em je Zeichen bei 15 px, wie struktogramm.py), mindestens 9
  // Breite in Zeichen, die ein Block braucht (Verzweigung: jeder Zweig nach SEINEM Anteil, nicht doppelt --
  // so wurde eine Treppe aus zwei Verzweigungen 24 cm breit und schrumpfte in der Uebung auf Fussnotengroesse)
  function zeichen(kn) {
    return Math.max(3, ...kn.map(k => k.art === "anweisung" ? k.text.length
      : k.art === "schleife" ? Math.max((k.kopf || "").length, 2.4 + zeichen(k.rumpf))
      : Math.max((k.bed || "").length * 1.15, (k.ja.length ? zeichen(k.ja) : 3) * (k.li + k.re) / k.li, (k.nein.length ? zeichen(k.nein) : 3) * (k.li + k.re) / k.re)));
  }
  function breiteFuer(baum, titel) {
    const n = Math.max(zeichen(baum), (titel || "").length * 0.85);
    return Math.max(9, Math.min(24, (n * 15 * 0.5 + 16) / 38 + 0.3));     // 0,5 em je Zeichen: mit 0,48 lag der Text am Rand
  }
  // Im Baukasten entstandene Verzweigungen (auto) teilen ihre Breite nach dem Inhalt ihrer Zweige
  function ausgleichen(kn) {
    kn.forEach(k => {
      if (k.art === "schleife") ausgleichen(k.rumpf);
      else if (k.art === "wenn") { ausgleichen(k.ja); ausgleichen(k.nein); if (k.auto) { k.li = Math.max(zeichen(k.ja), 6); k.re = Math.max(zeichen(k.nein), 6); } }
    });
  }
  const lesbar = t => { try { K.ausdruck(t); return true; } catch (e) { return false; } };

  window.Werkstaetten.struktogramm = function (wurzel, opt) {
    opt = opt || {};
    // Struktogramme aus dem Thema (Lehrerwahl ④, 19.10.): opt.quelle = EIN Struktogramm eines Vortragsschritts
    // (dann nur dieser Tisch), opt.struktogramme = die des ganzen Themas fuer den Reiter (vor „Eigenes“).
    // befehle="schau|norden" legt den Stapel fest; ohne Angabe gibt es ihn, sobald ein Eingabe-Kasten da ist.
    const TI = {};
    const ausThema = (e, i) => ({ name: e.name || "Thema", titel: e.algorithmus || "Algorithmus", quelle: e.quelle, auftrag: e.auftrag || "",
      befehle: e.befehle ? String(e.befehle).split("|").map(x => x.trim()).filter(Boolean) : BEFEHLE, aufruf: e.aufruf || "" });
    Object.entries(TISCHE).forEach(([k, t]) => { if (k !== "eigenes") TI[k] = t; });
    (opt.struktogramme || []).forEach((e, i) => { TI["thema" + i] = ausThema(e); });
    TI.eigenes = TISCHE.eigenes;
    if (opt.quelle && !opt.entwurf) { TI.vortrag = ausThema(opt); opt = Object.assign({}, opt, { tisch: "vortrag" }); }
    // Plan einer Aufgabe (Aufgabenart „Plan“, 19.10.): EIN Tisch, die Quelle kommt aus dem Stand, jede Aenderung
    // geht an opt.aendern(quelle, titel) (die Uebung speichert sie), „Neu“ faengt mit opt.start wieder an.
    // opt.proben: die Faelle der Aufgabe -- „Laufen lassen“ startet mit den Startwerten des gewaehlten Falls.
    if (opt.entwurf) {
      TI.entwurf = { name: "Plan", titel: opt.algorithmus || "Algorithmus", quelle: opt.quelle || opt.start || "…", start: opt.start || "…", entwurf: true, auftrag: "",
        befehle: BEFEHLE };
      opt = Object.assign({}, opt, { tisch: "entwurf" });
    }
    const PROBEN = opt.proben || [];
    let fall = 0;
    const RUHIG = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
    const fest = Object.prototype.hasOwnProperty.call(TI, opt.tisch || "");
    let tisch = fest ? opt.tisch : opt.struktogramme && opt.struktogramme.length ? "thema0" : "spiel";
    let python = false, bauen = false, baum, titel, wo = {}, welt, it, ev, spur, laeufer = null, befehle = [], aktuell = null, alt = {};
    let gewaehlt = null, rueck = [], geaendert = false;

    const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
    const zeig = w => typeof w === "string" ? '"' + w + '"' : K.zeig(w);     // Kaestchen wie Ausgabe: True/False
    wurzel.textContent = "";
    wurzel.classList.add("strukto-ws");
    const kopfzeile = h("div", "kopfzeile-ws");
    const reiter = h("div", "tische");
    const reiterKnoepfe = Object.entries(TI).map(([k, t]) => { const b = h("button", "", t.name); b.addEventListener("click", () => { if (tisch !== k) { tisch = k; laden(); } }); reiter.appendChild(b); return [k, b]; });
    if (fest) reiter.hidden = true;
    const modus = h("div", "bau-modus");   // nicht „modus“: so heisst schon das Schild tippen/aufdecken am Codeschritt
    const mBauen = h("button", "", "✎ Bauen"), mLaufen = h("button", "", "▸ Laufen lassen");
    modus.append(mBauen, mLaufen);
    kopfzeile.append(reiter, modus);
    const auftrag = h("p", "auftrag");
    const flaeche = h("div", "flaeche");
    const bildEl = h("div", "bild");
    const pyEl = h("pre", "py"); pyEl.hidden = true;
    const bildReihe = h("div", "bildreihe"); bildReihe.append(bildEl, pyEl);
    const knoepfe = h("div", "knoepfe");
    const kZurueck = h("button", "", "◂ zurück");   // Lehrer 24.10. (T13 W10): jede Werkstatt, die schrittweise laeuft, kann zurueck
    const kSchritt = h("button", "primaer", "Schritt ▸");
    const kKopf = h("button", "", "bis zum Schleifenkopf ▸▸");
    const kAllein = h("button", "", "läuft allein");
    const kVorn = h("button", "ruhig", "von vorn");
    const kRueck = h("button", "", "↶ rückgängig");
    const kNeu = h("button", "ruhig", "Neu");
    const kPython = h("button", "", "als Python zeigen");
    knoepfe.append(kZurueck, kSchritt, kKopf, kAllein, kVorn, kRueck, kNeu, kPython);
    let gemacht = 0;   // Schritte seit dem Start des Laufs -- „◂ zurück“ laeuft von vorn bis einen davor (der Lauf ist bestimmt)
    const meldung = h("p", "meldung");
    const links = h("div", "links"); links.append(bildReihe, knoepfe, meldung);
    const seite = h("div", "seite-spalte");
    const befehlTeil = h("div", "teil befehle-teil");
    const befehlListe = h("div", "befehle");
    const befehlFeld = h("input"); befehlFeld.placeholder = "＋ Befehl"; befehlFeld.size = 12; befehlFeld.setAttribute("aria-label", "Befehl dazulegen");
    befehlTeil.append(h("p", "etikett", "Befehle der Reihe nach"), befehlListe, befehlFeld);
    const kastenTeil = h("div", "teil"); const kaestchenEl = h("div", "kaestchen-reihe");
    kastenTeil.append(h("p", "etikett", "Kästchen"), kaestchenEl);
    const ausgabeTeil = h("div", "teil"); const ausgabeEl = h("pre", "ausgabe");
    ausgabeTeil.append(h("p", "etikett", "Ausgabe"), ausgabeEl);
    const fallTeil = h("div", "teil fall-teil");
    if (PROBEN.length) {
      const wahl = h("select"); wahl.setAttribute("aria-label", "Mit welchem Fall laufen");
      PROBEN.forEach((p, i) => { const o = h("option", "", (p.zeigen || []).map(z => z[0] === "Befehle" ? z[1] : z[1]).join(" · ") || "Fall " + (i + 1)); o.value = String(i); wahl.appendChild(o); });
      wahl.addEventListener("change", () => { fall = +wahl.value; befehle = fallBefehle(); argumente = startArgumente(); neuerLauf(); });
      fallTeil.append(h("p", "etikett", "Laufen mit dem Fall"), wahl);
    } else fallTeil.hidden = true;
    // Aufruf (T13): je Parameter ein Feld, die Werte kommen nach Platz hinein
    const aufrufTeil = h("div", "teil aufruf-teil"); const aufrufEl = h("div", "aufruf");
    aufrufTeil.append(h("p", "etikett", "Aufruf"), aufrufEl);
    let argumente = null, aufrufFehler = "";
    seite.append(fallTeil, aufrufTeil, befehlTeil, kastenTeil, ausgabeTeil);
    flaeche.append(links, seite);
    wurzel.append(kopfzeile, auftrag, flaeche);

    befehlFeld.addEventListener("keydown", e => {
      if (e.key !== "Enter") return;
      const t = befehlFeld.value.trim().toLowerCase(); if (!t) return;
      befehle.push(t); welt.eingaben.push(t); befehlFeld.value = "";
      if (ev && ev.art === "warte") melde("Befehl liegt bereit – weiter mit „Schritt“.");
      zeichneSeite();
    });
    function melde(t, art) { meldung.textContent = t; meldung.className = "meldung" + (art ? " " + art : ""); }

    // ─── Laden, Speichern ────────────────────────────────────────────────────────────
    function laden() {
      const T = TI[tisch];
      let q = T.quelle; titel = T.titel;
      if (T.eigen) {
        try { const g = JSON.parse(localStorage.getItem(SPEICHER) || "null"); if (g && g.quelle) { q = g.quelle; titel = g.titel || titel; } } catch (e) { /* ohne Speicher: leer anfangen */ }
      }
      try { baum = K.lesen(q); } catch (e) { baum = K.lesen("…"); }
      rueck = []; gewaehlt = null; geaendert = false;
      bauen = (!!T.eigen || !!T.entwurf) && K.schreiben(baum) === K.schreiben(K.lesen(T.start || "…"));   // ein leeres Eigenes (ein unberuehrter Plan) beginnt im Bauen
      if (T.entwurf && opt.titel) titel = opt.titel;
      befehle = fallBefehle();     // je Tisch (und Fall) sein Stapel; „von vorn“ behaelt dazugelegte
      argumente = startArgumente();
      reiterKnoepfe.forEach(([k, b]) => b.classList.toggle("an", k === tisch));
      auftrag.textContent = T.auftrag; auftrag.hidden = !T.auftrag;
      neuerLauf();
    }
    // Die Argumente zum Start: aus dem Fall (Werte der Parameter, als Ausdruck geschrieben), sonst aus
    // aufruf="name(…)" im Thema, sonst leer -- je Parameter ein Text
    function startArgumente() {
      const sig = K.signatur(titel); if (!sig) return null;
      const F = PROBEN[fall];
      if (F && F.werte && sig.parameter.every(p => p in F.werte)) return sig.parameter.map(p => K.python(K.ausdruck(literal(F.werte[p]))));
      const a = K.argumente(TI[tisch].aufruf || opt.aufruf || "");
      return a && a.length === sig.parameter.length ? a : sig.parameter.map(() => "");
    }
    function literal(w) { return typeof w === "string" ? JSON.stringify(w) : Array.isArray(w) ? "[" + w.map(literal).join(", ") + "]" : K.zeig(w); }
    function zeichneAufruf() {
      const sig = K.signatur(titel);
      aufrufTeil.hidden = !sig; aufrufEl.textContent = "";
      if (!sig) return;
      if (!argumente || argumente.length !== sig.parameter.length) argumente = startArgumente();
      aufrufEl.append(h("code", "", sig.name + "("));
      sig.parameter.forEach((p, i) => {
        if (i) aufrufEl.append(h("code", "", ", "));
        const f = h("input"), breit = () => { f.size = Math.max(4, p.length + 1, f.value.length + 1); }; f.value = argumente[i]; breit();
        f.placeholder = p; f.title = "kommt in " + p; f.setAttribute("aria-label", "Argument " + (i + 1) + ", kommt in den Parameter " + p);
        f.addEventListener("input", breit);
        f.addEventListener("change", () => { argumente[i] = f.value.trim(); neuerLauf(); });
        aufrufEl.append(f);
      });
      aufrufEl.append(h("code", "", ")"));
    }
    function fallBefehle() { const F = PROBEN[fall]; return (F && F.eingaben && F.eingaben.length ? F.eingaben : (TI[tisch].befehle || [])).slice(); }
    function speichern() {
      if (TI[tisch].entwurf) { if (opt.aendern) opt.aendern(K.schreiben(baum), titel); return; }
      if (!TI[tisch].eigen) { geaendert = true; return; }
      try { localStorage.setItem(SPEICHER, JSON.stringify({ titel, quelle: K.schreiben(baum) })); } catch (e) { /* privat: nur fuer diese Sitzung */ }
    }
    function merken() { rueck.push(JSON.stringify({ titel, quelle: K.schreiben(baum) })); if (rueck.length > 50) rueck.shift(); }

    // ─── Laufen ──────────────────────────────────────────────────────────────────────
    function neuerLauf() {
      stopp();
      // mit Faellen: die Startwerte und Befehle des gewaehlten Falls (sonst NameError bei hat_ausweis)
      const F = PROBEN[fall];
      // tief kopiert: Eine Liste im Fall darf ein Lauf aendern (liste[i] = …), der naechste beginnt frisch
      welt = { v: JSON.parse(JSON.stringify(F ? F.werte : {})), eingaben: befehle.slice(), ausgaben: [], gelesen: 0 };
      // die Argumente nach Platz in die Parameter (T13) -- ein falsch geschriebenes stoppt den Lauf vor dem ersten Kasten
      aufrufFehler = "";
      const sig = K.signatur(titel);
      if (sig && argumente) {
        sig.parameter.forEach((p, i) => {
          if (aufrufFehler) return;
          if (!argumente[i]) { aufrufFehler = "Für den Parameter " + p + " fehlt im Aufruf noch ein Wert."; return; }
          try { welt.v[p] = K.werten(K.ausdruck(argumente[i]), {}); }
          catch (e) { aufrufFehler = "Den Wert für " + p + " kann die Werkstatt nicht lesen: „" + argumente[i] + "“ – " + e.message; }
        });
      }
      it = K.lauf(baum, welt, AKTIONEN); ev = null; spur = []; aktuell = null; alt = {}; gemacht = 0;
      melde(bauen ? "" : aufrufFehler || "Noch nichts gelaufen. „Schritt“ beginnt oben.", aufrufFehler && !bauen ? "fehler" : "");
      zeichneAufruf(); zeichneBild(); zeichne();
    }
    function schritt() {
      if (bauen) return false;
      if (aufrufFehler) { melde(aufrufFehler, "fehler"); return false; }
      if (ev && ev.art === "ende") return false;
      alt = JSON.parse(JSON.stringify(welt.v));
      let r;
      try { r = it.next(); }
      catch (e) { melde("Hier bricht es ab: " + e.message, "fehler"); ev = { art: "ende", fehler: true }; zeichne(); return false; }
      ev = r.done ? { art: "ende" } : r.value;
      gemacht++;
      if (ev.art === "kopf") { spur = []; aktuell = ev.durchlauf; }
      if (ev.id && ev.art !== "warte" && spur[spur.length - 1] !== ev.id) spur.push(ev.id);   // das Ende nach einer Rückgabe traegt die id ihres Kastens
      erklaere(); zeichne();
      return ev.art !== "ende" && ev.art !== "warte";
    }
    function eingabeKasten(id) { const w = wo[id]; return !!(w && w.k && w.k.art === "anweisung" && /^[a-z_]\w*\s*=\s*Eingabe\b/i.test(w.k.text)); }
    function erklaere() {
      if (ev.art === "kopf" && ev.fuer === "zaehl") melde(ev.wert ? ev.name + " bekommt den Wert " + K.zeig(ev.element) + " – der Rumpf läuft (" + ev.durchlauf + ". Durchlauf)." : ev.name + " hat alle Werte durchlaufen – es geht unter der Schleife weiter (" + ev.durchlauf + " Durchläufe).", ev.wert ? "wahr" : "falsch");
      else if (ev.art === "kopf" && ev.fuer === "jedes") melde(ev.wert ? ev.name + " bekommt " + (ev.durchlauf === 1 ? "das erste" : "das nächste") + " Element: " + zeig(ev.element) + " – der Rumpf läuft (" + ev.durchlauf + ". Durchlauf)." : "Kein Element mehr – es geht unter der Schleife weiter (" + ev.durchlauf + " Durchläufe).", ev.wert ? "wahr" : "falsch");
      else if (ev.art === "kopf") melde(ev.wert ? "Die Bedingung ist wahr – der Rumpf läuft (" + ev.durchlauf + ". Durchlauf)." : "Die Bedingung ist falsch – es geht unter der Schleife weiter (" + ev.durchlauf + " Durchläufe).", ev.wert ? "wahr" : "falsch");
      else if (ev.art === "wenn") melde("Die Bedingung ist " + (ev.wert ? "wahr – der ja-Zweig läuft." : "falsch – der nein-Zweig läuft."), ev.wert ? "wahr" : "falsch");
      else if (ev.art === "warte") melde("Der Stapel ist leer. Leg einen Befehl dazu, dann weiter mit „Schritt“.", "fehler");
      else if (ev.art === "ende" && ev.rueckgabe) melde("Zurückgegeben: " + zeig(ev.wert) + " – der Algorithmus endet hier, was danach käme, läuft nicht mehr." + (aktuell != null ? " Die Schleife lief " + aktuell + "-mal." : ""), "gut");
      else if (ev.art === "ende") melde("Fertig." + (aktuell != null ? " Die Schleife lief " + aktuell + "-mal." : ""), "gut");
      else if (eingabeKasten(ev.id) && welt.eingaben.length) melde("Der nächste Befehl kommt in eingabe.");
      else if (wo[ev.id] && wo[ev.id].k && RUECKGABE.test(wo[ev.id].k.text.trim())) melde("Eine Rückgabe: Der Wert wird ausgerechnet und zurückgegeben – danach endet der Algorithmus.");
      else if (wo[ev.id] && wo[ev.id].k && wortKasten(wo[ev.id].k.text)) melde("Ein Kasten in Worten – er läuft als Platzhalter mit, ohne etwas zu ändern.");
      else melde("");
    }
    function wortKasten(t) { return !/^Ausgabe:/.test(t) && !RUECKGABE.test(t.trim()) && !/^[a-z_]\w*\s*=/i.test(t) && !K.platzZuweisung(t) && !AKTIONEN[t]; }

    // ─── Zeichnen ────────────────────────────────────────────────────────────────────
    let lage = {}, vb = 1;
    function zeichneBild() {
      wo = K.nummern(baum);
      // Platz rechts nur fuer das Schild am Schleifenkopf -- ohne Schleife druckte er das Bild nur zusammen (Plan-Feld 19.10.)
      const mitSchleife = JSON.stringify(baum).includes('"schleife"');
      // ein für-Kopf traegt den Wert im Schild (◂ ding = "kreide") -- dafuer so viel Platz wie das laengste
      // Schild braucht (Probe T10: mit RECHTS allein war es abgeschnitten)
      let rechts = mitSchleife ? RECHTS : 0;
      Object.values(K.nummern(baum)).forEach(w => {
        if (!w.k || w.k.art !== "schleife") return;
        let kp; try { kp = K.kopf(w.k.kopf); } catch (e) { return; }
        if (kp.art !== "solange") rechts = Math.max(rechts, (2 + kp.name.length + 3 + (kp.art === "zaehl" ? 4 : SCHILD_WERT + 3)) * 8.4 + 18 + 16);
      });
      const z = K.zeichnen(baum, { breite: breiteFuer(baum, titel), titel, skala: opt.skala || SKALA, rechts, beschreibung: "Struktogramm " + titel });
      bildEl.innerHTML = z.svg; lage = z.lage;
      vb = Number(bildEl.querySelector("svg").getAttribute("width"));
      pyEl.textContent = "";
      let zeilen;
      const sig = K.signatur(titel);
      try { zeilen = K.alsPython(baum, AKTIONEN, PROBEN[fall] && PROBEN[fall].werte, sig && Object.assign({ argumente }, sig)); } catch (e) { zeilen = [{ id: "", text: "# (eine Bedingung ist noch nicht lesbar)", tief: 0 }]; }
      zeilen.forEach(zl => { const s = h("span", "z", "    ".repeat(zl.tief) + zl.text); s.dataset.id = zl.id; pyEl.appendChild(s); });
      // Bauen: Kaesten anklickbar, der Titel auch
      const svg = bildEl.querySelector("svg");
      svg.querySelectorAll(".flaechen > *").forEach(f => {
        f.addEventListener("click", ev2 => { if (!bauen) return; ev2.stopPropagation(); waehle(f.dataset.id); });
        f.addEventListener("dblclick", ev2 => { if (!bauen) return; ev2.stopPropagation(); waehle(f.dataset.id); bearbeite(); });
      });
      const t = svg.querySelector(".titel");
      if (t) t.addEventListener("click", () => { if (bauen) titelBearbeiten(); });
    }
    function zeichne() {
      const svg = bildEl.querySelector("svg"), marken = svg.querySelector(".marken");
      marken.textContent = "";
      svg.querySelectorAll(".flaechen > *").forEach(f => f.setAttribute("class", "fl"));
      const fl = id => svg.querySelector('.flaechen [data-id="' + id + '"]');
      bildEl.querySelectorAll(".leiste-bau, .text-im-kasten").forEach(e => { if (!e.contains(document.activeElement)) e.remove(); });
      wurzel.classList.toggle("baut", bauen);
      if (bauen) {
        if (gewaehlt && fl(gewaehlt)) { const c = fl(gewaehlt).cloneNode(); c.setAttribute("class", "rahmen-wahl"); marken.appendChild(c); leiste(); }
      } else {
        spur.slice(0, -1).forEach(id => { const f = fl(id); if (f) f.classList.add("spur"); });
        const id = ev && ev.id;
        if (id) {
          const f = fl(id);
          if (f) { f.classList.add(ev.art === "kopf" && !ev.wert ? "falsch" : "an"); const c = f.cloneNode(); c.setAttribute("class", "rahmen"); marken.appendChild(c); }
          if (ev.art === "kopf" && lage[id]) {
            // für: das Schild sagt, welchen Wert die Schleifenvariable jetzt hat
            const L = lage[id], text = ev.fuer ? (ev.wert ? "◂ " + ev.name + " = " + kurz(zeig(ev.element)) : "◂ fertig: weiter")
              : ev.wert ? "◂ wahr: Rumpf" : "◂ falsch: weiter", w = text.length * 8.4 + 18;
            marken.insertAdjacentHTML("beforeend", `<g class="chip ${ev.wert ? "wahr" : "falsch"}"><rect x="${L.x + L.w + 8}" y="${L.y + 3}" width="${w}" height="${L.h - 6}" rx="${(L.h - 6) / 2}"/><text x="${L.x + L.w + 8 + w / 2}" y="${L.y + L.h / 2}" text-anchor="middle" dominant-baseline="central">${text}</text></g>`);
          }
        }
        // Durchlauf-Zaehler im Rand der Schleife, die gerade laeuft (die aeusserste mit Kopf in der Spur)
        const sch = baum.find(k => k.art === "schleife");
        if (sch && aktuell && lage[sch.id]) {
          const R = lage[sch.id].rand, cx = R.x + R.w / 2, cy = R.y + 17;
          marken.insertAdjacentHTML("beforeend", `<g class="zaehler"><circle cx="${cx}" cy="${cy}" r="14"/><text x="${cx}" y="${cy + 1}" text-anchor="middle" dominant-baseline="central"${aktuell > 9 ? ' class="klein"' : ""}>${aktuell > 9 ? aktuell : aktuell + "."}</text></g>`);
        }
      }
      pyEl.querySelectorAll(".z").forEach(z => {
        const id = bauen ? gewaehlt : ev && ev.id;
        z.className = "z" + (id && z.dataset.id === id ? " an" : !bauen && spur.slice(0, -1).includes(z.dataset.id) ? " spur" : "");
      });
      zeichneSeite();
      const fertig = ev && ev.art === "ende", hatSchleife = !!JSON.stringify(baum).includes('"schleife"');
      mBauen.classList.toggle("an", bauen); mLaufen.classList.toggle("an", !bauen);
      [kZurueck, kSchritt, kKopf, kAllein, kVorn].forEach(k => { k.hidden = bauen; });
      kZurueck.disabled = !gemacht || !!laeufer;
      [kRueck, kNeu].forEach(k => { k.hidden = !bauen; });
      kRueck.disabled = !rueck.length;
      kNeu.textContent = TI[tisch].eigen || TI[tisch].entwurf ? "Neu" : "↺ Original";
      kNeu.disabled = !TI[tisch].eigen && !TI[tisch].entwurf && !geaendert;
      kSchritt.disabled = fertig; kKopf.disabled = fertig || !hatSchleife; kAllein.disabled = fertig && !laeufer;
      kKopf.hidden = bauen || !hatSchleife;
      kAllein.textContent = laeufer ? "■ anhalten" : "läuft allein";
      kAllein.classList.toggle("stopp", !!laeufer);
      kPython.textContent = python ? "ohne Python" : "als Python zeigen";
      pyEl.hidden = !python;
      wurzel.classList.toggle("mit-python", python);
      seite.hidden = bauen;
    }
    function zeichneSeite() {
      const T = TI[tisch];
      befehlTeil.hidden = !(T.befehle && JSON.stringify(baum).includes("Eingabe"));
      befehlListe.textContent = "";
      const wartet = ev && ev.art === "warte";
      const amEingabeKasten = ev && ev.art === "anweisung" && eingabeKasten(ev.id);
      befehle.forEach((b, i) => {
        const z = h("div", "zeile");
        const verbraucht = i < welt.gelesen;
        const naechster = i === welt.gelesen && amEingabeKasten;
        z.appendChild(h("span", "befehl" + (verbraucht ? " weg" : naechster ? " naechster" : ""), b));
        if (naechster) z.appendChild(h("span", "pfeil", "→ eingabe"));
        if (!verbraucht) {
          const x = h("button", "weg-knopf", "×"); x.title = "Befehl wegnehmen";
          x.addEventListener("click", () => { befehle.splice(i, 1); welt.eingaben.splice(i - welt.gelesen, 1); zeichneSeite(); });
          z.appendChild(x);
        }
        befehlListe.appendChild(z);
      });
      befehlFeld.classList.toggle("wartet", !!wartet);
      kaestchenEl.textContent = "";
      Object.entries(welt.v).forEach(([n, w]) => {
        const k = h("div", "kasten" + (JSON.stringify(alt[n]) !== JSON.stringify(w) ? " neu" : ""));
        k.dataset.name = n;
        k.append(h("span", "schild", n), h("span", "karte", zeig(w)));
        kaestchenEl.appendChild(k);
      });
      if (!kaestchenEl.childNodes.length) kaestchenEl.appendChild(h("span", "leer", "noch keine"));
      ausgabeEl.textContent = welt.ausgaben.join("\n");
      ausgabeEl.scrollTop = 1e6;
    }

    // ─── Bauen (Lehrerwahl 19.10., Runde 2: Fassung A „Kasten waehlen, Leiste darunter“) ─────────
    // Die Leiste fuegt UNTER dem gewaehlten Kasten ein; ein leerer Zweig (∅) nimmt etwas auf. Ein neuer
    // Kasten ist sofort offen zum Tippen. Eine Schleife bekommt gleich einen Kasten in den Rumpf (ein
    // Rumpf ist nie leer), eine Verzweigung zwei leere Zweige.
    const skala = () => { const s = bildEl.querySelector("svg"); return s ? s.getBoundingClientRect().width / vb : 1; };
    function ueber(el, L) {
      const s = skala(), svg = bildEl.querySelector("svg"), a = bildEl.getBoundingClientRect(), b = svg.getBoundingClientRect();
      el.style.left = (b.left - a.left + L.x * s) + "px"; el.style.top = (b.top - a.top + L.y * s) + "px";
      if (L.w != null) el.style.width = (L.w * s) + "px"; if (L.h != null) el.style.height = (L.h * s) + "px";
      bildEl.appendChild(el); return el;
    }
    // ein Klick waehlt immer (nicht umschalten: nach dem Tippen ist der Kasten noch gewaehlt, ein zweiter Klick
    // haette die Leiste wieder weggenommen); aufheben mit Klick daneben oder Escape
    function waehle(id) { gewaehlt = id; zeichne(); }
    function leiste() {
      const w = wo[gewaehlt], L = lage[gewaehlt]; if (!w || !L) return;
      const l = h("div", "leiste-bau");
      const kn = (t, tu, titelText, cls) => { const b = h("button", cls || "", t); if (titelText) b.title = titelText; b.addEventListener("click", e => { e.stopPropagation(); tu(); }); l.appendChild(b); return b; };
      l.appendChild(h("span", "lbl", w.leer ? "hinein:" : "darunter:"));
      kn("＋ Anweisung", () => einfuegen("anweisung"));
      kn("＋ Schleife", () => einfuegen("schleife"), "solange …");
      kn("＋ für … bis", () => einfuegen("schleife", "für i = 0 bis "), "Zählschleife: für i = 0 bis …");
      kn("＋ für jedes", () => einfuegen("schleife", "für jedes x in "), "für jedes x in einer Liste");
      kn("＋ Verzweigung", () => einfuegen("wenn"));
      kn("＋ Rückgabe", () => einfuegen("anweisung", "Rückgabe "), "Rückgabe …: gibt einen Wert zurück, danach endet der Algorithmus");
      if (!w.leer) {
        l.appendChild(h("span", "trenn"));
        kn("✎", bearbeite, "Text ändern (oder Doppelklick)");
        kn("↑", () => schiebe(-1), "nach oben").disabled = w.i === 0;
        kn("↓", () => schiebe(1), "nach unten").disabled = w.i === w.liste.length - 1;
        kn("✕", loesche, "löschen", "rot");
      }
      const unten = w.leer ? L.y + L.h : unterkante(w.k);
      ueber(l, { x: L.x + 12, y: unten + 6 });
      // seit „＋ Rückgabe“ (T12) ist die Leiste breiter als die Vortragsspalte (860 px): dann bricht sie
      // innerhalb der Werkstatt um, statt ueber den Rand zu ragen
      const platz = wurzel.getBoundingClientRect().right - l.getBoundingClientRect().left - 8;
      if (platz > 0 && l.getBoundingClientRect().width > platz) { l.style.flexWrap = "wrap"; l.style.width = "max-content"; l.style.maxWidth = platz + "px"; }
    }
    // die Unterkante eines Kastens samt allem, was in ihm steckt (Leiste „darunter“ sitzt unter dem Ganzen)
    function unterkante(k) {
      const L = lage[k.id];
      if (k.art === "anweisung") return L.y + L.h;
      if (k.art === "schleife") return L.rand.y + L.rand.h;
      return Math.max(...["ja", "nein"].map(z => k[z].length ? Math.max(...k[z].map(unterkante)) : lage[k.id + "." + z].y + lage[k.id + "." + z].h));
    }
    function neuerKnoten(art, kopf) {
      if (art === "anweisung") return { art, text: kopf || "" };     // „＋ Rückgabe“ legt die Vorlage „Rückgabe “ hin
      if (art === "schleife") return { art, kopf: kopf || "solange ", rumpf: [{ art: "anweisung", text: "…" }] };
      return { art: "wenn", bed: "", jaText: "ja", neinText: "nein", li: 1, re: 1, ja: [], nein: [], auto: true };
    }
    function einfuegen(art, kopf) {
      const w = wo[gewaehlt]; if (!w) return;
      merken();
      const k = neuerKnoten(art, kopf); k.frisch = true;    // Einfuegen + erstes Tippen = EIN Schritt fuers Rueckgaengig
      if (w.leer) w.leer.push(k); else w.liste.splice(w.i + 1, 0, k);
      umgebaut(); gewaehlt = k.id; zeichne(); bearbeite();
    }
    function schiebe(d) {
      const w = wo[gewaehlt]; const j = w.i + d; if (j < 0 || j >= w.liste.length) return;
      merken(); const k = w.liste.splice(w.i, 1)[0]; w.liste.splice(j, 0, k);
      umgebaut(); gewaehlt = k.id; zeichne();
    }
    function loesche() {
      const w = wo[gewaehlt]; if (!w || w.leer) return;
      if (w.liste === baum && baum.length === 1) { melde("Ein Struktogramm braucht mindestens einen Kasten.", "fehler"); return; }
      if (w.liste.length === 1 && w.liste !== baum && istRumpf(w.liste)) { melde("Eine Schleife braucht mindestens einen Kasten im Rumpf – lösch die Schleife oder ändere den Text.", "fehler"); return; }
      merken(); w.liste.splice(w.i, 1); gewaehlt = null; umgebaut(); zeichne();
    }
    function istRumpf(liste) { return Object.values(wo).some(x => x.k && x.k.art === "schleife" && x.k.rumpf === liste); }
    function umgebaut() { speichern(); neuerLauf(); }
    // Text im Kasten: ein Eingabefeld genau ueber dem Kasten (Schleife: ueber dem Kopf, Verzweigung: ueber der Bedingung)
    function bearbeite() {
      const w = wo[gewaehlt]; if (!w || w.leer) return;
      const k = w.k, L = lage[gewaehlt], z = lage[gewaehlt];
      const feld = h("input", "text-im-kasten");
      const feldWert = k.art === "anweisung" ? (k.text === "…" ? "" : k.text) : k.art === "schleife" ? k.kopf : k.bed;
      feld.value = feldWert;
      feld.placeholder = k.art === "anweisung" ? "z. B. zuege = zuege - 1" : k.art === "schleife" ? "solange … · für i = 0 bis … · für jedes x in …" : "Bedingung, z. B. raum = \"tor\"";
      const box = k.art === "wenn" ? { x: z.x + z.w * 0.15, y: z.y + 2, w: z.w * 0.7, h: 0.62 * 38 * SKALA } : { x: L.x, y: L.y, w: L.w, h: L.h > 40 * SKALA ? 0.62 * 38 * SKALA : L.h };
      bildEl.querySelectorAll(".leiste-bau").forEach(e => e.remove());
      ueber(feld, box);
      // eine neue für-Schleife oder Rückgabe: die Vorlage bleibt stehen, weiter geht es hinter ihr
      feld.focus(); if (k.frisch && /^(für|Rückgabe) /.test(feldWert)) feld.setSelectionRange(feldWert.length, feldWert.length); else feld.select();
      let fertig = false;
      const ab = (uebernehmen) => {
        if (fertig) return; fertig = true;
        let t = feld.value.replace(/\|/g, "").replace(/\s+/g, " ").trim();
        feld.remove();
        const frisch = k.frisch; delete k.frisch;
        // Escape bei einem gerade eingefuegten Kasten bricht das Einfuegen ganz ab
        if (!uebernehmen) { if (frisch) { const r = rueck.pop(); const g = JSON.parse(r); titel = g.titel; baum = K.lesen(g.quelle); gewaehlt = null; speichern(); neuerLauf(); } else zeichne(); return; }
        if (k.art === "anweisung" && /^(wiederhole|wenn)\b|^sonst$/.test(t)) { melde("Für eine Schleife oder Verzweigung die Knöpfe der Leiste nehmen – hier steht nur eine Anweisung.", "fehler"); zeichne(); return; }
        if (t !== feldWert || frisch) {
          if (!frisch) merken();
          if (k.art === "anweisung") k.text = t || "…";
          else if (k.art === "schleife") k.kopf = t || "solange …";
          else k.bed = t || "…";
          umgebaut();
        }
        pruefeText(k);
        zeichne();
      };
      feld.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); ab(true); } else if (e.key === "Escape") { e.preventDefault(); ab(false); } });
      feld.addEventListener("blur", () => ab(true));
    }
    // Sagt beim Bauen, was die Werkstatt beim Laufen nicht ausrechnen kann (ein Kasten in Worten ist erlaubt)
    function pruefeText(k) {
      let m;
      if (k.art === "schleife") { let ok = true; try { K.kopf(k.kopf); } catch (e) { ok = false; } if (!ok) melde("Diesen Kopf kann die Werkstatt nicht ausrechnen: „" + k.kopf + "“ – schreib ihn wie „solange zuege > 0“, „für i = 0 bis 4“ oder „für jedes ding in rucksack“.", "fehler"); else melde(""); }
      else if (k.art === "wenn") { if (!lesbar(k.bed)) melde("Diese Bedingung kann die Werkstatt nicht ausrechnen: „" + k.bed + "“.", "fehler"); else melde(""); }
      else if (RUECKGABE.test(k.text.trim())) {
        let r = null; try { r = K.rueckgabe(k.text); } catch (e) { melde(e.message.replace(/^SyntaxError: /, "") + ".", "fehler"); return; }
        melde(lesbar(r) ? "" : "Hinter „Rückgabe“ steht nichts, was die Werkstatt ausrechnen kann – beim Laufen bricht es dort ab.", lesbar(r) ? "" : "fehler");
      }
      else if ((m = k.text.match(/^Ausgabe:\s*(.*)$/))) melde(lesbar(m[1]) ? "" : "Hinter „Ausgabe:“ steht nichts, was die Werkstatt ausrechnen kann (Text in Anführungszeichen?).", lesbar(m[1]) ? "" : "fehler");
      else if ((m = k.text.match(/^([a-z_]\w*)\s*=\s*(.+)$/i)) && !/^Eingabe\b/i.test(m[2])) melde(lesbar(m[2]) ? "" : "Die rechte Seite kann die Werkstatt nicht ausrechnen – beim Laufen bricht es dort ab.", lesbar(m[2]) ? "" : "fehler");
      else if (k.text !== "…" && wortKasten(k.text)) melde("Ein Kasten in Worten: Er läuft als Platzhalter mit.");
      else melde("");
    }
    function titelBearbeiten() {
      const feld = h("input", "text-im-kasten"); feld.value = titel;
      ueber(feld, { x: 6, y: 2, w: Math.min(vb - 12, 420), h: 24 });
      feld.focus(); feld.select();
      let fertig = false;
      const ab = ok => { if (fertig) return; fertig = true; const t = feld.value.trim(); feld.remove(); if (ok && t && t !== titel) { merken(); titel = t; umgebaut(); } zeichne(); };
      feld.addEventListener("keydown", e => { if (e.key === "Enter") ab(true); else if (e.key === "Escape") ab(false); });
      feld.addEventListener("blur", () => ab(true));
    }

    function bisKopf() {
      stopp();
      for (let n = 0; n < 500; n++) { if (!schritt()) return; if (ev.art === "kopf") return; }
    }
    function stopp() { if (laeufer) { clearInterval(laeufer); laeufer = null; } }
    function allein() {
      if (laeufer) { stopp(); zeichne(); return; }
      laeufer = setInterval(() => {
        if (!schritt()) { stopp(); zeichne(); return; }
        if (ev.art === "kopf" && ev.wert && ev.durchlauf >= GRENZE) {
          stopp(); melde("Beim " + GRENZE + ". Durchlauf angehalten – die Bedingung ist immer noch wahr.", "fehler"); zeichne();
        }
      }, RUHIG ? 60 : 120);
      zeichne();
    }
    kSchritt.addEventListener("click", () => { stopp(); schritt(); });
    kKopf.addEventListener("click", bisKopf);
    kAllein.addEventListener("click", allein);
    kVorn.addEventListener("click", () => { befehle = befehle.slice(); neuerLauf(); });
    kZurueck.addEventListener("click", () => {
      if (!gemacht) return;
      const ziel = gemacht - 1;
      neuerLauf();
      for (let i = 0; i < ziel; i++) schritt();   // still bis einen davor (am Ende oder beim Warten tut schritt nichts)
    });
    kPython.addEventListener("click", () => { python = !python; zeichne(); });
    mBauen.addEventListener("click", () => { if (bauen) return; bauen = true; gewaehlt = null; neuerLauf(); });
    mLaufen.addEventListener("click", () => { if (!bauen) return; bauen = false; gewaehlt = null; neuerLauf(); });
    kRueck.addEventListener("click", () => { const r = rueck.pop(); if (!r) return; const g = JSON.parse(r); titel = g.titel; baum = K.lesen(g.quelle); gewaehlt = null; speichern(); neuerLauf(); });
    kNeu.addEventListener("click", () => {
      if (TI[tisch].eigen || TI[tisch].entwurf) { if (!confirm("Ein neues Struktogramm anfangen? Das bisherige ist dann weg (rückgängig geht noch).")) return; merken(); baum = K.lesen(TI[tisch].start || "…"); titel = TI[tisch].titel; }
      else { merken(); baum = K.lesen(TI[tisch].quelle); titel = TI[tisch].titel; geaendert = false; }
      gewaehlt = null; speichern(); if (!TI[tisch].eigen) geaendert = false; neuerLauf();
    });
    wurzel.addEventListener("keydown", e => { if (bauen && e.key === "Escape" && gewaehlt && !e.target.matches("input")) { gewaehlt = null; zeichne(); } });
    bildEl.addEventListener("click", e => { if (bauen && gewaehlt && e.target.closest("svg") && !e.target.closest(".flaechen")) { gewaehlt = null; zeichne(); } });

    laden();
    return { get welt() { return welt; }, get ereignis() { return ev; }, get quelle() { return K.schreiben(baum); }, get titel() { return titel; }, kern: K,
      // fuer Tests und die Besprechung: eine Quelle setzen (wie getippt -- rueckgaengig geht, gespeichert wird)
      setzen(q, t) { merken(); baum = K.lesen(q); if (t) titel = t; gewaehlt = null; speichern(); neuerLauf(); } };
  };
  window.Werkstaetten.struktogramm.einleitung = "Ein Struktogramm läuft Kasten für Kasten: Was leuchtet als Nächstes? Wie oft läuft die Schleife? Unter „Eigenes“ baust du dein eigenes. Dann „als Python zeigen“.";
  window.Werkstaetten.struktogramm.kern = K;
  window.Werkstaetten.struktogramm.aktionen = AKTIONEN;   // fuer test/plan_gleichlauf.py
})();
