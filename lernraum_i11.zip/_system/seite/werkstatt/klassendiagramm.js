// Werkstatt „Klassendiagramm“ (13.11.2026) -- Klassendiagramme wie im Abitur am Bild bauen. Fuer iq1 `schach`, ab dem
// Thema `klassen` (danach bauplan, kapsel, beziehung, figuren, spielfeld, zwischenstand). Lehrerwahl aus drei Attrappen
// (werkstatt/informatik/q1/gk/planung/uml_werkstatt/, 11.11.): Fassung A „Am Bild bauen“; „als Python zeigen“ im
// Vortrag frei, in der Uebung nur, wo ein Tisch es erlaubt (Lehrer: „nicht schummeln … einfach den Code erzeugen“);
// was die Werkstatt meldet: passt.
//   * Kaesten auf der Flaeche, die Zeilen direkt in die Faecher tippen (oben Attribute, unten Methoden). Die Werkstatt
//     ordnet die Kaesten selbst an (wie uml.py: nebeneinander, untereinander, Raster) -- niemand schiebt Pixel.
//   * Jede Zeile wird beim Verlassen geprueft: wellig rot unterstrichen, darunter der Satz mit der richtigen Form.
//     Die Regeln sind die von werkstatt/_scripts/uml.py (der Zeichner bricht an ihnen ab) -- hier ein zweiter Laeufer
//     (K.befunde, K.eintragBefunde), dieselben Codes; test/uml_gleichlauf.py haelt beide gleich (LR6). Das Fach weiss,
//     ob eine Zeile Methode sein soll: `+ get_name: String` unten heisst „Klammern“, nicht „Attribut nach Methode“.
//   * Beziehungen erst ab Stufe beziehung (LT9): „◇ hat“ oder „→ kennt“ waehlen, vom einen Kasten zum anderen ziehen
//     (oder nacheinander anklicken); die Raute kommt an den Kasten, an dem man anfaengt. Jede Beziehung wird als Satz
//     zurueckgelesen („Eine Figur hat ein Spielfeld.“), ⇄ dreht sie um. „▷ erbt“ erst ab Stufe erben (Zugabe).
//   * Pruefen gegen die Aufgabe (nur an Tischen mit `soll`): fehlt etwas aus dem Text, ist eine Klasse zu viel, sitzt
//     die Raute falsch. Verraet nicht, WAS fehlt. Namen sind frei (get_name oder gib_name), die Form nicht.
//   * als Python zeigen: das Klassengeruest daneben (Typangaben wie im Abitur 2026, Rümpfe `pass`); wer auf eine Zeile
//     zeigt, sieht ihr Gegenstueck.
// Optionen: tische="figur|eigenes" oder [{name, quelle, soll, stufe, python}] · tisch= (einer) · quelle=/soll= (der
// Tisch des Vortragsschritts, aus ```uml-Bloecken) · stufe=klassen|kapsel|beziehung|erben · ort=vortrag (Python frei,
// nichts gemerkt) · python=ja (auch in der Uebung) · python=nein (auch im Vortrag kein „als Python zeigen“).
// Einbinden: Werkstaetten.klassendiagramm(element, opt) -> { stand, quelle, pruefen, python, tisch, film }
window.Werkstaetten = window.Werkstaetten || {};
(function () {
  // ─── Der Kern: die Regeln von uml.py (zweiter Laeufer) ────────────────────────────────────────────────────────
  const K = {};
  const W = "[\\p{L}\\p{N}_]";                       // Pythons \w (Unicode)
  const RX = (s, f) => new RegExp(s.replace(/\\w/g, W), "u" + (f || ""));
  const ERLAUBT = new Set(["String", "integer", "float", "boolean"]);
  const FALSCH = {
    Integer: "integer", Int: "integer", int: "integer", Boolean: "boolean", bool: "boolean", Bool: "boolean",
    Float: "float", Double: "float", double: "float", str: "String", string: "String", Str: "String",
    List: "list[…]", None: "(nichts)", void: "(nichts)",
  };
  const NAME = /^[A-Za-zÄÖÜäöüß_][\p{L}\p{N}_ÄÖÜäöüß]*$/u;
  const BEZIEHUNG = RX("^(\\w+)\\s*(<>-|->|--\\|>)\\s*(\\w+)$");
  const ist_gross = c => !!c && c === c.toUpperCase() && c !== c.toLowerCase();
  K.FALSCH = FALSCH;

  function teilen(par) {                              // an Kommas trennen, nicht in list[…]
    const t = []; let tiefe = 0, a = "";
    for (const c of par) { if (c === "[") tiefe++; else if (c === "]") tiefe--; if (c === "," && tiefe === 0) { t.push(a); a = ""; } else a += c; }
    t.push(a); return t;
  }
  function typ(t, f, klassen) {
    t = t.trim();
    if (!t) { f.push({ code: "typ_fehlt" }); return; }
    const m = RX("^(\\w+)\\[(.+)\\]$").exec(t);
    if (m) { if (m[1] !== "list") f.push({ code: "typ_liste", typ: t }); typ(m[2], f, klassen); return; }
    if (Object.prototype.hasOwnProperty.call(FALSCH, t)) { f.push({ code: "typ_falsch", typ: t, soll: FALSCH[t] }); return; }
    if (ERLAUBT.has(t) || klassen.has(t)) return;
    if (!NAME.test(t) || !ist_gross(t[0])) f.push({ code: "typ_unbekannt", typ: t });
  }
  // eine Zeile eines Fachs: wie _eintrag_pruefen -- gibt [{code, …}]
  function eintrag(t, methode, klassen) {
    const f = [];
    if (t.includes(" :")) f.push({ code: "leer_vor_doppelpunkt" });
    if (!["+", "-", "#"].includes(t.slice(0, 1)) || t.slice(1, 2) !== " ") { f.push({ code: "sichtbarkeit" }); return f; }
    const sicht = t[0], rest = t.slice(2).trim();
    if (methode) {
      const m = RX("^(\\w+)\\((.*)\\)(?::\\s*(.+))?$").exec(rest);
      if (!m) { f.push({ code: "methode_form" }); return f; }
      const [, name, par, rueck] = m;
      if (name === "__init__") {
        if (sicht !== "-") f.push({ code: "init_plus" });
        if (rueck !== undefined) f.push({ code: "init_rueckgabe" });
      } else if (name.startsWith("__")) f.push({ code: "dunder_name", name });
      if (rueck !== undefined) {
        if (rueck.trim() === "None") f.push({ code: "none" }); else typ(rueck, f, klassen);
      }
      for (const p of par.trim() ? teilen(par).map(x => x.trim()) : []) {
        if (p === "self") { f.push({ code: "self" }); continue; }
        const pm = RX("^(\\w+):\\s*(.+)$").exec(p);
        if (!pm) { f.push({ code: "parameter_ohne_typ", name: p }); continue; }
        if (pm[1] === "self") f.push({ code: "self" });
        if (pm[1].startsWith("__")) f.push({ code: "dunder_parameter", name: pm[1] });
        typ(pm[2], f, klassen);
      }
    } else {
      const m = RX("^(\\w+)(?::\\s*(.*))?$").exec(rest);
      if (!m) { f.push({ code: "attribut_form" }); return f; }
      if (m[1].startsWith("__")) f.push({ code: "dunder_name", name: m[1] });
      if (m[2] === undefined) f.push({ code: "attribut_ohne_typ", name: m[1] }); else typ(m[2], f, klassen);
    }
    return f;
  }
  K.eintrag = eintrag;
  K.eintragBefunde = (t, methode, klassen) => eintrag(t, methode, new Set(klassen || [])).map(x => x.code);

  // Die Quelle (.uml) lesen wie uml.lesen -- streng: [[zeile, code], …]
  K.befunde = function (text) {
    const f = [], klassen = [], bez = [];
    let akt = null;
    text.split(/\r\n|\r|\n/).forEach((roh, i) => {
      const nr = i + 1;
      if (!roh.trim() || roh.startsWith("#")) return;
      if (roh[0] === " " || roh[0] === "\t") {
        if (!akt) { f.push([nr, "ohne_klasse"]); return; }
        const t = roh.trim(), methode = t.includes("(");
        if (!methode && akt.e.some(x => x.methode)) f.push([nr, "attribut_nach_methode"]);
        akt.e.push({ nr, t, methode }); return;
      }
      akt = null;
      const t = roh.trim();
      if (t.startsWith("klasse ")) {
        const name = t.slice(7).trim();
        if (!NAME.test(name)) f.push([nr, "klassenname"]);
        else if (klassen.some(k => k.name === name)) f.push([nr, "klasse_doppelt"]);
        akt = { name, e: [] }; klassen.push(akt);
      } else if (t.startsWith("lage:")) {
        const w = t.slice(5).trim().split(/\s+/).filter(Boolean);
        if (!((w.length === 1 && (w[0] === "untereinander" || w[0] === "nebeneinander")) || (w.length === 2 && w[0] === "raster" && /^\d+$/.test(w[1]) && +w[1] >= 1))) f.push([nr, "lage"]);
      } else if (t.startsWith("titel:")) {
      } else if (t.startsWith("art:")) {
        if (t.slice(4).trim() !== "loesung") f.push([nr, "art"]);
      } else {
        const m = BEZIEHUNG.exec(t);
        if (!m) f.push([nr, "unbekannt"]); else bez.push([m[1], m[2], m[3], nr]);
      }
    });
    const namen = new Set(klassen.map(k => k.name));
    if (!klassen.length) f.push([0, "keine_klasse"]);
    klassen.forEach(k => k.e.forEach(e => eintrag(e.t, e.methode, namen).forEach(x => f.push([e.nr, x.code]))));
    const gesehen = new Set();
    bez.forEach(([von, , nach, nr]) => {
      [von, nach].forEach(x => { if (!namen.has(x)) f.push([nr, "beziehung_klasse"]); });
      if (von === nach) f.push([nr, "beziehung_selbst"]);
      const paar = [von, nach].sort().join("\u0000");
      if (gesehen.has(paar)) f.push([nr, "beziehung_doppelt"]);
      gesehen.add(paar);
    });
    return f;
  };

  // Die Quelle nachsichtig als Modell lesen (Werkstatt, Tische, soll): {klassen:[{name, attribute, methoden}],
  // beziehungen:[{von, art, nach}], lage, titel, namen:{…}, nicht:{…}}
  K.modell = function (text) {
    const d = { klassen: [], beziehungen: [], lage: "", titel: "", namen: [], nicht: {} };
    let akt = null;
    String(text || "").split(/\r\n|\r|\n/).forEach(roh => {
      if (!roh.trim()) return;
      if (roh.startsWith("#")) {
        // Anweisungen fuer „Pruefen gegen die Aufgabe“ -- fuer uml.py sind es Kommentare
        let m = /^#\s*namen:\s*(.+)$/.exec(roh);
        if (m) { d.namen.push(m[1].trim().split(/\s+/)); return; }
        m = /^#\s*nicht:\s*([^=]+?)\s*=\s*(.+)$/.exec(roh);
        if (m) d.nicht[m[1].trim()] = m[2].trim();
        return;
      }
      if ((roh[0] === " " || roh[0] === "\t") && akt) {
        const t = roh.trim(); (t.includes("(") ? akt.methoden : akt.attribute).push(t); return;
      }
      akt = null;
      const t = roh.trim();
      if (t.startsWith("klasse ")) { akt = { name: t.slice(7).trim(), attribute: [], methoden: [] }; d.klassen.push(akt); }
      else if (t.startsWith("lage:")) d.lage = t.slice(5).trim();
      else if (t.startsWith("titel:")) d.titel = t.slice(6).trim();
      else { const m = BEZIEHUNG.exec(t); if (m) d.beziehungen.push({ von: m[1], art: m[2], nach: m[3] }); }
    });
    return d;
  };
  // ... und zurueck: die Sprache von uml.py (damit ein Entwurf gezeichnet, gedruckt, abgegeben werden kann)
  K.schreiben = function (d) {
    const z = [];
    if (d.lage) z.push("lage: " + d.lage);
    if (d.titel) z.push("titel: " + d.titel);
    d.klassen.forEach(k => { if (z.length) z.push(""); z.push("klasse " + k.name); k.attribute.concat(k.methoden).forEach(e => z.push("    " + e)); });
    if (d.beziehungen.length) z.push("");
    d.beziehungen.forEach(b => z.push(b.von + " " + b.art + " " + b.nach));
    return z.join("\n") + "\n";
  };

  // eine gueltige Zeile zerlegen (nur nach eintrag() ohne Befund)
  function zerlegen(t, methode) {
    const sicht = t[0], rest = t.slice(2).trim();
    if (methode) {
      const m = RX("^(\\w+)\\((.*)\\)(?::\\s*(.+))?$").exec(rest);
      return { sicht, name: m[1], methode: true, rueck: m[3] ? m[3].trim() : "",
        params: m[2].trim() ? teilen(m[2]).map(p => { const pm = RX("^(\\w+):\\s*(.+)$").exec(p.trim()); return { name: pm[1], typ: pm[2].trim() }; }) : [] };
    }
    const m = RX("^(\\w+)(?::\\s*(.*))?$").exec(rest);
    return { sicht, name: m[1], typ: (m[2] || "").trim(), methode: false };
  }
  K.zerlegen = zerlegen;

  // ─── Als Python: das Klassengeruest ───────────────────────────────────────────────────────────────────────────
  const pyTyp = t => { const m = /^list\[(.+)\]$/.exec(t); return m ? "list[" + pyTyp(m[1]) + "]" : ({ String: "str", integer: "int", float: "float", boolean: "bool" })[t] || t; };
  const vorgabe = t => /^list\[/.test(t) ? "[]" : ({ String: '""', integer: "0", float: "0.0", boolean: "False" })[t] || "None";
  const pyName = (sicht, name) => sicht === "-" && name !== "__init__" ? "__" + name : sicht === "#" ? "_" + name : name;
  // gibt [{text, id}] -- id ist die der Zeile im Diagramm (fuer das Gegenstueck beim Zeigen), sonst ""
  K.python = function (d) {
    const aus = [], namen = new Set(d.klassen.map(k => k.name));
    const def = (kopf, params, rueck, id) => {
      const teile = ["self"].concat(params.map(p => p.name + ": " + pyTyp(p.typ)));
      const schluss = ")" + (rueck ? " -> " + pyTyp(rueck) : "") + ":";
      const eins = "    def " + kopf + "(" + teile.join(", ") + schluss;
      if (eins.length <= 46 || teile.length < 3) { aus.push({ text: eins, id }); return; }
      // lang: umbrechen wie in der Attrappe, die Fortsetzung unter der ersten Klammer
      const ein = " ".repeat(("    def " + kopf + "(").length);
      let zeile = "    def " + kopf + "(";
      teile.forEach((t, i) => {
        const stueck = t + (i < teile.length - 1 ? ", " : schluss);
        if (zeile.trim().length && (zeile + stueck).trimEnd().length > 46 && !zeile.endsWith("(")) { aus.push({ text: zeile.trimEnd(), id }); zeile = ein; }
        zeile += stueck;
      });
      aus.push({ text: zeile, id });
    };
    d.klassen.forEach((k, ki) => {
      if (!NAME.test(k.name)) return;
      if (aus.length) aus.push({ text: "", id: "" }, { text: "", id: "" });
      aus.push({ text: "class " + k.name + ":", id: "k" + ki });
      const gut = (liste, methode, art) => liste.map((t, i) => ({ t, i, id: "k" + ki + "-" + art + i }))
        .filter(x => !eintrag(x.t, methode, namen).length).map(x => Object.assign(zerlegen(x.t, methode), { id: x.id }));
      const attr = gut(k.attribute, false, "a"), meth = gut(k.methoden, true, "m");
      const init = meth.find(m => m.name === "__init__");
      aus.push({ text: "", id: "" });
      def("__init__", init ? init.params : [], "", init ? init.id : "");
      const pn = new Set((init ? init.params : []).map(p => p.name));
      attr.forEach(a => aus.push({ text: "        self." + pyName(a.sicht, a.name) + " = " + (pn.has(a.name) ? a.name : vorgabe(a.typ)), id: a.id }));
      if (!attr.length) aus.push({ text: "        pass", id: init ? init.id : "" });
      meth.filter(m => m !== init).forEach(m => {
        aus.push({ text: "", id: "" });
        def(pyName(m.sicht, m.name), m.params, m.rueck, m.id);
        aus.push({ text: "        pass", id: m.id });
      });
    });
    return aus;
  };

  // ─── Pruefen gegen die Aufgabe ────────────────────────────────────────────────────────────────────────────────
  const STUFEN = ["klassen", "kapsel", "beziehung", "erben"];
  const stufeNr = s => Math.max(0, STUFEN.indexOf(s));
  K.STUFEN = STUFEN;
  const norm = s => String(s).toLowerCase().replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss")
    .replace(/^(gib|hole)_/, "get_").replace(/^setze_/, "set_");
  // Artikel fuer den Satz „Eine Figur hat ein Spielfeld.“ / „Ein Spielfeld kennt einen Spieler.“ -- das Geschlecht
  // geraten an der Endung (weiblich, saechlich, sonst maennlich), dazu Ausnahmen. Der Name selbst wird nicht gebeugt.
  const MAENNLICH = new Set(["kunde", "name", "junge", "loewe", "affe", "hase", "kaese", "gedanke", "buchstabe", "kollege", "experte", "zeuge", "bote", "erbe", "termin", "teil", "zug"]);
  const WEIBLICH = /(ung|ur|heit|keit|schaft|ion|taet|ei|in|e|ik|thek|ie|enz|anz|ur|nacht|kraft|zahl|wahl|art|liste|bahn|uhr|tuer|frau)$/;
  const SAECHLICH = /(feld|brett|spiel|buch|konto|lager|heim|tier|glied|portal|regal|fach|objekt|programm|system|ding|bild|zimmer|haus|auto|ticket|produkt|ment|um|chen|lein|geraet|stueck|ziel|ergebnis|zeugnis|fenster|schloss|rad|boot|schiff|hotel|kino|team|paket|formular|angebot|gebaeude|rezept|getraenk|zeug|duell|kind|land|amt|werk|netz|konto|depot)$/;
  K.geschlecht = function (name) {
    const n = norm(name);
    if (MAENNLICH.has(n)) return "m";
    if (SAECHLICH.test(n)) return "n";
    if (WEIBLICH.test(n)) return "f";
    return "m";
  };
  K.artikel = function (name, gross, akkusativ) {
    const g = K.geschlecht(name);
    const w = g === "f" ? "eine" : g === "m" && akkusativ ? "einen" : "ein";
    return gross ? w[0].toUpperCase() + w.slice(1) : w;
  };
  K.satz = function (b) {
    if (b.art === "--|>") return K.artikel(b.von, true) + " " + b.von + " ist " + K.artikel(b.nach) + " " + b.nach + ".";
    return K.artikel(b.von, true) + " " + b.von + " " + (b.art === "<>-" ? "hat" : "kennt") + " " + K.artikel(b.nach, false, true) + " " + b.nach + ".";
  };

  K.vergleichen = function (ist, soll, stufe) {
    const st = stufeNr(stufe), m = [];
    const alt = {};
    (soll.namen || []).forEach(g => g.forEach(n => { alt[norm(n)] = norm(g[0]); }));
    const nn = s => alt[norm(s)] || norm(s);
    const namenIst = new Set(ist.klassen.map(k => k.name));
    // nur gueltige Zeilen zaehlen -- rote Zeilen erst richtig schreiben
    const rot = ist.klassen.some(k => k.attribute.some(t => eintrag(t, false, namenIst).length || t.includes("(")) || k.methoden.some(t => eintrag(t, true, namenIst).length));
    if (rot) return { ok: false, meldungen: [{ text: "Erst die rot markierten Zeilen richtig schreiben – dann prüft die Werkstatt gegen die Aufgabe." }] };
    const sk = new Map(soll.klassen.map(k => [nn(k.name), k]));
    const ik = new Map(ist.klassen.map(k => [nn(k.name), k]));
    const fehlendeKlassen = [...sk.keys()].filter(n => !ik.has(n)).length;
    if (fehlendeKlassen) m.push({ text: fehlendeKlassen === 1 ? "Im Text steht noch eine Klasse, die im Diagramm fehlt." : "Im Text stehen noch " + fehlendeKlassen + " Klassen, die im Diagramm fehlen." });
    ist.klassen.forEach(k => {
      if (sk.has(nn(k.name))) return;
      const h = Object.keys(soll.nicht || {}).find(x => nn(x) === nn(k.name));
      m.push({ klasse: k.name, text: h ? soll.nicht[h] : "Eine Klasse " + k.name + " steht so nicht im Text." });
    });
    sk.forEach((s, n) => {
      const k = ik.get(n); if (!k) return;
      const sa = s.attribute.map(t => zerlegen(t, false)), ia = k.attribute.map(t => zerlegen(t, false));
      const sm = s.methoden.map(t => zerlegen(t, true)), im = k.methoden.map(t => zerlegen(t, true));
      let fa = 0, fm = 0;
      sa.forEach(a => {
        const b = ia.find(x => nn(x.name) === nn(a.name));
        if (!b) { fa++; return; }
        b.gefunden = true;
        if (b.typ !== a.typ) m.push({ klasse: k.name, text: k.name + ": Der Typ von " + b.name + " passt nicht zum Text." });
        else if (st >= 1 && b.sicht !== a.sicht) m.push({ klasse: k.name, text: k.name + ": " + b.name + " – privat oder öffentlich? Lies im Text nach." });
      });
      ia.filter(x => !x.gefunden).forEach(x => m.push({ klasse: k.name, text: k.name + ": " + x.name + " steht so nicht im Text." }));
      sm.forEach(a => {
        const b = im.find(x => nn(x.name) === nn(a.name));
        if (!b) { fm++; return; }
        b.gefunden = true;
        const typen = l => l.map(p => p.typ);
        const gleich = a.name === "__init__" ? typen(a.params).sort().join() === typen(b.params).sort().join() : typen(a.params).join() === typen(b.params).join();
        if (!gleich) m.push({ klasse: k.name, text: k.name + ": " + (a.name === "__init__" ? "Der Konstruktor bekommt" : b.name + " bekommt") + " laut Text andere Werte mit." });
        if (a.rueck !== b.rueck) m.push({ klasse: k.name, text: k.name + ": Was gibt " + b.name + " zurück? Lies im Text nach." });
        if (st >= 1 && a.name !== "__init__" && a.sicht !== b.sicht) m.push({ klasse: k.name, text: k.name + ": " + b.name + " – privat oder öffentlich? Lies im Text nach." });
      });
      im.filter(x => !x.gefunden).forEach(x => m.push({ klasse: k.name, text: k.name + ": " + (x.name === "__init__" ? "Einen Konstruktor" : x.name) + " verlangt der Text nicht." }));
      if (fa) m.push({ klasse: k.name, text: fa === 1 ? "Im Text steht noch eine Angabe zu " + k.name + ", die im Diagramm fehlt." : "Im Text stehen noch " + fa + " Angaben zu " + k.name + ", die im Diagramm fehlen." });
      if (fm) m.push({ klasse: k.name, text: fm === 1 ? k.name + " kann laut Text noch etwas, das im Diagramm fehlt." : k.name + " kann laut Text noch " + fm + " Dinge, die im Diagramm fehlen." });
    });
    // Beziehungen: Richtung und Art
    const sb = soll.beziehungen.map(b => ({ von: nn(b.von), nach: nn(b.nach), art: b.art }));
    const name = n => (ist.klassen.find(k => nn(k.name) === n) || {}).name || n;
    let fehltB = 0;
    sb.forEach(s => {
      const b = ist.beziehungen.find(x => [nn(x.von), nn(x.nach)].sort().join() === [s.von, s.nach].sort().join());
      if (!b) { if (ik.has(s.von) && ik.has(s.nach)) fehltB++; return; }
      b.gefunden = true;
      if (b.art !== s.art) m.push({ text: "Zwischen " + name(s.von) + " und " + name(s.nach) + ": hält das eine das andere (Raute) oder kennt es es nur (Pfeil)?" });
      else if (nn(b.von) !== s.von) m.push({ text: b.art === "<>-" ? "Die Raute sitzt falsch herum: Sie gehört an den Kasten, der den anderen hält." : b.art === "->" ? "Der Pfeil zeigt falsch herum: Er zeigt auf die Klasse, die gekannt wird." : "Das Dreieck sitzt an der allgemeineren Klasse." });
    });
    ist.beziehungen.filter(b => !b.gefunden).forEach(b => m.push({ text: "Die Beziehung zwischen " + b.von + " und " + b.nach + " steht nicht im Text." }));
    ist.beziehungen.forEach(b => { delete b.gefunden; });
    if (fehltB) m.push({ text: fehltB === 1 ? "Zwischen zwei Klassen fehlt noch eine Beziehung." : "Es fehlen noch " + fehltB + " Beziehungen." });
    return m.length ? { ok: false, meldungen: m } : { ok: true, meldungen: [{ text: "Alle Klassen, Attribute und Methoden aus dem Text, in der Form des Abiturs." + (st >= 2 && sb.length ? " Die Beziehungen stimmen." : "") }] };
  };

  // ─── Saetze: was die Werkstatt zu einer Zeile sagt (freundlicher als uml.py, mit der richtigen Form) ─────────
  // Die richtige Form, soweit sie sich ableiten laesst; „…“ heisst: hier fehlt etwas, das nur du weisst
  K.vorschlag = function (t, methode) {
    let s = t.trim();
    if (/^[+\-#]\S/.test(s)) s = s[0] + " " + s.slice(1);
    if (!/^[+\-#] /.test(s)) s = (/^__init__\b/.test(s) ? "- " : "+ ") + s;
    s = s.replace(/\s+:/g, ":").replace(/:(?=\S)(?![^(]*\))/g, ": ");
    const kopf = s.slice(0, 2); let rest = s.slice(2).trim();
    const mapTyp = x => x.replace(RX("\\b(\\w+)\\b", "g"), w => (FALSCH[w] && !/^(None|void|List)$/.test(w)) ? FALSCH[w] : w).replace(/\bList\[/g, "list[");
    if (methode) {
      if (!rest.includes("(")) rest = rest.replace(RX("^(\\w+)"), "$1()");
      const m = RX("^(\\w+)\\((.*)\\)(?::\\s*(.*))?$").exec(rest);
      if (!m) return kopf + rest;
      let [, name, par, rueck] = m;
      const init = name === "__init__";
      if (!init) name = name.replace(/^_+/, "");
      const ps = par.trim() ? teilen(par).map(p => p.trim()).filter(p => !/^self\b/.test(p)).map(p => {
        const pm = RX("^(\\w+)\\s*:\\s*(.+)$").exec(p);
        return pm ? pm[1].replace(/^_+/, "") + ": " + mapTyp(pm[2].trim()) : p.replace(/^_+/, "") + ": …";
      }) : [];
      rueck = (rueck || "").trim();
      if (init || /^(None|void)$/.test(rueck)) rueck = "";
      return (init ? "- " : kopf) + name + "(" + ps.join(", ") + ")" + (rueck ? ": " + mapTyp(rueck) : "");
    }
    const m = RX("^(\\w+)(?::\\s*(.*))?$").exec(rest);
    if (!m) return kopf + rest;
    return kopf + m[1].replace(/^_+/, "") + ": " + (m[2] && m[2].trim() && !/^(None|void)$/.test(m[2].trim()) ? mapTyp(m[2].trim()) : "…");
  };
  // Code -> Satz (stufe: was schon eingefuehrt ist, LT9)
  K.saetze = function (befunde, stufe, methode) {
    const st = stufeNr(stufe);
    return befunde.map(b => {
      switch (b.code) {
        case "leer_vor_doppelpunkt": return "Vor dem Doppelpunkt steht kein Leerzeichen";
        case "sichtbarkeit": return st >= 1 ? "Vorn steht die Sichtbarkeit (+ oder -) und ein Leerzeichen" : "Vorn steht + und ein Leerzeichen (beim Konstruktor -)";
        case "methode_ohne_klammern": return "Eine Methode hat Klammern, auch ohne Parameter";
        case "methode_im_attributfach": return "Das ist eine Methode – sie gehört ins untere Fach";
        case "methode_form": return "Eine Methode schreibt man name(parameter: Typ): Rückgabetyp";
        case "attribut_form": return "Ein Attribut schreibt man name: Typ";
        case "init_plus": return "Der Konstruktor steht mit Minus";
        case "init_rueckgabe": return "Der Konstruktor hat keine Rückgabe";
        case "dunder_name": case "dunder_parameter": return st >= 1 ? "Im Diagramm ohne __ – das Minus sagt schon, dass es privat ist" : "Im Diagramm steht kein __ vor dem Namen";
        case "none": return "Ohne Rückgabe steht nichts hinter der Klammer";
        case "parameter_ohne_typ": return "Jeder Parameter hat einen Typ";
        case "attribut_ohne_typ": return "Jedes Attribut hat einen Typ";
        case "self": return "self steht nur im Code, nicht im Diagramm";
        case "typ_fehlt": return "Hier fehlt ein Typ";
        case "typ_liste": return "Eine Liste schreibt man list[Typ]";
        case "typ_falsch":
          if (b.soll === "(nichts)") return methode ? "Ohne Rückgabe steht nichts hinter der Klammer" : b.typ + " ist kein Typ im Diagramm";
          if (b.typ === "List") return "Eine Liste schreibt man klein: list[…]";
          if (["int", "str", "bool"].includes(b.typ)) return "Im Diagramm heißt der Typ " + b.soll + " – " + b.typ + " steht im Code";
          return "Im Diagramm heißt der Typ " + b.soll + ", nicht " + b.typ;
        case "typ_unbekannt": return "Typen sind String, integer, float, boolean, list[…] oder eine Klasse (groß geschrieben)";
        default: return b.code;
      }
    });
  };
  // eine Zeile in ihrem Fach: [{code, …}] -- das Fach sagt, ob sie eine Methode sein soll
  K.zeilePruefen = function (t, methode, klassen) {
    const k = new Set(klassen || []);
    if (!methode && t.includes("(")) return [{ code: "methode_im_attributfach" }];
    let f = eintrag(t, methode, k);
    // Leerzeichen vor dem Doppelpunkt: die Folgemeldungen („keine Form“, „ohne Typ“) weg -- gesagt wird, was dann noch fehlt
    if (f.some(x => x.code === "leer_vor_doppelpunkt")) f = [{ code: "leer_vor_doppelpunkt" }].concat(eintrag(t.replace(/\s+:/g, ":"), methode, k));
    if (methode && !t.includes("(")) return f.map(x => x.code === "methode_form" ? { code: "methode_ohne_klammern" } : x);
    return f;
  };

  // ─── Das Bild ohne Bedienung (Pult, Besprechung, 13.11.) -- gezeichnet wie uml.py (Masse, Raute beim Haltenden) ─
  // Liegen die Kaesten von Hand (pos), dann so, wie die Klasse sie gelegt hat; sonst im Raster. Als Text, ohne xmlns.
  K.svg = function (d, o) {
    o = o || {};
    const S = 15, Z = 21, KOPF = 28, P = 9, LEER = 10, RAND = 8, esc = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    const breite = (s, fett) => String(s).length * S * (0.5 + (fett ? 0.04 : 0));
    const ks = (d.klassen || []).map(k => {
      const b = Math.max(120, breite(k.name || "?", true), ...k.attribute.concat(k.methoden).map(x => breite(x))) + 2 * P;
      const ha = k.attribute.length ? k.attribute.length * Z + 8 : LEER, hm = k.methoden.length ? k.methoden.length * Z + 8 : LEER;
      return { k, b, ha, h: KOPF + ha + hm, x: 0, y: 0 };
    });
    if (d.pos && ks.every(x => d.pos[x.k.name])) {
      const x0 = Math.min(...ks.map(x => d.pos[x.k.name].x)), y0 = Math.min(...ks.map(x => d.pos[x.k.name].y));
      ks.forEach(x => { x.x = d.pos[x.k.name].x - x0 + RAND; x.y = d.pos[x.k.name].y - y0 + RAND; });
    } else {
      const sp = d.lage === "untereinander" ? 1 : d.lage === "nebeneinander" ? ks.length : /^raster \d+$/.test(d.lage || "") ? +d.lage.split(" ")[1] : Math.min(3, ks.length) || 1;
      const sb = [], zh = [];
      ks.forEach((x, i) => { sb[i % sp] = Math.max(sb[i % sp] || 0, x.b); zh[Math.floor(i / sp)] = Math.max(zh[Math.floor(i / sp)] || 0, x.h); });
      ks.forEach((x, i) => { const s = i % sp, z = Math.floor(i / sp); x.x = RAND + sb.slice(0, s).reduce((a, v) => a + v, 0) + s * 80 + (sb[s] - x.b) / 2; x.y = RAND + zh.slice(0, z).reduce((a, v) => a + v, 0) + z * 56; });
    }
    const L = ks.map(x => ({ x: x.x, y: x.y, b: x.b, h: x.h })), idx = new Map(ks.map((x, i) => [x.k.name, i]));
    const schnitt = (a, cx, cy, zx, zy) => { const dx = zx - cx, dy = zy - cy, t = Math.min(dx ? (a.b / 2) / Math.abs(dx) : Infinity, dy ? (a.h / 2) / Math.abs(dy) : Infinity); return [cx + dx * t, cy + dy * t]; };
    const strecke = (a, b) => {
      const ox = [Math.max(a.x, b.x), Math.min(a.x + a.b, b.x + b.b)], oy = [Math.max(a.y, b.y), Math.min(a.y + a.h, b.y + b.h)];
      if (ox[1] - ox[0] >= 24) { const x = (ox[0] + ox[1]) / 2; return a.y < b.y ? [x, a.y + a.h, x, b.y] : [x, a.y, x, b.y + b.h]; }
      if (oy[1] - oy[0] >= 24) { const y = (oy[0] + oy[1]) / 2; return a.x < b.x ? [a.x + a.b, y, b.x, y] : [a.x, y, b.x + b.b, y]; }
      return schnitt(a, a.x + a.b / 2, a.y + a.h / 2, b.x + b.b / 2, b.y + b.h / 2).concat(schnitt(b, b.x + b.b / 2, b.y + b.h / 2, a.x + a.b / 2, a.y + a.h / 2));
    };
    const f = v => v.toFixed(1);
    let teile = "";
    ks.forEach(x => {
      teile += '<rect x="' + f(x.x) + '" y="' + f(x.y) + '" width="' + f(x.b) + '" height="' + f(x.h) + '"/>' +
        '<line x1="' + f(x.x) + '" y1="' + f(x.y + KOPF) + '" x2="' + f(x.x + x.b) + '" y2="' + f(x.y + KOPF) + '"/>' +
        '<line x1="' + f(x.x) + '" y1="' + f(x.y + KOPF + x.ha) + '" x2="' + f(x.x + x.b) + '" y2="' + f(x.y + KOPF + x.ha) + '"/>' +
        '<text class="name" x="' + f(x.x + x.b / 2) + '" y="' + f(x.y + KOPF / 2) + '" text-anchor="middle" dominant-baseline="central">' + esc(x.k.name) + "</text>";
      const fach = (zl, y0) => zl.forEach((s, i) => {
        const rot = o.pruefen !== false && K.zeilePruefen(s, zl === x.k.methoden, ks.map(y => y.k.name)).length;
        teile += '<text' + (rot ? ' class="rot"' : "") + ' x="' + f(x.x + P) + '" y="' + f(y0 + 4 + Z / 2 + i * Z) + '" dominant-baseline="central">' + esc(s) + "</text>";
      });
      fach(x.k.attribute, x.y + KOPF); fach(x.k.methoden, x.y + KOPF + x.ha);
    });
    (d.beziehungen || []).forEach(b => {
      const a = L[idx.get(b.von)], c = L[idx.get(b.nach)]; if (!a || !c) return;
      const [x1, y1, x2, y2] = b.art === "<>-" ? strecke(c, a) : strecke(a, c);
      const l = Math.hypot(x2 - x1, y2 - y1) || 1, ux = (x2 - x1) / l, uy = (y2 - y1) / l, nx = -uy, ny = ux;
      const pt = (q, r) => f(x2 - ux * q + nx * r) + "," + f(y2 - uy * q + ny * r);
      const [zeichen, ende] = b.art === "<>-" ? ['<polygon class="leer" points="' + [pt(0, 0), pt(9, 6), pt(18, 0), pt(9, -6)].join(" ") + '"/>', pt(18, 0)]
        : b.art === "--|>" ? ['<polygon class="leer" points="' + [pt(0, 0), pt(14, 8), pt(14, -8)].join(" ") + '"/>', pt(14, 0)]
        : ['<polyline class="pfeil" points="' + [pt(12, 7), pt(0, 0), pt(12, -7)].join(" ") + '"/>', pt(0, 0)];
      const [ex, ey] = ende.split(",");
      teile += '<line x1="' + f(x1) + '" y1="' + f(y1) + '" x2="' + ex + '" y2="' + ey + '"/>' + zeichen;
    });
    const w = Math.ceil(Math.max(120, ...L.map(x => x.x + x.b)) + RAND), hh = Math.ceil(Math.max(40, ...L.map(x => x.y + x.h)) + RAND);
    return '<svg class="uml-bild" viewBox="0 0 ' + w + " " + hh + '" width="' + w + '" role="img" aria-label="' + esc(o.titel || "Klassendiagramm: " + ks.map(x => x.k.name).join(", ")) + '">' +
      '<style>rect{fill:#fff;stroke:#2f66c4;stroke-width:1.6}line,.pfeil{fill:none;stroke:#2f66c4;stroke-width:1.6}.leer{fill:#fff;stroke:#2f66c4;stroke-width:1.6}' +
      'text{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;font-size:15px;fill:#1c1b1a}.name{font-weight:700}.rot{fill:#d6453d;text-decoration:underline wavy}</style>' + teile + "</svg>";
  };

  // ─── Die eingebauten Tische ────────────────────────────────────────────────────────────────────────────────────
  // figur (Thema klassen): die Figur aus `benutzen` -- ihr Steckbrief war bewusst eine Skizze (W5), hier wird daraus
  // das Klassendiagramm. Was sie weiss, zeigte der Debugger (__art, __farbe, __zeile, __spalte), was sie kann, der Steckbrief.
  const EINGEBAUT = {
    figur: { name: "Figur", stufe: "klassen", quelle: "klasse Figur\n",
      soll: "# namen: ziehen ziehe bewege\nklasse Figur\n    - art: String\n    - farbe: String\n    - zeile: integer\n    - spalte: integer\n" +
        "    - __init__(art: String, farbe: String, zeile: integer, spalte: integer)\n    + get_art(): String\n    + get_farbe(): String\n" +
        "    + get_zeile(): integer\n    + get_spalte(): integer\n    + get_wert(): integer\n    + ziehen(zeile: integer, spalte: integer)\n" },
    eigenes: { name: "Eigenes", eigenes: true, quelle: "" },
  };
  K.EINGEBAUT = EINGEBAUT;

  // ─── Die Werkstatt ─────────────────────────────────────────────────────────────────────────────────────────────
  // Bedienung (Lehrer 13.11., nach der ersten Fassung: „etwas moderner … und wie bei der alten Q3-Automatenwerkstatt
  // flüssiger bedienbar, mit Drag and Drop … bei der Positionierung von Klassen, Erstellung von Beziehungen“):
  //   * Kasten am Kopf ziehen = verschieben (Linien wandern mit, Raster 8 px); „Ordnen“ legt sie wieder wie uml.py hin
  //   * Doppelklick ins Leere = neue Klasse an dieser Stelle
  //   * Zeile am Griff ⋮⋮ ziehen = umsortieren, auch in ein anderes Fach oder eine andere Klasse
  //   * ab Stufe beziehung: vom Punkt am Kasten zum anderen Kasten ziehen (Gummiband); beim Loslassen die Wahl als Satz
  //   * Klick waehlt (Kasten, Linie); Entf loescht, Strg/⌘+Z rueckgaengig, mit Umschalt wiederholen; Esc bricht ab
  // Alle Zeigerereignisse haengen EINMAL an der Flaeche (Delegation, Pointer-Capture) -- so darf die Buehne waehrend des
  // Ziehens neu gezeichnet werden (gelernt in der Sprachwerkstatt iq3: Doppelklick kam mit Capture beim Container an).
  const ICON = {
    rueck: '<path d="M6 3.5 2.5 7 6 10.5"/><path d="M3 7h6.5a3.5 3.5 0 0 1 0 7H7"/>',
    vor: '<path d="M10 3.5 13.5 7 10 10.5"/><path d="M13 7H6.5a3.5 3.5 0 0 0 0 7H9"/>',
    ordnen: '<rect x="2" y="2" width="5" height="5" rx="1.2"/><rect x="9" y="2" width="5" height="5" rx="1.2"/><rect x="2" y="9" width="5" height="5" rx="1.2"/><rect x="9" y="9" width="5" height="5" rx="1.2"/>',
    neu: '<path d="M13.2 8a5.2 5.2 0 1 1-1.6-3.7"/><path d="M12 1.8v3h-3"/>',
    plus: '<path d="M8 3v10M3 8h10"/>',
    pruefen: '<path d="M3 8.5 6.5 12 13 4.5"/>',
  };
  const icon = n => '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + ICON[n] + "</svg>";
  const RASTER = 8;
  const MAC = /Mac|iPhone|iPad/.test((navigator.platform || "") + (navigator.userAgent || ""));
  const ARTEN = [["<>-", "◇", "hat"], ["->", "→", "kennt"], ["--|>", "▷", "erbt"]];

  window.Werkstaetten.klassendiagramm = function (wurzel, opt) {
    opt = opt || {};
    const vortrag = opt.ort === "vortrag";
    const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
    const kopie = x => JSON.parse(JSON.stringify(x));
    const RUHIG = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Tische: aus dem Schritt (quelle/soll), aus tische= (Namen der eingebauten oder Objekte), sonst figur + eigenes
    // Aufgabenmodus (Aufgabenart „Diagramm“, 13.11.): eine Aufgabe, kein „Eigenes“, kein Python; jede Aenderung geht an
    // opt.aendern (die Seite speichert im Stand), „✔ Selbstcheck“ fragt opt.selbstcheck (der Server prueft gegen die Aufgabe)
    const entwurf = !!opt.entwurf;
    let liste = [];
    if (entwurf) liste.push({ kennung: "aufgabe", name: opt.name || "Diagramm", quelle: opt.start || "", stufe: opt.stufe || "klassen" });
    else if (opt.quelle != null || opt.soll) liste.push({ name: opt.name || opt.titel || "Diagramm", quelle: opt.quelle || "", soll: opt.soll || "", stufe: opt.stufe, python: opt.python });
    const roh = Array.isArray(opt.tische) ? opt.tische : String(opt.tische || opt.tisch || "").split("|").map(x => x.trim()).filter(Boolean);
    if (!entwurf) roh.forEach(t => {
      if (typeof t === "string") { if (EINGEBAUT[t]) liste.push(Object.assign({ kennung: t }, EINGEBAUT[t])); }
      else liste.push(Object.assign({}, t));
    });
    if (!liste.length && !entwurf) liste = ["figur", "eigenes"].map(k => Object.assign({ kennung: k }, EINGEBAUT[k]));
    const hoechste = liste.reduce((a, t) => Math.max(a, stufeNr(t.stufe || opt.stufe || "klassen")), 0);
    const tische = liste.map((t, i) => {
      const s = t.stufe || opt.stufe || (t.eigenes ? STUFEN[hoechste] : "klassen");
      const m = K.modell(t.quelle); m.pos = null;
      return { kennung: t.kennung || ("t" + i), name: t.name, stufe: s, eigenes: !!t.eigenes, start: m,
        // python="nein" am Schritt schaltet den Knopf auch im Vortrag ab (Reihensichtung iq1 Teil I, Paket 4, 17.11.):
        // Wo die Klasse das Geruest selbst schreiben soll, verraet „als Python zeigen“ die Antwort
        soll: t.soll ? K.modell(t.soll) : null, python: !entwurf && t.python !== "nein" && opt.python !== "nein" &&
          (vortrag || t.python === true || t.python === "ja" || opt.python === "ja" || opt.python === true) };
    });
    const ORT = (/#\/([^/]+)\/t\/([^/]+\/[^/]+)/.exec(location.hash || "") || []).slice(1).join(":");
    const schluessel = t => "lernraum-klassendiagramm:" + (t.eigenes ? "eigenes" : ORT + ":" + t.kennung);
    const merken = t => {
      if (entwurf) { if (opt.aendern) opt.aendern(kopie(t.d)); return; }
      if (vortrag || (!t.eigenes && !ORT)) return;
      try { localStorage.setItem(schluessel(t), JSON.stringify(t.d)); } catch (e) {}
    };
    tische.forEach(t => {
      t.d = kopie(t.start);
      if (entwurf && opt.modell && Array.isArray(opt.modell.klassen)) t.d = Object.assign({ beziehungen: [], lage: "", pos: null }, kopie(opt.modell));
      else if (!vortrag && (t.eigenes || ORT)) { try { const g = localStorage.getItem(schluessel(t)); if (g) t.d = JSON.parse(g); } catch (e) {} }
      t.rueck = []; t.vor = [];
    });

    let tisch = tische[0], edit = null, pyAn = false, pruefung = entwurf && opt.pruefung ? { ok: !!opt.pruefung.ok, meldungen: (opt.pruefung.meldungen || []).map(text => ({ text })), zuletzt: true } : null, zeigeId = "", tippen = 0, tippt = false;
    let auswahl = null, menue = null, zug = null, neuName = "", rafLinien = 0, umgestellt = null;
    const st = () => stufeNr(tisch.stufe);
    const namen = () => tisch.d.klassen.map(k => k.name);
    const prefix = methode => methode ? "+ " : st() >= 1 ? "- " : "+ ";

    // ── das Geruest ──
    wurzel.textContent = "";
    wurzel.classList.add("uml-ws");
    const kopf = h("div", "uml-kopf");
    const chip = h("span", "uml-chip", "Klassendiagramm");
    const reiter = h("div", "uml-segment tische");
    const knopf = (cls, ic, text, titel) => { const b = h("button", cls); b.type = "button"; b.innerHTML = (ic ? icon(ic) : "") + (text ? "<span>" + text + "</span>" : ""); if (titel) { b.title = titel; b.setAttribute("aria-label", titel); } return b; };
    const kKlasse = knopf("", "plus", "Klasse", "Neue Klasse (oder Doppelklick ins Leere)");
    const werkzeuge = h("div", "uml-segment werkzeuge");
    const kRueck = knopf("ikon", "rueck", "", "Rückgängig (" + (MAC ? "⌘" : "Strg") + "+Z)");
    const kVor = knopf("ikon", "vor", "", "Wiederholen (" + (MAC ? "⌘" : "Strg") + "+Umschalt+Z)");
    const kOrdnen = knopf("ikon", "ordnen", "", "Ordnen: die Kästen wieder nebeneinander und untereinander legen");
    const kNeu = knopf("ikon", "neu", "", "Von vorn");
    // Zoom in jeder Ansicht (Durchsicht iq1 klassen, 13.11.: „solange ich die Sicht mit Scrollbars zur gewünschten
    // Stelle bringen kann … und zoomen kann“) -- dieselbe Stufe wie A−/A+ über der Werkstatt im Vortrag
    const kKlein = knopf("ikon zoom", "", "A−", "Kleiner zeigen");
    const kGross = knopf("ikon zoom", "", "A+", "Größer zeigen");
    werkzeuge.append(kRueck, kVor, kOrdnen, kNeu, kKlein, kGross);
    const rechts = h("span", "rechts");
    const kPy = knopf("schalter", "", "als Python zeigen");
    const kPruef = entwurf ? knopf("primaer", "", "✔ Selbstcheck", "Mit der Aufgabe vergleichen") : knopf("primaer", "pruefen", "Prüfen", "Gegen die Aufgabe prüfen");
    rechts.append(werkzeuge, kPy, kPruef);
    kopf.append(chip, reiter, kKlasse, rechts);
    const mitte = h("div", "uml-mitte");
    const flaeche = h("div", "uml-flaeche"); flaeche.tabIndex = 0;
    flaeche.setAttribute("aria-label", "Klassendiagramm: Kästen ziehen, Doppelklick legt eine Klasse an");
    const buehne = h("div", "uml-buehne");
    const linien = h("div", "uml-linien");
    flaeche.append(buehne);
    const pyEl = h("div", "uml-py"); pyEl.hidden = true;
    mitte.append(flaeche, pyEl);
    const unten = h("div", "uml-unten");
    const kuerzel = h("p", "uml-kuerzel");
    wurzel.append(kopf, mitte, unten, kuerzel);

    tische.forEach(t => {
      const b = h("button", "", t.name); b.type = "button";
      b.addEventListener("click", () => { if (tisch === t) return; editEnde(true); tisch = t; auswahl = null; menueZu(); pruefung = null; zeichnen(); });
      t.knopf = b; reiter.append(b);
    });
    reiter.hidden = tische.length < 2;

    function aendern(f) {                       // eine Aenderung, ein Schritt fuer ↶
      tisch.rueck.push(kopie(tisch.d)); if (tisch.rueck.length > 100) tisch.rueck.shift();
      tisch.vor = [];
      f(tisch.d); pruefung = null; merken(tisch);
    }
    function rueckgaengig() { if (!tisch.rueck.length) return; edit = null; tisch.vor.push(kopie(tisch.d)); tisch.d = tisch.rueck.pop(); nachSprung(); }
    function wiederholen() { if (!tisch.vor.length) return; edit = null; tisch.rueck.push(kopie(tisch.d)); tisch.d = tisch.vor.pop(); nachSprung(); }
    function nachSprung() { merken(tisch); pruefung = null; auswahl = null; menueZu(); zeichnen(); }

    // ── Kaesten ──
    function kasten(k, ki) {
      const box = h("div", "uml-kasten"); box.dataset.k = ki;
      if (auswahl && auswahl.art === "klasse" && auswahl.k === ki) box.classList.add("gewaehlt");
      if (!RUHIG && ((neuName && k.name === neuName) || (!k.name && edit && edit.art === "name" && edit.k === ki))) box.classList.add("neu");
      const nameEl = h("div", "uml-name");
      nameEl.title = "Am Kopf ziehen: verschieben · Klick auf den Namen: umbenennen";
      // der Klassenname hat sein Gegenstueck „class Figur:“ im Code daneben (Durchsicht iq1 klassen W12, 13.11.)
      nameEl.dataset.id = "k" + ki;
      if (zeigeId === "k" + ki) nameEl.classList.add("gezeigt");
      nameEl.addEventListener("pointerenter", () => zeigen("k" + ki)); nameEl.addEventListener("pointerleave", () => zeigen(""));
      if (edit && edit.k === ki && edit.art === "name") nameEl.append(feld(k.name, "name"));
      else {
        const s = h("span", "uml-klassenname", k.name || "Name?"); if (!k.name) s.classList.add("leer");
        if (k.name && (!NAME.test(k.name) || namen().filter(n => n === k.name).length > 1)) s.classList.add("falsch");
        const weg = h("button", "uml-weg", "×"); weg.type = "button"; weg.title = "Klasse löschen"; weg.tabIndex = -1;
        nameEl.append(s, weg);
      }
      box.append(nameEl, fach(k, ki, false), fach(k, ki, true));
      if (st() >= 2) { const a = h("span", "uml-anker"); a.title = "Ziehen: Beziehung zu einer anderen Klasse"; box.append(a); }
      return box;
    }
    function fach(k, ki, methode) {
      const el = h("div", "uml-fach " + (methode ? "methoden" : "attribute"));
      el.dataset.k = ki; el.dataset.f = methode ? "m" : "a";
      const zeilen = methode ? k.methoden : k.attribute;
      zeilen.forEach((t, i) => {
        const id = "k" + ki + "-" + (methode ? "m" : "a") + i;
        if (edit && edit.k === ki && edit.art === (methode ? "m" : "a") && edit.i === i) { el.append(feld(t, "zeile")); return; }
        const z = h("div", "uml-zeile"); z.dataset.id = id; z.dataset.i = i;
        const g = h("span", "uml-griff", "⋮⋮"); g.setAttribute("aria-hidden", "true"); g.title = "Ziehen: Zeile verschieben";
        z.append(g, h("span", "uml-text", t));
        if (tippt && tippt.id === id) z.classList.add("tippt");
        if (K.zeilePruefen(t, methode, namen()).length && !(tippt && tippt.id === id)) z.classList.add("falsch");
        if (zeigeId === id) z.classList.add("gezeigt");
        if (umgestellt && umgestellt.has(id)) z.classList.add("umgestellt");
        z.addEventListener("pointerenter", () => zeigen(id)); z.addEventListener("pointerleave", () => zeigen(""));
        el.append(z);
      });
      if (edit && edit.k === ki && edit.art === (methode ? "m" : "a") && edit.i === zeilen.length) el.append(feld(prefix(methode), "zeile"));
      const plus = h("button", "uml-plus", methode ? "+ Methode" : "+ Attribut"); plus.type = "button"; plus.tabIndex = -1;
      el.append(plus);
      return el;
    }
    // das Feld, in dem getippt wird -- so breit wie sein Text
    function feld(wert, art) {
      const f = h("input", "uml-feld"); f.value = wert; f.spellcheck = false; f.autocomplete = "off";
      const breite = () => { f.style.width = Math.max(art === "name" ? 6 : 12, f.value.length + 2) + "ch"; };
      breite();
      f.addEventListener("input", breite);
      f.addEventListener("keydown", e => {
        e.stopPropagation();
        if (e.key === "Enter") { e.preventDefault(); const war = edit; editEnde(true); if (war && war.art !== "name" && f.value.trim() && f.value.trim() !== prefix(war.art === "m").trim()) weiterTippen(war); else if (war && war.art === "name") ersteZeile(war.k); }
        else if (e.key === "Escape") { e.preventDefault(); editEnde(false); flaeche.focus({ preventScroll: true }); }
      });
      f.addEventListener("blur", () => setTimeout(() => { if (edit && edit.feld === f) editEnde(true); }, 0));
      setTimeout(() => { if (f.isConnected) { f.focus({ preventScroll: true }); f.setSelectionRange(f.value.length, f.value.length); } }, 0);
      if (edit) edit.feld = f;
      return f;
    }
    function editStart(e) { editEnde(true); menueZu(); edit = e; zeichnen(); }
    function editEnde(uebernehmen) {
      if (!edit) return;
      const e = edit; edit = null;
      const wert = e.feld ? e.feld.value : null;
      if (uebernehmen && wert != null) {
        const k = tisch.d.klassen[e.k];
        if (k && e.art === "name") {
          const neu = wert.trim(), alt = k.name;
          if (!neu && !k.attribute.length && !k.methoden.length) aendern(d => klasseWeg(d, e.k));
          else if (neu !== alt) aendern(d => {
            d.beziehungen.forEach(b => { if (b.von === alt) b.von = neu; if (b.nach === alt) b.nach = neu; });
            if (d.pos && d.pos[alt]) { d.pos[neu] = d.pos[alt]; delete d.pos[alt]; }
            d.klassen[e.k].name = neu;
          });
        } else if (k) {
          const l = e.art === "m" ? "methoden" : "attribute";
          const t = wert.trim(), leer = !t || t === "+" || t === "-" || t === "#";
          const alt = k[l][e.i];
          if (leer && alt !== undefined) aendern(d => { d.klassen[e.k][l].splice(e.i, 1); });
          else if (!leer && t !== alt) aendern(d => { if (alt === undefined) d.klassen[e.k][l].push(t); else d.klassen[e.k][l][e.i] = t; });
        }
      }
      zeichnen();
    }
    function klasseWeg(d, ki) {
      const n = d.klassen[ki].name;
      d.klassen.splice(ki, 1);
      d.beziehungen = d.beziehungen.filter(b => b.von !== n && b.nach !== n);
      if (d.pos) delete d.pos[n];
    }
    function weiterTippen(war) {         // Enter: gleich die naechste Zeile im selben Fach -- wie auf Papier
      const k = tisch.d.klassen[war.k]; if (!k) return;
      const l = war.art === "m" ? k.methoden : k.attribute;
      editStart({ k: war.k, art: war.art, i: Math.min(war.i + 1, l.length) });
    }
    function ersteZeile(ki) { const k = tisch.d.klassen[ki]; if (k && !k.attribute.length && !k.methoden.length) editStart({ k: ki, art: "a", i: 0 }); }

    // ── Lage: von Hand (d.pos) oder wie uml.py (Spalten nach der Breite, je Spalte die breiteste, oben buendig) ──
    const fs = () => parseFloat(getComputedStyle(buehne).fontSize) || 16;
    const boxen = () => [...buehne.querySelectorAll(".uml-kasten")];
    const lagenAusDom = () => boxen().map(b => ({ x: b.offsetLeft, y: b.offsetTop, b: b.offsetWidth, h: b.offsetHeight }));
    function automatisch(masse) {
      const RAND = 1.6 * fs(), NEBEN = 3.5 * fs(), UNTER = 2.6 * fs();
      const platz = Math.max(200, flaeche.clientWidth - 2 * RAND), n = masse.length;
      const breiteBei = sp => { const sb = []; masse.forEach((m, i) => { sb[i % sp] = Math.max(sb[i % sp] || 0, m.b); }); return { sb, ges: sb.reduce((a, x) => a + x, 0) + (sp - 1) * NEBEN }; };
      const lage = tisch.d.lage || "";
      let sp;
      if (lage === "untereinander") sp = 1;
      else if (lage === "nebeneinander") sp = n;
      else if (/^raster \d+$/.test(lage)) sp = +lage.split(" ")[1];
      else { sp = Math.min(n, 3); while (sp > 1 && breiteBei(sp).ges > platz) sp--; }
      const { sb, ges } = breiteBei(sp), zh = [];
      masse.forEach((m, i) => { const z = Math.floor(i / sp); zh[z] = Math.max(zh[z] || 0, m.h); });
      const links = RAND + Math.max(0, (platz - ges) / 2);
      return masse.map((m, i) => {
        const s = i % sp, z = Math.floor(i / sp);
        return { x: links + sb.slice(0, s).reduce((a, v) => a + v, 0) + s * NEBEN + (sb[s] - m.b) / 2, y: RAND + zh.slice(0, z).reduce((a, v) => a + v, 0) + z * UNTER };
      });
    }
    // ein freier Platz fuer eine neue Klasse, wenn von Hand gelegt wird: rechts neben die obere Reihe, sonst darunter
    function freierPlatz(lagen, b) {
      const RAND = 1.6 * fs(), NEBEN = 3.5 * fs(), UNTER = 2.6 * fs();
      if (!lagen.length) return { x: RAND, y: RAND };
      const oben = Math.min(...lagen.map(l => l.y)), reihe = lagen.filter(l => l.y < oben + 40);
      const x = Math.max(...reihe.map(l => l.x + l.b)) + NEBEN;
      if (x + (b || 160) < flaeche.clientWidth - RAND) return { x, y: oben };
      return { x: RAND, y: Math.max(...lagen.map(l => l.y + l.h)) + UNTER };
    }
    const einrasten = v => Math.max(0, Math.round(v / RASTER) * RASTER);
    function positionieren() {
      const bx = boxen();
      buehne.style.width = ""; buehne.style.height = "";
      if (!bx.length) return [];
      const masse = bx.map(b => ({ b: b.offsetWidth, h: b.offsetHeight }));
      let lagen;
      if (tisch.d.pos) {
        lagen = [];
        tisch.d.klassen.forEach((k, i) => {
          let p = tisch.d.pos[k.name];
          if (!p) { p = freierPlatz(lagen.filter(Boolean), masse[i].b); p = { x: einrasten(p.x), y: einrasten(p.y) }; tisch.d.pos[k.name] = p; }
          lagen[i] = { x: p.x, y: p.y, b: masse[i].b, h: masse[i].h };
        });
        // Wird die Flaeche schmaler (der Code geht daneben auf, das Fenster wird kleiner), ruecken von Hand gelegte
        // Kaesten gemeinsam nach links, bis sie wieder hineinpassen -- vorher sah man nur noch den linken Rand eines
        // Kastens (Durchsicht iq1 klassen W11, 13.11.). Die Lage untereinander bleibt, nur nach links und nie ueber
        // den Rand hinaus.
        const R = 1.6 * fs(), breit = flaeche.clientWidth;
        const rechts = Math.max(...lagen.map(l => l.x + l.b)), links = Math.min(...lagen.map(l => l.x));
        const dx = Math.floor(Math.min(rechts + R - breit, links - R) / RASTER) * RASTER;
        if (breit > 0 && dx > 0 && !zug) lagen.forEach((l, i) => { l.x -= dx; tisch.d.pos[tisch.d.klassen[i].name].x = l.x; });
      } else lagen = automatisch(masse).map((p, i) => ({ x: p.x, y: p.y, b: masse[i].b, h: masse[i].h }));
      lagen.forEach((l, i) => { bx[i].style.left = l.x + "px"; bx[i].style.top = l.y + "px"; });
      groesse(lagen);
      return lagen;
    }
    function groesse(lagen) {
      const R = 1.6 * fs();
      buehne.style.height = Math.max(9 * fs(), ...lagen.map(l => l.y + l.h + R)) + "px";
      buehne.style.width = Math.max(flaeche.clientWidth, ...lagen.map(l => l.x + l.b + R)) + "px";
    }
    function festhalten() {                     // vor dem ersten Ziehen: alle Kaesten bleiben, wo sie gerade liegen
      if (tisch.d.pos) return;
      const l = lagenAusDom(); tisch.d.pos = {};
      tisch.d.klassen.forEach((k, i) => { if (l[i]) tisch.d.pos[k.name] = { x: Math.round(l[i].x), y: Math.round(l[i].y) }; });
    }

    // die Strecke von Rand zu Rand (wie _strecke in uml.py) und das Zeichen am Ende (wie _spitze)
    function schnitt(a, cx, cy, zx, zy) { const dx = zx - cx, dy = zy - cy; const t = Math.min(dx ? (a.b / 2) / Math.abs(dx) : Infinity, dy ? (a.h / 2) / Math.abs(dy) : Infinity); return [cx + dx * t, cy + dy * t]; }
    function strecke(a, b) {
      const ox = [Math.max(a.x, b.x), Math.min(a.x + a.b, b.x + b.b)], oy = [Math.max(a.y, b.y), Math.min(a.y + a.h, b.y + b.h)];
      if (ox[1] - ox[0] >= 24) { const x = (ox[0] + ox[1]) / 2; return a.y < b.y ? [x, a.y + a.h, x, b.y] : [x, a.y, x, b.y + b.h]; }
      if (oy[1] - oy[0] >= 24) { const y = (oy[0] + oy[1]) / 2; return a.x < b.x ? [a.x + a.b, y, b.x, y] : [a.x, y, b.x + b.b, y]; }
      const ac = [a.x + a.b / 2, a.y + a.h / 2], bc = [b.x + b.b / 2, b.y + b.h / 2];
      return schnitt(a, ac[0], ac[1], bc[0], bc[1]).concat(schnitt(b, bc[0], bc[1], ac[0], ac[1]));
    }
    function spitze(x1, y1, x2, y2, art) {
      const l = Math.hypot(x2 - x1, y2 - y1) || 1, ux = (x2 - x1) / l, uy = (y2 - y1) / l, nx = -uy, ny = ux;
      const p = (a, q) => (x2 - ux * a + nx * q).toFixed(1) + "," + (y2 - uy * a + ny * q).toFixed(1);
      if (art === "<>-") return ['<polygon class="leer" points="' + [p(0, 0), p(9, 6), p(18, 0), p(9, -6)].join(" ") + '"/>', p(18, 0)];
      if (art === "--|>") return ['<polygon class="leer" points="' + [p(0, 0), p(14, 8), p(14, -8)].join(" ") + '"/>', p(14, 0)];
      return ['<polyline class="pfeil" points="' + [p(12, 7), p(0, 0), p(12, -7)].join(" ") + '"/>', p(0, 0)];
    }
    function linienZeichnen(lagen) {
      lagen = lagen || lagenAusDom();
      const idx = new Map(tisch.d.klassen.map((k, i) => [k.name, i]));
      let svg = "";
      tisch.d.beziehungen.forEach((b, i) => {
        const a = lagen[idx.get(b.von)], c = lagen[idx.get(b.nach)];
        if (!a || !c) return;
        // die Raute beim Haltenden (von): die Strecke laeuft vom Teil zum Ganzen, das Zeichen sitzt an ihrem Ende
        const [x1, y1, x2, y2] = b.art === "<>-" ? strecke(c, a) : strecke(a, c);
        const [zeichen, ende] = spitze(x1, y1, x2, y2, b.art);
        const [ex, ey] = ende.split(",");
        const gew = auswahl && auswahl.art === "bez" && auswahl.i === i ? " gewaehlt" : "";
        const linie = 'x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + ex + '" y2="' + ey + '"';
        svg += '<g class="bez' + gew + '" data-i="' + i + '"><line class="treffer" data-i="' + i + '" x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '"/><line ' + linie + "/>" + zeichen + "</g>";
      });
      if (zug && zug.art === "bez" && zug.bewegt) {
        const a = lagen[zug.k];
        if (a) {
          const ziel = zug.ziel != null ? lagen[zug.ziel] : null;
          const [x1, y1, x2, y2] = ziel ? strecke(a, ziel) : schnitt(a, a.x + a.b / 2, a.y + a.h / 2, zug.x, zug.y).concat([zug.x, zug.y]);
          svg += '<line class="gummi" x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '"/><circle class="gummi-ende" cx="' + x2.toFixed(1) + '" cy="' + y2.toFixed(1) + '" r="4"/>';
        }
      }
      // als Text gesetzt, ohne xmlns -- K5 duldet keine externe Adresse in der Seite (wie die Werkstatt Struktogramm)
      linien.innerHTML = '<svg width="' + buehne.offsetWidth + '" height="' + buehne.offsetHeight + '" aria-hidden="true">' + svg + "</svg>";
    }
    const linienBald = () => { if (rafLinien) return; rafLinien = requestAnimationFrame(() => { rafLinien = 0; linienZeichnen(); }); };

    // ── Unten: Meldungen der Zeilen, Saetze der Beziehungen, Pruefen ──
    function untenZeichnen() {
      unten.textContent = "";
      const fehl = h("div", "uml-meldungen");
      tisch.d.klassen.forEach((k, ki) => {
        if (k.name && (!NAME.test(k.name) || namen().filter(n => n === k.name).length > 1))
          fehl.append(meldung(k.name, "Klasse", NAME.test(k.name) ? "Die Klasse " + k.name + " steht zweimal da – jede Klasse gibt es einmal" : "Ein Klassenname ist ein Wort, groß geschrieben, ohne Leerzeichen", "", { k: ki, art: "name" }));
        [false, true].forEach(methode => (methode ? k.methoden : k.attribute).forEach((t, i) => {
          const bef = K.zeilePruefen(t, methode, namen());
          if (!bef.length || (tippt && tippt.id === "k" + ki + "-" + (methode ? "m" : "a") + i)) return;
          const satz = [...new Set(K.saetze(bef, tisch.stufe, methode))];
          let form = bef[0].code === "methode_im_attributfach" ? "" : K.vorschlag(t, methode);
          if (form === t.trim()) form = "";
          fehl.append(meldung(k.name || "Klasse", methode ? "Methode" : "Attribut", satz.join(". "), form, { k: ki, art: methode ? "m" : "a", i }));
        }));
      });
      if (fehl.children.length) unten.append(fehl);
      if (st() >= 2 && tisch.d.beziehungen.length) {
        const sl = h("div", "uml-saetze");
        tisch.d.beziehungen.forEach((b, i) => {
          const z = h("div", "uml-satz");
          if (auswahl && auswahl.art === "bez" && auswahl.i === i) z.classList.add("gewaehlt");
          z.append(h("span", "uml-satz-chip", "gelesen"), h("b", "", K.satz(b)));
          const dreh = h("button", "ruhig", "⇄"); dreh.type = "button"; dreh.title = "umdrehen"; dreh.setAttribute("aria-label", "umdrehen");
          dreh.addEventListener("click", () => { aendern(d => { const x = d.beziehungen[i]; [x.von, x.nach] = [x.nach, x.von]; }); zeichnen(); });
          const weg = h("button", "ruhig", "×"); weg.type = "button"; weg.title = "Beziehung löschen"; weg.setAttribute("aria-label", "Beziehung löschen");
          weg.addEventListener("click", () => { aendern(d => { d.beziehungen.splice(i, 1); }); auswahl = null; zeichnen(); });
          z.append(dreh, weg); sl.append(z);
        });
        unten.append(sl);
      }
      if (pruefung) {
        const p = h("div", "uml-pruefung " + (pruefung.ok ? "ok" : "offen"));
        p.append(h("div", "uml-pruefung-titel", (entwurf ? "Selbstcheck" : "Geprüft") + (pruefung.ok ? ": passt" : ": noch nicht") + (pruefung.zuletzt ? " (zuletzt – nach einer Änderung noch einmal)" : "")));
        const ul = h("ul"); pruefung.meldungen.forEach(m => ul.append(h("li", "", m.text))); p.append(ul);
        unten.append(p);
      }
    }
    function meldung(klasse, art, satz, form, ziel) {
      const z = h("div", "uml-meldung");
      z.append(h("span", "uml-meldung-chip", klasse + " · " + art), h("span", "uml-meldung-satz", satz + (form ? ":" : ".")));
      if (form) z.append(h("code", "", form));
      if (ziel) { z.classList.add("klickbar"); z.title = "zur Zeile"; z.addEventListener("click", () => editStart(ziel)); }
      return z;
    }

    // ── Python daneben ──
    function pythonZeichnen() {
      pyEl.hidden = !pyAn; kPy.classList.toggle("an", pyAn); kPy.setAttribute("aria-pressed", String(pyAn)); mitte.classList.toggle("mit-py", pyAn);
      if (!pyAn) return;
      pyEl.textContent = "";
      const pre = h("pre", "uml-code");
      K.python(tisch.d).forEach(z => {
        const zeile = h("span", "py-zeile"); zeile.dataset.id = z.id;
        if (z.id && z.id === zeigeId) zeile.classList.add("gezeigt");
        farbig(zeile, z.text || " ");
        if (z.id) { zeile.addEventListener("pointerenter", () => zeigen(z.id)); zeile.addEventListener("pointerleave", () => zeigen("")); }
        pre.append(zeile, "\n");
      });
      const rot = tisch.d.klassen.some(k => k.attribute.some(t => K.zeilePruefen(t, false, namen()).length) || k.methoden.some(t => K.zeilePruefen(t, true, namen()).length));
      pyEl.append(pre);
      if (rot) pyEl.append(h("p", "uml-py-rot", "Rote Zeilen stehen hier erst, wenn sie stimmen."));
      const leg = h("p", "uml-legende");
      [["String", "str"], ["integer", "int"], ["boolean", "bool"], ["- __init__(…)", "def __init__(self, …)"], [": boolean", "-> bool"]]
        .concat(st() >= 1 ? [["- zeile", "self.__zeile"]] : []).forEach(([a, b]) => { const s = h("span", "paar"); s.append(h("b", "", a), " → ", h("b", "", b)); leg.append(s, " "); });
      pyEl.append(leg);
    }
    function farbig(el, text) {
      const rx = /(\bclass\b|\bdef\b|\bpass\b|\bself\b|\bNone\b|\bFalse\b)|(\b(?:str|int|float|bool|list)\b)|("[^"]*"|\b\d+(?:\.\d+)?\b)/g;
      let i = 0, m;
      while ((m = rx.exec(text))) { el.append(text.slice(i, m.index)); el.append(h("span", m[1] ? "py-wort" : m[2] ? "py-typ" : "py-wert", m[0])); i = m.index + m[0].length; }
      el.append(text.slice(i));
    }
    function zeigen(id) {
      if (!pyAn || zug) id = "";                 // das Gegenstueck gibt es nur, wenn der Code daneben steht
      if (zeigeId === id) return; zeigeId = id;
      buehne.querySelectorAll(".uml-zeile, .uml-name").forEach(z => z.classList.toggle("gezeigt", !!id && z.dataset.id === id));
      pyEl.querySelectorAll(".py-zeile").forEach(z => z.classList.toggle("gezeigt", !!id && z.dataset.id === id));
    }

    // ── Menue an der Stelle: die Art einer neuen Beziehung als Satz, oder was mit einer Linie geschehen soll ──
    function menueZu() { if (menue) { menue.remove(); menue = null; } }
    function menueAuf(p, titel, eintraege) {
      menueZu();
      menue = h("div", "uml-menue"); menue.setAttribute("role", "menu");
      if (titel) menue.append(h("div", "uml-menue-titel", titel));
      eintraege.forEach(([zeichen, text, tun, cls]) => {
        const b = h("button", "uml-menue-eintrag" + (cls ? " " + cls : "")); b.type = "button"; b.setAttribute("role", "menuitem");
        b.append(h("span", "uml-menue-zeichen", zeichen), h("span", "", text));
        b.addEventListener("click", ev => { ev.stopPropagation(); menueZu(); tun(); });
        menue.append(b);
      });
      buehne.append(menue);
      const w = menue.offsetWidth, hh = menue.offsetHeight;
      menue.style.left = Math.max(4, Math.min(p.x + 10, buehne.offsetWidth - w - 4)) + "px";
      menue.style.top = Math.max(4, Math.min(p.y + 10, buehne.offsetHeight - hh - 4)) + "px";
      const erster = menue.querySelector("button"); if (erster) erster.focus({ preventScroll: true });
    }
    const arten = () => ARTEN.filter(a => a[0] !== "--|>" || st() >= 3);
    function neueBeziehungFragen(von, nach, p) {
      const a = tisch.d.klassen[von].name, b = tisch.d.klassen[nach].name;
      menueAuf(p, "Welche Beziehung?", arten().map(([art, z]) => [z, K.satz({ von: a, art, nach: b }), () => verbinden(von, nach, art)]));
    }
    function linieFragen(i, p) {
      const b = tisch.d.beziehungen[i]; if (!b) return;
      auswahl = { art: "bez", i }; zeichnen();
      const andere = arten().filter(a => a[0] !== b.art).map(([art, z, wort]) => [z, "stattdessen: " + K.satz({ von: b.von, art, nach: b.nach }), () => { aendern(d => { d.beziehungen[i].art = art; }); zeichnen(); }]);
      menueAuf(p, K.satz(b), [["⇄", "umdrehen: " + K.satz({ von: b.nach, art: b.art, nach: b.von }), () => { aendern(d => { const x = d.beziehungen[i]; [x.von, x.nach] = [x.nach, x.von]; }); zeichnen(); }]]
        .concat(andere, [["×", "Beziehung löschen", () => { aendern(d => { d.beziehungen.splice(i, 1); }); auswahl = null; zeichnen(); }, "gefahr"]]));
    }
    function verbinden(a, b, art) {
      const von = tisch.d.klassen[a].name, nach = tisch.d.klassen[b].name;
      aendern(d => { d.beziehungen = d.beziehungen.filter(x => !((x.von === von && x.nach === nach) || (x.von === nach && x.nach === von))); d.beziehungen.push({ von, art, nach }); });
      auswahl = null; zeichnen();
    }
    function neueKlasse(p) {
      editEnde(true); menueZu();
      let ki;
      aendern(d => {
        if (p) festhalten();
        d.klassen.push({ name: "", attribute: [], methoden: [] }); ki = d.klassen.length - 1;
        if (p && d.pos) d.pos[""] = { x: einrasten(p.x - 60), y: einrasten(p.y - 14) };
      });
      edit = { k: ki, art: "name" };
      zeichnen();
    }

    // ── alles zeichnen ──
    function zeichnen() {
      tische.forEach(t => { t.knopf.classList.toggle("an", t === tisch); t.knopf.setAttribute("aria-pressed", String(t === tisch)); });
      kPy.hidden = !tisch.python; if (!tisch.python) pyAn = false;
      kPruef.hidden = !tisch.soll && !entwurf;
      kRueck.disabled = !tisch.rueck.length; kVor.disabled = !tisch.vor.length;
      kOrdnen.disabled = !tisch.d.pos;
      const offenesMenue = menue; menue = null;
      buehne.textContent = "";
      buehne.append(linien);
      tisch.d.klassen.forEach((k, i) => buehne.append(kasten(k, i)));
      if (!tisch.d.klassen.length) buehne.append(h("p", "uml-leer", "Leer. Doppelklick legt eine Klasse an – oder „+ Klasse“."));
      untenZeichnen();
      pythonZeichnen();                   // vor dem Anordnen: der Code daneben nimmt der Flaeche Breite
      linienZeichnen(positionieren());
      if (offenesMenue) { buehne.append(offenesMenue); menue = offenesMenue; }
      neuName = "";
      const t = MAC ? "⌘" : "Strg", kb = s => "<kbd>" + s + "</kbd>";
      kuerzel.innerHTML = [kb("Doppelklick") + " ins Leere: neue Klasse", "Kopf ziehen: verschieben", kb("⋮⋮") + " ziehen: Zeile verschieben",
        st() >= 2 ? kb("●") + " ziehen: Beziehung" : "", kb("Enter") + " nächste Zeile", kb("Entf") + " Gewähltes löschen",
        kb(t) + "+" + kb("Z") + " rückgängig"].filter(Boolean).join(" · ");
      if (edit && edit.feld && !edit.feld.isConnected) edit = null;
    }

    // ── Zeiger: ein Satz Ereignisse an der Flaeche ──
    const punkt = ev => { const r = buehne.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
    const kastenAm = el => { const b = el && el.closest && el.closest(".uml-kasten"); return b && buehne.contains(b) ? +b.dataset.k : null; };
    flaeche.addEventListener("pointerdown", ev => {
      if (ev.button !== 0 || tippt) return;
      if (ev.target.closest(".uml-menue")) return;
      if (ev.target.closest(".uml-feld")) return;          // im Feld: Text markieren wie gewohnt
      if (edit) editEnde(true);                            // die Zeile gilt, sobald man woanders hinfasst
      if (menue) { menueZu(); if (!ev.target.closest(".uml-kasten, .treffer")) { ev.preventDefault(); return; } }
      const el = document.elementFromPoint(ev.clientX, ev.clientY) || ev.target;
      const p = punkt(ev), k = kastenAm(el);
      zug = { el, p0: p, x: p.x, y: p.y, cx: ev.clientX, cy: ev.clientY, bewegt: false, art: "tippen", k };
      if (el.closest(".uml-anker") && k != null) zug.art = "bez";
      else if (el.closest(".uml-griff")) {
        const f = el.closest(".uml-fach"), z = el.closest(".uml-zeile");
        Object.assign(zug, { art: "zeile", k: +f.dataset.k, f: f.dataset.f, i: +z.dataset.i });
      } else if (el.closest(".uml-name") && !el.closest(".uml-weg") && k != null) {
        const b = boxen()[k];
        Object.assign(zug, { art: "kasten", x0: b.offsetLeft, y0: b.offsetTop });
      } else if (el.closest(".treffer")) Object.assign(zug, { art: "linie", i: +el.closest(".treffer").dataset.i });
      flaeche.setPointerCapture(ev.pointerId);
      flaeche.focus({ preventScroll: true });
      ev.preventDefault();
    });
    flaeche.addEventListener("pointermove", ev => {
      if (!zug) return;
      const p = punkt(ev);
      if (!zug.bewegt && Math.hypot(ev.clientX - zug.cx, ev.clientY - zug.cy) < 4) return;
      const erstes = !zug.bewegt; zug.bewegt = true; zug.x = p.x; zug.y = p.y;
      if (zug.art === "kasten") {
        if (erstes) { aendern(() => festhalten()); wurzel.classList.add("zieht"); boxen()[zug.k].classList.add("gezogen"); }
        const n = tisch.d.klassen[zug.k].name, nx = einrasten(zug.x0 + p.x - zug.p0.x), ny = einrasten(zug.y0 + p.y - zug.p0.y);
        tisch.d.pos[n] = { x: nx, y: ny };
        const b = boxen()[zug.k]; b.style.left = nx + "px"; b.style.top = ny + "px";
        groesse(lagenAusDom()); linienBald();
      } else if (zug.art === "bez") {
        const ziel = kastenAm(document.elementFromPoint(ev.clientX, ev.clientY));
        zug.ziel = ziel != null && ziel !== zug.k ? ziel : null;
        boxen().forEach((b, i) => { b.classList.toggle("ziel", i === zug.ziel); b.classList.toggle("anfang", i === zug.k); });
        wurzel.classList.add("zieht"); linienBald();
      } else if (zug.art === "zeile") zeileZiehen(ev, p, erstes);
    });
    const loslassen = ev => {
      if (!zug) return;
      const z = zug; zug = null;
      try { flaeche.releasePointerCapture(ev.pointerId); } catch (e) {}
      wurzel.classList.remove("zieht");
      if (z.art === "kasten" && z.bewegt) { merken(tisch); zeichnen(); return; }
      if (z.art === "bez" && z.bewegt) {
        boxen().forEach(b => b.classList.remove("ziel", "anfang"));
        if (z.ziel != null) neueBeziehungFragen(z.k, z.ziel, { x: z.x, y: z.y });
        linienZeichnen(); return;
      }
      if (z.art === "zeile" && z.bewegt) { zeileAblegen(z); return; }
      if (z.art === "linie") { linieFragen(z.i, { x: z.x, y: z.y }); return; }
      if (ev.type === "pointerup") tippenAuf(z.el, z.k);
    };
    flaeche.addEventListener("pointerup", loslassen);
    flaeche.addEventListener("pointercancel", loslassen);
    // ein Tipp ohne Ziehen: Zeile oeffnen, Namen aendern, Zeile anlegen, Klasse loeschen, waehlen
    function tippenAuf(el, k) {
      if (!el || !el.closest) return;
      if (el.closest(".uml-plus")) { const f = el.closest(".uml-fach"); const kl = tisch.d.klassen[+f.dataset.k]; editStart({ k: +f.dataset.k, art: f.dataset.f, i: (f.dataset.f === "m" ? kl.methoden : kl.attribute).length }); return; }
      if (el.closest(".uml-weg") && k != null) { aendern(d => klasseWeg(d, k)); auswahl = null; zeichnen(); return; }
      const z = el.closest(".uml-zeile");
      if (z) { const f = z.closest(".uml-fach"); editStart({ k: +f.dataset.k, art: f.dataset.f, i: +z.dataset.i }); return; }
      if (el.closest(".uml-klassenname") && k != null) { auswahl = { art: "klasse", k }; editStart({ k, art: "name" }); return; }
      if (k != null) { auswahl = { art: "klasse", k }; zeichnen(); return; }
      if (auswahl) { auswahl = null; zeichnen(); }
    }
    // ein Klick ohne Zeiger (Tastatur, Skript, Bildschirmleser) auf „+ Attribut“ oder × -- der Zeiger kommt ueber tippenAuf
    flaeche.addEventListener("click", ev => { if (ev.detail === 0 && ev.target.closest && ev.target.closest(".uml-plus, .uml-weg")) tippenAuf(ev.target, kastenAm(ev.target)); });
    flaeche.addEventListener("dblclick", ev => {
      const el = document.elementFromPoint(ev.clientX, ev.clientY);
      if (!el || el.closest(".uml-kasten, .treffer, .uml-menue, .uml-feld")) return;
      neuName = ""; neueKlasse(punkt(ev));
    });
    // Zeile ziehen: ein Schatten folgt dem Zeiger, eine Linie zeigt, wo sie landet
    let geist = null, marke = null;
    function zeileZiehen(ev, p, erstes) {
      if (erstes) {
        const k = tisch.d.klassen[zug.k], t = (zug.f === "m" ? k.methoden : k.attribute)[zug.i];
        geist = h("div", "uml-geist", t); marke = h("div", "uml-marke");
        buehne.append(geist, marke);
        const z = buehne.querySelector('.uml-fach[data-k="' + zug.k + '"][data-f="' + zug.f + '"] .uml-zeile[data-i="' + zug.i + '"]');
        if (z) z.classList.add("zieht-weg");
        wurzel.classList.add("zieht");
      }
      geist.style.left = (p.x + 12) + "px"; geist.style.top = (p.y - 10) + "px";
      geist.hidden = true;
      const el = document.elementFromPoint(ev.clientX, ev.clientY);
      geist.hidden = false;
      const f = el && el.closest && el.closest(".uml-fach");
      zug.ziel = null; marke.hidden = true;
      if (!f || !buehne.contains(f)) return;
      const zs = [...f.querySelectorAll(".uml-zeile")];
      let i = zs.filter(z => { const r = z.getBoundingClientRect(); return r.top + r.height / 2 < ev.clientY; }).length;
      const br = buehne.getBoundingClientRect(), fr = f.getBoundingClientRect();
      const y = zs.length ? (i < zs.length ? zs[i].getBoundingClientRect().top : zs[zs.length - 1].getBoundingClientRect().bottom) : fr.top + 4;
      Object.assign(marke.style, { left: (fr.left - br.left + 4) + "px", width: (fr.width - 8) + "px", top: (y - br.top - 1) + "px" });
      marke.hidden = false;
      zug.ziel = { k: +f.dataset.k, f: f.dataset.f, i };
    }
    function zeileAblegen(z) {
      if (geist) geist.remove(); if (marke) marke.remove(); geist = marke = null;
      const ziel = z.ziel;
      if (ziel && !(ziel.k === z.k && ziel.f === z.f && (ziel.i === z.i || ziel.i === z.i + 1))) {
        aendern(d => {
          const quelle = z.f === "m" ? d.klassen[z.k].methoden : d.klassen[z.k].attribute;
          const [t] = quelle.splice(z.i, 1);
          const zl = ziel.f === "m" ? d.klassen[ziel.k].methoden : d.klassen[ziel.k].attribute;
          zl.splice(ziel.k === z.k && ziel.f === z.f && ziel.i > z.i ? ziel.i - 1 : ziel.i, 0, t);
        });
      }
      zeichnen();
    }
    // Tasten an der Werkstatt (nicht im Feld): rueckgaengig, wiederholen, loeschen, abbrechen
    wurzel.addEventListener("keydown", ev => {
      if (ev.target.closest(".uml-feld")) return;
      const mod = MAC ? ev.metaKey : ev.ctrlKey;
      if (mod && (ev.key === "z" || ev.key === "Z")) { ev.preventDefault(); if (ev.shiftKey) wiederholen(); else rueckgaengig(); return; }
      if (mod && (ev.key === "y" || ev.key === "Y")) { ev.preventDefault(); wiederholen(); return; }
      if (ev.key === "Escape") {
        if (zug) { if (geist) geist.remove(); if (marke) marke.remove(); geist = marke = null; zug = null; wurzel.classList.remove("zieht"); zeichnen(); }
        else if (menue) menueZu(); else if (auswahl) { auswahl = null; zeichnen(); }
        return;
      }
      if ((ev.key === "Delete" || ev.key === "Backspace") && auswahl && flaeche.contains(ev.target) && !ev.target.closest(".uml-menue")) {
        ev.preventDefault();
        const a = auswahl; auswahl = null; menueZu();
        aendern(d => { if (a.art === "klasse") klasseWeg(d, a.k); else d.beziehungen.splice(a.i, 1); });
        zeichnen();
      }
    });
    // Knoepfe der Kopfzeile -- und Tastatur auf „+ Attribut“ / ×, die sonst nur der Zeiger erreicht
    kKlasse.addEventListener("click", () => neueKlasse(null));
    kRueck.addEventListener("click", rueckgaengig);
    kVor.addEventListener("click", wiederholen);
    kOrdnen.addEventListener("click", () => {
      editEnde(true);
      const vorher = lagenAusDom();
      aendern(d => { d.pos = null; });
      zeichnen();
      if (RUHIG) return;
      // gleiten lassen: von der alten Lage in die neue, die Linien laufen mit (Bewegung zeigt hier etwas: wohin)
      const bx = boxen(), nachher = lagenAusDom();
      bx.forEach((b, i) => { if (vorher[i]) { b.style.transition = "none"; b.style.left = vorher[i].x + "px"; b.style.top = vorher[i].y + "px"; } });
      void buehne.offsetWidth;
      bx.forEach((b, i) => { b.style.transition = ""; b.classList.add("gleitet"); b.style.left = nachher[i].x + "px"; b.style.top = nachher[i].y + "px"; });
      const ende = performance.now() + 260;
      const lauf = () => { linienZeichnen(); if (performance.now() < ende) requestAnimationFrame(lauf); else bx.forEach(b => b.classList.remove("gleitet")); };
      requestAnimationFrame(lauf);
    });
    // Zoom: die Schrift der Werkstatt eine Stufe kleiner oder groesser; von Hand gelegte Kaesten wandern mit, sonst
    // ueberlappten sie beim Vergroessern
    let eigeneStufe = 1;
    function zoomen(d) {
      const vor = fs();
      if (typeof schriftAendern === "function") schriftAendern(d, "werkstatt");
      else { eigeneStufe = Math.max(0.6, Math.min(1.8, eigeneStufe + d * 0.15)); wurzel.style.fontSize = (eigeneStufe * 100) + "%"; }
      const nach = fs();
      if (tisch.d.pos && vor && nach && Math.abs(nach - vor) > 0.01) {
        const f = nach / vor;
        Object.values(tisch.d.pos).forEach(p => { p.x = einrasten(p.x * f); p.y = einrasten(p.y * f); });
      }
      zeichnen();
    }
    kKlein.addEventListener("click", () => zoomen(-1));
    kGross.addEventListener("click", () => zoomen(1));
    kNeu.addEventListener("click", () => { edit = null; aendern(d => { const s = kopie(tisch.start); d.klassen = s.klassen; d.beziehungen = s.beziehungen; d.lage = s.lage; d.pos = null; }); auswahl = null; pyAn = false; zeichnen(); });
    kPy.addEventListener("click", () => { pyAn = !pyAn; zeichnen(); });
    kPruef.addEventListener("click", pruefen);
    async function pruefen() {
      editEnde(true);
      if (entwurf) {
        if (!opt.selbstcheck) return null;
        kPruef.disabled = true;
        try { const r = await opt.selbstcheck(kopie(tisch.d)); pruefung = r ? { ok: !!r.ok, meldungen: (r.meldungen || []).map(text => ({ text })) } : null; }
        finally { kPruef.disabled = false; }
        zeichnen(); return pruefung;
      }
      pruefung = tisch.soll ? K.vergleichen(tisch.d, tisch.soll, tisch.stufe) : null; zeichnen(); return pruefung;
    }
    let breiteVorher = 0;
    // erst im naechsten Bild neu anordnen -- im Rueckruf selbst aenderte sich die Groesse noch einmal, und der Browser
    // meldete „ResizeObserver loop completed with undelivered notifications“ (diagrammseite.mjs, 13.11.)
    let rafGroesse = 0;
    if (window.ResizeObserver) new ResizeObserver(() => { if (rafGroesse) return; rafGroesse = requestAnimationFrame(() => { rafGroesse = 0; const b = wurzel.clientWidth; if (b && Math.abs(b - breiteVorher) > 2 && !edit && !zug) { breiteVorher = b; linienZeichnen(positionieren()); } }); }).observe(wurzel);

    // ── Film (LV10): die kleinen Schritte bedienen die Werkstatt ──
    //   + klasse: Figur · + attribut: Figur | + art: String · + methode: Figur | + ziehe(…) · + ersetze: Figur | alt | neu
    //   + hat: Spielfeld Figur · + kennt: Zug Figur · + erbt: Dame Figur · + umdrehen: Figur Spielfeld
    //   + zeichen: Figur | - | art farbe zeile spalte  (nur das Zeichen vorn, alle genannten Zeilen in EINEM Schritt;
    //     ohne Namen: alle Attribute -- Durchsicht iq1 kapsel, W5, 14.11.2026: „Nicht alles neu schreiben, nur (in einem
    //     Schritt) aus den + ein - machen“)
    //   + pruefen · + python · + tisch: figur · + neu · + halt
    const teileArg = x => String(x.befehl || "").split("|").map(s => s.trim());
    const kIdx = n => tisch.d.klassen.findIndex(k => k.name === n);
    function filmSchritt(x, animiert) {
      const a = x.aktion;
      umgestellt = null;   // das Leuchten gilt nur fuer seinen Schritt
      if (a === "neu") { tisch.d = kopie(tisch.start); tisch.rueck = []; tisch.vor = []; pyAn = false; pruefung = null; auswahl = null; edit = null; menueZu(); }
      else if (a === "tisch") { const t = tische.find(t => t.kennung === x.wert || t.name === x.wert); if (t) { tisch = t; pruefung = null; } }
      else if (a === "klasse") { const n = String(x.befehl || "").trim(); if (n && kIdx(n) < 0) { aendern(d => d.klassen.push({ name: n, attribute: [], methoden: [] })); neuName = animiert ? n : ""; } }
      else if (a === "attribut" || a === "methode") {
        const [n, ...r] = teileArg(x); const t = r.join(" | "); let ki = kIdx(n);
        if (ki < 0) { aendern(d => d.klassen.push({ name: n, attribute: [], methoden: [] })); ki = tisch.d.klassen.length - 1; }
        const l = a === "methode" ? "methoden" : "attribute";
        if (animiert) { tippenAnimiert(ki, l, null, t); return; }
        aendern(d => d.klassen[ki][l].push(t));
      } else if (a === "ersetze") {
        const [n, alt, neu] = teileArg(x); const ki = kIdx(n); if (ki < 0) return;
        const k = tisch.d.klassen[ki]; const l = k.attribute.includes(alt) ? "attribute" : k.methoden.includes(alt) ? "methoden" : null; if (!l) return;
        const i = k[l].indexOf(alt);
        if (animiert) { tippenAnimiert(ki, l, i, neu); return; }
        aendern(d => { d.klassen[ki][l][i] = neu; });
      } else if (a === "zeichen") {
        const [n, z, liste] = teileArg(x); const ki = kIdx(n); if (ki < 0 || !/^[-+#~]$/.test(z || "")) return;
        const wahl = String(liste || "").split(/\s+/).filter(Boolean);
        const name = t => t.replace(/^[-+#~]\s*/, "").split(/[:(]/)[0].trim();
        const ids = [];
        aendern(d => { const k = d.klassen[ki]; ["attribute", "methoden"].forEach(l => k[l].forEach((t, i) => {
          if (!(wahl.length ? wahl.includes(name(t)) : l === "attribute") || !/^[-+#~]/.test(t) || t[0] === z) return;
          k[l][i] = z + t.slice(1); ids.push("k" + ki + "-" + (l === "methoden" ? "m" : "a") + i);
        })); });
        // die geaenderten Zeilen leuchten kurz auf -- nichts wird neu getippt
        if (animiert && ids.length) { const meins = umgestellt = new Set(ids); setTimeout(() => { if (umgestellt === meins) { umgestellt = null; zeichnen(); } }, 1600); }
      } else if (a === "hat" || a === "kennt" || a === "erbt") {
        const v = kIdx(x.von), n = kIdx(x.nach); if (v >= 0 && n >= 0) verbinden(v, n, { hat: "<>-", kennt: "->", erbt: "--|>" }[a]);
      } else if (a === "umdrehen") {
        aendern(d => d.beziehungen.forEach(b => { if ((b.von === x.von && b.nach === x.nach) || (b.von === x.nach && b.nach === x.von)) [b.von, b.nach] = [b.nach, b.von]; }));
      } else if (a === "pruefen") { pruefung = tisch.soll ? K.vergleichen(tisch.d, tisch.soll, tisch.stufe) : null; }
      else if (a === "python") { pyAn = tisch.python; }
      zeichnen();
    }
    // sichtbar tippen: Zeichen fuer Zeichen in die Zeile, geprueft wird beim Ende (wie beim Verlassen der Zeile)
    function tippenAnimiert(ki, l, i, text) {
      const nr = ++tippen;
      aendern(d => { if (i == null) d.klassen[ki][l].push(""); else d.klassen[ki][l][i] = ""; });
      const pos = i == null ? tisch.d.klassen[ki][l].length - 1 : i;
      const id = "k" + ki + "-" + (l === "methoden" ? "m" : "a") + pos;
      tippt = { id };
      let n = 0;
      const schritt = () => {
        if (nr !== tippen) return;
        n++;
        tisch.d.klassen[ki][l][pos] = text.slice(0, n);
        const z = buehne.querySelector('.uml-zeile[data-id="' + id + '"] .uml-text');
        if (z) z.textContent = text.slice(0, n);
        if (n < text.length) setTimeout(schritt, RUHIG ? 0 : 45);
        else { tippt = false; merken(tisch); zeichnen(); }
      };
      zeichnen();
      setTimeout(schritt, RUHIG ? 0 : 120);
    }
    function filmHerstellen(l) {
      tippen++; tippt = false; umgestellt = null;
      tisch = tische[0]; tisch.d = kopie(tisch.start); tisch.rueck = []; tisch.vor = []; pyAn = false; pruefung = null; auswahl = null; edit = null; menueZu();
      l.forEach(x => filmSchritt(x, false));
      zeichnen();
    }

    zeichnen();
    return {
      stand: () => ({ tisch: tisch.kennung, stufe: tisch.stufe, quelle: K.schreiben(tisch.d), klassen: tisch.d.klassen.map(k => k.name),
        falsch: [...buehne.querySelectorAll(".uml-zeile.falsch .uml-text")].map(z => z.textContent),
        meldungen: [...unten.querySelectorAll(".uml-meldung")].map(z => z.textContent),
        saetze: [...unten.querySelectorAll(".uml-satz b")].map(z => z.textContent),
        pruefung: pruefung ? { ok: pruefung.ok, meldungen: pruefung.meldungen.map(m => m.text) } : null,
        python: pyAn ? pyEl.querySelector("pre").textContent : null,
        beziehungenZiehen: !!buehne.querySelector(".uml-anker"), arten: arten().filter(() => st() >= 2).map(a => a[2]),
        pythonKnopf: !kPy.hidden, vonHand: !!tisch.d.pos, menue: menue ? [...menue.querySelectorAll("button")].map(b => b.textContent) : null,
        auswahl: auswahl ? Object.assign({}, auswahl) : null }),
      quelle: () => K.schreiben(tisch.d), modell: () => kopie(tisch.d),
      pruefen, python: an => { pyAn = an !== false && tisch.python; zeichnen(); },
      tisch: k => { const t = tische.find(t => t.kennung === k || t.name === k); if (t) { tisch = t; zeichnen(); } },
      tische: () => tische.map(t => t.kennung),
      film: { spielen: x => filmSchritt(x, true), herstellen: filmHerstellen, laeuft: () => !!tippt },
    };
  };
  window.Werkstaetten.klassendiagramm.kern = K;
  window.Werkstaetten.klassendiagramm.einleitung = "Die Werkstatt Klassendiagramm: Doppelklick legt eine Klasse an, am Kopf zieht ihr sie hin, wo sie stehen soll. Die Zeilen tippt ihr direkt in die Fächer – oben die Attribute, unten die Methoden. Jede Zeile wird beim Verlassen geprüft, mit der richtigen Form im Satz. „Prüfen“ vergleicht mit der Aufgabe.";
  window.Werkstaetten.klassendiagramm.kurz = "Klassendiagramm am Bild bauen: Zeilen in die Fächer tippen, „Prüfen“ vergleicht mit der Aufgabe.";
})();
