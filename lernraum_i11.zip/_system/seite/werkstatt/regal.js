// Werkstatt "Regal" -- eine Liste als Regal mit Faechern, gezaehlt ab 0.
// Rolle A (Beschluss 07.10.): erst das Problem ohne Code (hineinlegen,
// herausnehmen, nachruecken sehen), dann "als Python zeigen" -- dieselben
// Handgriffe als append, remove, [n], len. Verraet keine Blattloesung.
// Einbinden: Werkstaetten.regal(element, {dinge: [...], faecher: 6})
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.regal = function (wurzel, opt) {
  opt = opt || {};
  const FAECHER = opt.faecher || 6;
  const vorrat = (opt.dinge || ["lampe", "schluessel", "karte", "seil", "kreide", "apfel"]).slice();
  const liste = (opt.start || []).slice();
  const protokoll = [];
  let python = false;

  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  wurzel.textContent = "";
  wurzel.classList.add("regal");
  const brett = h("div", "brett");
  const vorratEl = h("div", "vorrat");
  const zeile1 = h("div", "zeile");
  const zeile2 = h("div", "zeile");
  const protokollEl = h("div", "protokoll");
  protokollEl.hidden = true;

  const antwortLen = h("span", "antwort", "");
  const fachNr = h("input"); fachNr.type = "number"; fachNr.min = 0; fachNr.max = FAECHER - 1; fachNr.placeholder = "2";
  const fachAntwort = h("span", "antwort", "");
  const sucheFeld = h("input"); sucheFeld.type = "text"; sucheFeld.placeholder = "karte"; sucheFeld.size = 9;
  const sucheAntwort = h("span", "antwort", "");
  const schalter = h("button", "", "als Python zeigen");
  const zurueck = h("button", "ruhig", "leeren");

  function py(z) { protokoll.push(z); protokollEl.textContent = protokoll.join("\n"); protokollEl.scrollTop = 1e6; }

  function zeichne() {
    brett.textContent = "";
    for (let i = 0; i < FAECHER; i++) {
      const f = h("div", "fach" + (i < liste.length ? "" : " leer"));
      f.appendChild(h("span", "fnr", String(i)));
      if (i < liste.length) {
        const d = h("span", "ding", liste[i]);
        d.title = "herausnehmen";
        d.addEventListener("click", () => { liste.splice(i, 1); py(python ? 'rucksack.remove("' + d.textContent + '")' : "herausgenommen: " + d.textContent); zeichne(); });
        f.appendChild(d);
      }
      brett.appendChild(f);
    }
    vorratEl.textContent = "";
    vorratEl.appendChild(h("span", "", "hineinlegen: "));
    vorrat.forEach(name => {
      const d = h("span", "ding", name);
      d.addEventListener("click", () => {
        if (liste.length >= FAECHER) { fachAntwort.textContent = "Das Regal ist voll."; fachAntwort.classList.add("fehler"); return; }
        liste.push(name); py(python ? 'rucksack.append("' + name + '")' : "hineingelegt: " + name); zeichne();
      });
      vorratEl.appendChild(d);
    });
    antwortLen.textContent = (python ? "len(rucksack) = " : "Anzahl: ") + liste.length;
    fachAnsehen(false);
    suchen(false);
  }
  function fachAnsehen(mitProtokoll) {
    const n = parseInt(fachNr.value, 10);
    fachAntwort.classList.remove("fehler");
    if (isNaN(n)) { fachAntwort.textContent = ""; return; }
    if (n >= 0 && n < liste.length) {
      fachAntwort.textContent = (python ? "rucksack[" + n + "] = " : "Fach " + n + ": ") + (python ? '"' + liste[n] + '"' : liste[n]);
      if (mitProtokoll && python) py("rucksack[" + n + "]    # " + '"' + liste[n] + '"');
    } else {
      fachAntwort.textContent = python ? "rucksack[" + n + "]  →  IndexError: list index out of range" : "Fach " + n + " ist leer – das gibt es nicht.";
      fachAntwort.classList.add("fehler");
      if (mitProtokoll && python) py("rucksack[" + n + "]    # IndexError");
    }
  }
  function suchen(mitProtokoll) {
    const w = sucheFeld.value.trim();
    if (!w) { sucheAntwort.textContent = ""; return; }
    const da = liste.indexOf(w) >= 0;
    sucheAntwort.textContent = python ? '"' + w + '" in rucksack  →  ' + (da ? "True" : "False") : (da ? w + " ist im Regal" : w + " ist nicht im Regal");
    if (mitProtokoll && python) py('"' + w + '" in rucksack    # ' + (da ? "True" : "False"));
  }
  schalter.addEventListener("click", () => {
    python = !python;
    schalter.textContent = python ? "ohne Python" : "als Python zeigen";
    protokollEl.hidden = !python;
    if (python && !protokoll.length) py("rucksack = [" + liste.map(x => '"' + x + '"').join(", ") + "]");
    zeichne();
  });
  zurueck.addEventListener("click", () => { liste.length = 0; protokoll.length = 0; protokollEl.textContent = ""; if (python) py("rucksack = []"); zeichne(); });
  fachNr.addEventListener("input", () => fachAnsehen(true));
  sucheFeld.addEventListener("input", () => suchen(true));

  zeile1.appendChild(h("span", "", "Fach ansehen:")); zeile1.appendChild(fachNr); zeile1.appendChild(fachAntwort);
  zeile1.appendChild(antwortLen);
  zeile2.appendChild(h("span", "", "Ist da?")); zeile2.appendChild(sucheFeld); zeile2.appendChild(sucheAntwort);
  zeile2.appendChild(schalter); zeile2.appendChild(zurueck);
  wurzel.appendChild(brett); wurzel.appendChild(vorratEl); wurzel.appendChild(zeile1); wurzel.appendChild(zeile2); wurzel.appendChild(protokollEl);
  zeichne();
  return { liste, protokoll };
};
window.Werkstaetten.regal.einleitung = "Erst ohne Code: hineinlegen, herausnehmen, nachsehen. Dann „als Python zeigen“.";
