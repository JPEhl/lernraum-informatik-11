# CodeMirror 6 — gebündelt

`codemirror.js` ist ein Bündel (esbuild, IIFE, `window.CM`) aus
codemirror 6.0.1, @codemirror/lang-python 6.1.6, @codemirror/lang-html 6.4.9
und ihren Abhängigkeiten (27 Pakete, alle MIT — Texte in `LIZENZ.txt`).
Gebaut am 2026-10-12, **neu gebündelt am 2026-10-21** mit `WidgetType` (Zwischenstände im Fahrplan:
gelöschte Zeilen als Widget). Der Eingang liegt seitdem in `werkstatt/lernraum/codemirror_eingang.js` (vorher nur im Scratchpad; nicht unter `seite/`, das geht an die Klasse):

```js
import { EditorState, Compartment } from "@codemirror/state";
import { EditorView, keymap, lineNumbers, ... } from "@codemirror/view";
...
window.CM = { ... };
```

Neu bündeln (`--before=2026-10-12` hält dieselben Paketstände; das Bündel vom 21.10. ist genau um den
Namen `WidgetType` länger): `npm i --before=2026-10-12 codemirror@6.0.1 @codemirror/lang-python@6.1.6
@codemirror/lang-html@6.4.9 esbuild@0.24.0`, dann
`npx esbuild eingang.js --bundle --minify --format=iife --target=es2020
--outfile=codemirror.js`. Die Lizenzdatei sammelt ein kleines Node-Skript
aus allen `node_modules/*/LICENSE`. Kein CDN, kein Netz zur Laufzeit.
