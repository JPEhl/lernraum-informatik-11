/* Lernraum · werkbuch.js -- Werkbuch (Lehrer): Daten, Haken in der Durchsicht, Eintragskarten.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Werkbuch (Lehrer): was angemerkt wurde und was daraus wurde ──────────────────
// Lehrerentscheidung 14.10.: drei Quellen in einer Liste -- Durchsicht, nach der Stunde,
// Klasse (ohne Namen). Gebaut aus werkbuch/*.json der Kursquelle (versioniert); was
// seither dazukam, liefert der Server als Status "neu". Reiter "Werkbuch" je Thema;
// in der Durchsicht stehen erledigte Eintraege als gruene Haken an ihrer Stelle --
// standardmaessig an, per Knopf aus, die Wahl merkt sich der Browser.
const W = { daten: null, haken: true, zeigen: null };
try { W.haken = localStorage.getItem("lernraum.werkbuch.haken") !== "aus"; } catch (e) {}
const W_STATUS = [["offen", "offen"], ["frage", "Frage an dich"], ["eingearbeitet", "eingearbeitet"], ["bewusst_nicht", "bewusst nicht"], ["neu", "neu, noch nicht eingelesen"]];
const W_QUELLE = [["durchsicht", "Durchsicht"], ["stunde", "nach der Stunde"], ["klasse", "Klasse"]];
function neueKennung(quelle) { return (quelle === "stunde" ? "s" : "d") + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function kennungVon(n) { return n.id || ((n.quelle || "durchsicht")[0] + "-" + (n.zeit || "")); }   // wie kursserver/werkbuch.py
async function werkbuchLaden(neu) { if (W.daten && !neu) return; try { W.daten = await api("werkbuch/lesen", {}); } catch (e) { W.daten = { themen: {} }; if (e.status !== 423) meldung("Werkbuch: " + e.message, "fehler"); } }
function werkbuchThema(pfad) { return ((W.daten || {}).themen || {})[pfad] || { eintraege: [], urteile: {} }; }
function werkbuchFuerRoute(r) { const t = themaRoute(); return t ? werkbuchThema(t).eintraege.filter(e => e.route === r && e.status !== "neu") : []; }
function werkbuchErledigt(e) { return e.status === "eingearbeitet" || e.status === "bewusst_nicht"; }
function statusText(s) { return (W_STATUS.find(x => x[0] === s) || [s, s])[1]; }
function quelleText(q) { return (W_QUELLE.find(x => x[0] === q) || [q, q])[1]; }
function stelleKurz(titel) { const t = (titel || "").split(" · "); return t.length > 2 && t[0].startsWith("Thema ") ? t.slice(2).join(" · ") : (titel || ""); }
function hakenSchalten() { W.haken = !W.haken; try { localStorage.setItem("lernraum.werkbuch.haken", W.haken ? "an" : "aus"); } catch (e) {} leisteZeichnen(); nadelnZeichnen(); }
// Ein erledigter Eintrag steht nur dort, wo seine Stelle noch dieselbe ist: Anker gefunden UND
// der Text beginnt gleich. Nach dem Einarbeiten hat sich die Stelle oft geändert -- dann
// kein Haken an einer falschen Stelle; er bleibt im Zähler der Leiste und im Werkbuch.
function stelleStimmt(el, e) {
  if (!e.ausschnitt) return true;
  const norm = s => (s || "").trim().replace(/\s+/g, " ").slice(0, 24);
  const a = norm(el.textContent), b = norm(e.ausschnitt);
  return !!a && !!b && (a.startsWith(b.slice(0, 12)) || b.startsWith(a.slice(0, 12)));
}
function werkbuchMarkenZeichnen(r, haupt, belegt) {
  for (const e of werkbuchFuerRoute(r)) {
    const erledigt = werkbuchErledigt(e);
    if (erledigt && !W.haken) continue;
    const el = ankerFinden(e); let x, y;
    if (W.zeigen === e.id && !W.gescrollt && el) { W.gescrollt = true; stelleAufklappen(el); el.scrollIntoView({ block: "center" }); }
    if (el && stelleStimmt(el, e)) [x, y] = zeichenOrt(el, e.dx ?? .5, e.dy ?? .5, belegt);
    else if (!erledigt && e.x != null) { x = e.x; y = e.y; }
    else continue;
    if (y < haupt.top || y > haupt.bottom) continue;
    const titel = "W" + e.nr + " · " + statusText(e.status) + (e.wie ? ": " + e.wie : "") + (e.commit ? " (" + e.commit + ")" : "") + "\n" + (e.text || "");
    const cls = (erledigt ? "wb-marke " + e.status : e.status === "frage" ? "wb-marke frage" : "nadel wb " + (e.stapel || "")) + (W.zeigen === e.id ? " puls" : "");
    const zeichen = { eingearbeitet: "✓", bewusst_nicht: "–", frage: "?" }[e.status];
    D.ebene.append(h("div", { class: cls, style: "left:" + x + "px;top:" + y + "px", title: titel, "data-wb": e.id, onclick: ev => { ev.stopPropagation(); werkbuchEintragDialog(e); } }, h("span", {}, zeichen || "W" + e.nr)));
  }
}
function werkbuchEintragDialog(e) {
  const inhalt = h("div", { class: "werkbuch-dialog" }, werkbuchKarte(e, false));
  const t = themaRoute();
  dialog("Werkbuch W" + e.nr, inhalt, [["Im Werkbuch zeigen", async () => { location.hash = adr("t/" + t + "/werkbuch"); }, "ruhig"], ["Schließen", async () => {}, "primaer"]]);
}
// Ein Eintrag als Karte: Kopf (Nummer, Quelle, Stapel, Status), Stelle, Text, was daraus wurde.
function werkbuchKarte(e, mitLink, mitKommentar) {
  const art = e.quelle === "klasse" ? (ARTEN.find(z => z[0] === e.art) || null) : null;
  const kopf = h("div", { class: "wk" }, h("span", { class: "wnr" }, e.nr ? "W" + e.nr : "neu"),
    h("span", { class: "quelle-chip " + e.quelle }, quelleText(e.quelle)),
    art ? h("span", { class: "art-chip " + e.art }, art[2] + " " + art[1]) : null,
    e.stapel ? h("span", { class: "stapel-chip " + e.stapel }, (STAPEL.find(s => s[0] === e.stapel) || [0, e.stapel])[1]) : null,
    h("span", { class: "status-chip " + e.status }, statusText(e.status)));
  const stelle = h("div", { class: "ws" }, stelleKurz(e.titel) || e.route, e.ausschnitt ? h("span", { class: "leer" }, " · bei „" + e.ausschnitt.slice(0, 60) + "“") : null,
    mitLink ? h("a", { href: adr(e.route), class: "zur-stelle", onclick: () => { W.zeigen = e.id; W.gescrollt = false; setTimeout(() => { W.zeigen = null; }, 6000); if (!D.an) durchsichtSchalten(); } }, "an der Stelle zeigen") : null);
  const karte = h("div", { class: "werkbuch-eintrag " + e.status }, kopf, stelle, h("div", { class: "wt" }, e.text || h("span", { class: "leer" }, "(ohne Text)")));
  if (e.wie || e.commit || e.wirksam) karte.append(h("div", { class: "ww" }, e.wie ? h("span", {}, h("b", {}, e.status === "bewusst_nicht" ? "Warum nicht: " : "Daraus wurde: "), e.wie) : null,
    e.commit ? h("span", { class: "commit" }, "Commit " + e.commit) : null, e.wirksam ? h("span", { class: "wirksam" }, "wirksam: " + e.wirksam) : null));
  // Eigene Kommentare (Lehrer 14.10.: „zu den Punkten eigene Kommentare für die spätere Umsetzung“)
  const komm = e.kommentare || [];
  if (komm.length || mitKommentar) {
    const kbox = h("div", { class: "wkomm" });
    for (const k of komm) kbox.append(h("div", { class: "kommentar" + (k.lebend ? " lebend" : k.neu ? " neu" : "") },
      h("span", { class: "kz" }, "Dein Kommentar · " + (k.zeit || "").slice(0, 10).split("-").reverse().join(".") + (k.lebend ? " · noch nicht eingelesen" : k.neu ? " · noch nicht umgesetzt" : "")),
      h("div", {}, k.text),
      k.lebend && mitKommentar ? h("button", { class: "ruhig klein-knopf", title: "Kommentar wieder wegnehmen", onclick: async () => { await api("werkbuch/kommentar", { id: e.id, zeit: k.zeit, loeschen: true }); e.kommentare = komm.filter(x => x !== k); karte.replaceWith(werkbuchKarte(e, mitLink, mitKommentar)); } }, "✕") : null));
    if (mitKommentar) {
      const feld = h("textarea", { placeholder: "Dein Kommentar für die spätere Umsetzung …" }); feld.hidden = true;
      const speichern = h("button", { class: "primaer", hidden: true, onclick: async () => {
        const text = feld.value.trim(); if (!text) return;
        try { const a = await api("werkbuch/kommentar", { id: e.id, text }); e.kommentare = komm.concat([Object.assign({ lebend: true }, a.kommentar)]); karte.replaceWith(werkbuchKarte(e, mitLink, mitKommentar)); }
        catch (err) { meldung(err.message, "fehler"); } } }, "Kommentar speichern");
      const auf = h("button", { class: "ruhig kommentar-knopf", onclick: () => { feld.hidden = speichern.hidden = false; auf.hidden = true; feld.focus(); } }, "＋ Kommentar");
      kbox.append(auf, feld, speichern);
    }
    karte.append(kbox);
  }
  return karte;
}
