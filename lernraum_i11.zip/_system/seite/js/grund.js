/* Die Arbeitsseite des Lernraums. Kein Framework, kein Netz.
   Alles, was Inhalt ist, kommt aus /api/inhalt (gebaut von bauen.py); alles,
   was Zustand ist, liegt im Stand auf dem Stick (_stand/stand.json).
   Geteilt in Dateien unter seite/js/ (14.10.2026, vorher eine seite.js mit
   1235 Zeilen); index.html lädt sie der Reihenfolge nach, sie teilen einen
   Namensraum. Dieser Teil: Hilfen (h, api, meldung) und der Zustand Z. */
"use strict";
// Bis 14.10.2026 hiess das System „Kursordner“: Geraeteeinstellungen einmal mitnehmen.
try { for (let i = localStorage.length - 1; i >= 0; i--) { const k = localStorage.key(i); if (k && k.startsWith("kursordner.")) { const n = "lernraum." + k.slice(11); if (localStorage.getItem(n) === null) localStorage.setItem(n, localStorage.getItem(k)); localStorage.removeItem(k); } } } catch (e) {}

// ─── Hilfen ───────────────────────────────────────────────────────────────────
const $ = (sel, el) => (el || document).querySelector(sel);
function h(tag, attrs, ...kinder) {
  const e = document.createElement(tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v;
    else if (k === "html") e.innerHTML = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v === true) e.setAttribute(k, "");
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const k of kinder.flat()) if (k != null) e.append(k.nodeType ? k : document.createTextNode(String(k)));
  return e;
}
async function api(name, daten) {
  // X-Kurs: welchen Kurs diese Seite zeigt. Ist im Pult inzwischen ein anderer offen
  // (zweiter Tab, Wechsel), antwortet der Server 409 und schreibt nichts in den falschen.
  const kopf = Z.kurs ? { "X-Kurs": Z.kurs } : {};
  const r = daten === undefined
    ? await fetch("/api/" + name, { credentials: "same-origin", headers: kopf })
    : await fetch("/api/" + name, { method: "POST", credentials: "same-origin",
        headers: Object.assign({ "Content-Type": "application/json" }, kopf), body: JSON.stringify(daten) });
  let j = {};
  try { j = await r.json(); } catch (e) { j = { fehler: "Antwort unlesbar (" + r.status + ")" }; }
  if (r.status === 409 && j.kurs_gewechselt) { setTimeout(() => laden().then(zeichnen), 0); }
  if (!r.ok) { const f = new Error(j.fehler || ("Fehler " + r.status)); f.status = r.status; f.daten = j; throw f; }
  return j;
}
// Adressen tragen den Kurs vorne: #/i11/t/abenteuer/anfang/vortrag/1 (Lehrerentscheidung 14.10.).
// route = alles danach; Nadeln, Urteile und Werkbuch speichern die Route OHNE Kurs --
// ihre Daten liegen ohnehin je Kurs.
function adr(route) { return "#/" + encodeURIComponent(Z.kurs) + (route ? "/" + route : ""); }
function hashTeile() { return location.hash.replace(/^#\/?/, "").split("/").filter(Boolean).map(decodeURIComponent); }
function routeOhneKurs() { const t = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean); if (decodeURIComponent(t[0] || "") === Z.kurs) t.shift(); return t.join("/"); }
function kursTitel(k) { const e = (Z.kurse || []).find(x => x.kurs === k); return e ? e.titel : k; }
const schlafen = ms => new Promise(r => setTimeout(r, ms));
function bilderPfad(el, themaPfad) {
  el.querySelectorAll("img").forEach(img => { const s = img.getAttribute("src") || ""; if (!/^(\/|https?:|data:)/.test(s)) img.src = "/themen/" + themaPfad + "/" + s; });
}
// Gezeichnete Zeichen statt Emoji (Regel wie MARKE_ZEICHEN in thema.js, Lehrerwahl 14./15.10.):
// Emojis sehen unter Windows und auf dem Mac verschieden aus. Farbe kommt aus CSS (currentColor).
const NADEL_ZEICHEN = '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="zf" d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7z"/><circle class="zi" cx="12" cy="9" r="2.6"/></svg>';
const SCHLOSS_ZEICHEN = '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="zb" d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/><rect class="zf" x="5" y="10" width="14" height="11" rx="2.5"/></svg>';
// Zahnrad und Auge (Lehrer 15.10.: „so wie du empfiehlst“ -- ⚙ und 👁 sind echte Emoji; ✓ ✎ ? bleiben Schrift)
const ZAHNRAD_ZEICHEN = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle class="zz" cx="12" cy="12" r="8.6"/><circle class="zf" cx="12" cy="12" r="7"/><circle class="zi" cx="12" cy="12" r="2.8"/></svg>';
// Lesezeichen (19.10.): ein Band mit Kerbe -- gefuellt, wenn es hier liegt (CSS .gesetzt)
const LESEZEICHEN_ZEICHEN = '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="zl" d="M6.5 3h11v18l-5.5-4.6L6.5 21z"/></svg>';
const AUGE_ZEICHEN = '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="zb" d="M2.5 12s3.5-6.3 9.5-6.3 9.5 6.3 9.5 6.3-3.5 6.3-9.5 6.3S2.5 12 2.5 12z"/><circle class="zf" cx="12" cy="12" r="3.1"/></svg>';
// Der Käfer des Debuggers (Lehrer 17.10.: „Debugger auch Debugger nennen“; in Thonny ist es auch ein Käfer)
const KAEFER_ZEICHEN = '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="zb" d="M7 10.5H3.6M6.6 14.8H3M7.6 18.6 5 20.8M17 10.5h3.4M17.4 14.8H21M16.4 18.6l2.6 2.2M10.4 5 8.8 2.8M13.6 5l1.6-2.2"/><ellipse class="zf" cx="12" cy="14.6" rx="5.3" ry="6.4"/><circle class="zf" cx="12" cy="6.6" r="2.7"/><path class="zt" d="M12 9.6v10.8"/></svg>';
function zeichen(svg, art) { return h("span", { class: "zeichen " + (art || ""), html: svg }); }
function meldung(text, art) {
  const d = $("#dialoge");
  const m = h("div", { class: "hinweis" + (art === "fehler" ? " fehler" : "") }, text);
  m.style.position = "fixed"; m.style.right = "1em"; m.style.bottom = "1em"; m.style.zIndex = 60; m.style.maxWidth = "28em"; m.style.background = art === "fehler" ? "#fbe9e9" : "";
  d.append(m); setTimeout(() => m.remove(), 5000);
}

// ─── Zustand ─────────────────────────────────────────────────────────────────
const Z = { inhalt: null, stand: null, lehrer: false, beamer: false, laufend: null, kurs: "", kurse: [], pult: false };

async function laden() {
  const a = await api("inhalt");
  Z.inhalt = a.inhalt; Z.stand = a.stand; Z.lehrer = a.lehrer; Z.beamer = a.beamer;
  Z.kurs = a.kurs || a.inhalt.kurs; Z.kurse = a.kurse || []; Z.pult = !!a.pult;
  document.body.dataset.kurs = Z.kurs;
  document.body.classList.toggle("lehrer", Z.lehrer);
  document.body.classList.toggle("beamer", Z.beamer);
  document.title = (Z.lehrer ? "Lehrerpult · " : "Lernraum ") + Z.inhalt.titel;
  $("#kopf-titel").textContent = Z.inhalt.titel;
}
function thema(reiheK, themaK) {
  for (const r of Z.inhalt.reihen) if (r.kennung === reiheK) for (const t of r.themen) if (t.kennung === themaK) return { reihe: r, thema: t, pfad: reiheK + "/" + themaK };
  return null;
}
function aufgabenStand(kennung) { return (Z.stand.aufgaben || {})[kennung] || {}; }
