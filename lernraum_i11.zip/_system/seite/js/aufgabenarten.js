/* Lernraum · aufgabenarten.js -- Aufgabenarten in der Übung: Parsons-Puzzle und Fall (Debug-Detektiv).
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// Block B2 der Feature-Galerie (15.10., Rang 8 und 10). Beide stehen in einer Aufgabe, an ihrer
// Stelle im Text, als <figure> (eigener Tag: verschiebt keine nth-of-type-Anker). Was richtig ist,
// weiß nur der Server (_system/pruefstoff.json) -- die Seite schickt, was die Klasse gelegt oder
// verdächtigt hat, und zeigt die Antwort.

// Nebeneinander (Vorrat | Programm, Code | Akte) erst, wenn die Spalte es trägt -- in der Übung neben
// dem Editor ist sie schmal, und Code darf nie mitten in der Zeile umbrechen (Fotos 15.10.).
function breitSchalten(f, ab) {
  const pruefe = () => f.classList.toggle("breit", f.clientWidth >= ab);
  if (window.ResizeObserver) new ResizeObserver(pruefe).observe(f);
  requestAnimationFrame(pruefe);
}

// ─── Parsons-Puzzle (::: parsons) ──────────────────────────────────────────────────────
// Links der Vorrat (gemischt, mit Ablenker), rechts das Programm. Ziehen mit der Maus oder
// anklicken (wandert hinüber); mit der Tastatur Enter (hinüber) und Alt+↑/↓ (verschieben).
// „Prüfen“ sagt nur, wie viele Zeilen noch nicht stimmen.
function parsonsPuzzle(f, T, a, nachher) {
  const name = f.dataset.parsons, kennung = T.pfad + "/" + name;
  const vorrat = $(".pz-vorrat", f), programm = $(".pz-programm", f);
  const urteil = h("p", { class: "pz-urteil" });
  const konsole = h("div", { class: "konsole" }); konsole.hidden = true;
  const st = () => (Z.stand.puzzles || {})[kennung] || {};
  const zeilen = [...f.querySelectorAll(".pz-zeile")];
  zeilen.forEach(li => { li.tabIndex = 0; li.title = "Ziehen – oder anklicken, dann wandert die Zeile hinüber"; });
  // Gemerkt: das zuletzt geprüfte Programm (im Stand) -- gelöst bleibt gelöst zu sehen
  for (const t of st().programm || []) { const li = zeilen.find(x => x.dataset.text === t && x.parentElement === vorrat); if (li) programm.append(li); }
  function programmText() { return [...programm.querySelectorAll(".pz-zeile")].map(li => li.dataset.text); }
  function geaendert() { urteil.textContent = ""; urteil.className = "pz-urteil"; f.classList.remove("geprueft", "geloest"); leerZeigen(); }
  function leerZeigen() { programm.classList.toggle("leer", !programm.querySelector(".pz-zeile")); vorrat.classList.toggle("leer", !vorrat.querySelector(".pz-zeile")); }
  function hinueber(li) { (li.parentElement === vorrat ? programm : vorrat).append(li); li.focus(); geaendert(); }
  // Ziehen: echte Pointer-Ereignisse; ohne Bewegung ist es ein Klick (wandert hinüber)
  zeilen.forEach(li => {
    li.addEventListener("keydown", ev => {
      if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); hinueber(li); }
      else if (ev.altKey && (ev.key === "ArrowUp" || ev.key === "ArrowDown")) {
        ev.preventDefault(); const nb = ev.key === "ArrowUp" ? li.previousElementSibling : li.nextElementSibling;
        if (nb) { ev.key === "ArrowUp" ? nb.before(li) : nb.after(li); li.focus(); geaendert(); }
      }
    });
    li.addEventListener("pointerdown", ev => {
      if (ev.button !== 0) return;
      ev.preventDefault();
      const start = [ev.clientX, ev.clientY], r = li.getBoundingClientRect();
      let platz = null;
      li.setPointerCapture(ev.pointerId);
      const ziehen = e => {
        if (!platz) {
          if (Math.hypot(e.clientX - start[0], e.clientY - start[1]) < 5) return;
          platz = h("li", { class: "pz-platz" }); platz.style.height = r.height + "px";
          li.after(platz); li.classList.add("zieht"); li.style.width = r.width + "px";
        }
        li.style.left = (e.clientX - (start[0] - r.left)) + "px"; li.style.top = (e.clientY - (start[1] - r.top)) + "px";
        // Ziel: die Liste unter dem Zeiger, der Platz vor der ersten Zeile, deren Mitte darunter liegt
        const ziel = [vorrat, programm].find(u => { const b = u.getBoundingClientRect(); return e.clientX >= b.left - 20 && e.clientX <= b.right + 20 && e.clientY >= b.top - 30 && e.clientY <= b.bottom + 40; });
        if (!ziel) return;
        const vor = [...ziel.querySelectorAll(".pz-zeile")].filter(x => x !== li).find(x => { const b = x.getBoundingClientRect(); return e.clientY < b.top + b.height / 2; });
        if (vor) vor.before(platz); else ziel.append(platz);
      };
      const ende = () => {
        li.removeEventListener("pointermove", ziehen); li.removeEventListener("pointerup", ende); li.removeEventListener("pointercancel", ende);
        if (!platz) { hinueber(li); return; }
        platz.replaceWith(li); li.classList.remove("zieht"); li.style.left = li.style.top = li.style.width = ""; geaendert();
      };
      li.addEventListener("pointermove", ziehen); li.addEventListener("pointerup", ende); li.addEventListener("pointercancel", ende);
    });
  });
  async function pruefen() {
    let r; try { r = await api("stand/puzzle", { kennung, reihenfolge: programmText() }); } catch (e) { meldung(e.message, "fehler"); return; }
    (Z.stand.puzzles = Z.stand.puzzles || {})[kennung] = r.puzzle;
    f.classList.add("geprueft"); f.classList.toggle("geloest", r.geloest);
    urteil.className = "pz-urteil " + (r.geloest ? "ok" : "offen");
    urteil.textContent = r.geloest ? "Richtig – alle Zeilen am richtigen Platz, und die falsche ist draußen geblieben."
      : !programmText().length ? "Noch liegt keine Zeile in eurem Programm."
      : "Noch " + r.falsch + (r.falsch === 1 ? " Zeile stimmt" : " Zeilen stimmen") + " nicht – am falschen Platz, zu viel oder noch nicht da.";
    if (nachher) nachher();
  }
  // Ausführen: das gelegte Programm läuft wirklich (eine eigene Datei neben den Beispielen)
  async function ausfuehren() {
    konsole.hidden = false; konsole.textContent = "";
    let lauf; try { lauf = await api("lauf/start", { pfad: "themen/" + T.pfad + "/beispiele/puzzle_" + name + ".py", text: programmText().join("\n") + "\n", thema: T.pfad, ort: "uebung/" + a.nr }); }
    catch (e) { konsole.textContent = e.message; return; }
    await laufZeigen(lauf, konsole);
  }
  f.append(h("div", { class: "zeile pz-knoepfe" },
    h("button", { type: "button", class: "primaer", onclick: pruefen }, "Prüfen"),
    h("button", { type: "button", class: "ruhig", onclick: ausfuehren }, "▶ Ausführen"),
    h("button", { type: "button", class: "ruhig", onclick: () => { zeilen.forEach(li => vorrat.append(li)); konsole.hidden = true; geaendert(); } }, "Von vorn")), urteil, konsole);
  breitSchalten(f, 980);
  if (st().geloest) { f.classList.add("geprueft", "geloest"); urteil.className = "pz-urteil ok"; urteil.textContent = "Gelöst."; }
  leerZeigen();
}
function puzzleGeloest(a) { return (a.parsons || []).every(n => !!((Z.stand.puzzles || {})[a.kennung.replace(/\/[^/]+$/, "") + "/" + n] || {}).geloest); }

// Ein Lauf in eine Konsole (Puzzle; dasselbe wie ausfuehrTeil, mit Satz und Fehlerbuch-Hinweis).
async function laufZeigen(lauf, konsole) {
  let ab = 0;
  while (true) {
    let r; try { r = await api("lauf/lesen", { id: lauf.id, ab }); } catch (e) { konsole.append("\n" + e.message); return; }
    if (r.text) konsole.append(r.text); ab = r.bis;
    if (r.fertig) {
      if (r.fehler) konsole.append(h("span", { class: "satz" }, (r.fehler.zeile ? "Zeile " + r.fehler.zeile + ": " : "") + r.fehler.satz), fehlerbuchHinweis(r.fehlerbuch));
      else konsole.append(h("span", { class: "satz" }, "— Programm beendet —"));
      return;
    }
    await schlafen(200);
  }
}

// ─── Fall (::: fall) ───────────────────────────────────────────────────────────────────
// Verdächtige Zeilen anklicken, dann „Verdacht prüfen“: Treffer bleiben grün mit dem Befund,
// saubere Zeilen sagt die Akte einmal. Erst nach dem ersten Verdacht gibt es das Programm zum
// Kopieren (Galerie: „erst anklicken, ausführen dürft ihr danach“).
function fallAkte(f, T, a, nachher) {
  const name = f.dataset.fall, kennung = T.pfad + "/" + name, zahl = +f.dataset.fehler;
  const zeilen = [...f.querySelectorAll(".fz")];
  const akte = $(".akte", f);
  const stand = h("p", { class: "akte-stand" }), befunde = h("ul", { class: "akte-befunde" }), sauber = h("p", { class: "akte-sauber" });
  const pruefKnopf = h("button", { type: "button", class: "primaer", disabled: true, onclick: pruefen }, "Verdacht prüfen");
  const kopierKnopf = h("button", { type: "button", class: "ruhig", hidden: true }, "Kopieren");
  akte.append(h("div", { class: "akte-kopf" }, "Akte"), stand, befunde, sauber, h("div", { class: "zeile" }, pruefKnopf, kopierKnopf));
  let code = "";
  kopierKnopf.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(code); }
    catch (e) { const ta = h("textarea", {}); ta.value = code; document.body.append(ta); ta.select(); try { document.execCommand("copy"); } catch (e2) {} ta.remove(); }
    kopierKnopf.textContent = "✓ kopiert"; setTimeout(() => { kopierKnopf.textContent = "Kopieren"; }, 1500);
  });
  zeilen.forEach(li => {
    li.tabIndex = 0; li.setAttribute("role", "button");
    // Höchstens so viele Verdachte, wie Fehler noch offen sind (Lehrer 16.10.: sonst findet, wer alles
    // anklickt, alles). Der Server sperrt ebenso; hier sagt die Akte es sofort.
    const umschalten = () => {
      if (li.classList.contains("gefunden")) return;
      const offen = zahl - f.querySelectorAll(".fz.gefunden").length;
      if (!li.classList.contains("verdacht") && f.querySelectorAll(".fz.verdacht").length >= offen) {
        sauber.textContent = "Höchstens " + offen + (offen === 1 ? " Verdacht" : " Verdachte") + " auf einmal – so viele Fehler sind noch offen. Nehmt erst einen zurück.";
        return;
      }
      li.classList.toggle("verdacht"); li.classList.remove("sauber"); pruefKnopf.disabled = !f.querySelector(".fz.verdacht");
    };
    li.addEventListener("click", umschalten);
    li.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); umschalten(); } });
  });
  function zeigen(r) {
    const gef = Object.keys(r.befunde).map(Number).sort((x, y) => x - y);
    zeilen.forEach(li => { if (gef.includes(+li.dataset.z)) { li.classList.add("gefunden"); li.classList.remove("verdacht", "sauber"); li.removeAttribute("role"); } });
    const ak = r.akte || {};
    stand.textContent = "";
    stand.append(h("b", { class: "akte-zahl" }, String(gef.length)), " von " + zahl + " gefunden" + (ak.falsch ? " · " + ak.falsch + " falsche" + (ak.falsch === 1 ? "r Verdacht" : " Verdachte") : ""));
    befunde.textContent = ""; gef.forEach(z => befunde.append(h("li", { html: "<b>Zeile " + z + ":</b> " + r.befunde[z] })));
    if (gef.length === zahl) { f.classList.add("geloest"); stand.append(h("span", { class: "akte-zu" }, " – Fall gelöst")); }
    if (r.code) { code = r.code; kopierKnopf.hidden = false; }
    pruefKnopf.disabled = !f.querySelector(".fz.verdacht");
  }
  async function pruefen() {
    const verdacht = zeilen.filter(li => li.classList.contains("verdacht")).map(li => +li.dataset.z);
    if (!verdacht.length) return;
    let r; try { r = await api("stand/fall", { kennung, verdacht }); } catch (e) { meldung(e.message, "fehler"); return; }
    (Z.stand.faelle = Z.stand.faelle || {})[kennung] = r.akte;
    zeilen.forEach(li => { if (r.sauber.includes(+li.dataset.z)) { li.classList.remove("verdacht"); li.classList.add("sauber"); } });
    sauber.textContent = r.sauber.length ? (r.sauber.length === 1 ? "Zeile " + r.sauber[0] + " ist sauber." : "Zeilen " + r.sauber.join(", ") + " sind sauber.") : "";
    zeigen(r);
    if (nachher) nachher();
  }
  breitSchalten(f, 860);
  api("stand/fall", { kennung }).then(zeigen).catch(e => { stand.textContent = e.message; });
}
function fallStand(a) {
  const t = a.kennung.replace(/\/[^/]+$/, "");
  return (a.fall || []).map(n => (Z.stand.faelle || {})[t + "/" + n] || {});
}

// ─── Vorhersage (::: vorhersage) ───────────────────────────────────────────────────────
// Durchsicht T3 (16.10.): Was sich eindeutig prüfen lässt, prüft die Seite -- nicht Papier. Je
// Zeile ein Feld; „Prüfen“ fragt den Server je Feld (die richtigen Antworten kennt nur er).
function vorhersageTabelle(f, T, a, nachher) {
  const name = f.dataset.vorhersage, kennung = T.pfad + "/" + name;
  const felder = [...f.querySelectorAll(".vh-feld")];
  const urteil = h("p", { class: "pz-urteil" });
  const st = () => (Z.stand.vorhersagen || {})[kennung] || {};
  (st().antworten || []).forEach((x, i) => { if (felder[i]) felder[i].value = x; });
  function markieren(einzeln) { felder.forEach((e, i) => { e.classList.toggle("richtig", !!einzeln[i]); e.classList.toggle("falsch", einzeln[i] === false); }); }
  if (st().richtig) markieren(st().richtig);
  felder.forEach(e => e.addEventListener("input", () => { e.classList.remove("richtig", "falsch"); urteil.textContent = ""; }));
  async function pruefen() {
    let r; try { r = await api("stand/vorhersage", { kennung, antworten: felder.map(e => e.value) }); } catch (e) { meldung(e.message, "fehler"); return; }
    (Z.stand.vorhersagen = Z.stand.vorhersagen || {})[kennung] = r.vorhersage;
    markieren(r.einzeln);
    const falsch = r.einzeln.filter(x => !x).length;
    f.classList.toggle("geloest", r.geloest);
    urteil.className = "pz-urteil " + (r.geloest ? "ok" : "offen");
    urteil.textContent = r.geloest ? "Alles richtig vorhergesagt." : "Noch " + falsch + (falsch === 1 ? " Antwort stimmt" : " Antworten stimmen") + " nicht – die roten Felder.";
    if (nachher) nachher();
  }
  f.append(h("div", { class: "zeile pz-knoepfe" }, h("button", { type: "button", class: "primaer", onclick: pruefen }, "Prüfen")), urteil);
  if (st().geloest) { f.classList.add("geloest"); urteil.className = "pz-urteil ok"; urteil.textContent = "Gelöst."; }
}
function vorhersageGeloest(a) { const t = a.kennung.replace(/\/[^/]+$/, ""); return (a.vorhersage || []).every(n => !!((Z.stand.vorhersagen || {})[t + "/" + n] || {}).geloest); }
function fragenGeloest(a) { const t = a.kennung.replace(/\/[^/]+$/, ""); return (a.fragen || []).every(n => !!((Z.stand.fragen || {})[t + "/" + n] || {}).geloest); }

// ─── Plan (::: plan) ───────────────────────────────────────────────────────────────────
// Aufgabenart „Plan“ (19.10.2026, Lehrerwahl aus Attrappen Runde 3, Fassung B): Die Klasse baut ein
// Struktogramm in der Werkstatt Struktogramm. Es steht RECHTS, statt der Arbeitsdatei, solange die
// Aufgabe offen ist (links waere es fussnotenklein); in der Aufgabe steht nur der Hinweis darauf.
// Jede Aenderung geht in den Stand (stand/plan), „Proben laufen lassen“ rechnet der SERVER mit den
// Faellen der Aufgabe (kursserver/plan.py) -- derselbe Laeufer rechnet die Sterne im Pult nach.
// Eigener Tag (plan-feld): Die nth-of-type-Anker der Arbeitsseite bleiben, wo sie waren.
function planFeld(T, a, nachher) {
  const name = (a.plan || [])[0], kennung = T.pfad + "/" + name, spec = ((T.thema.plaene || {})[name]) || { proben: [], start: "…", algorithmus: "Algorithmus" };
  const gemerkt = () => (Z.stand.plaene || {})[kennung] || {};
  const feld = h("plan-feld", {});
  feld.append(h("h3", {}, "Aufgabe " + a.nr + " · euer Plan"));
  const box = h("div", {}); feld.append(box);
  let uhr = null, zuletzt = null;
  async function sichern(quelle, titel, proben) {
    clearTimeout(uhr); uhr = null;
    const r = await api("stand/plan", { kennung, quelle, titel, proben: !!proben });
    (Z.stand.plaene = Z.stand.plaene || {})[kennung] = r.plan;
    return r;
  }
  const w = Werkstaetten.struktogramm(box, { entwurf: true, skala: 1, algorithmus: spec.algorithmus, start: spec.start, quelle: gemerkt().quelle, titel: gemerkt().titel,
    proben: spec.proben, aendern: (q, t) => { zuletzt = [q, t]; clearTimeout(uhr); uhr = setTimeout(() => sichern(q, t).then(nachher).catch(e => meldung(e.message, "fehler")), 600); } });
  feld._werkstatt = w;
  // Die Proben: links die Startwerte (Spalten aus dem ersten Fall), dann was herauskommen soll, was der Plan ausgibt
  const namen = (spec.proben[0] || { zeigen: [] }).zeigen.map(z => z[0]);
  const tab = h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, namen.join(" · ") || "Fall"), h("th", {}, "soll ausgeben"), h("th", {}, "euer Plan gibt aus"), h("th", {}, ""))));
  const tb = h("tbody", {}); tab.append(tb);
  const zeilen = spec.proben.map(p => {
    const aus = h("td", { class: "pl-aus" }), urteil = h("td", { class: "pl-urteil" });
    tb.append(h("tr", {}, h("td", {}, ...p.zeigen.flatMap((z, i) => [i ? " · " : "", h("code", {}, z[1])])), h("td", {}, p.soll ? p.soll.join(" / ") : h("i", {}, "endet")), aus, urteil));
    return { aus, urteil };
  });
  const urteil = h("p", { class: "pl-gesamt" });
  const knopf = h("button", { class: "primaer", onclick: async () => {
    knopf.disabled = true;
    try {
      const r = await sichern(w.quelle, w.titel, true), E = r.ergebnis;
      if (!E.lesbar) { urteil.className = "pl-gesamt nein"; urteil.textContent = "Der Plan ist nicht lesbar: " + E.fehler; return; }
      E.proben.forEach((x, i) => {
        zeilen[i].aus.textContent = x.fehler ? "bricht ab: " + x.fehler : (x.ausgaben.join(" / ") || "—") + (x.endet ? "" : " … " + x.grund);
        zeilen[i].urteil.textContent = x.ok ? "✓" : "✗"; zeilen[i].urteil.className = "pl-urteil " + (x.ok ? "ok" : "nein");
      });
      const alle = E.ok === E.von;
      urteil.className = "pl-gesamt " + (alle ? "ok" : "nein");
      urteil.textContent = alle ? "Alle " + E.von + " Fälle stimmen." : E.ok + " von " + E.von + " stimmen. Seht euch den Fall an, der nicht stimmt, und ändert den Plan.";
      nachher();
    } catch (e) { meldung(e.message, "fehler"); }
    finally { knopf.disabled = false; }
  } }, "▸ Proben laufen lassen");
  feld.append(h("div", { class: "pl-proben" }, h("p", {}, h("b", {}, "Proben"), " – euer Plan läuft mit diesen Fällen:"), tab, h("div", { class: "zeile" }, knopf), urteil));
  if (gemerkt().versuche) { urteil.className = "pl-gesamt " + (gemerkt().geloest ? "ok" : "nein"); urteil.textContent = "Zuletzt: " + gemerkt().ok + " von " + gemerkt().von + " Fällen – nach einer Änderung noch einmal laufen lassen."; }
  feld._sichern = () => zuletzt ? sichern(zuletzt[0], zuletzt[1]) : Promise.resolve();
  return feld;
}
function planGeloest(a) { const t = a.kennung.replace(/\/[^/]+$/, ""); return (a.plan || []).every(n => !!((Z.stand.plaene || {})[t + "/" + n] || {}).geloest); }
