/* Lernraum · aufzeichnung.js -- die Aufzeichnung (Schritt für Schritt durch einen Lauf).
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Aufzeichnung ────────────────────────────────────────────────────────────────
// Namen der Objekte: die Variable, die darauf zeigt (mehrere: „a = b"), sonst der Weg dorthin
// („raeume[2]") -- statt der Adresse (Lehrer 14.10.: „list #6688" sagt nichts).
function objektNamen(s) {
  const namen = {}, direkt = {};
  for (const bereich of [s.lokal || {}, s.global || {}]) for (const [k, w] of Object.entries(bereich)) if (w && w.art === "ref") (direkt[w.id] = direkt[w.id] || []).includes(k) || direkt[w.id].push(k);
  for (const [oid, ks] of Object.entries(direkt)) namen[oid] = ks.join(" = ");
  const besuchen = (w, weg) => {
    if (!w || w.art !== "ref") return;
    if (!(w.id in namen)) namen[w.id] = weg;
    const o = (s.objekte || {})[w.id]; if (!o || !o.inhalt || o._besucht) return; o._besucht = true;
    if (["list", "tuple"].includes(o.typ)) o.inhalt.forEach((x, i) => besuchen(x, namen[w.id] + "[" + i + "]"));
    else if (o.typ === "dict") o.inhalt.forEach(([k, v]) => besuchen(v, namen[w.id] + "[" + k.text + "]"));
    else if (o.typ !== "set") o.inhalt.forEach(([k, v]) => besuchen(v, namen[w.id] + "." + k.text));
  };
  for (const bereich of [s.lokal || {}, s.global || {}]) for (const [k, w] of Object.entries(bereich)) besuchen(w, k);
  for (const o of Object.values(s.objekte || {})) delete o._besucht;
  return namen;
}
// Der Debugger (Lehrer 17.10., Durchsicht T5 W3: „Läuft die Shell auch mit, wenn der Debugger läuft? …
// Einzelschritt, Eintreten etc. … und ich würde den Debugger auch Debugger nennen“). Das Programm läuft
// EINMAL durch und wird aufgezeichnet (aufzeichnen.py); danach geht man durch die Schritte -- auch zurück.
// Die Knöpfe nach den üblichen Namen (step over/into/out): Schritt über · Schritt hinein · Schritt heraus · Weiter (bis zum
// nächsten Haltepunkt, Klick auf eine Zeilennummer). Die Shell des Editors bleibt sichtbar und zeigt die
// Ausgabe BIS zum aktuellen Schritt: die markierte Zeile ist die, die als Nächstes läuft -- ihre Ausgabe
// erscheint erst einen Schritt später (bis 17.10. stand sie einen Schritt zu früh in einem kleinen Kasten).
function aufzeichnung(edIch, opts) {
  const ziel = opts.aufzeichnungsZiel ? opts.aufzeichnungsZiel() : edIch.konsole.parentElement;
  const konsole = edIch.konsole;
  const vorher = [...konsole.childNodes];               // was die Shell vorher zeigte -- beim Schließen zurück
  const wrap = h("div", { class: "aufzeichnung" });
  const steuerung = h("div", { class: "steuerung" });
  const ablaeufeEl = h("div", { class: "ablaeufe" });
  const schieber = h("input", { type: "range", min: 0, max: 0, value: 0, "aria-label": "Schritt wählen" });
  const zaehler = h("span", { class: "zaehler" }, "");
  const codeansicht = h("div", { class: "codeansicht", title: "Klick auf eine Zeilennummer: Haltepunkt setzen oder entfernen" });
  const tafel = h("div", { class: "tafel" });
  const satzEl = h("div", { class: "dbg-satz" }); satzEl.hidden = true;   // der Satz eines Film-Halts (24.10.)
  const meld = h("div", { class: "meldung hinweis" }, "Der Debugger lässt das Programm einmal laufen und merkt sich jeden Schritt … Bei einem Fenster: klicke darin – jeder Klick wird ein eigener Ablauf. Fenster schließen beendet den Lauf.");
  // Breit (Vortrag, Lehrer 24.10.: „optisch im Vortrag noch eine Katastrophe: so groß, dass man gar nichts erkennt“ --
  // in der rechten Spalte standen die Knoepfe riesig, Code und Variablen unter dem Bildrand): der Debugger nimmt die
  // ganze Breite, links der Code und darunter die Shell (die Shell des Editors wird hinuebergehaengt und beim
  // Schliessen zurueckgestellt), rechts die Variablen.
  const breit = !!opts.aufzeichnungBreit;
  const shellHeim = { el: konsole.parentElement, nach: konsole.nextSibling };
  const shellStil = konsole.style.cssText;   // die Hoehe der Shell im Editor -- im Debugger hat sie eine eigene
  const shellZurueck = () => { if (breit && konsole.parentElement !== shellHeim.el) { shellHeim.el.insertBefore(konsole, shellHeim.nach && shellHeim.nach.parentElement === shellHeim.el ? shellHeim.nach : null); konsole.style.cssText = shellStil; } };
  const zu = h("button", { class: "ruhig", onclick: () => { shellZurueck(); wrap.remove(); konsole.textContent = ""; konsole.append(...vorher); if (id) api("aufzeichnen/stopp", { id }); if (opts.onAufzeichnungZu) opts.onAufzeichnungZu(); } }, "✕ schließen");
  const knopf = (text, titel, f) => h("button", { title: titel, onclick: f }, text);
  const kZurueck = knopf("◀ zurück", "Einen Schritt zurück", () => gehe(pos - 1));
  const kUeber = knopf("Schritt über", "Die markierte Zeile ganz ausführen – ruft sie eine Funktion auf, läuft die ganz durch", () => gehe(ueber()));
  const kHinein = knopf("Schritt hinein", "Einen einzelnen Schritt – ruft die Zeile eine Funktion auf, geht es in die Funktion hinein", () => gehe(pos + 1));
  const kHeraus = knopf("Schritt heraus", "Die Funktion zu Ende laufen lassen und zurück, wo sie aufgerufen wurde", () => gehe(heraus()));
  const kWeiter = knopf("Weiter ▶▶", "Bis zum nächsten Haltepunkt laufen (Klick auf eine Zeilennummer setzt einen) – ohne Haltepunkt bis zum Ende", () => gehe(weiter()));
  // Schriftgroessen (24.10.): Code und Shell wie im Editor, dazu die Variablen -- je Beamer einstellbar, gemerkt
  const schrift = (art, name) => h("span", { class: "schrift", "data-art": art }, h("span", { class: "schrift-name" }, name),
    h("button", { class: "ruhig", title: name + ": Schrift kleiner", onclick: () => schriftAendern(-1, art) }, "A−"),
    h("button", { class: "ruhig", title: name + ": Schrift größer", onclick: () => schriftAendern(1, art) }, "A+"));
  const schriften = h("span", { class: "dbg-schriften" }, schrift("code", "Code"), schrift("debugger", "Variablen"), schrift("shell", "Shell"));
  steuerung.append(h("b", { class: "dbg-titel" }, zeichen(KAEFER_ZEICHEN, "z-kaefer"), "Debugger"), kZurueck, kUeber, kHinein, kHeraus, kWeiter, schieber, zaehler, ablaeufeEl, schriften, zu);
  // Fenstergroessen (24.10.): ein Trenner zwischen Code und Variablen; im Vortrag einer zwischen Code und Shell, in der
  // Uebung ein Griff unter beiden fuer die Hoehe -- je Beamer einstellbar, gemerkt, Doppelklick setzt zurueck
  const links = h("div", { class: "dbg-links" }, codeansicht);
  const spalt = spaltenTrenner(wrap, breit ? "debugger-vortrag" : "debugger", "--dbg-teilung");
  if (breit) {
    wrap.classList.add("breit");
    wrap.append(steuerung, satzEl, links, spalt, tafel, meld);
    if (ziel._shellZurueck) ziel._shellZurueck();      // ein zweiter Start: die Shell erst aus dem alten Debugger holen
    ziel.textContent = "";
    konsole.style.cssText = "";
    links.append(hoehenTrenner(konsole, "shell-debugger", "Shell"), konsole);
    ziel._shellZurueck = shellZurueck;
  } else {
    wrap.append(steuerung, satzEl, links, spalt, tafel, hoehenGriff(wrap, "debugger", "--dbg-hoehe", "Höhe"), meld);
    if (opts.aufzeichnungsZiel) ziel.textContent = "";
  }
  konsole.hidden = false;
  ziel.append(wrap);

  const quelle = edIch.text().split("\n");
  const halt = new Set();
  const zeilenEl = quelle.map((z, i) => {
    const n = h("span", { class: "n", onclick: () => { halt.has(i + 1) ? halt.delete(i + 1) : halt.add(i + 1); el.classList.toggle("halt", halt.has(i + 1)); } }, String(i + 1));
    const el = h("div", { class: "z" }, n, h("span", {}, z || " "));
    return el;
  });
  codeansicht.append(...zeilenEl);

  const ablaeufe = []; let aktiv = 0, pos = 0, id = null, grenze = null, fehler = null, fertig = false;
  // input() (24.10.): Die Aufzeichnung wartet an einem input(), bis in der Shell eine Zeile getippt wird --
  // wartet = {frage, ablauf}; das Feld erscheint, sobald man im Debugger am letzten Schritt steht
  let wartet = null, nachEingabe = false;
  const ausgaben = []; // {ablauf, schritt, text}: schritt = der Schritt, dessen Zeile gerade lief

  function schritte() { return (ablaeufe[aktiv] || { schritte: [] }).schritte; }
  function tiefe(i) { const s = schritte()[i]; return s ? (s.stapel || []).length : 0; }
  function ueber() { const a = schritte(), t = tiefe(pos); for (let i = pos + 1; i < a.length; i++) if (tiefe(i) <= t) return i; return a.length - 1; }
  function heraus() { const a = schritte(), t = tiefe(pos); for (let i = pos + 1; i < a.length; i++) if (tiefe(i) < t) return i; return a.length - 1; }
  function weiter() { const a = schritte(); for (let i = pos + 1; i < a.length; i++) if (a[i].ereignis === "line" && halt.has(a[i].zeile)) return i; return a.length - 1; }
  function gehe(i) { const a = schritte(); if (!a.length) return; pos = Math.max(0, Math.min(a.length - 1, i)); zeigen(); }

  function ablaufKnoepfe() {
    ablaeufeEl.textContent = "";
    if (ablaeufe.length < 2) return;
    ablaeufe.forEach((a, i) => ablaeufeEl.append(h("button", { class: i === aktiv ? "aktiv" : "", onclick: () => { aktiv = i; pos = 0; zeigen(); } }, a.name + " (" + a.schritte.length + ")")));
  }
  let namen = {};
  function wertEl(w, objekte, tiefe) {
    if (!w) return h("span", {}, "?");
    if (w.art === "wert") return h("span", { class: "vw" }, w.text);
    const typ = ((objekte || {})[w.id] || {}).typ || "Objekt";
    return h("span", { class: "ref", title: "zeigt auf den Kasten " + (namen[w.id] || typ) + " unten" }, "→ " + (namen[w.id] || typ));
  }
  function objektEl(oid, o, objekte) {
    const box = h("div", { class: "objekt" }, h("div", { class: "ot" }, namen[oid] ? h("b", {}, namen[oid]) : null, " " + o.typ));
    if (o.inhalt && (o.typ === "list" || o.typ === "tuple" || o.typ === "set")) o.inhalt.forEach((x, i) => box.append(h("span", { class: "fach" }, h("span", { class: "fn" }, String(i)), wertEl(x, objekte, 1))));
    else if (o.inhalt) o.inhalt.forEach(([k, v]) => box.append(h("div", { class: "var" }, h("span", { class: "vn" }, k.text), wertEl(v, objekte, 1))));
    else box.append(h("span", {}, o.text || ""));
    if (o.mehr) box.append(h("span", { class: "leer" }, " … " + o.mehr + " weitere"));
    return box;
  }
  // Die Shell zeigt, was bis HIER ausgegeben wurde: alles aus früheren Abläufen, im aktuellen alles aus
  // Zeilen, die schon gelaufen sind -- am letzten Schritt auch das Letzte (und die Fehlermeldung).
  function shell(s, letzter) {
    const text = ausgaben.filter(x => x.ablauf < aktiv || (x.ablauf === aktiv && (x.schritt < s.nr || letzter))).map(x => x.text).join("");
    konsole.textContent = "";
    konsole.append(h("span", { class: "satz dbg-shell" }, "Debugger · Ausgabe bis Schritt " + (s.nr + 1) + (letzter && fertig ? " (Ende)" : "")), "\n", text);
    if (letzter && fertig && fehler && aktiv === ablaeufe.length - 1) konsole.append(h("span", { class: "fehlertext" }, "\n" + fehler));
    if (letzter && wartet && aktiv === wartet.ablauf) {
      const feld = h("input", { class: "dbg-eingabe", spellcheck: "false", "aria-label": "Eingabe für input()", placeholder: "eintippen, Enter" });
      feld.addEventListener("keydown", async ev => {
        if (ev.key !== "Enter") return;
        ev.preventDefault();
        const text = feld.value; feld.disabled = true;
        wartet = null; nachEingabe = true;
        try { await api("aufzeichnen/eingabe", { id, text }); } catch (e) { melde(e.message, true); }
      });
      konsole.append(feld);
      setTimeout(() => feld.focus(), 0);
    }
    konsole.scrollTop = 1e9;
  }
  function zeigen() {
    ablaufKnoepfe();
    const a = schritte(); if (!a.length) { tafel.textContent = ""; tafel.append(h("p", { class: "leer" }, "noch keine Schritte")); return; }
    const s = a[pos], letzter = pos === a.length - 1;
    namen = objektNamen(s);
    schieber.max = a.length - 1; schieber.value = pos;
    kZurueck.disabled = pos === 0; kUeber.disabled = kHinein.disabled = kWeiter.disabled = letzter; kHeraus.disabled = letzter || tiefe(pos) <= 1;
    zaehler.textContent = "Schritt " + (pos + 1) + " von " + a.length + " · Zeile " + s.zeile + (s.ereignis === "call" ? " · Aufruf " + s.funktion + "()" : s.ereignis === "return" ? (s.funktion === "<module>" ? " · Ende" : " · Rückkehr aus " + s.funktion + "()") : s.ereignis === "exception" ? " · Ausnahme" : "");
    zeilenEl.forEach((z, i) => z.classList.toggle("aktuell", i + 1 === s.zeile));
    // die markierte Zeile ins Bild -- nur in der Codeansicht scrollen (scrollIntoView schob in der Uebung die Seite und
    // liess die Zeile unten ausserhalb, 24.10.); ein Drittel Luft darueber
    const z = zeilenEl[s.zeile - 1];
    if (z) { const c = codeansicht.getBoundingClientRect(), r = z.getBoundingClientRect(); if (r.top < c.top || r.bottom > c.bottom) codeansicht.scrollTop += (r.top - c.top) - c.height / 3; }
    tafel.textContent = "";
    const glob = h("div", { class: "rahmen" }, h("div", { class: "rt" }, "Variablen (Programm)"));
    const gk = Object.keys(s.global || {}); if (!gk.length) glob.append(h("div", { class: "leer" }, "noch keine"));
    for (const k of gk) glob.append(h("div", { class: "var" }, h("span", { class: "vn" }, k), wertEl(s.global[k], s.objekte)));
    tafel.append(glob);
    if (s.funktion !== "<module>") {
      const lok = h("div", { class: "rahmen" }, h("div", { class: "rt" }, "in " + s.stapel.filter(x => x !== "<module>").join(" → ") + "()"));
      for (const k of Object.keys(s.lokal || {})) lok.append(h("div", { class: "var" }, h("span", { class: "vn" }, k), wertEl(s.lokal[k], s.objekte)));
      if (s.rueckgabe) lok.append(h("div", { class: "var" }, h("span", { class: "vn" }, "↩ Rückgabe"), wertEl(s.rueckgabe, s.objekte)));
      tafel.append(lok);
    }
    if (s.ausnahme) tafel.append(h("div", { class: "rahmen fehler" }, s.ausnahme));
    const ok = Object.keys(s.objekte || {}); if (ok.length) { const ob = h("div", { class: "rahmen" }, h("div", { class: "rt" }, "Objekte")); for (const oid of ok) ob.append(objektEl(oid, s.objekte[oid], s.objekte)); tafel.append(ob); }
    shell(s, letzter);
    wrap.classList.toggle("wartet", !!wartet);
    if (wartet && aktiv === wartet.ablauf) { melde(letzter ? "Das Programm wartet auf eine Eingabe – tippt sie in die Shell und drückt Enter." : "Das Programm wartet bei Schritt " + a.length + " auf eine Eingabe – geht bis dorthin (Weiter ▶▶).", true); meld.dataset.warte = "1"; }
    else if (meld.dataset.warte) { delete meld.dataset.warte; melde(""); }
  }
  schieber.addEventListener("input", () => gehe(parseInt(schieber.value, 10)));

  // Die Meldung (24.10.): Im breiten Debugger steht ein blosser Hinweis nur als Tooltip am Zaehler -- als eigene Zeile
  // sprang sie beim Ziehen der Shell (Lehrer: „verschiebt sich nervig“); sichtbar bleibt nur, was wichtig ist
  // (Fehler, Grenze, Fenster-Programm)
  const melde = (text, wichtig) => { meld.textContent = text; meld.classList.toggle("wichtig", !!wichtig); zaehler.title = text; };
  melde(meld.textContent);
  // Fuer den Code-Film (24.10.): fertig (der Lauf ist aufgezeichnet), gehZu(zeile, mal) springt an das mal-te
  // Erreichen der Zeile, satz(html, impuls) zeigt den Text des Halts, schliessen() wie ✕
  let fertigMelden; const fertigVersprechen = new Promise(r => { fertigMelden = r; });
  const steuer = {
    fertig: fertigVersprechen,
    offen: () => wrap.isConnected,
    gehZu(zeile, mal) {
      const a = schritte(); let n = 0;
      for (let i = 0; i < a.length; i++) if (a[i].ereignis === "line" && a[i].zeile === zeile && ++n === (mal || 1)) { gehe(i); return true; }
      return false;
    },
    satz(html, impuls) { satzEl.innerHTML = (html || "") + (impuls ? '<div class="impuls">' + impuls + "</div>" : ""); satzEl.hidden = !html && !impuls; },
    schliessen: () => zu.click(),
  };
  edIch._dbg = steuer;

  (async () => {
    const eingaben = (opts.eingaben ? opts.eingaben() : []);
    try { id = (await api("aufzeichnen/start", { pfad: edIch.pfad, eingaben })).id; } catch (e) { melde(e.message, true); fertigMelden(false); return; }
    let ab = 0;
    while (true) {
      let b; try { b = await api("aufzeichnen/lesen", { id, ab }); } catch (e) { melde(e.message, true); fertigMelden(false); break; }
      ab = b.bis;
      for (const ev of b.ereignisse) {
        if (ev.art === "ablauf") ablaeufe[ev.nr] = { name: ev.name, schritte: [] };
        else if (ev.art === "schritt") { const a = ablaeufe[ev.ablauf] || (ablaeufe[ev.ablauf] = { name: "Ablauf " + ev.ablauf, schritte: [] }); ev.nr = a.schritte.length; a.schritte.push(ev); }
        else if (ev.art === "ausgabe") ausgaben.push({ ablauf: ev.ablauf, schritt: (ablaeufe[ev.ablauf] || { schritte: [] }).schritte.length - 1, text: ev.text });
        else if (ev.art === "grenze") grenze = ev.text;
        else if (ev.art === "fehler") fehler = ev.text;
        else if (ev.art === "mainloop") melde(ev.text, true);
        else if (ev.art === "warte") wartet = { frage: ev.frage, ablauf: ev.ablauf };
      }
      if (b.fertig) fertig = true;
      if (nachEingabe && schritte().length > pos + 1) { nachEingabe = false; pos++; }   // wie in Thonny: nach Enter geht es weiter
      // nur bei Neuem zeichnen -- sonst ersetzte jede Abfrage (alle 250 ms) das Eingabefeld in der Shell
      if (b.ereignisse.length || b.fertig) zeigen();
      if (b.fertig) fertigMelden(true);
      if (b.fertig) {
        if (grenze) { melde("⚠ " + grenze, true); meld.classList.add("fehler"); }
        else if (fehler) melde("Der Debugger ist fertig – das Programm ist mit einem Fehler geendet; der letzte Schritt zeigt die Stelle.", true);
        else melde("Der Debugger ist fertig: " + ablaeufe.reduce((n, a) => n + a.schritte.length, 0) + " Schritte" + (ablaeufe.length > 1 ? " in " + ablaeufe.length + " Abläufen" : "") + ". Die markierte Zeile läuft als Nächstes. Klick auf eine Zeilennummer setzt einen Haltepunkt für „Weiter“.");
        break;
      }
      await schlafen(250);
    }
  })();
  return steuer;
}
