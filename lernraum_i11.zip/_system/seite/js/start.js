/* Lernraum · start.js -- der Start.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Start ──────────────────────────────────────────────────────────────────────────────
laden().then(zeichnen).catch(e => { $("#haupt").textContent = ""; $("#haupt").append(h("p", { class: "fehler seite" }, "Die Seite konnte nicht laden: " + e.message)); });
