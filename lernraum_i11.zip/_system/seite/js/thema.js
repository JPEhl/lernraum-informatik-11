/* Lernraum · thema.js -- Thema mit Reitern, Vortrag, Erklärung.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Thema mit Reitern ─────────────────────────────────────────────────────────
function themaSeite(haupt, reiheK, themaK, reiter, extra) {
  const T = thema(reiheK, themaK);
  if (!T) { haupt.append(h("p", { class: "fehler" }, "Thema unbekannt.")); return; }
  const frei = Z.lehrer || !!(Z.stand.kennwoerter || {})[T.pfad];
  kopfZeichnen([[T.reihe.titel, adr("")], [T.thema.titel, adr("t/" + T.pfad + "/vortrag")]]);
  haupt.append(h("div", { class: "thema-kopf" }, h("h1", {}, "Thema " + T.thema.nr + " · " + T.thema.titel), T.thema.untertitel ? h("div", { class: "unter" }, T.thema.untertitel) : null));
  const reiterDef = [["vortrag", "Vortrag"], ["erklaerung", "Erklärung"], ["uebung", "Übung"]];
  if (T.thema.werkstatt) reiterDef.push(["werkstatt", "Werkstatt"]);
  if (T.thema.hat_loesung) reiterDef.push(["loesung", "Lösung"]);
  if (Z.lehrer) reiterDef.push(["regie", "Regie"], ["werkbuch", "Werkbuch"]);
  const zu = k => k === "loesung" && !frei;
  Object.assign(HIER, { thema: T.pfad, reiter, schritt: 0, marker: 0 });
  // eigener Tag (header), kein div: die Nadel-Anker zaehlen „#haupt > div:nth-of-type(n)“ (19.10.,
  // mit einem div verrutschten alle Nadeln, Haken und Haengestellen um eins)
  haupt.append(h("header", { class: "reiter-zeile" }, h("nav", { class: "reiter" }, reiterDef.map(([k, n]) => h("a", { href: adr("t/" + T.pfad + "/" + k), class: (k === reiter ? "aktiv" : "") + (zu(k) ? " gesperrt" : "") + (k === "regie" || k === "werkbuch" ? " nur-lehrer nur-ohne-beamer" : "") }, n, zu(k) ? zeichen(SCHLOSS_ZEICHEN, "z-schloss") : null))),
    reiter === "regie" || reiter === "werkbuch" ? null : lesezeichenKnopf()));
  api("stand/lesestelle", { thema: T.pfad, wo: { reiter, extra: extra || "" } }).catch(() => {});
  ({ vortrag: vortragSeite, erklaerung: erklaerungSeite, uebung: uebungSeite, werkstatt: werkstattSeite, loesung: loesungSeite, regie: regieSeite, werkbuch: werkbuchSeite }[reiter] || vortragSeite)(haupt, T, extra);
}

// Wo der Unterricht steht -- das LESEZEICHEN (Lehrer 19.10., Fassung A: „manuell einstellen … nach
// jeder Stunde als kleinen Marker“). Nur ein Klick auf „Hier aufgehört“ merkt die Stelle; von selbst
// geschieht nichts mehr. Bis dahin merkte das Pult jedes Öffnen außerhalb der Durchsicht (16.10.,
// ab 17.10. mit Stundenplan nur in der Stunde) -- ohne Stundenplan stand dann die Vorbereitung als
// „Beim nächsten Mal weiter“ da. HIER ist die Stelle, die gerade zu sehen ist (Thema, Reiter,
// Vortragsschritt, Fahrplan-Marker); der Knopf liest sie beim Klick.
const HIER = { thema: "", reiter: "", schritt: 0, marker: 0 };
let LESEZEICHEN_KNOPF = null;
function unterrichtStelle(thema) { return (((Z.stand.unterricht || {}).themen) || {})[thema] || null; }
function lesezeichenHier() {
  const st = unterrichtStelle(HIER.thema);
  return !!st && (Z.stand.unterricht || {}).zuletzt === HIER.thema && st.reiter === HIER.reiter
    && (HIER.reiter !== "vortrag" || (st.schritt === HIER.schritt && (st.marker || 0) === (HIER.marker || 0)));
}
function lesezeichenKnopf() {
  if (!Z.lehrer) return null;
  // auch am Beamer sichtbar: er zeigt der Klasse nichts, und am Ende der Stunde soll niemand umschalten
  LESEZEICHEN_KNOPF = h("button", { type: "button", class: "lesezeichen-knopf", onclick: async () => {
    try { const r = await api("unterricht/lesezeichen", { thema: HIER.thema, reiter: HIER.reiter, schritt: HIER.schritt, marker: HIER.marker, weg: lesezeichenHier() }); Z.stand.unterricht = r.unterricht; }
    catch (e) { return; }
    lesezeichenZeichnen();
  } });
  lesezeichenZeichnen();
  return LESEZEICHEN_KNOPF;
}
function lesezeichenZeichnen() {
  const b = LESEZEICHEN_KNOPF; if (!b) return;
  const an = lesezeichenHier();
  b.classList.toggle("gesetzt", an); b.textContent = "";
  b.append(zeichen(LESEZEICHEN_ZEICHEN, "z-lesezeichen"), an ? "Lesezeichen hier" : "Hier aufgehört");
  b.title = an ? "Hier geht es beim nächsten Mal weiter – ein Klick nimmt das Lesezeichen weg" : "Am Ende der Stunde: Hier geht es beim nächsten Mal weiter";
  b.setAttribute("aria-pressed", String(an));
}
// Die Sozialform eines Schritts oder einer Aufgabe (Block 2): eine kleine Marke, eigener Tag (small),
// damit die nth-of-type-Anker der Nadeln bleiben.
function sozialMarke(formen) { return formen && formen.length ? h("small", { class: "sozialform", title: "Sozialform" }, formen.join(" → ")) : null; }

// Das Zeichen der Marke „Jetzt ihr": Block mit Stift, gezeichnet statt Emoji -- sieht unter
// Windows und auf dem Mac gleich aus (Lehrerwahl 14.10., vorher ✋).
const MARKE_ZEICHEN = '<svg viewBox="0 0 48 48" aria-hidden="true">'
  + '<rect class="mz-block" x="6" y="5" width="28" height="36" rx="5"/>'
  + '<path class="mz-linie" d="M12 15h16M12 22h16M12 29h9"/>'
  + '<path class="mz-stift" d="M27 42.5l2.2-7.4 12.6-15.6 5.2 4.2-12.6 15.6z"/>'
  + '<path class="mz-spitze" d="M27 42.5l2.2-7.4 3.1 2.5z"/></svg>';

// ─── Vortrag ───────────────────────────────────────────────────────────────────────
function vortragSeite(haupt, T, extra) {
  const schritte = T.thema.vortrag;
  let nr = Math.max(1, Math.min(schritte.length, parseInt(extra || "1", 10) || 1));
  const wrap = h("div", { class: "vortrag" });
  const leiste = h("div", { class: "schrittleiste" });
  const inhalt = h("div", {});
  const regie = h("div", { class: "regie-leiste nur-lehrer nur-ohne-beamer" });
  const regieTrenner = hoehenTrenner(regie, "regie", "Regie");
  regieTrenner.classList.add("nur-lehrer", "nur-ohne-beamer");
  wrap.append(leiste, inhalt, regieTrenner, regie); haupt.append(wrap);
  let regieAn = false;
  let filmAktiv = null;   // der Code-Film des aktuellen Schritts (nur im Pult), sonst null
  function gehe(n) { nr = Math.max(1, Math.min(schritte.length, n)); location.hash = adr("t/" + T.pfad + "/vortrag/" + nr); }
  function zeigen() {
    leiste.textContent = "";
    schritte.forEach(s => leiste.append(h("span", { class: "punkt " + s.art + (s.nr === nr ? " aktiv" : ""), title: s.titel || s.art, onclick: () => gehe(s.nr) }, String(s.nr))));
    leiste.append(h("span", { class: "zaehler" }, nr + " / " + schritte.length));
    // „Weiter →“ / „← Zurück“ wechseln immer die FOLIE; durch die kleinen Schritte eines Films gehen →/Bild ↓ (Praesenter)
    // und ▶ (Lehrer 24.10., T14 W1: „Ein Klick auf weiter sollte auf die nächste Folie führen“)
    leiste.append(h("span", { class: "pfeile" }, h("button", { class: "ruhig", onclick: () => gehe(nr - 1), disabled: nr === 1 }, "← Zurück"), h("button", { class: "weiter", onclick: () => gehe(nr + 1), disabled: nr === schritte.length }, "Weiter →"),
      Z.lehrer ? h("button", { class: "ruhig nur-ohne-beamer", onclick: () => { regieAn = !regieAn; regie.hidden = regieTrenner.hidden = !regieAn; } }, "Regie") : null));
    const s = schritte[nr - 1];
    filmAktiv = null;
    inhalt.textContent = ""; inhalt.className = "schritt " + s.art;
    HIER.schritt = nr; HIER.marker = s.fahrplan ? fahrplanStart(s, T.pfad) : 0; lesezeichenZeichnen();
    regie.hidden = regieTrenner.hidden = !regieAn; regie.textContent = "";
    const regieText = s.regie ? h("div", { html: s.regie }) : h("span", { class: "leer" }, "keine Regie zu diesem Schritt");
    // Beim Tippen steht das Ziel daneben (Lehrer 14.10.: „den Zielcode anzeigen")
    if (s.ziel_text) { regie.classList.add("mit-ziel"); regie.append(regieText, h("div", { class: "ziel" }, h("div", { class: "zt" }, "Ziel zum Abtippen · " + s.ziel), h("pre", { class: "code" }, h("code", {}, s.ziel_text)))); }
    else { regie.classList.remove("mit-ziel"); regie.append(regieText); }
    if (s.art === "folie") {
      // Der Impuls kommt aus bauen.inline() schon als HTML (sonst stand „zuege &lt; 30“ da, T4 17.10.);
      // eine Folie ohne Impuls haengt nichts an -- DOM-append schreibt null als Text „null“
      if (s.spalten) {
        // form="spalten" (25.10.): das erste Bild, der erste Code oder die erste Tabelle links, der Rest und der Impuls rechts
        const d = h("div", { html: s.html }), kinder = [...d.children];
        const i = kinder.findIndex(k => /^(PRE|TABLE|FIGURE)$/.test(k.tagName) || !!k.querySelector("img, pre, table"));
        const links = h("div", { class: "spalte-links" }), rechts = h("div", { class: "spalte-rechts" });
        kinder.forEach((k, j) => (j === i ? links : rechts).append(k));
        if (s.impuls) rechts.append(h("div", { class: "impuls", html: s.impuls }));
        inhalt.classList.add("spalten");
        inhalt.append(h("h2", {}, s.titel, sozialMarke(s.sozialform)), h("div", { class: "spalten-zeile" }, links, rechts));
      } else inhalt.append(h("h2", {}, s.titel, sozialMarke(s.sozialform)), h("div", { html: s.html }), ...(s.impuls ? [h("div", { class: "impuls", html: s.impuls })] : []));
      bilderPfad(inhalt, T.pfad);     // Bilder auf Folien (17.10., T5 W1: die erste Folie mit Bild -- vorher fehlte der Pfad)
    } else if (s.art === "marke") {
      inhalt.append(h("h2", {}, h("span", { class: "marke-zeichen", html: MARKE_ZEICHEN }), s.titel, sozialMarke(s.sozialform)), h("div", { html: s.html }));
      bilderPfad(inhalt, T.pfad);     // ein Bild an der Marke (T10, 21.10.: die zwei Plaene der Runde -- vorher fehlte der Pfad)
    } else if (s.art === "merke") {
      inhalt.append(h("div", { class: "merke" }, h("div", { class: "merke-titel" }, s.titel), h("div", { html: s.html })));
      bilderPfad(inhalt, T.pfad);     // ein Bild im Merke (T6 W4, 19.10.: „grafisch nochmal hier zeigen“)
    } else if (s.art === "werkstatt") {
      const links = h("div", {}); const rechts = h("div", { class: "nebentext" }, h("h2", {}, s.titel || "Werkstatt", sozialMarke(s.sozialform)), h("div", { html: s.html }), s.impuls ? h("div", { class: "impuls", html: s.impuls }) : null);
      inhalt.append(links, rechts);
      werkstattEinbauen(links, s.name, T, s.optionen);
    } else if (s.art === "code" || s.art === "html") {
      const pfad = "themen/" + T.pfad + "/vortrag/" + s.arbeit;
      const kopf = h("div", { class: "kopfzeile" }, h("h2", {}, s.titel || s.arbeit), h("span", { class: "modus " + s.modus }, s.modus), h("span", { class: "leer" }, s.arbeit), sozialMarke(s.sozialform));
      // Code-Film (21.10.): der Text rechts wächst Schritt für Schritt -- im Pult und, ohne Regie, offen für die Klasse
      // (Lehrer 22.10.: „nicht nötig, dass der Vortrag gesperrt ist“; bis dahin erst mit dem Kennwort der Lösung)
      const film = s.film || null;
      const filmText = h("div", { class: "film-text" }), filmImpuls = h("div", { class: "impuls" }); filmImpuls.hidden = true;
      const rechts = h("div", { class: "nebentext" + (film ? " mit-film" : "") }, h("div", { class: "film-einleitung", html: s.html }),
        film ? filmText : null,
        film ? filmImpuls : (s.impuls ? h("div", { class: "impuls", html: s.impuls }) : null));
      let vorschau = null;
      const zusatz = [
        () => h("button", { onclick: async () => { if (!confirm("Zielfassung in den Editor laden? Deine Änderungen hier werden ersetzt.")) return; const a = await api("datei/zuruecksetzen", { pfad, auf: "ziel" }); ed.setzen(a.text); if (vorschau) vorschauNeu(); } }, zeichen(AUGE_ZEICHEN, "z-auge"), "aufdecken"),
        () => h("button", { class: "ruhig", onclick: async () => { if (!confirm("Zurück zum Startzustand?")) return; const a = await api("datei/zuruecksetzen", { pfad, auf: "start" }); ed.setzen(a.text); if (vorschau) vorschauNeu(); } }, "↺ zum Start"),
      ];
      // Der Debugger im Vortrag (24.10.): eine eigene Flaeche ueber die ganze Breite; solange er offen ist, sind Editor und
      // Nebentext ausgeblendet (vorher stand er in der rechten Spalte -- „so groß, dass man gar nichts erkennt“)
      const dbgFlaeche = h("div", { class: "dbg-flaeche" }); dbgFlaeche.hidden = true;
      const ed = arbeitsEditor({ pfad, thema: T.pfad, ort: "vortrag/" + s.nr, sprache: s.art === "html" ? "html" : "python", zusatzKnoepfe: zusatz, ohneAufzeichnung: s.art === "html",
        eingabenVorschlag: T.thema.eingaben, aufzeichnungBreit: true,
        aufzeichnungsZiel: () => { inhalt.classList.add("debug-an"); dbgFlaeche.hidden = false; return dbgFlaeche; },
        onAufzeichnungZu: () => { inhalt.classList.remove("debug-an"); dbgFlaeche.hidden = true; },
        onGespeichert: () => { if (vorschau) vorschauNeu(); } });
      function vorschauNeu() { vorschau.src = "/" + pfad + "?t=" + Date.now(); }
      inhalt.append(kopf);
      // Die Zielzeile (21.10.): ein Satz, was das Programm danach kann -- für dich in einem Jahr und für die Klasse
      if (s.ziel_satz) { inhalt.classList.add("mit-ziel"); inhalt.append(h("div", { class: "ziel-zeile" }, h("b", {}, "Ziel: "), h("span", { html: s.ziel_satz }))); }
      bilderPfad(rechts, T.pfad);     // ein Bild neben dem Editor -- das Struktogramm, nach dem getippt wird (T6 W1/W8/W10, 19.10.)
      if (s.fahrplan) {
        inhalt.classList.add("mit-fahrplan");
        if (film) {
          const regieJetzt = h("div", { class: "regie-jetzt" }); regieJetzt.hidden = true; if (Z.lehrer) regie.prepend(regieJetzt);
          filmAktiv = filmSpieler(s, T, nr, ed, filmText, filmImpuls, regieJetzt);
          inhalt.append(filmAktiv.nav);
        } else {
          inhalt.append(fahrplanLeiste(s, T, nr, ed));
        }
      }
      // Ein Trenner zwischen Editor und Text (24.10.: „Fenstergröße … je nach Auflösung des Beamers“), gemerkt
      inhalt.append(ed.box, spaltenTrenner(inhalt, "vortrag", "--vortrag-teilung"), rechts, dbgFlaeche);
      if (s.art === "html") {
        vorschau = h("iframe", { class: "vorschau", title: "Vorschau" }); vorschau.style.width = "100%"; vorschau.style.height = "60vh"; vorschau.style.border = "1px solid #cfd8e1"; vorschau.style.background = "#fff";
        rechts.prepend(vorschau); vorschauNeu();
        $(".werkzeuge button.primaer", ed.box).hidden = true; $(".werkzeuge button.gefahr", ed.box).hidden = true;
      } else { ed.box.append(hoehenTrenner(ed.konsole, "shell-vortrag", "Shell"), ed.konsole); }
      ed.laden();
    }
  }
  zeigen();
  // Pfeiltasten und Präsenter (Bild ↓/↑): In einem Codeschritt mit Film geht es zuerst durch die kleinen Schritte,
  // erst nach dem letzten auf die nächste Folie -- wie Animationen in PowerPoint (21.10.). Der Präsenter wirkt
  // auch, wenn der Cursor im Editor steht; die Pfeile dort bleiben fürs Tippen.
  window.onkeydown = async ev => {
    const imFeld = ["INPUT", "TEXTAREA"].includes(document.activeElement.tagName) || !!document.activeElement.closest(".cm-editor");
    const vor = ev.key === "PageDown" || (!imFeld && ev.key === "ArrowRight"), rueck = ev.key === "PageUp" || (!imFeld && ev.key === "ArrowLeft");
    if (!vor && !rueck) return;
    if (filmAktiv) { ev.preventDefault(); const ok = vor ? await filmAktiv.weiter() : filmAktiv.zurueck(); if (!ok) gehe(nr + (vor ? 1 : -1)); return; }
    if (imFeld) return;
    gehe(nr + (vor ? 1 : -1));
  };
}
// Der Fahrplan (Block 2, Lehrerwahl 16.10.: Fassung C, eine Leiste über dem Editor): 3–5 Marker,
// kein Code. Weiter nur von Hand -- ein Klick auf den Marker (automatisch nach dem Ausführen passt
// nicht: die Abstimmung liegt vor dem Ausführen, manche Marker brauchen zwei Läufe). Im Pult beginnt er
// beim Marker des Lesezeichens (sonst bei ①); die Klasse sieht ihn ohne Hervorhebung, bis sie klickt.
function fahrplanStart(s, pfad) {
  if (!Z.lehrer) return 0;
  const st = unterrichtStelle(pfad);
  return st && st.reiter === "vortrag" && st.schritt === s.nr && st.marker ? Math.min(st.marker, s.fahrplan.length) : 1;
}
function fahrplanLeiste(s, T, nr, ed) {
  const nav = h("nav", { class: "fahrplan", "aria-label": "Fahrplan" });
  let jetzt = fahrplanStart(s, T.pfad);
  const knoepfe = s.fahrplan.map((t, i) => h("button", { type: "button", onclick: () => { jetzt = i + 1; zeichnen(); if (HIER.schritt === nr) { HIER.marker = jetzt; lesezeichenZeichnen(); } } },
    h("span", { class: "fp-n" }, "①②③④⑤"[i]), h("span", { html: t })));
  function zeichnen() { knoepfe.forEach((k, i) => { k.className = !jetzt ? "" : i + 1 < jetzt ? "fertig" : i + 1 === jetzt ? "jetzt" : ""; k.setAttribute("aria-current", String(i + 1 === jetzt)); }); }
  nav.append(...knoepfe); zeichnen();
  return nav;
}
// Der Code-Film (Lehrerwunsch 21.10., T11): zwei Ebenen -- die Kapitel sind die Marker der Leiste, darin kleine
// Schritte. „Weiter“ tippt den nächsten Schritt sichtbar (Animation im Editor), ein Klick während des Tippens macht
// ihn sofort fertig, „Zurück“ zeigt den Stand davor ohne Animation, ein Kapitel-Marker springt an den Kapitelanfang
// und spielt dessen ersten Schritt. Rechts wächst der Text innerhalb eines Kapitels, der Impuls ist der letzte des
// Kapitels; die Regiezeile steht oben im Regie-Fenster (nie am Beamer).
// Tempo (Lehrer 21.10.: „Tippen ruhig könnte sogar noch ruhiger sein“): ruhig 18 Zeichen/s, höchstens 3,5 s je Schritt
let filmEinpassenJetzt = null;   // die Mini-Folie des Films, der gerade zu sehen ist, passt sich beim Ändern der Fenstergröße neu ein
window.addEventListener("resize", () => { if (filmEinpassenJetzt) filmEinpassenJetzt(); });
const FILM_TEMPO = { ruhig: { zps: 18, maxSek: 3.5, rotMs: 800 }, zuegig: { zps: 60, maxSek: 1, rotMs: 350 } };
function filmSpieler(s, T, nr, ed, filmText, filmImpuls, regieJetzt) {
  const F = s.film, n = F.length;
  let idx = -1;
  const stand = k => { for (let i = k; i >= 0; i--) if (F[i].art === "code") return F[i].code; return s.film_start; };
  const vorStand = k => { for (let i = k; i >= 0; i--) if (F[i].art === "code") return stand(i - 1); return s.film_start; };
  let tempoName = "ruhig"; try { tempoName = localStorage.getItem("lernraum.filmtempo") || "ruhig"; } catch (e) {}
  const nav = h("nav", { class: "fahrplan film", "aria-label": "Code-Film" });
  const knoepfe = s.fahrplan.map((t, i) => h("button", { type: "button", title: "Kapitel " + (i + 1) + " von vorn", onclick: () => kapitel(i + 1) },
    h("span", { class: "fp-n" }, "①②③④⑤"[i]), h("span", { html: t })));
  const zaehler = h("span", { class: "film-zaehler" });
  const tempoWahl = h("select", { class: "film-tempo nur-ohne-beamer", title: "Wie schnell der Code getippt wird", onchange: () => { tempoName = tempoWahl.value; try { localStorage.setItem("lernraum.filmtempo", tempoName); } catch (e) {} } },
    h("option", { value: "ruhig" }, "Tippen: ruhig"), h("option", { value: "zuegig" }, "Tippen: zügig"));
  tempoWahl.value = tempoName;
  const knopfZurueck = h("button", { type: "button", class: "ruhig film-schritt", title: "einen kleinen Schritt zurück (Bild ↑)", onclick: () => zurueck() }, "◀");
  const knopfWeiter = h("button", { type: "button", class: "film-schritt", title: "nächster kleiner Schritt (→, Bild ↓, Präsenter)", onclick: () => weiter() }, "▶");
  nav.append(...knoepfe, h("span", { class: "film-steuer" }, knopfZurueck, zaehler, knopfWeiter, tempoWahl));
  // Die rechte Seite ist eine Mini-Folie (Lehrer 21.10.: „der Text rechts [ist] sehr klein … Warum bauen wir die rechte
  // Seite nicht wie Mini-Folien auf?“, Variante C): innerhalb eines Kapitels baut sie sich auf -- der aktuelle Teil
  // groß, die vorherigen kleiner --, eine Abstimmung (ein Halt mit Liste A/B/C) ist eine eigene Mini-Folie.
  const startKap = Z.lehrer ? fahrplanStart(s, T.pfad) : 0;
  let kapFest = 0;   // mit Lesezeichen: das Kapitel, vor dessen erstem Schritt der Film steht
  // Ein Bild in der Einleitung (das Struktogramm, nach dem getippt wird, T6) steht auf jeder Mini-Folie, der Text nur
  // vor dem Start und im ersten Kapitel
  const einl = new DOMParser().parseFromString(s.html || "", "text/html").body; const bildTeile = [];   // ohne Laden der Bilder
  einl.querySelectorAll("img").forEach(img => { const huelle = img.closest("p, figure") || img; if (!bildTeile.includes(huelle)) bildTeile.push(huelle); });
  const einleitungBilder = bildTeile.map(b => b.outerHTML).join("");
  bildTeile.forEach(b => b.remove());
  const einleitungText = einl.innerHTML;
  function zeichnen() {
    const kap = kapFest || (idx >= 0 ? F[idx].kapitel : startKap);
    const folie = filmText.parentElement;
    const abstimmung = idx >= 0 && F[idx].art === "halt" && /<(ul|ol)\b/.test(F[idx].text || "");
    if (folie) folie.classList.toggle("abstimmung", abstimmung);
    knoepfe.forEach((k, i) => { k.className = !kap ? "" : i + 1 < kap ? "fertig" : i + 1 === kap ? "jetzt" : ""; k.setAttribute("aria-current", String(i + 1 === kap)); });
    zaehler.textContent = (idx + 1) + " / " + n + (halb === "kopie" ? " · kopiert" : halb ? " · rot" : "");
    zaehler.title = halb === "kopie" ? "Markiert ist, was kopiert wird -- der nächste Druck fügt es ein" : halb ? "Rot ist, was gleich wegfällt -- der nächste Druck löscht und tippt das Neue" : "";
    filmText.textContent = ""; let impuls = "";
    // wie eine Folie: oben das Kapitel als Titel; die Einleitung des Schritts steht vor dem Start groß, im ersten Kapitel
    // als erster (kleiner) Teil
    if (idx < 0) filmText.append(h("div", { class: "film-teil jetzt", html: einleitungText }), einleitungBilder ? h("div", { class: "film-bild", html: einleitungBilder }) : "", h("p", { class: "film-start nur-ohne-beamer" }, "→, Bild ↓ (Präsenter) oder ▶ tippt den ersten kleinen Schritt. „Weiter →“ geht zur nächsten Folie."));
    else {
      filmText.append(h("h3", { class: "film-kapitel" }, h("span", { class: "kap-nr" }, "①②③④⑤"[kap - 1]), h("span", { html: s.fahrplan[kap - 1] })));
      if (einleitungBilder) filmText.append(h("div", { class: "film-bild", html: einleitungBilder }));   // der Plan bleibt auf jeder Mini-Folie, gleich unter dem Titel
      if (kap === 1 && einleitungText.trim()) filmText.append(h("div", { class: "film-teil", html: einleitungText }));
    }
    for (let i = 0; i <= idx; i++) if (F[i].kapitel === kap) { if (F[i].text) filmText.append(h("div", { class: "film-teil" + (i === idx ? " jetzt" : ""), html: F[i].text })); if (F[i].impuls) impuls = F[i].impuls; }
    bilderPfad(filmText, T.pfad);
    filmImpuls.innerHTML = impuls; filmImpuls.hidden = !impuls;
    einpassen();
    filmText.querySelectorAll("img").forEach(img => { if (!img.complete) img.addEventListener("load", einpassen, { once: true }); });
    const r = idx >= 0 ? F[idx].regie : "";
    regieJetzt.innerHTML = r ? "<b>Jetzt:</b> " + r : ""; regieJetzt.hidden = !r;
    if (HIER.schritt === nr && kap) { HIER.marker = kap; lesezeichenZeichnen(); }
  }
  // Die Mini-Folie passt immer aufs Bild (Messlauf 22.10.: in Folienschrift lief sie bei 1400 × 900 an 30 Stellen
  // über): erst die Schrift Stufe um Stufe kleiner, bis höchstens 0,75 der Folienschrift; reicht das nicht, fallen
  // die ältesten grauen Teile weg -- der aktuelle Text, das Bild und der Impuls bleiben immer.
  function einpassen() {
    const folie = filmText.parentElement; if (!folie) return;
    if (!folie.isConnected) { einpassen.warten = (einpassen.warten || 0) + 1; if (einpassen.warten < 20) requestAnimationFrame(einpassen); return; }   // noch nicht eingehängt
    einpassen.warten = 0;
    const zuViel = () => folie.scrollHeight > folie.clientHeight + 1;
    folie.style.fontSize = ""; filmText.querySelectorAll(".film-teil").forEach(t => { t.hidden = false; });
    const voll = parseFloat(getComputedStyle(folie).fontSize);
    for (let f = 1; zuViel() && f > 0.75; ) { f = Math.round((f - 0.05) * 100) / 100; folie.style.fontSize = (voll * f) + "px"; }
    for (const t of filmText.querySelectorAll(".film-teil:not(.jetzt)")) { if (!zuViel()) break; t.hidden = true; }
  }
  filmEinpassenJetzt = einpassen;

  // halb: Der Schritt löscht etwas -- der erste Druck hat es nur rot markiert, der zweite löscht und tippt.
  // halb === "kopie": ein Einfüge-Schritt -- der erste Druck markiert die Quelle, der zweite fügt auf einmal ein.
  let halb = false;
  const tempo = () => FILM_TEMPO[tempoName] || FILM_TEMPO.ruhig;
  // + debugger (24.10.): Ein Halt startet den Debugger (einmal je Folge von Halten) und springt an seine Zeile; jeder
  // andere Schritt schliesst ihn -- der Code im Editor gehoert dann wieder dem Film
  let dbgLauf = 0;
  function debugAbgleich() {
    const x = F[idx], lauf = ++dbgLauf;
    if (!x || x.art !== "debug") { if (ed.debuggerZu) ed.debuggerZu(); return; }
    (async () => {
      const d = await ed.debuggerStarten(x.eingaben); if (!d) return;
      await d.fertig; if (lauf !== dbgLauf) return;
      if (!d.gehZu(x.zeile, x.mal)) d.satz("<p><b>Zeile " + x.zeile + " wird " + (x.mal > 1 ? "kein " + x.mal + ". Mal" : "nicht") + " erreicht.</b></p>", "");
      else d.satz(x.text, x.impuls);
    })();
  }
  function abspielen() {
    const x = F[idx];
    debugAbgleich();
    // ein Programm, das noch läuft (die Endlosschleife der Probe in T10), hält an, sobald sich der Code ändert
    if (x.art === "code" && ed.laeuft && ed.laeuft()) ed.stopp();
    if (x.art === "code" && x.einfuegen) { halb = "kopie"; ed.kopieMarkieren(x.code, stand(idx - 1)); zeichnen(); }
    else if (x.art === "code" && ed.hatWeg(x.code, stand(idx - 1))) { halb = true; ed.wegMarkieren(x.code, stand(idx - 1)); zeichnen(); }
    else if (x.art === "code") ed.standAnimieren(x.code, stand(idx - 1), tempo());
    else if (x.art === "lauf") ed.ausfuehren(x.eingaben);
  }
  async function weiter() {
    if (ed.laeuftAnimation()) { ed.animationFertig(); return true; }
    if (halb === "kopie") { halb = false; zeichnen(); ed.standZeigen(F[idx].code, stand(idx - 1)); return true; }
    if (halb) { halb = false; zeichnen(); ed.standAnimieren(F[idx].code, stand(idx - 1), Object.assign({}, tempo(), { schonRot: true })); return true; }
    if (idx >= n - 1) return false;
    kapFest = 0; idx++; zeichnen(); abspielen();
    return true;
  }
  function zurueck() {
    if (idx < 0) return false;
    ed.animationFertig(); if (ed.laeuft()) ed.stopp(); kapFest = 0; halb = false; idx--; zeichnen();
    ed.standZeigen(stand(idx), vorStand(idx));
    debugAbgleich();
    return true;
  }
  function kapitel(m) {
    ed.animationFertig(); if (ed.laeuft()) ed.stopp(); halb = false;
    idx = F.findIndex(x => x.kapitel === m) - 1;
    ed.standZeigen(stand(idx), stand(idx));
    kapFest = 0; idx++; zeichnen(); abspielen();
  }
  // Mit Lesezeichen in einem späteren Kapitel: dort weitermachen (der Code steht auf dem Stand davor)
  const start = fahrplanStart(s, T.pfad);
  if (start > 1) { idx = F.findIndex(x => x.kapitel === start) - 1; kapFest = start; ed.ladenDann(() => ed.standZeigen(stand(idx), stand(idx))); }
  zeichnen();
  return { nav, weiter, zurueck };
}
function werkstattEinbauen(el, name, T, opt) {
  const w = (window.Werkstaetten || {})[name];
  if (!w) { el.append(h("p", { class: "fehler" }, "Werkstatt „" + name + "“ ist nicht gebündelt.")); return; }
  w(el, opt || {});
}

// ─── Erklärung ─────────────────────────────────────────────────────────────────────
// Seit Block B (Galerie 15.10., Rang 5–7): Lernpfad links (Inhaltsverzeichnis, das mitläuft),
// je Abschnitt eine Prüffrage, Beispiele in drei Stufen, Glossarbegriffe gepunktet. Alles Neue
// steht in eigenen Tags (nav, fieldset, figure, glossar-wort) -- die nth-of-type-Anker der
// Absätze und Kästen (Nadeln, Anmerkungen, Werkbuch) bleiben, wie sie waren.
function erklaerungSeite(haupt, T, extra) {
  const inhalt = h("div", { html: T.thema.erklaerung });
  const s = h("div", { class: "seite erklaerung" }, inhalt);
  bilderPfad(s, T.pfad);
  kopierKnoepfe(s);
  s.querySelectorAll(".beispiel").forEach(b => b.append(...ausfuehrTeil(T, b.dataset.datei)));
  const fragen = [...s.querySelectorAll("fieldset.pruef")].map(f => pruefFrage(f, T));
  s.querySelectorAll("figure.stufen").forEach(f => stufenBeispiel(f, T));
  glossarMarkieren(inhalt);
  if (fragen.length) lernpfad(s, inhalt, T, fragen);
  haupt.append(s);
  // Sprungziel (Glossar: „erklärt in …“): hinscrollen, dann die Adresse ohne Ziel -- sonst
  // wäre es für Nadeln und Urteile eine eigene Ansicht.
  if (extra) {
    const z = document.getElementById(extra);
    history.replaceState(null, "", adr("t/" + T.pfad + "/erklaerung"));
    if (z) requestAnimationFrame(() => z.scrollIntoView({ block: "start" }));
  }
}
function ausfuehrTeil(T, datei) {
  const pfad = "themen/" + T.pfad + "/" + datei;
  const konsole = h("div", { class: "konsole" }); konsole.hidden = true;
  const knopf = h("button", { type: "button", onclick: async () => {
    konsole.hidden = false; konsole.textContent = ""; let lauf;
    try { lauf = await api("lauf/start", { pfad, thema: T.pfad, ort: "erklaerung" }); } catch (e) { konsole.textContent = e.message; return; }
    let ab = 0; while (true) { const r = await api("lauf/lesen", { id: lauf.id, ab }); if (r.text) konsole.append(r.text); ab = r.bis; if (r.fertig) { if (r.fehler) konsole.append(h("span", { class: "satz" }, r.fehler.satz), fehlerbuchHinweis(r.fehlerbuch)); break; } await schlafen(200); }
  } }, "▶ Ausführen");
  return [knopf, konsole];
}

// Prüffrage (::: frage): eine Wahl, sofort die Begründung, keine Note. Gelöst = der Abschnitt
// gilt als gelesen (im Stand). Danach lassen sich die anderen Wahlen noch nachlesen.
function pruefFrage(f, T) {
  // Seit 16.10. kennt die Seite die richtige Wahl nicht mehr (sie zählt für die Sterne): der Server
  // sagt es je Klick; eine gelöste Frage merkt sich ihre richtige Wahl im Stand.
  const name = f.dataset.frage, kennung = T.pfad + "/" + name;
  const knoepfe = [...f.querySelectorAll(".pf-w")], warum = [...f.querySelectorAll(".pf-warum")];
  const st = () => (Z.stand.fragen || {})[kennung] || {};
  const ich = { el: f, kennung, geloest: () => !!st().geloest, beimLoesen: null };
  const zeigen = (i, richtig) => warum.forEach(w => { w.hidden = +w.dataset.i !== i; w.classList.toggle("richtig", +w.dataset.i === i && richtig); });
  const geloestZeigen = i => { f.classList.add("geloest"); if (knoepfe[i]) knoepfe[i].classList.add("richtig"); };
  if (ich.geloest() && Number.isInteger(st().wahl)) { geloestZeigen(st().wahl); zeigen(st().wahl, true); }
  knoepfe.forEach((k, i) => k.addEventListener("click", async () => {
    let r; try { r = await api("stand/frage", { kennung, wahl: i }); } catch (e) { meldung(e.message, "fehler"); return; }
    (Z.stand.fragen = Z.stand.fragen || {})[kennung] = r.frage;
    k.classList.add(r.richtig ? "richtig" : "falsch"); zeigen(i, r.richtig);
    if (r.richtig) { geloestZeigen(i); if (ich.beimLoesen) ich.beimLoesen(); }
  }));
  return ich;
}

// Lernpfad: links die Abschnitte (Überschriften), ✓ wenn ihre Frage gelöst ist; der Abschnitt,
// in dem man liest, ist hervorgehoben. Nur ohne Beamer und erst ab einer Breite, die ihn trägt.
function lernpfad(s, inhalt, T, fragen) {
  s.classList.add("mit-pfad");
  const nav = h("nav", { class: "lernpfad nur-ohne-beamer", "aria-label": "Auf dieser Seite" }, h("div", { class: "lp-kopf" }, "Auf dieser Seite"));
  const zaehler = h("div", { class: "lp-zahl" });
  const eintraege = [];
  const ziele = [...inhalt.children].filter(el => el.tagName === "H3" || el.classList.contains("merke"));
  for (const z of ziele) {
    let frage = null;
    if (z.tagName === "H3") for (let n = z.nextElementSibling; n && n.tagName !== "H3" && !n.classList.contains("merke"); n = n.nextElementSibling) if (n.matches("fieldset.pruef")) { frage = fragen.find(x => x.el === n); break; }
    const mt = z.tagName === "H3" ? null : z.querySelector(".merke-titel");
    const titel = z.tagName === "H3" ? z.textContent : "Merke" + (mt && mt.textContent.trim() ? " · " + mt.textContent.trim() : "");
    const zeichenEl = h("span", { class: "lp-z" });
    const a = h("a", { href: "#", onclick: ev => { ev.preventDefault(); z.scrollIntoView({ block: "start", behavior: "smooth" }); } }, zeichenEl, h("span", {}, titel));
    eintraege.push({ z, frage, a, zeichenEl }); nav.append(a);
  }
  nav.append(zaehler);
  function aktualisieren() {
    for (const e of eintraege) { const ok = e.frage && e.frage.geloest(); e.zeichenEl.textContent = !e.frage ? "·" : ok ? "✓" : "○"; e.a.classList.toggle("gelesen", !!ok); e.a.classList.toggle("ohne-frage", !e.frage); }
    const n = fragen.filter(f => f.geloest()).length;
    zaehler.textContent = n + " von " + fragen.length + " Fragen beantwortet";
  }
  fragen.forEach(f => { f.beimLoesen = aktualisieren; });
  function mitlaufen() {
    const oben = s.getBoundingClientRect().top + 90; let jetzt = eintraege[0];
    for (const e of eintraege) if (e.z.getBoundingClientRect().top <= oben) jetzt = e;
    if (s.scrollTop > 0 && s.scrollTop + s.clientHeight >= s.scrollHeight - 4) jetzt = eintraege[eintraege.length - 1];   // ganz unten: der letzte, auch wenn er nie oben ankommt
    eintraege.forEach(e => e.a.classList.toggle("jetzt", e === jetzt));
  }
  s.addEventListener("scroll", mitlaufen, { passive: true });
  aktualisieren(); requestAnimationFrame(mitlaufen);
  s.prepend(nav);
}

// Beispiel in Stufen (::: stufen): 1 ganz gelöst mit Erklärung je Zeile · 2 mit Lücken · 3 nur
// der Auftrag (die Aufgabe der Übung). Alle drei stehen im DOM, zwei sind verborgen -- Zeichen
// dort sitzen am Knopf der Stufe (zeichenOrt). Die gewählte Stufe merkt sich der Stand.
const STUFEN = ["1 · ganz gelöst", "2 · mit Lücken", "3 · selbst"];
function stufenBeispiel(f, T) {
  const name = f.dataset.stufen, kennung = T.pfad + "/" + name;
  const teile = [".st-eins", ".st-zwei", ".st-drei"].map(x => f.querySelector(x));
  const st = () => (Z.stand.stufen || {})[kennung] || {};
  const knoepfe = STUFEN.map((t, i) => h("button", { type: "button", onclick: () => zeigen(i + 1, true) }, t));
  f.querySelector(".st-wahl").append(...knoepfe);
  f._stufeKnopf = teil => knoepfe[teile.indexOf(teil)];
  f._stufeZeigen = teil => zeigen(teile.indexOf(teil) + 1, false);
  teile[0].append(h("div", { class: "zeile" }, ...ausfuehrTeil(T, f.dataset.datei)));
  // Stufe 1: Zeile und Erklärung gehören zusammen -- Zeigen auf das eine hebt das andere hervor
  const paar = z => f.querySelectorAll('.st-eins [data-z="' + z + '"]');
  f.querySelectorAll(".st-eins [data-z]").forEach(el => {
    el.addEventListener("mouseenter", () => paar(el.dataset.z).forEach(x => x.classList.add("hell")));
    el.addEventListener("mouseleave", () => paar(el.dataset.z).forEach(x => x.classList.remove("hell")));
  });
  // Stufe 2: Lücken, geprüft vom Server (je Lücke)
  const luecken = [...f.querySelectorAll(".st-luecke")], hinweise = [...f.querySelectorAll(".st-hinweise li")];
  const urteil = h("p", { class: "st-urteil" });
  teile[1].append(h("div", { class: "zeile" }, h("button", { type: "button", class: "primaer", onclick: pruefen }, "Prüfen"),
    h("button", { type: "button", class: "ruhig", onclick: () => zeigen(1, true) }, "Stufe 1 ansehen")), urteil);
  luecken.forEach(l => l.addEventListener("keydown", ev => { if (ev.key === "Enter") pruefen(); }));
  async function pruefen() {
    let r; try { r = await api("stand/stufe", { kennung, antworten: luecken.map(l => l.value) }); } catch (e) { meldung(e.message, "fehler"); return; }
    (Z.stand.stufen = Z.stand.stufen || {})[kennung] = r.stufe;
    r.einzeln.forEach((ok, i) => { luecken[i].classList.toggle("richtig", ok); luecken[i].classList.toggle("falsch", !ok); if (hinweise[i]) hinweise[i].classList.toggle("offen", !ok); });
    const n = r.einzeln.filter(Boolean).length;
    urteil.className = "st-urteil " + (n === luecken.length ? "ok" : "");
    urteil.textContent = n === luecken.length ? "Alle Lücken stimmen. Jetzt Stufe 3: ohne Vorlage." : n + " von " + luecken.length + " Lücken stimmen. Die roten noch einmal – der Hinweis mit derselben Nummer sagt, was hineingehört.";
    knoepfeZeichnen();
  }
  if (f.dataset.aufgabe) teile[2].append(h("div", { class: "zeile" }, h("a", { class: "knopf primaer", href: adr("t/" + T.pfad + "/uebung/" + f.dataset.aufgabe) }, "Zur Übung, Aufgabe " + f.dataset.aufgabe + " →")));
  let jetzt = 1;
  function knoepfeZeichnen() { knoepfe.forEach((k, i) => { k.className = (i + 1 === jetzt ? "aktiv" : "ruhig") + (i === 1 && st().luecken ? " fertig" : ""); k.setAttribute("aria-pressed", String(i + 1 === jetzt)); }); }
  function zeigen(n, merken) {
    jetzt = n; teile.forEach((t, i) => { t.hidden = i !== n - 1; }); knoepfeZeichnen();
    if (merken) api("stand/stufe", { kennung, stufe: n }).then(r => { (Z.stand.stufen = Z.stand.stufen || {})[kennung] = r.stufe; }).catch(() => {});
  }
  zeigen(st().stufe || 1, false);
}
