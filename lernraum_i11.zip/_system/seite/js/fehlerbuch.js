/* Lernraum · fehlerbuch.js -- Mein Fehlerbuch (Seite, Hinweis in der Shell, Karte in „Üben und Nachschlagen“).
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Mein Fehlerbuch (Galerie 15.10., Rang 9) ─────────────────────────────────────────
// Jede rote Meldung aus der Shell (Übung, Lösung, Vortrag, Beispiele, Puzzle) trägt der Server in
// den Stand ein -- je Fehlerart: wie oft, zuerst und zuletzt wo, die letzte Meldung, der Satz der
// Seite. Selbstcheck und Aufzeichnen zählen nicht, das Lehrerpult nie. Die Notiz schreibt die
// Person selbst; sie reist mit der Abgabe, die Übersicht zählt nur Arten, ohne Namen und Notiz.
function fehlerbuch() { return (Z.stand && Z.stand.fehlerbuch) || {}; }
function fehlerbuchArten() { return Object.entries(fehlerbuch()).filter(([, e]) => e.anzahl > 0).sort((x, y) => y[1].anzahl - x[1].anzahl || x[0].localeCompare(y[0])); }

// Wo eine Meldung kam: „Thema 1 · Übung 2a“, „Thema 1 · Vortrag 5“
function fehlerOrt(wo) {
  if (!wo) return "";
  const [rk, tk] = (wo.thema || "").split("/"); const t = thema(rk, tk);
  const [art, nr] = (wo.ort || "").split("/");
  const name = { uebung: "Übung", vortrag: "Vortrag", erklaerung: "Erklärung", loesung: "Lösung" }[art] || "";
  return (t ? "Thema " + t.thema.nr : wo.thema) + (name ? " · " + name + (nr ? " " + nr : "") : "");
}

// Unter einer roten Meldung in der Shell: der Weg ins Fehlerbuch (nur Schülerfassung -- der
// Server schickt „fehlerbuch“ nur dort mit).
function fehlerbuchHinweis(fb) {
  if (!fb || !fb.art) return null;
  const fbs = (Z.stand.fehlerbuch = Z.stand.fehlerbuch || {});
  fbs[fb.art] = Object.assign(fbs[fb.art] || {}, { anzahl: fb.anzahl });   // genug für die Karte auf der Kursseite; die Seite selbst lädt frisch
  return h("a", { class: "fb-hinweis", href: adr("fehlerbuch") }, "Steht in deinem Fehlerbuch: " + fb.art + " · " + fb.anzahl + "× ›");
}

async function fehlerbuchSeite(haupt) {
  kopfZeichnen([["Mein Fehlerbuch", adr("fehlerbuch")]]);
  try { const a = await api("inhalt"); Z.stand = a.stand; } catch (e) {}
  const s = h("div", { class: "seite fehlerbuch" }, h("h1", {}, "Mein Fehlerbuch"),
    h("p", { class: "unter" }, "Jede rote Meldung, die du in der Shell getroffen hast – mit dem, was sie heißt"));
  const arten = fehlerbuchArten();
  if (!arten.length) { s.append(h("p", { class: "leer" }, "Noch keine rote Meldung. Sie kommt bestimmt.")); haupt.append(s); return; }
  for (const [art, e] of arten) {
    const l = e.letzte || {};
    const notiz = h("input", { placeholder: "Meine Notiz: Woran erkenne ich ihn, was tue ich dann?", maxlength: "300" }); notiz.value = e.notiz || "";
    const gemerkt = h("span", { class: "leer fb-gemerkt" });
    const speichern = async () => { if ((e.notiz || "") === notiz.value.trim()) return; try { const r = await api("stand/fehlernotiz", { art, notiz: notiz.value }); e.notiz = r.eintrag.notiz; gemerkt.textContent = "gespeichert"; setTimeout(() => { gemerkt.textContent = ""; }, 1500); } catch (x) { gemerkt.textContent = x.message; } };
    notiz.addEventListener("blur", speichern); notiz.addEventListener("keydown", ev => { if (ev.key === "Enter") notiz.blur(); });
    s.append(h("div", { class: "fb-karte" + (art === "SyntaxError" ? " syntax" : "") },
      h("div", { class: "fb-kopf" }, h("b", {}, art), h("span", { class: "fb-zahl" }, e.anzahl + "×")),
      l.meldung ? h("div", { class: "fb-meldung" }, l.meldung) : null,
      l.code ? h("pre", { class: "code" }, h("code", {}, (l.zeile ? "Zeile " + l.zeile + ":  " : "") + l.code)) : null,
      e.satz ? h("p", { class: "fb-satz" }, e.satz) : null,
      h("p", { class: "leer fb-wo" }, "zuerst: " + fehlerOrt(e.erste) + (e.anzahl > 1 && l.thema ? " · zuletzt: " + fehlerOrt(l) : "")),
      h("label", { class: "fb-notiz" }, h("b", {}, "Meine Notiz:"), notiz, gemerkt)));
  }
  haupt.append(s);
}

// Die Karte im Bereich „Üben und Nachschlagen“ -- erst mit dem ersten Eintrag (Regel 4).
function fehlerbuchKarte() {
  const arten = fehlerbuchArten(); if (!arten.length) return null;
  const n = arten.reduce((s, [, e]) => s + e.anzahl, 0);
  return h("a", { class: "nachschlagkarte", href: adr("fehlerbuch") }, h("div", { class: "nr" }, "Mein Fehlerbuch"),
    h("div", { class: "titel" }, n + (n === 1 ? " rote Meldung" : " rote Meldungen")), h("div", {}, arten.map(([a, e]) => a + " " + e.anzahl + "×").join(" · ")));
}
