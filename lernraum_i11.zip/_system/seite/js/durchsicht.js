/* Lernraum · durchsicht.js -- Durchsicht (Lehrer): Nadeln und Urteile auf der lebenden Seite.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Durchsicht (Lehrer): Nadeln und Urteile auf der lebenden Seite ─────────────
// Wie Folien-, Buch- und Dateifilm in Mathe, nur direkt hier: Der Lehrer setzt
// Nadeln (Klick, Notiz, Stapel) und je Ansicht ein Urteil (ja · fast · nein +
// Notiz). Alles liegt in _durchsicht/durchsicht.json der Lehrerfassung;
// werkstatt/lernraum/durchsicht_lesen.py liest es. Nie am Beamer.
const D = { an: false, nadelModus: false, daten: null, leiste: null, ebene: null, takt: null };
const STAPEL = [["form", "Form"], ["stundenbau", "Stundenbau"], ["technik", "Technik"], ["regel", "Regel"]];
try { D.woher = localStorage.getItem("lernraum.durchsicht.woher") || "durchsicht"; } catch (e) { D.woher = "durchsicht"; }
function routeJetzt() {   // ".../vortrag" und ".../vortrag/1" sind dieselbe Ansicht -- eine Schreibweise fuer Nadeln
  const r = routeOhneKurs() || "kurs";
  if (/^t\/[^/]+\/[^/]+$/.test(r)) return r + "/vortrag/1";
  return /^t\/[^/]+\/[^/]+\/vortrag$/.test(r) ? r + "/1" : r;
}
function ansichtTitel() {
  const t = $(".thema-kopf h1"), reiter = $(".reiter a.aktiv");
  const s = $(".schritt .kopfzeile h2") || $(".schritt > h2") || $(".schritt .merke-titel") || $(".schritt.marke h2") || $(".schritt .nebentext h2");
  const teile = [t && t.textContent, reiter && reiter.textContent, s && s.textContent].filter(Boolean);
  if (!teile.length) return { kurs: "Kursseite", uebersicht: "Übersicht", besprechung: "Besprechung" }[routeJetzt()] || routeJetzt();
  const r = routeJetzt().split("/"); if (r[3] === "vortrag" && r[4]) teile.splice(2, 0, "Schritt " + r[4]);
  return teile.join(" · ");
}
async function durchsichtLaden() { if (D.daten) return; try { D.daten = (await api("durchsicht/lesen")).daten; } catch (e) { D.daten = { nadeln: [], urteile: {} }; meldung(e.message, "fehler"); } }
async function durchsichtSpeichern() { try { await api("durchsicht/schreiben", { daten: D.daten }); } catch (e) { meldung("Durchsicht nicht gespeichert: " + e.message, "fehler"); } }
async function durchsichtSchalten() {
  D.an = !D.an; document.body.classList.toggle("durchsicht", D.an);
  if (D.an) { await durchsichtLaden(); await werkbuchLaden(); D.takt = setInterval(nadelnZeichnen, 400); }
  else { clearInterval(D.takt); D.nadelModus = false; document.body.classList.remove("nadelmodus"); }
  kopfZeichnen(Z.weg); durchsichtNach();
}
function durchsichtNach() {
  if (!D.leiste) { D.leiste = h("div", { class: "durchsicht-leiste nur-ohne-beamer" }); document.body.insertBefore(D.leiste, $("main")); D.ebene = h("div", { class: "nadel-ebene nur-ohne-beamer" }); document.body.append(D.ebene); }
  D.leiste.hidden = !D.an; D.ebene.hidden = !D.an;
  if (!D.an || !D.daten) return;
  leisteZeichnen(); nadelnZeichnen();
}
function leisteZeichnen() {
  const r = routeJetzt(); const u = D.daten.urteile[r] || {};
  const L = D.leiste; L.textContent = "";
  L.append(h("span", { class: "dt" }, "Durchsicht"), h("span", { class: "dr", title: r }, ansichtTitel()));
  for (const k of ["ja", "fast", "nein"]) L.append(h("button", { class: "urteil " + k + (u.urteil === k ? " aktiv" : ""), onclick: async () => { D.daten.urteile[r] = Object.assign({}, D.daten.urteile[r] || {}, { urteil: u.urteil === k ? "" : k, titel: ansichtTitel(), zeit: new Date().toISOString() }); await durchsichtSpeichern(); leisteZeichnen(); } }, k));
  const notiz = h("input", { placeholder: "Notiz zur Ansicht …", value: u.notiz || "" });
  notiz.addEventListener("change", async () => { D.daten.urteile[r] = Object.assign({}, D.daten.urteile[r] || {}, { notiz: notiz.value, titel: ansichtTitel(), zeit: new Date().toISOString() }); await durchsichtSpeichern(); });
  L.append(notiz);
  const hier = D.daten.nadeln.filter(n => n.route === r).length;
  L.append(h("button", { class: "nadel-knopf" + (D.nadelModus ? " aktiv" : ""), onclick: nadelModusSchalten, title: "Taste N: dann irgendwo auf die Seite klicken" }, D.nadelModus ? "… jetzt auf die Stelle klicken" : [zeichen(NADEL_ZEICHEN, "z-nadel"), "Nadel setzen"]),
    h("span", { class: "dz" }, hier + " hier · " + D.daten.nadeln.length + " im Kurs"));
  // Werkbuch: erledigte Eintraege dieser Ansicht als gruene Haken (standardmaessig an, Wahl im Browser)
  const erl = werkbuchFuerRoute(r).filter(werkbuchErledigt);
  const amOrt = erl.filter(e => { const el = ankerFinden(e); return el && stelleStimmt(el, e); }).length;
  if (erl.length) L.append(h("button", { class: "haken-knopf" + (W.haken ? " aktiv" : ""), onclick: hakenSchalten,
    title: erl.length + " Einträge aus dem Werkbuch sind hier erledigt, " + amOrt + " davon stehen als grüner Haken an ihrer Stelle; die übrigen Stellen sind umgebaut – sie stehen im Reiter Werkbuch.\nKlick: " + (W.haken ? "Haken ausblenden" : "Haken zeigen") }, "✓ " + erl.length + " erledigt"));
}
function nadelModusSchalten() { D.nadelModus = !D.nadelModus; document.body.classList.toggle("nadelmodus", D.nadelModus); leisteZeichnen(); }
function ankerVon(el) {   // Pfad von #haupt zum Element als nth-of-type-Kette -- findet die Stelle beim naechsten Mal wieder
  const teile = []; let e = el;
  while (e && e.id !== "haupt" && e !== document.body) { let i = 1, s = e; while ((s = s.previousElementSibling)) if (s.tagName === e.tagName) i++; teile.unshift(e.tagName.toLowerCase() + ":nth-of-type(" + i + ")"); e = e.parentElement; }
  return e && e.id === "haupt" ? "#haupt > " + teile.join(" > ") : null;
}
function ankerFinden(n) { try { return n.anker ? document.querySelector(n.anker) : null; } catch (e) { return null; } }
function nadelSetzen(ev) {
  ev.preventDefault(); ev.stopPropagation();
  const el = ev.target; const anker = ankerVon(el); const r = el.getBoundingClientRect();
  const n = { id: neueKennung(D.woher), quelle: D.woher, nr: D.daten.nadeln.reduce((m, x) => Math.max(m, x.nr || 0), 0) + 1, route: routeJetzt(), titel: ansichtTitel(), anker,
    dx: r.width ? (ev.clientX - r.left) / r.width : 0.5, dy: r.height ? (ev.clientY - r.top) / r.height : 0.5, x: ev.clientX, y: ev.clientY,
    text: (el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 120), notiz: "", stapel: "form", zeit: new Date().toISOString() };
  D.nadelModus = false; document.body.classList.remove("nadelmodus"); leisteZeichnen();
  nadelDialog(n, true);
}
function nadelDialog(n, neu) {
  const notiz = h("textarea", { placeholder: "Was ist hier? Was soll anders sein?" }); notiz.value = n.notiz || "";
  const stapel = h("select", {}, STAPEL.map(([k, t]) => { const o = h("option", { value: k }, t); if (n.stapel === k) o.selected = true; return o; }));
  // Woher (Werkbuch, 14.10.): Durchsicht am Schreibtisch oder Beobachtung aus der Stunde
  const woher = h("select", {}, [["durchsicht", "Durchsicht"], ["stunde", "nach der Stunde"]].map(([k, t]) => { const o = h("option", { value: k }, t); if ((n.quelle || "durchsicht") === k) o.selected = true; return o; }));
  const inhalt = h("div", {}, h("p", { class: "leer" }, "Nadel " + n.nr + " · " + n.titel + (n.text ? " · „" + n.text.slice(0, 60) + "“" : "")), h("div", { class: "zeile" }, h("label", {}, "Woher"), woher), h("div", { class: "zeile" }, h("label", {}, "Stapel"), stapel), notiz);
  const knoepfe = [["Abbrechen", async () => {}, "ruhig"]];
  if (!neu) knoepfe.push(["Löschen", async () => { D.daten.nadeln = D.daten.nadeln.filter(x => x !== n); await durchsichtSpeichern(); durchsichtNach(); }, "gefahr"]);
  knoepfe.push(["Speichern", async () => { n.notiz = notiz.value; n.stapel = stapel.value; n.quelle = woher.value; n.zeit = new Date().toISOString(); if (neu) { D.daten.nadeln.push(n); D.woher = woher.value; try { localStorage.setItem("lernraum.durchsicht.woher", D.woher); } catch (e) {} } await durchsichtSpeichern(); durchsichtNach(); }, "primaer"]);
  dialog(neu ? "Neue Nadel" : "Nadel " + n.nr, inhalt, knoepfe);
  setTimeout(() => notiz.focus(), 50);
}
function nadelnZeichnen() {
  if (!D.an || !D.daten || !D.ebene) return;
  const r = routeJetzt(); D.ebene.textContent = "";
  const haupt = $("#haupt").getBoundingClientRect();
  const imWerkbuch = new Set(werkbuchFuerRoute(r).map(e => e.id));
  const belegt = new Map();   // zugeklappte Aufgabe -> Zahl der Zeichen an ihrer Kopfzeile
  for (const n of D.daten.nadeln.filter(x => x.route === r && !imWerkbuch.has(kennungVon(x)))) {
    const el = ankerFinden(n); let x = n.x, y = n.y;
    if (el) [x, y] = zeichenOrt(el, n.dx, n.dy, belegt);
    if (y < haupt.top || y > haupt.bottom) continue;
    D.ebene.append(h("div", { class: "nadel " + (n.stapel || "") + (n.quelle === "stunde" ? " aus-stunde" : ""), style: "left:" + x + "px;top:" + y + "px", title: (n.quelle === "stunde" ? "nach der Stunde: " : "") + (n.notiz || "") + " (" + (n.stapel || "") + ")", onclick: ev => { ev.stopPropagation(); nadelDialog(n, false); } }, h("span", {}, String(n.nr))));
  }
  werkbuchMarkenZeichnen(r, haupt, belegt);
}
document.addEventListener("click", ev => { if (D.an && D.nadelModus && ev.target.closest("#haupt")) nadelSetzen(ev); }, true);
document.addEventListener("scroll", () => { if (D.an) nadelnZeichnen(); }, true);
window.addEventListener("resize", () => { if (D.an) nadelnZeichnen(); });
document.addEventListener("keydown", ev => { if (!D.an || ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName) || document.activeElement.closest(".cm-editor")) return; if (ev.key === "n" || ev.key === "N") nadelModusSchalten(); });
