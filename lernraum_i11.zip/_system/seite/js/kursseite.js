/* Lernraum · kursseite.js -- Kursseite, Anmeldung, Fassung und Aktualisierung.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Kursseite ────────────────────────────────────────────────────────────────────
function themaStandText(t, pfad) {
  const ts = (Z.stand.themen || {})[pfad] || {};
  const teile = [];
  if (ts.selbstcheck) teile.push("Selbstcheck " + ts.selbstcheck.passt + " von " + ts.selbstcheck.von);
  const hilfen = Object.entries(Z.stand.aufgaben || {}).filter(([k]) => k.startsWith(pfad + "/")).reduce((n, [, a]) => n + (a.hilfen || []).length, 0);
  if (hilfen) teile.push(hilfen + " Hilfe(n) geöffnet");
  const fragen = Object.entries(Z.stand.fragen || {}).filter(([k, f]) => k.startsWith(pfad + "/") && f.geloest).length;
  if (fragen) teile.push(fragen + " Prüffrage" + (fragen === 1 ? "" : "n") + " gelöst");
  if ((Z.stand.kennwoerter || {})[pfad]) teile.push("Lösung frei");
  return teile.length ? teile.join(" · ") : "noch nicht begonnen";
}
// Im Pult: wo der Unterricht steht, nicht dein Probestand (Lehrer 16.10.: „hier sollte nicht stehen,
// wie viele Sterne ich schon habe, sondern was wir im Unterricht schon gemacht haben“).
function zeitDe(iso) { const m = (iso || "").match(/^\d{4}-(\d\d)-(\d\d)T(\d\d:\d\d)/); return m ? m[2] + "." + m[1] + "., " + m[3] : ""; }
function unterrichtText(t, pfad) {
  const st = unterrichtStelle(pfad);
  if (!st) return "im Unterricht noch nicht dran";
  const teile = [];
  if (st.reiter === "vortrag" && st.schritt) { const s = (t.vortrag || [])[st.schritt - 1]; teile.push("Vortrag Schritt " + st.schritt + " von " + (t.vortrag || []).length + (s && s.fahrplan && st.marker ? " (" + "①②③④⑤"[st.marker - 1] + ")" : "")); }
  else teile.push({ uebung: "Übung", erklaerung: "Erklärung", werkstatt: "Werkstatt", loesung: "Lösung" }[st.reiter] || st.reiter);
  return "Im Unterricht: " + teile.join(" · ") + " · Lesezeichen vom " + zeitDe(st.zeit);
}
function weiterKarte() {
  // Das Lesezeichen (Lehrer 19.10.): nur, was er am Ende einer Stunde mit „Hier aufgehört“ gesetzt hat
  const u = Z.stand.unterricht || {}, pfad = u.zuletzt, st = pfad && unterrichtStelle(pfad);
  if (!st) return h("div", { class: "weiter-karte leer-karte nur-ohne-beamer" }, h("div", { class: "wk-kopf" }, "Beim nächsten Mal weiter"),
    h("p", { class: "leer" }, "Noch kein Lesezeichen. Setz es am Ende der Stunde mit „Hier aufgehört“ – rechts neben den Reitern eines Themas."));
  const [rk, tk] = pfad.split("/"), T = thema(rk, tk); if (!T) return null;
  let wo, ziel;
  if (st.reiter === "vortrag" && st.schritt) {
    const s = T.thema.vortrag[st.schritt - 1] || {};
    wo = "Vortrag, Schritt " + st.schritt + (s.titel ? " „" + s.titel + "“" : "") + (s.fahrplan && st.marker ? ", Fahrplan " + "①②③④⑤"[st.marker - 1] + " " + s.fahrplan[st.marker - 1].replace(/<[^>]+>/g, "") : "");
    ziel = "t/" + pfad + "/vortrag/" + st.schritt;
  } else { wo = { uebung: "Übung", erklaerung: "Erklärung", werkstatt: "Werkstatt", loesung: "Lösung" }[st.reiter] || st.reiter; ziel = "t/" + pfad + "/" + st.reiter; }
  return h("a", { class: "weiter-karte nur-ohne-beamer", href: adr(ziel) }, h("div", { class: "wk-kopf" }, "Beim nächsten Mal weiter"),
    h("div", { class: "wk-wo" }, "Thema " + T.thema.nr + " · " + T.thema.titel), h("div", {}, wo), h("div", { class: "leer" }, "Lesezeichen vom " + zeitDe(st.zeit) + " →"));
}
// Wer arbeitet hier? Ohne Namen (oder eigene Stand-ZIP) bleiben die Themen zu -- die Abgabe braucht
// den Namen, und eine Stunde ohne ihn endet mit einer Abgabe, die niemandem gehört.
function anmeldeKarte() {
  const vor = h("input", { placeholder: "Vorname", autocomplete: "off" }), nach = h("input", { placeholder: "Nachname", autocomplete: "off" });
  const datei = h("input", { type: "file", accept: ".zip" });
  const fehler = h("p", { class: "fehler" });
  const los = async () => {
    if (!vor.value.trim() || !nach.value.trim()) { fehler.textContent = "Bitte Vor- und Nachnamen eintragen."; return; }
    try { const a = await api("stand/name", { vorname: vor.value.trim(), nachname: nach.value.trim() }); Z.stand = a.stand; kopfZeichnen([]); zeichnen(); }
    catch (e) { fehler.textContent = e.message; }
  };
  nach.addEventListener("keydown", ev => { if (ev.key === "Enter") los(); });
  datei.addEventListener("change", async () => {
    const f = datei.files[0]; if (!f) return;
    try { const a = await api("stand/zusammenfuehren", { daten: await dateiB64(f) }); Z.stand = a.stand;
      if (!Z.stand.name) { fehler.textContent = "In dieser ZIP steht kein Name – trag ihn oben ein."; return; }
      meldung("Willkommen zurück, " + Z.stand.name + " – dein Stand ist da."); zeichnen(); }
    catch (e) { fehler.textContent = e.message; }
  });
  return h("div", { class: "anmelden" },
    h("h2", {}, "Wer arbeitet hier?"),
    h("p", {}, "Trag deinen Namen ein, dann gehen die Themen auf. Er steht nur hier im Ordner und in deinen Abgaben."),
    h("div", { class: "zeile" }, vor, nach, h("button", { class: "primaer", onclick: los }, "Los geht’s")),
    h("p", { class: "oder" }, "oder"),
    h("p", {}, "Du hast schon an einem anderen Rechner gearbeitet? Nimm deine Stand-ZIP herein – dein Name kommt mit: ", datei),
    fehler);
}
function kursseite(haupt) {
  kopfZeichnen([]);
  const s = h("div", { class: "seite" }, h("h1", {}, Z.inhalt.titel), Z.inhalt.untertitel ? h("p", { class: "unter" }, Z.inhalt.untertitel) : null);
  const gesperrt = !Z.stand.name && !Z.lehrer;   // Lehrer 14.10.: Themen erst mit Namen oder eigener Stand-ZIP
  if (gesperrt) s.append(anmeldeKarte());
  if (Z.lehrer) { const w = weiterKarte(); if (w) s.append(w); }
  // Dein Weg: wie viele Themen sind begonnen (Stand), als Balken -- die Lernpfad-Ansicht (13.10.)
  const alle = Z.inhalt.reihen.flatMap(r => r.themen.map(t => r.kennung + "/" + t.kennung));
  const begonnen = alle.filter(p => themaStandText(null, p) !== "noch nicht begonnen").length;
  if (!Z.lehrer) {
    const balken = h("span", {}); balken.style.width = "0";
    s.append(h("div", { class: "fortschritt nur-ohne-beamer" }, h("div", { class: "ft" }, "Dein Weg"), h("div", { class: "fz" }, begonnen + " von " + alle.length + " Themen begonnen"), h("div", { class: "fb" }, balken)));
    requestAnimationFrame(() => { balken.style.width = (alle.length ? Math.round(100 * begonnen / alle.length) : 0) + "%"; });
  }
  // Kapitel und Teile einklappen (Film der Schuelerfassung 25.10., Lehrer: „dass man die Kapitel einklappen kann“) --
  // ein Klick auf die Ueberschrift; der Browser merkt es sich je Kurs (nur Bequemlichkeit, darf fehlen)
  function klappbar(ziel, kopf, schluessel) {
    let zu = false; try { zu = localStorage.getItem(schluessel) === "zu"; } catch (e) {}
    kopf.classList.add("klappkopf"); kopf.tabIndex = 0; kopf.setAttribute("role", "button");
    const setzen = (wert) => { zu = wert; ziel.classList.toggle("zu", zu); kopf.classList.toggle("zu", zu); kopf.setAttribute("aria-expanded", String(!zu)); };
    const wechseln = () => { setzen(!zu); try { if (zu) localStorage.setItem(schluessel, "zu"); else localStorage.removeItem(schluessel); } catch (e) {} };
    kopf.addEventListener("click", wechseln);
    kopf.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); wechseln(); } });
    setzen(zu);
  }
  for (const r of Z.inhalt.reihen) {
    const kap = h("section", { class: "kapitel" }, h("h2", {}, "Kapitel " + r.nr + " · " + r.titel), r.kurz ? h("p", {}, r.kurz) : null);
    klappbar(kap, kap.querySelector("h2"), "kapitel:" + Z.kurs + "/" + r.kennung);
    // je Teil der Reihe eine Ueberschrift und eine eigene Liste (Lehrer 24.10.: „keine Trennung zwischen Teil I und II
    // … Sollte es aber geben“); ohne Teile eine Liste wie bisher
    let liste = null, teil = null;
    for (const t of r.themen) {
      if (!liste || (t.teil || "") !== teil) {
        if (liste) kap.append(liste);
        teil = t.teil || "";
        if (teil) {
          const [schild, ...rest] = teil.split(" · ");
          kap.append(h("h3", { class: "teil" }, rest.length ? h("span", { class: "teil-schild" }, schild) : null, rest.length ? rest.join(" · ") : teil));
        }
        liste = h("div", { class: "themenliste" });
        if (teil) klappbar(liste, kap.lastElementChild, "teil:" + Z.kurs + "/" + r.kennung + "/" + teil);
      }
      const pfad = r.kennung + "/" + t.kennung;
      liste.append(h(gesperrt ? "div" : "a", { class: "themenkarte" + (gesperrt ? " gesperrt" : ""), "data-pfad": pfad, href: gesperrt ? null : adr("t/" + pfad + "/vortrag"), title: gesperrt ? "Erst deinen Namen eintragen – oben" : null }, h("div", { class: "nr", "data-nr": String(t.nr) }, "Thema " + t.nr), h("div", { class: "titel" }, gesperrt ? zeichen(SCHLOSS_ZEICHEN, "z-schloss") : null, t.titel), t.untertitel ? h("div", {}, t.untertitel) : null, Z.lehrer ? h("div", { class: "stand nur-ohne-beamer" + (unterrichtStelle(pfad) ? " aktiv" : "") }, unterrichtText(t, pfad))
        : h("div", { class: "stand nur-ohne-beamer" + (themaStandText(t, pfad) === "noch nicht begonnen" ? "" : " aktiv") }, themaStandText(t, pfad))));
    }
    if (liste) kap.append(liste);
    s.append(kap);
  }
  // Sterne je Thema (16.10.): nur für die Person -- nie am Beamer
  if (!gesperrt && !Z.lehrer) api("sterne", {}).then(r => {
    Z.sterne = Object.assign(Z.sterne || {}, r.sterne);
    s.querySelectorAll(".themenkarte[data-pfad]").forEach(k => {
      const st = r.sterne[k.dataset.pfad]; const ort = k.querySelector(".stand");
      if (st && ort && st.summe) ort.append(h("span", { class: "karte-sterne" + (st.geschafft ? " geschafft" : "") }, " · ★ " + st.summe + " von " + st.max + (st.mindest ? " (Ziel " + st.mindest + ")" : "")));
    });
  }).catch(() => {});
  const nachschlagen = !gesperrt && nachschlagenBereich();
  if (nachschlagen) s.append(nachschlagen);
  s.append(fassungKarte());
  haupt.append(s);
}

// ─── Fassung und Aktualisierung (Weg B, Lehrer 14.10.) ──────────────────────────
// Nur auf Knopfdruck. Die Seite geht nie ins Netz: Python holt fassung.json und die ZIP
// (CSP bleibt 'self'). Ohne Netz derselbe Weg von Hand: die ZIP hereinnehmen.
function datumDe(iso) { return (iso || "").split("-").reverse().join("."); }
function fassungText() {
  const i = Z.inhalt, nr = i.fassung_nr || 0;
  if (!nr) return "Noch keine veröffentlichte Fassung (Entwurf, gebaut " + datumDe(i.version) + ")";
  return "Fassung " + nr + (i.fassung_datum ? " vom " + datumDe(i.fassung_datum) : "") + (i.fassung_entwurf ? " + Änderungen (Entwurf, gebaut " + datumDe(i.version) + ")" : "");
}
function fassungKarte() {
  const box = h("div", { class: "fassung-karte" }, h("div", { class: "fk" }, h("b", {}, fassungText()), h("span", { class: "leer" }, " · Python läuft auf diesem Rechner, nichts verlässt ihn.")));
  if (Z.lehrer) { box.append(h("p", { class: "leer nur-ohne-beamer" }, "Lehrerpult: kommt aus dem Projekt (Abzug in deinen OneDrive-Ordner „Lehrerpult Informatik“). Die Klasse aktualisiert ihre Fassung hier unten per Knopf oder von Hand.")); return box; }
  const ausgabe = h("div", { class: "fassung-ausgabe" });
  const datei = h("input", { type: "file", accept: ".zip" }); datei.hidden = true;
  const sag = (...k) => { ausgabe.textContent = ""; ausgabe.append(...k); };
  const fehler = e => sag(h("p", { class: "fehler" }, e.message));
  async function einspielen() {
    sag(h("p", { class: "laden" }, "Wird eingespielt … nicht den Stick ziehen."));
    try {
      const a = await api("aktualisierung/einspielen", {});
      // der Server beendet sich gleich: keine Knoepfe mehr, die ins Leere fuehren
      knoepfe.remove(); $(".fk b", box).textContent = "Fassung " + a.bericht.nr + " eingespielt – wirksam nach dem Neustart";
      sag(h("div", { class: "fertig" }, h("p", {}, h("b", {}, "Fertig – jetzt Fassung " + a.bericht.nr + ".")),
        h("p", {}, "Dein Stand, deine Programme, Anmerkungen und Abgaben sind geblieben."),
        h("p", { class: "neustart" }, "Jetzt start.py neu starten: in Thonny ", h("b", {}, "■ Stopp"), ", dann ", h("b", {}, "F5"), ". Bis dahin läuft hier nichts mehr.")));
    } catch (e) { fehler(e); }
  }
  function zeigen(kopf, aenderungen, plan, los) {
    const z = plan && plan.zahlen;
    sag(h("div", { class: "fassung-neu" }, h("p", {}, h("b", {}, kopf)),
      h("ul", {}, (aenderungen.length ? aenderungen : ["(keine Liste dabei)"]).map(x => h("li", {}, x))),
      plan && plan.themen_neu.length ? h("p", {}, "Neue Themen: " + plan.themen_neu.join(" · ")) : null,
      z ? h("p", { class: "leer" }, "Ersetzt " + (z.ersetzen + z.neu) + " Dateien der Seite und der Themen" + (z.entfernen ? ", " + z.entfernen + " entfallen" : "") + ". Bewahrt: dein Stand, deine " + z.arbeit_bewahrt + " Arbeitsdateien, Anmerkungen, Abgaben.") : null,
      h("p", {}, h("button", { class: "primaer", onclick: los }, "Einspielen"), " ", h("button", { class: "ruhig", onclick: () => sag() }, "Später"))));
  }
  async function suchen() {
    sag(h("p", { class: "laden" }, "Suche nach einer neuen Fassung …"));
    try {
      const a = await api("aktualisierung/suchen", {});
      if (a.ohne_adresse) return sag(h("p", {}, "Für diesen Kurs ist keine Adresse eingetragen. Hat dir dein Lehrer eine Aktualisierungs-ZIP gegeben? Dann „Von Hand hereinnehmen …“."));
      if (!a.info.neu) return sag(h("p", { class: "ok" }, "Du hast die neueste Fassung (Fassung " + a.hier + ")."));
      zeigen("Fassung " + a.info.nr + (a.info.datum ? " vom " + datumDe(a.info.datum) : "") + " ist da:", a.info.aenderungen, null, async () => {
        sag(h("p", { class: "laden" }, "Wird geholt und geprüft …"));
        try { await api("aktualisierung/holen", {}); await einspielen(); } catch (e) { fehler(e); }
      });
    } catch (e) { fehler(e); }
  }
  datei.addEventListener("change", async () => {
    const f = datei.files[0]; datei.value = ""; if (!f) return;
    sag(h("p", { class: "laden" }, "Wird geprüft …"));
    try { const a = await api("aktualisierung/hereinnehmen", { daten: await dateiB64(f) }); const pl = a.plan;
      zeigen("Fassung " + pl.nr + (pl.datum ? " vom " + datumDe(pl.datum) : "") + " (von Hand" + (pl.alt_nr ? ", hier bisher Fassung " + pl.alt_nr : "") + "):", pl.aenderungen, pl, einspielen); }
    catch (e) { fehler(e); }
  });
  const knoepfe = h("div", { class: "zeile nur-ohne-beamer" }, h("button", { onclick: suchen }, "Nach neuer Fassung suchen"), h("button", { class: "ruhig", onclick: () => datei.click() }, "Von Hand hereinnehmen …"), datei);
  box.append(knoepfe, ausgabe);
  return box;
}
