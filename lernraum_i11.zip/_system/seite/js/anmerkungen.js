/* Lernraum · anmerkungen.js -- Anmerkungen der Klasse und Hängestellen (Lehrer).
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Anmerkungen (Klasse) und Hängestellen (Lehrer) ─────────────────────────────
// Lehrerwunsch 14.10.: Die Klasse setzt Nadeln wie der Lehrer in der Durchsicht -- eine
// Zeile und eine Art. Je Thema eine Datei (_anmerkungen/), sie reist mit der Abgabe.
// Die Lehrerfassung zeigt aus den geladenen Abgaben je Stelle einen Zähler (auch am
// Beamer, dort ohne Text). Anonym ist nur die Anzeige -- das sagt der Dialog ehrlich.
const A = { modus: false, thema: null, liste: [], haengestellen: false, stellen: [], ebene: null, takt: null };
const ARTEN = [["frage", "Verstehe ich nicht", "?"], ["fehler", "Fehler", "!"], ["idee", "Idee", "✦"]];
function themaRoute() { const r = routeJetzt().split("/"); return r[0] === "t" && r.length >= 3 ? r[1] + "/" + r[2] : null; }
function anmerkungenEbene() { if (!A.ebene) { A.ebene = h("div", { class: "nadel-ebene anmerkung-ebene" }); document.body.append(A.ebene); A.takt = setInterval(anmerkungenZeichnen, 400); } return A.ebene; }
async function anmerkungenNach() {
  const thema = themaRoute();
  if (Z.lehrer) { if (A.haengestellen) await haengestellenLaden(); anmerkungenZeichnen(); return; }
  if (thema !== A.thema) { A.thema = thema; A.liste = []; if (thema) { try { A.liste = (await api("anmerkungen/lesen", { thema })).anmerkungen; } catch (e) { A.liste = []; } } }
  anmerkungenZeichnen();
}
async function anmerkungenSpeichern() { try { await api("anmerkungen/schreiben", { thema: A.thema, anmerkungen: A.liste }); } catch (e) { meldung("Anmerkung nicht gespeichert: " + e.message, "fehler"); } }
function anmerkungModusSchalten() { if (!themaRoute()) return; A.modus = !A.modus; document.body.classList.toggle("nadelmodus", A.modus); kopfZeichnen(Z.weg); }
function anmerkungSetzen(ev) {
  ev.preventDefault(); ev.stopPropagation();
  const el = ev.target, r = el.getBoundingClientRect();
  const a = { nr: A.liste.reduce((m, x) => Math.max(m, x.nr || 0), 0) + 1, route: routeJetzt(), titel: ansichtTitel(), anker: ankerVon(el),
    dx: r.width ? (ev.clientX - r.left) / r.width : 0.5, dy: r.height ? (ev.clientY - r.top) / r.height : 0.5, x: ev.clientX, y: ev.clientY,
    ausschnitt: (el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 100), art: "frage", text: "", zeit: new Date().toISOString() };
  A.modus = false; document.body.classList.remove("nadelmodus"); kopfZeichnen(Z.weg);
  anmerkungDialog(a, true);
}
function anmerkungDialog(a, neu) {
  const text = h("input", { placeholder: "Eine Zeile: Was ist hier?", maxlength: 200 }); text.value = a.text || ""; text.style.width = "100%";
  const arten = h("div", { class: "arten" });
  const zeigen = () => arten.querySelectorAll("button").forEach(b => b.classList.toggle("aktiv", b.dataset.art === a.art));
  for (const [k, name, z] of ARTEN) arten.append(h("button", { class: "art " + k, "data-art": k, onclick: () => { a.art = k; zeigen(); } }, z + " " + name));
  zeigen();
  const inhalt = h("div", {}, a.ausschnitt ? h("p", { class: "leer" }, "An dieser Stelle: „" + a.ausschnitt.slice(0, 70) + "“") : null, arten, text,
    h("p", { class: "klein" }, "Deine Anmerkungen gehen mit der Abgabe zu diesem Thema an deinen Lehrer. Er sieht sie gesammelt ohne deinen Namen – die Abgabe-Datei selbst trägt ihn aber."));
  const knoepfe = [["Abbrechen", async () => {}, "ruhig"]];
  if (!neu) knoepfe.push(["Löschen", async () => { A.liste = A.liste.filter(x => x !== a); await anmerkungenSpeichern(); anmerkungenZeichnen(); }, "gefahr"]);
  knoepfe.push(["Speichern", async () => { a.text = text.value.trim(); a.zeit = new Date().toISOString(); if (neu) A.liste.push(a); await anmerkungenSpeichern(); anmerkungenZeichnen(); }, "primaer"]);
  dialog(neu ? "Anmerkung" : "Deine Anmerkung", inhalt, knoepfe);
  setTimeout(() => text.focus(), 50);
}
function ortVon(n, belegt) { const el = ankerFinden(n); return el ? zeichenOrt(el, n.dx, n.dy, belegt) : [n.x, n.y]; }
function anmerkungenZeichnen() {
  const ebene = anmerkungenEbene(); ebene.textContent = "";
  const haupt = $("#haupt"); if (!haupt) return;
  const hb = haupt.getBoundingClientRect(), r = routeJetzt();
  if (!Z.lehrer) {
    const belegt = new Map();
    for (const a of A.liste.filter(x => x.route === r)) {
      const [x, y] = ortVon(a, belegt); if (y < hb.top || y > hb.bottom) continue;
      const zeichen = (ARTEN.find(z => z[0] === a.art) || ARTEN[0])[2];
      ebene.append(h("div", { class: "nadel anmerkung " + a.art, style: "left:" + x + "px;top:" + y + "px", title: a.text || "", onclick: ev => { ev.stopPropagation(); anmerkungDialog(a, false); } }, h("span", {}, zeichen)));
    }
  } else if (A.haengestellen) {
    // Stellen in einer zugeklappten Aufgabe zählen zusammen: eine Blase an ihrer Kopfzeile.
    const zu = new Map(), stellen = [];
    for (const s of A.stellen) {
      const b = zugeklappteAufgabe(ankerFinden(s));
      if (!b) { stellen.push([s, ortVon(s)]); continue; }
      const z = zu.get(b) || { frage: 0, fehler: 0, idee: 0, texte: [] };
      z.frage += s.frage; z.fehler += s.fehler; z.idee += s.idee; z.texte = z.texte.concat(s.texte); zu.set(b, z);
    }
    for (const [b, z] of zu) stellen.push([z, kopfOrt(b)]);
    for (const [s, [x, y]] of stellen) {
      if (y < hb.top || y > hb.bottom) continue;
      const n = s.frage + s.fehler + s.idee;
      const art = s.frage >= s.fehler && s.frage >= s.idee ? "frage" : s.fehler >= s.idee ? "fehler" : "idee";
      const titel = [s.frage ? s.frage + "× verstehe ich nicht" : "", s.fehler ? s.fehler + "× Fehler" : "", s.idee ? s.idee + "× Idee" : ""].filter(Boolean).join(" · ")
        + (s.texte.length ? "\n– " + s.texte.map(t => t.text).join("\n– ") : "");
      ebene.append(h("div", { class: "haengestelle " + art, style: "left:" + x + "px;top:" + y + "px", title: titel }, String(n)));
    }
  }
}
async function haengestellenLaden() {
  try { const a = await api("anmerkungen/klasse", { route: routeJetzt() }); A.stellen = a.stellen || [];
    if (a.leer) meldung("Noch keine Abgaben geladen – erst in der Übersicht die Abgaben laden."); }
  catch (e) { A.stellen = []; meldung(e.message, "fehler"); }
}
async function haengestellenSchalten() { A.haengestellen = !A.haengestellen; kopfZeichnen(Z.weg); if (A.haengestellen) await haengestellenLaden(); anmerkungenZeichnen(); }
document.addEventListener("click", ev => { if (!Z.lehrer && A.modus && ev.target.closest("#haupt")) anmerkungSetzen(ev); }, true);
document.addEventListener("keydown", ev => { if (Z.lehrer || ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName) || document.activeElement.closest(".cm-editor") || $(".dialog")) return; if (ev.key === "n" || ev.key === "N") anmerkungModusSchalten(); });
