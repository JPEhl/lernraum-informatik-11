/* Lernraum · lernkarten.js -- Lernkarten (Seite, Karte in „Üben und Nachschlagen“, Zählung der Klasse
   in der Übersicht). Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self') -- darum tragen alle Namen hier „lk“/„LK_“. */
"use strict";
// ─── Lernkarten (Galerie 15.10., Rang 15; Lehrer 16.10.: „Entscheide du“) ─────────────────────
// Die Karten entstehen in bauen.py ohne Zusatztext: jeder Glossar-Begriff (vorne der Begriff, hinten
// die Definition) und jede Prüffrage der ERKLÄRUNG (vorne die Frage, hinten die richtige Wahl mit
// Begründung). Die Vorhersagen und Fragen der Übung werden keine Karten: Sie zählen für die Sterne.
// Geprüft wird wie auf Papier: aufdecken, selbst sagen (Abruf, nicht Wiedererkennen). Fünf Fächer;
// Fach und Fälligkeit rechnet der Stand (stand.lernkarte). Die Klasse sieht eine Begriffskarte, sobald
// sie in deren Thema etwas getan hat, eine Fragekarte erst, wenn die Frage in der Erklärung gelöst ist
// (sonst nähme die Karte der Erklärung die Frage vorweg) -- Späteres erscheint nicht, auch nicht grau.
// Nie am Beamer; im Pult nur zum Ansehen.
// „ab“, nicht „nach“: Die Tage sind ein Mindestabstand, kein Takt (Lehrer 17.10.: „klingt, als müssten es genau
// 2 Tage sein“). Später üben ist genauso gut -- belegt ist das Verteilen, nicht die Zahl (stand.LK_TAGE).
const LK_FAECHER = ["jedes Mal", "ab 2 Tagen", "ab 4 Tagen", "ab 8 Tagen", "sitzt"];
const LK_RUNDE = 10;                     // höchstens so viele Karten je Runde

function lkAlle() { return Z.inhalt.lernkarten || []; }
function lkEintrag(c) { return ((Z.stand || {}).lernkarten || {})[c.id] || null; }
function lkFach(c) { const e = lkEintrag(c); return e ? Math.min(5, Math.max(1, +e.fach || 1)) : 1; }
function lkHeute() { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
function lkDran(c) { const e = lkEintrag(c); return !e || !e.faellig || e.faellig <= lkHeute(); }
function lkSichtbar(c) {
  if (Z.lehrer) return true;
  if (c.art === "frage") return !!(((Z.stand || {}).fragen || {})[c.id.slice(6)] || {}).geloest;
  return themaBegonnen(c.thema);
}
function lkThemaText(c) { const [rk, tk] = c.thema.split("/"); const T = thema(rk, tk); return T ? "Thema " + T.thema.nr + " · " + T.thema.titel : c.thema; }
function lkMischen(liste) { const a = liste.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
// Eine Runde: zuerst die niedrigen Fächer, innerhalb eines Fachs gemischt (Themen durcheinander)
function lkRundeZiehen(karten) {
  const nachFach = [1, 2, 3, 4, 5].map(f => lkMischen(karten.filter(c => lkFach(c) === f)));
  return nachFach.flat().slice(0, LK_RUNDE);
}

async function lernkartenSeite(haupt) {
  kopfZeichnen([["Lernkarten", adr("lernkarten")]]);
  try { const a = await api("inhalt"); Z.stand = a.stand; } catch (e) {}
  const s = h("div", { class: "seite lernkarten" });
  haupt.append(s);
  if (Z.lehrer) return lkPultListe(s);
  lkUebersicht(s);
}

// ─── Die Fächer und der Knopf ────────────────────────────────────────────────────────────
function lkUebersicht(s) {
  s.textContent = "";
  s.append(h("h1", {}, "Lernkarten"), h("p", { class: "unter" }, "Begriffe und Prüffragen aus deinen Themen – aufdecken, ehrlich sagen, ob du es wusstest"));
  const sichtbar = lkAlle().filter(lkSichtbar), verborgen = lkAlle().length - sichtbar.length;
  if (!sichtbar.length) {
    s.append(h("p", { class: "leer" }, "Noch keine Karte. Sie kommen, sobald du in einem Thema arbeitest."));
    return;
  }
  const dran = sichtbar.filter(lkDran);
  const faecher = h("div", { class: "lk-faecher" });
  for (let f = 1; f <= 5; f++) {
    const im = sichtbar.filter(c => lkFach(c) === f), d = im.filter(lkDran).length;
    faecher.append(h("div", { class: "lk-fach" + (d ? " dran" : ""), "data-fach": String(f) }, h("div", { class: "z" }, String(im.length)),
      h("div", { class: "fn" }, "Fach " + f), h("div", { class: "leer" }, LK_FAECHER[f - 1]),
      d && f > 1 ? h("div", { class: "lk-d" }, d + " dran") : null));
  }
  s.append(faecher);
  const zeile = h("div", { class: "zeile lk-los" });
  if (dran.length) {
    const n = Math.min(dran.length, LK_RUNDE);
    zeile.append(h("button", { class: "primaer", onclick: () => lkRunde(s, lkRundeZiehen(dran), true) }, n + (n === 1 ? " Karte üben" : " Karten üben")),
      h("span", { class: "leer" }, dran.length + " von " + sichtbar.length + " Karten sind dran" + (dran.length > LK_RUNDE ? " – " + LK_RUNDE + " je Runde" : "")));
  } else {
    const naechste = sichtbar.map(c => (lkEintrag(c) || {}).faellig || "").filter(Boolean).sort()[0];
    zeile.append(h("span", {}, "Gerade ist keine Karte dran" + (naechste ? " – die nächste am " + datumDe(naechste) + "." : ".")),
      h("button", { class: "ruhig", onclick: () => lkRunde(s, lkRundeZiehen(sichtbar), false) }, "Trotzdem üben"));
  }
  s.append(zeile);
  s.append(h("p", { class: "leer lk-regel" }, "Gewusst: Die Karte wandert ein Fach weiter und kommt seltener wieder. Noch nicht: zurück in Fach 1, sie kommt beim nächsten Mal wieder. Wann du übst, entscheidest du – eine Karte wartet in ihrem Fach, bis du kommst."));
  if (verborgen) s.append(h("p", { class: "leer lk-spaeter" }, verborgen + (verborgen === 1 ? " weitere Karte kommt" : " weitere Karten kommen") + " mit den nächsten Themen und Prüffragen."));
}

// Was „gewusst“ heißt -- über den Knöpfen. Fettgedrucktes zählt nur, wenn mehr fett ist als der Begriff selbst.
function lkMassstab(c) {
  if (c.art !== "begriff") return "Gewusst heißt: Du hattest genau diese Antwort – nicht nur fast.";
  return (c.hinten.match(/<strong>/g) || []).length > 1 ? "Gewusst heißt: Du hättest alles Fettgedruckte gesagt – nicht nur ungefähr."
    : "Gewusst heißt: Du hättest es so erklärt – nicht nur ungefähr.";
}

// ─── Eine Runde ───────────────────────────────────────────────────────────────────────────
// zaehlt = die Karten waren dran (sonst „Trotzdem üben“: der Stand schiebt sie dann nicht weiter)
function lkRunde(s, karten, zaehlt) {
  let i = 0; const ergebnis = { ja: 0, nein: 0 };
  function zeigen() {
    s.textContent = "";
    if (i >= karten.length) return lkSchluss(s, ergebnis, zaehlt);
    const c = karten[i];
    const kopf = h("div", { class: "lk-kopf" }, h("span", { class: "lk-chip " + c.art }, c.art === "begriff" ? "Begriff" : "Prüffrage"),
      h("span", { class: "leer" }, "Karte " + (i + 1) + " von " + karten.length + " · Fach " + lkFach(c)));
    const vorne = c.art === "begriff"
      ? h("div", { class: "lk-vorne" }, h("div", { class: "lk-wort", html: c.vorne }), h("p", { class: "leer" }, "Was heißt das? Sag es dir – dann dreh um."))
      : h("div", { class: "lk-vorne" }, h("div", { html: c.vorne }), h("p", { class: "leer" }, "Antworte für dich – dann dreh um."));
    const karte = h("section", { class: "lk-karte", "data-karte": c.id }, kopf, vorne);
    const unten = h("div", { class: "zeile lk-knoepfe" });
    const umdrehen = h("button", { class: "primaer lk-umdrehen", onclick: () => {
      unten.textContent = "";
      karte.append(h("div", { class: "lk-hinten" }, h("div", { class: "lk-chip hinten" }, "Rückseite"), h("div", { html: c.hinten }),
        h("div", { class: "leer lk-herkunft" }, lkThemaText(c) + " · " + (c.art === "begriff" ? "Definition" : "Prüffrage der Erklärung"))),
        // Wer sich selbst bewertet, urteilt zu milde -- ein halber Satz gilt als gewusst (Dunlosky & Rawson 2012).
        // Ein Maßstab direkt über den Knöpfen; Haken je Kernpunkt hätten mehr gebracht, kosten aber jede Karte einen Klick mehr.
        h("p", { class: "lk-massstab" }, lkMassstab(c)));
      unten.append(h("button", { class: "primaer lk-ja", onclick: () => antworten(true) }, "Wusste ich"), h("button", { class: "lk-nein", onclick: () => antworten(false) }, "Noch nicht"));
      karte.append(unten);
      unten.querySelector(".lk-ja").focus();
    } }, "Umdrehen");
    unten.append(umdrehen);
    karte.append(unten);
    s.append(h("h1", {}, "Lernkarten"), karte, h("p", {}, h("a", { href: "#", class: "leer", onclick: ev => { ev.preventDefault(); lkUebersicht(s); } }, "Runde abbrechen")));
    umdrehen.focus();
    async function antworten(gewusst) {
      unten.querySelectorAll("button").forEach(b => { b.disabled = true; });
      try {
        const a = await api("stand/lernkarte", { kennung: c.id, gewusst });
        (Z.stand.lernkarten = Z.stand.lernkarten || {})[c.id] = a.eintrag;
        ergebnis[gewusst ? "ja" : "nein"]++; i++; zeigen();
      } catch (x) { meldung(x.message, "fehler"); unten.querySelectorAll("button").forEach(b => { b.disabled = false; }); }
    }
  }
  zeigen();
}

function lkSchluss(s, e, zaehlt) {
  s.append(h("h1", {}, "Lernkarten"), h("div", { class: "lk-karte lk-fertig" }, h("h2", {}, "Runde geschafft"),
    h("p", {}, e.ja + " gewusst" + (zaehlt && e.ja ? " – " + (e.ja === 1 ? "sie wandert" : "sie wandern") + " ein Fach weiter" : "") + ", " + e.nein + " noch nicht" + (e.nein ? " – zurück in Fach 1" : "") + "."),
    zaehlt ? null : h("p", { class: "leer" }, "Die Karten waren nicht dran: Gewusste bleiben in ihrem Fach."),
    h("div", { class: "zeile" }, h("button", { class: "primaer", onclick: () => lkUebersicht(s) }, "Zu den Fächern"))));
}

// ─── Im Pult: alle Karten zum Ansehen, je Thema ─────────────────────────────────────────
function lkPultListe(s) {
  s.append(h("h1", {}, "Lernkarten"), h("p", { class: "unter" }, "So entstehen die Karten der Klasse. Üben kann man nur in der Schülerfassung; was hängen bleibt, zählt die Übersicht ohne Namen."),
    h("p", { class: "leer" }, "Eine Begriffskarte sieht die Klasse, sobald sie im Thema gearbeitet hat; eine Prüffragen-Karte erst, wenn sie die Frage in der Erklärung gelöst hat."));
  let thema_ = null, liste = null;
  for (const c of lkAlle()) {
    if (c.thema !== thema_) { thema_ = c.thema; liste = h("div", { class: "lk-pult" }); s.append(h("h2", {}, lkThemaText(c)), liste); }
    liste.append(h("div", { class: "lk-paar", "data-karte": c.id },
      h("div", { class: "lk-karte klein" }, h("span", { class: "lk-chip " + c.art }, c.art === "begriff" ? "Begriff" : "Prüffrage"), c.art === "begriff" ? h("div", { class: "lk-wort", html: c.vorne }) : h("div", { html: c.vorne })),
      h("div", { class: "lk-karte klein lk-hinten" }, h("div", { html: c.hinten }))));
  }
}

// Die Karte im Bereich „Üben und Nachschlagen“ -- erst, wenn es eine Karte gibt (Regel 4).
function lernkartenKarte() {
  const alle = lkAlle(); if (!alle.length) return null;
  if (Z.lehrer) return h("a", { class: "nachschlagkarte", href: adr("lernkarten") }, h("div", { class: "nr" }, "Lernkarten"),
    h("div", { class: "titel" }, alle.length + " Karten"), h("div", {}, "aus Definitionen und den Prüffragen der Erklärungen"));
  const sichtbar = alle.filter(lkSichtbar); if (!sichtbar.length) return null;
  const dran = sichtbar.filter(lkDran).length, sitzen = sichtbar.filter(c => lkFach(c) === 5).length;
  return h("a", { class: "nachschlagkarte", href: adr("lernkarten") }, h("div", { class: "nr" }, "Lernkarten"),
    h("div", { class: "titel" }, dran ? dran + (dran === 1 ? " Karte ist dran" : " Karten sind dran") : "Gerade keine Karte dran"),
    h("div", {}, dran === sichtbar.length ? "Begriffe und Prüffragen aus deinen Themen" : sichtbar.length + (sichtbar.length === 1 ? " Karte" : " Karten") + (sitzen ? " · " + sitzen + " sitzen" : "")));
}

// ─── Übersicht: die Klasse ohne Namen ───────────────────────────────────────────────────
// Welche Karten bei den meisten in Fach 1 hängen -- dort sitzt eine Fehlvorstellung fest.
function lernkartenKlasse(d) {
  const box = h("div", { class: "lk-klasse" }, h("h3", {}, "Lernkarten der Klasse (ohne Namen)"),
    h("p", { class: "leer" }, d.personen + (d.personen === 1 ? " Person hat" : " Personen haben") + " mit Lernkarten geübt (je Person die neueste Abgabe). Oben die Karten, die bei den meisten noch in Fach 1 liegen."));
  const zeile = k => h("tr", { "data-karte": k.id }, h("td", {}, k.art === "begriff" ? "Begriff" : "Prüffrage"), h("td", {}, k.kurz),
    h("td", { class: "leer x" }, lkThemaText(k).split(" · ")[0]), h("td", { class: "x" }, k.faecher[0] + " von " + k.personen),
    h("td", { class: "x", title: "Fach 1 · 2 · 3 · 4 · 5" }, k.faecher.join(" · ")), h("td", { class: "x" }, String(k.nicht)));
  const kopf = () => h("thead", {}, h("tr", {}, h("th", {}, "Art"), h("th", {}, "Karte"), h("th", {}, "aus"), h("th", {}, "in Fach 1"), h("th", {}, "Fächer 1–5"), h("th", {}, "„noch nicht“")));
  const oben = d.karten.slice(0, 8), rest = d.karten.slice(8);
  box.append(h("table", {}, kopf(), h("tbody", {}, oben.map(zeile))));
  if (rest.length) box.append(h("details", {}, h("summary", {}, "alle " + d.karten.length + " Karten"), h("table", {}, kopf(), h("tbody", {}, rest.map(zeile)))));
  return box;
}
