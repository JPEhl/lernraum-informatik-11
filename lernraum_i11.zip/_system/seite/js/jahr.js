/* Lernraum · jahr.js -- die Jahresübersicht des Lehrerpults (Lehrerwunsch 16.10.2026).
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self').
   Je Person und Thema, was aus der Übersicht übernommen wurde (Knopf dort): Sterne
   nachgerechnet, Ziel, ohne ★, versucht, Hilfen, mit wem, Mini-Exit ja/nein, wann.
   Je Thema eine Frist -- danach heißt eine Abgabe „verspätet“. Die Note gibst du
   außerhalb; rechts steht nur ihre Grundlage. Nie am Beamer (der Server sagt 423). */
"use strict";
function datumZeit(iso) { const m = (iso || "").match(/^\d{4}-(\d\d)-(\d\d)(?:T(\d\d:\d\d))?/); return m ? m[2] + "." + m[1] + "." + (m[3] ? ", " + m[3] : "") : ""; }
function schuljahrSeite(haupt) {
  kopfZeichnen([["Schuljahr", null]]);
  const s = h("div", { class: "seite schuljahr" }, h("h1", {}, "Schuljahr · " + Z.inhalt.titel));
  haupt.append(s);
  if (!Z.lehrer) { s.append(h("p", {}, "Nur im Lehrerpult.")); return; }
  if (Z.beamer) { s.append(h("p", { class: "hinweis" }, "Beamer ist an – das Schuljahr bleibt zu. Erst „Beamer aus“.")); return; }
  const inhalt = h("div", {}, h("p", { class: "laden" }, "Wird geladen …"));
  s.append(inhalt);
  api("jahr/lesen", {}).then(r => zeigen(r.jahr, r.themen)).catch(e => { inhalt.textContent = e.message; });
  function zeigen(J, themen) {
    inhalt.textContent = "";
    const namen = Object.keys(J.personen).sort((a, b) => a.localeCompare(b, "de"));
    const eintrag = (n, t) => ((J.eintraege || {})[n] || {})[t];
    const dran = t => !!J.fristen[t] || namen.some(n => eintrag(n, t));
    const spaet = (e, t) => !!(J.fristen[t] && e && (e.abgegeben || "").slice(0, 10) > J.fristen[t]);
    const ziel = e => e.sterne != null ? !!e.geschafft : !!(e.selbstcheck && e.selbstcheck[1] && e.selbstcheck[0] === e.selbstcheck[1]);
    if (!namen.length) {
      inhalt.append(h("p", { class: "leer" }, "Noch nichts übernommen. In der ", h("a", { href: adr("uebersicht") }, "Übersicht"),
        " Abgaben und Kursliste laden, dann „In die Jahresübersicht übernehmen“."));
      return;
    }
    inhalt.append(h("p", { class: "unter" }, "Aus den Abgaben, die du in der Übersicht übernommen hast · zuletzt übernommen " + datumZeit(J.zuletzt) + " · liegt in deinem OneDrive, nie im Projekt."),
      h("p", { class: "jahr-legende" }, h("span", { class: "ziel" }, "Ziel erreicht"), h("span", { class: "unter" }, "abgegeben, Ziel nicht erreicht"),
        h("span", { class: "fehlt" }, "nicht abgegeben"), h("span", { class: "offen" }, "· noch nicht dran"), h("span", { class: "spaet-chip" }, "verspätet"), " nach der Frist des Themas"));
    const kopf = h("tr", {}, h("th", {}, "Name"));
    for (const t of themen) {
      const feld = h("input", { type: "date", value: J.fristen[t.pfad] || "", title: "Frist: danach heißt eine Abgabe „verspätet“" });
      feld.addEventListener("change", async () => { try { const r = await api("jahr/frist", { thema: t.pfad, datum: feld.value }); zeigen(r.jahr, themen); } catch (e) { meldung(e.message, "fehler"); } });
      kopf.append(h("th", {}, h("div", {}, "Thema " + t.nr + " · " + t.titel), h("label", { class: "frist" }, "Frist ", feld)));
    }
    kopf.append(h("th", {}, "Grundlage für die Note"));
    const tb = h("tbody", {});
    const det = h("aside", { class: "jahr-detail" }); det.hidden = true;
    for (const n of namen) {
      const tr = h("tr", {}, h("th", {}, n));
      let ab = 0, zahl = 0, zi = 0, sp = 0, st = 0, soll = 0;
      for (const t of themen) {
        const e = eintrag(n, t.pfad);
        if (!dran(t.pfad)) { tr.append(h("td", { class: "jz offen" }, "·")); continue; }
        zahl++;
        if (t.mindest) soll += t.mindest;
        if (!e) { tr.append(h("td", { class: "jz fehlt" }, "fehlt")); continue; }
        ab++; if (ziel(e)) zi++; if (spaet(e, t.pfad)) sp++; if (e.sterne != null && t.mindest) st += e.sterne;
        const zelle = h("td", { class: "jz " + (ziel(e) ? "ziel" : "unter"), tabindex: "0", title: "Einzelheiten" },
          // Themen ohne Sterne (Rucksack): der Selbstcheck -- ein ✓ nur, wenn er ganz passt; ohne Lauf nur „abgegeben“
          e.sterne != null ? [h("b", {}, "★ " + e.sterne), h("span", {}, "/" + e.max)]
            : e.selbstcheck && e.selbstcheck[1] ? [h("b", {}, (e.selbstcheck[0] === e.selbstcheck[1] ? "✓ " : "") + e.selbstcheck[0]), h("span", {}, "/" + e.selbstcheck[1] + " Selbstcheck")]
            : h("b", {}, "abgegeben"),
          (e.ohne_stern || []).length ? h("i", {}, "ohne ★: A" + e.ohne_stern.join(", A")) : null,
          spaet(e, t.pfad) ? h("em", { class: "spaet-chip" }, "verspätet") : null,
          (e.frueher || []).length ? h("em", { class: "nach-chip" }, "nachgereicht") : null);
        zelle.addEventListener("click", () => einzelheiten(n, t, e, zelle));
        tr.append(zelle);
      }
      const quote = soll ? Math.round(100 * st / soll) : null;
      tr.append(h("td", { class: "js" }, ab + "/" + zahl + " abgegeben", h("br"), zi + "× Ziel" + (quote != null ? " · ★ " + quote + " % vom Ziel" : ""), sp ? [h("br"), sp + "× verspätet"] : null));
      tb.append(tr);
    }
    inhalt.append(h("div", { class: "jahr-rahmen" }, h("table", { class: "jahr-tabelle" }, h("thead", {}, kopf), tb)), det,
      h("p", { class: "leer" }, "„★ % vom Ziel“: alle Sterne der Themen mit Ziel, geteilt durch die Summe der Ziele (fehlende Abgaben zählen 0). Die Note gibst du – das hier ist ihre Grundlage."));
    function einzelheiten(n, t, e, zelle) {
      inhalt.querySelectorAll(".jz.gewaehlt").forEach(x => x.classList.remove("gewaehlt")); zelle.classList.add("gewaehlt");
      det.hidden = false; det.textContent = "";
      const zeile = (k, v) => [h("dt", {}, k), h("dd", {}, v)];
      det.append(h("h3", {}, n + " · Thema " + t.nr + " · " + t.titel), h("dl", {},
        zeile("abgegeben", datumZeit(e.abgegeben) + (spaet(e, t.pfad) ? " – verspätet (Frist " + datumZeit(J.fristen[t.pfad]) + ")" : "")),
        (e.frueher || []).length ? zeile("ersetzt", "die Abgabe vom " + e.frueher.map(datumZeit).join(", ")) : [],
        e.sterne != null ? zeile("Sterne", "★ " + e.sterne + " von " + e.max + (e.mindest ? " · Ziel " + e.mindest + (e.geschafft ? " erreicht" : " nicht erreicht") : "") + (e.nachgerechnet ? "" : " (Selbstauskunft, nicht nachgelaufen)")) : [],
        (e.ohne_stern || []).length ? zeile("ohne ★", "Aufgabe " + e.ohne_stern.join(", ")) : [],
        (e.versucht || []).length ? zeile("versucht", e.versucht.map(v => "★".repeat(v.stufe) + " in Aufgabe " + v.nr).join(" · ") + " (nicht geschafft)") : [],
        e.selbstcheck ? zeile("Selbstcheck", e.selbstcheck[0] + " von " + e.selbstcheck[1]) : [],
        zeile("Hilfen", e.hilfen + " geöffnet"),
        zeile("zu zweit mit", e.partner || "–"),
        zeile("Mini-Exit", e.miniexit ? "ausgefüllt" : "leer"),
        e.hinweis ? zeile("Hinweis", e.hinweis) : []),
        h("p", {}, h("button", { class: "ruhig", onclick: async () => {
          if (!confirm("Diesen Eintrag aus dem Schuljahr entfernen?\n\n" + n + " · Thema " + t.nr)) return;
          try { const r = await api("jahr/entfernen", { name: n, thema: t.pfad }); zeigen(r.jahr, themen); } catch (x) { meldung(x.message, "fehler"); } } }, "Eintrag entfernen")));
    }
  }
}
