/* Lernraum · editor.js -- CodeMirror-Editor, Arbeitsdatei im Editor, Eingaben, Trenner, Kopieren-Knöpfe.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ── Editor (CodeMirror 6) ──────────────────────────────────────────────────────
const fehlerMarke = CM.Decoration.line({ class: "cm-fehlerzeile" });
const aktuellMarke = CM.Decoration.line({ class: "cm-aktuellezeile" });
// Zwischenstände im Fahrplan (Lehrerwunsch 21.10., T11): neu grün, geändert gelb, gelöscht rot und
// durchgestrichen. Gelöschte Zeilen stehen nicht mehr im Code -- sie sind ein Widget über der Stelle.
const neuMarke = CM.Decoration.line({ class: "cm-stand-neu" });
const geaendertMarke = CM.Decoration.line({ class: "cm-stand-geaendert" });
const gehtMarke = CM.Decoration.line({ class: "cm-stand-geht" });
// Kopieren und Einfügen (Lehrer 22.10.: „Könnte man das Copy-Pasten auch als Copy-Pasten und nicht als Tippen
// animieren?“): die Quelle wie eine Auswahl, dann erscheint der Block auf einmal
const kopieMarke = CM.Decoration.line({ class: "cm-stand-kopie" });
class GeloeschtWidget extends CM.WidgetType {
  constructor(zeilen) { super(); this.zeilen = zeilen; }
  eq(w) { return w.zeilen.join("\n") === this.zeilen.join("\n"); }
  toDOM() { const d = h("div", { class: "cm-stand-weg", "aria-label": "gelöscht" }); this.zeilen.forEach(z => d.append(h("div", {}, z || " "))); return d; }
  ignoreEvent() { return true; }
}
// Zeilenvergleich: gibt je Zeile des neuen Texts "gleich" | "neu" | "geaendert" und die gelöschten Zeilen
// mit der Zeile, vor der sie standen. Patience-Vergleich: Zeilen, die in beiden Texten genau einmal
// vorkommen, werden zuerst verankert (in T11 steht hilfe() zweimal -- die längste gemeinsame Folge allein
// hätte „Viel Glück“ gelöscht und neu geschrieben, statt den Aufruf ohne Klammern gelb zu zeigen);
// dazwischen die längste gemeinsame Folge. Ein Block aus Weg und Neu nebeneinander zählt paarweise als
// „geändert“; was übrig bleibt, ist neu bzw. gelöscht.
function zeilenVergleich(alt, neu) {
  const a = alt.split("\n"), b = neu.split("\n");
  const ops = [];   // ["=", i, j] | ["-", i] | ["+", j]
  function lcs(a0, a1, b0, b1) {
    const n = a1 - a0, m = b1 - b0;
    const t = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) t[i][j] = a[a0 + i] === b[b0 + j] ? t[i + 1][j + 1] + 1 : Math.max(t[i + 1][j], t[i][j + 1]);
    let i = 0, j = 0;
    while (i < n || j < m) {
      if (i < n && j < m && a[a0 + i] === b[b0 + j]) { ops.push(["=", a0 + i, b0 + j]); i++; j++; }
      else if (j >= m || (i < n && t[i + 1][j] >= t[i][j + 1])) { ops.push(["-", a0 + i]); i++; }
      else { ops.push(["+", b0 + j]); j++; }
    }
  }
  function patience(a0, a1, b0, b1) {
    while (a0 < a1 && b0 < b1 && a[a0] === b[b0]) { ops.push(["=", a0++, b0++]); }
    const ende = [];
    while (a1 > a0 && b1 > b0 && a[a1 - 1] === b[b1 - 1]) { a1--; b1--; ende.unshift(["=", a1, b1]); }
    const zaehle = (arr, x0, x1) => { const z = new Map(); for (let k = x0; k < x1; k++) z.set(arr[k], (z.get(arr[k]) || 0) + 1); return z; };
    const za = zaehle(a, a0, a1), zb = zaehle(b, b0, b1), posA = new Map();
    for (let k = a0; k < a1; k++) if (za.get(a[k]) === 1 && zb.get(a[k]) === 1 && a[k].trim()) posA.set(a[k], k);
    const paare = []; for (let k = b0; k < b1; k++) if (posA.has(b[k]) && zb.get(b[k]) === 1) paare.push([posA.get(b[k]), k]);
    // längste steigende Folge nach der Position im alten Text
    const vor = [], spitzen = [];
    paare.forEach((p, k) => { let lo = 0, hi = spitzen.length; while (lo < hi) { const mid = (lo + hi) >> 1; if (paare[spitzen[mid]][0] < p[0]) lo = mid + 1; else hi = mid; } vor[k] = lo ? spitzen[lo - 1] : -1; spitzen[lo] = k; });
    const anker = []; for (let k = spitzen.length ? spitzen[spitzen.length - 1] : -1; k >= 0; k = vor[k]) anker.unshift(paare[k]);
    if (!anker.length) lcs(a0, a1, b0, b1);
    else { let ia = a0, ib = b0; for (const [x, y] of anker) { patience(ia, x, ib, y); ops.push(["=", x, y]); ia = x + 1; ib = y + 1; } patience(ia, a1, ib, b1); }
    ops.push(...ende);
  }
  patience(0, a.length, 0, b.length);
  const art = new Array(b.length).fill("gleich"), weg = [];
  for (let k = 0; k < ops.length;) {
    if (ops[k][0] === "=") { k++; continue; }
    const wegZ = [], neuJ = [];
    while (k < ops.length && ops[k][0] !== "=") { if (ops[k][0] === "-") wegZ.push(a[ops[k][1]]); else neuJ.push(ops[k][1]); k++; }
    const naechste = k < ops.length ? ops[k][2] : b.length;
    const paare = Math.min(wegZ.length, neuJ.length);
    neuJ.forEach((jj, x) => { art[jj] = x < paare ? "geaendert" : "neu"; });
    if (wegZ.length > paare) weg.push([naechste, wegZ.slice(paare)]);
  }
  return { art, weg, ops };
}
function editor(parent, text, sprache, onChange, schreibgeschuetzt) {
  const marken = new CM.Compartment();
  const stand = new CM.Compartment();
  let standSetzen = false;
  const ext = [
    CM.lineNumbers(), CM.highlightActiveLine(), CM.highlightActiveLineGutter(), CM.highlightSpecialChars(), CM.drawSelection(),
    CM.history(), CM.indentUnit.of("    "), CM.bracketMatching(), CM.closeBrackets(), CM.indentOnInput(),
    CM.syntaxHighlighting(CM.defaultHighlightStyle, { fallback: true }), CM.highlightSelectionMatches(),
    CM.keymap.of([...CM.closeBracketsKeymap, ...CM.defaultKeymap, ...CM.historyKeymap, ...CM.searchKeymap, CM.indentWithTab]),
    sprache === "html" ? CM.html() : CM.python(),
    marken.of([]), stand.of([]),
    CM.EditorView.updateListener.of(u => {
      if (!u.docChanged) return;
      // Der erste eigene Tastendruck nimmt die Farben des Zwischenstands weg -- ab dort tippt man normal weiter
      if (!standSetzen) setTimeout(() => view.dispatch({ effects: stand.reconfigure([]) }), 0);
      if (onChange) onChange(u.state.doc.toString());
    }),
  ];
  if (schreibgeschuetzt) ext.push(CM.EditorState.readOnly.of(true), CM.EditorView.editable.of(false));
  const view = new CM.EditorView({ state: CM.EditorState.create({ doc: text, extensions: ext }), parent });
  let anim = null;
  function programmatisch(spec) { standSetzen = true; try { view.dispatch(spec); } finally { standSetzen = false; } }
  function farben(art, weg) {
    const doc = view.state.doc, deko = [];
    art.forEach((x, j) => { if (x !== "gleich" && j < doc.lines) deko.push((x === "neu" ? neuMarke : geaendertMarke).range(doc.line(j + 1).from)); });
    weg.forEach(([vor, zeilen]) => {
      const pos = vor < doc.lines ? doc.line(vor + 1).from : doc.length;
      deko.push(CM.Decoration.widget({ widget: new GeloeschtWidget(zeilen), block: true, side: vor < doc.lines ? -1 : 1 }).range(pos));
    });
    programmatisch({ effects: stand.reconfigure(CM.EditorView.decorations.of(CM.Decoration.set(deko, true))) });
  }
  // Ruhig zur Stelle (Lehrer 21.10.: „der Code ist sehr plötzlich zur korrekten Stelle gesprungen“): steht sie schon
  // im Bild, bleibt alles, wo es ist; sonst gleitet der Editor hin, mit drei Zeilen davor. Gibt die Dauer in ms.
  function sanftZu(pos, sanft) {
    const sd = view.scrollDOM, b = view.lineBlockAt(pos), oben = sd.scrollTop, hoehe = sd.clientHeight;
    const rand = b.height * 2;
    if (b.top >= oben + rand / 2 && b.bottom <= oben + hoehe - rand) return 0;
    sd.scrollTo({ top: Math.max(0, b.top - b.height * 3), behavior: sanft ? "smooth" : "auto" });
    return sanft ? 420 : 0;
  }
  return {
    view,
    text: () => view.state.doc.toString(),
    setzen(t) { view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: t } }); view.dispatch({ effects: marken.reconfigure([]) }); },
    markieren(zeile, art) {
      if (!zeile || zeile > view.state.doc.lines) { view.dispatch({ effects: marken.reconfigure([]) }); return; }
      const pos = view.state.doc.line(zeile).from;
      const deko = CM.Decoration.set([(art === "aktuell" ? aktuellMarke : fehlerMarke).range(pos)]);
      view.dispatch({ effects: marken.reconfigure(CM.EditorView.decorations.of(deko)) });
      view.dispatch({ effects: CM.EditorView.scrollIntoView(pos, { y: "center" }) });
    },
    entmarkieren() { view.dispatch({ effects: marken.reconfigure([]) }); },
    // Setzt den Code auf einen Zwischenstand und färbt, was sich gegenüber `alt` geändert hat.
    // Ein normaler Edit: Strg+Z holt den Stand davor zurück (auch das, was man selbst getippt hatte).
    async standZeigen(neu, alt) {
      if (anim) { anim.abbrechen(); await anim.fertig; }
      programmatisch({ changes: { from: 0, to: view.state.doc.length, insert: neu }, effects: marken.reconfigure([]) });
      const { art, weg } = zeilenVergleich(alt, neu);
      farben(art, weg);
      const erste = art.findIndex(x => x !== "gleich");
      const ziel = erste >= 0 ? erste : (weg.length ? Math.min(weg[0][0], view.state.doc.lines - 1) : -1);
      if (ziel >= 0) sanftZu(view.state.doc.line(ziel + 1).from, false);
      return { neu: art.filter(x => x === "neu").length, geaendert: art.filter(x => x === "geaendert").length, weg: weg.reduce((s, w) => s + w[1].length, 0) };
    },
    // Der Code-Film (Lehrerwunsch 21.10.): von `alt` nach `neu`, sichtbar getippt. Erst ruhig zur Stelle scrollen,
    // dann wird kurz rot, was wegfällt, dann erscheint das Neue Zeichen für Zeichen (Einrückung sofort).
    // opt.zps Zeichen je Sekunde, opt.maxSek höchstens so lange; ein zweiter Klick bricht ab (fertig sofort).
    async standAnimieren(neu, alt, opt) {
      if (anim) { anim.abbrechen(); await anim.fertig; }
      const norm = x => x.replace(/\s+$/, "");
      programmatisch(norm(view.state.doc.toString()) !== norm(alt)
        ? { changes: { from: 0, to: view.state.doc.length, insert: alt }, effects: [marken.reconfigure([]), stand.reconfigure([])] }
        : { effects: opt.schonRot ? [marken.reconfigure([])] : [marken.reconfigure([]), stand.reconfigure([])] });
      const { art, weg, ops } = zeilenVergleich(alt, neu);
      if (alt === neu) return;
      let abgebrochen = false, fertigAuf = null;
      const meins = { abbrechen() { abgebrochen = true; }, fertig: new Promise(r => { fertigAuf = r; }) };
      anim = meins;
      const warte = ms => new Promise(r => setTimeout(r, ms));
      // 1. zur ersten Stelle, an der sich etwas tut (im alten Text)
      let ia = 0; for (const o of ops) { if (o[0] !== "=") break; ia = o[1] + 1; }
      const zeileAlt = Math.min(ia, view.state.doc.lines - 1);
      const dauer = sanftZu(view.state.doc.line(zeileAlt + 1).from, true);
      if (dauer) await warte(dauer);
      // 2. was wegfällt oder sich ändert, kurz rot und durchgestrichen -- im Code selbst
      const gehen = ops.filter(o => o[0] === "-").map(o => o[1]);
      if (gehen.length && !abgebrochen && !opt.schonRot) {
        const d = view.state.doc;
        programmatisch({ effects: stand.reconfigure(CM.EditorView.decorations.of(CM.Decoration.set(gehen.map(i => gehtMarke.range(d.line(i + 1).from)), true))) });
        await warte(opt.rotMs || 550);
      }
      // 3. der neue Text, mit leeren Zeilen dort, wo Neues hinkommt -- dann Zeichen für Zeichen
      const zeilen = neu.split("\n");
      const offen = art.map((x, j) => x === "gleich" ? null : j).filter(j => j !== null);
      const gerueste = zeilen.map((z, j) => art[j] === "gleich" ? z : (z.match(/^\s*/)[0]));
      programmatisch({ changes: { from: 0, to: view.state.doc.length, insert: gerueste.join("\n") } });
      farben(art, weg);
      const rest = offen.map(j => [j, zeilen[j].slice(gerueste[j].length)]);
      const zeichen = rest.reduce((s, r) => s + r[1].length, 0);
      const zps = Math.max(opt.zps || 30, zeichen / (opt.maxSek || 2));
      const takt = 30, jeTakt = Math.max(1, Math.round(zps * takt / 1000));
      for (const [j, text] of rest) {
        if (!abgebrochen && j < view.state.doc.lines) { const d = sanftZu(view.state.doc.line(j + 1).from, true); if (d) await warte(d); }
        for (let k = 0; k < text.length; k += jeTakt) {
          if (abgebrochen) break;
          const pos = view.state.doc.line(j + 1).to;
          programmatisch({ changes: { from: pos, insert: text.slice(k, k + jeTakt) } });
          farben(art, weg);
          await warte(takt);
        }
        if (abgebrochen) break;
      }
      if (norm(view.state.doc.toString()) !== norm(neu)) programmatisch({ changes: { from: 0, to: view.state.doc.length, insert: neu } });
      farben(art, weg);
      if (anim === meins) anim = null;
      fertigAuf();
    },
    // Löschen und Schreiben in zwei Drücken (Lehrer 21.10.: „die Schritte, bei denen erst was gelöscht und dann was
    // neues geschrieben wird, [gehen mir] zu schnell“): Der erste Druck markiert nur, was wegfällt, und bleibt stehen.
    hatWeg: (neu, alt) => zeilenVergleich(alt, neu).ops.some(o => o[0] === "-"),
    async wegMarkieren(neu, alt) {
      if (anim) { anim.abbrechen(); await anim.fertig; }
      const norm = x => x.replace(/\s+$/, "");
      programmatisch(norm(view.state.doc.toString()) !== norm(alt)
        ? { changes: { from: 0, to: view.state.doc.length, insert: alt }, effects: [marken.reconfigure([]), stand.reconfigure([])] }
        : { effects: [marken.reconfigure([]), stand.reconfigure([])] });
      const gehen = zeilenVergleich(alt, neu).ops.filter(o => o[0] === "-").map(o => o[1]);
      if (!gehen.length) return;
      sanftZu(view.state.doc.line(gehen[0] + 1).from, true);
      const d = view.state.doc;
      programmatisch({ effects: stand.reconfigure(CM.EditorView.decorations.of(CM.Decoration.set(gehen.map(i => gehtMarke.range(d.line(i + 1).from)), true))) });
    },
    // Erster Druck eines Einfüge-Schritts: der Code steht noch auf `alt`, die Zeilen, aus denen kopiert wird, sind
    // markiert -- gesucht wird je neuer Block eine Folge alter Zeilen mit demselben Text (Einrückung egal).
    async kopieMarkieren(neu, alt) {
      if (anim) { anim.abbrechen(); await anim.fertig; }
      const norm = x => x.replace(/\s+$/, "");
      programmatisch(norm(view.state.doc.toString()) !== norm(alt)
        ? { changes: { from: 0, to: view.state.doc.length, insert: alt }, effects: [marken.reconfigure([]), stand.reconfigure([])] }
        : { effects: [marken.reconfigure([]), stand.reconfigure([])] });
      const { art } = zeilenVergleich(alt, neu);
      const b = neu.split("\n"), a = alt.split("\n").map(z => z.trim());
      const bloecke = []; art.forEach((x, j) => { if (x === "gleich") return; const l = bloecke[bloecke.length - 1]; if (l && l[l.length - 1] === j - 1) l.push(j); else bloecke.push([j]); });
      const quelle = [];
      for (const bl of bloecke) {
        const t = bl.map(j => b[j].trim());
        for (let i = 0; i + t.length <= a.length; i++) if (t.every((x, k) => a[i + k] === x)) { for (let k = 0; k < t.length; k++) quelle.push(i + k); break; }
      }
      if (!quelle.length) return 0;
      const d = view.state.doc, zeilen = [...new Set(quelle)].sort((x, y) => x - y);
      sanftZu(d.line(zeilen[0] + 1).from, true);
      programmatisch({ effects: stand.reconfigure(CM.EditorView.decorations.of(CM.Decoration.set(zeilen.map(i => kopieMarke.range(d.line(i + 1).from)), true))) });
      return zeilen.length;
    },
    laeuftAnimation: () => !!anim,
    animationFertig() { if (anim) anim.abbrechen(); },
  };
}

// Eine Arbeitsdatei im Editor: speichert verzögert, kann ausführen, aufzeichnen, zurücksetzen.
function arbeitsEditor(opts) {
  // opts: pfad (relativ zur Wurzel), thema (reihe/thema), ort (fürs Fehlerbuch: uebung, vortrag/5 …), sprache, knoepfe: [..], onGespeichert, zusatzKnoepfe
  const box = h("div", { class: "editorbox" });
  const cmEl = h("div", { class: "cm-huelle" });
  const werkzeuge = h("div", { class: "werkzeuge" });
  const status = h("span", { class: "status" }, "");
  const konsole = h("div", { class: "konsole" });
  box.append(cmEl, werkzeuge);
  let ed = null, speicherTimer = null, gespeichert = true, lauf = null;
  const ich = { box, konsole, ed: null, pfad: opts.pfad };
  const nachLaden = [];   // was erst geht, wenn der Editor steht (Lesezeichen im Code-Film)

  async function laden() {
    const a = await api("datei/lesen", { pfad: opts.pfad });
    ed = ich.ed = editor(cmEl, a.text, opts.sprache || "python", geaendert, opts.schreibgeschuetzt);
    for (const f of nachLaden.splice(0)) f();
    if (opts.onGeladen) opts.onGeladen(a.text);
  }
  function geaendert() {
    gespeichert = false; status.textContent = "…";
    clearTimeout(speicherTimer); speicherTimer = setTimeout(speichern, 1200);
  }
  async function speichern() {
    if (!ed || gespeichert) return;
    try { await api("datei/schreiben", { pfad: opts.pfad, text: ed.text() }); gespeichert = true; status.textContent = "gespeichert"; if (opts.onGespeichert) opts.onGespeichert(ed.text()); }
    catch (e) { status.textContent = "nicht gespeichert: " + e.message; }
  }
  function konsoleLeeren() { konsole.textContent = ""; }
  function schreiben(text, cls) { const s = h("span", { class: cls || "" }, text); konsole.append(s); konsole.scrollTop = 1e9; }

  // vorgabe: Eingaben, die der Code-Film sichtbar in die Eingabezeile tippt und abschickt (21.10.)
  async function ausfuehren(vorgabe) {
    await speichern(); if (ed) ed.entmarkieren();
    konsoleLeeren(); konsole.hidden = false;
    if (lauf) { try { await api("lauf/stopp", { id: lauf.id }); } catch (e) {} }
    stoppKnopf.disabled = false; startKnopf.disabled = true;
    try { lauf = await api("lauf/start", { pfad: opts.pfad, thema: opts.thema, ort: opts.ort || "" }); }
    catch (e) { schreiben(e.message, "fehlertext"); startKnopf.disabled = false; stoppKnopf.disabled = true; return; }
    const eingabe = h("input", { placeholder: "Eingabe für das Programm – Enter schickt sie", onkeydown: async ev => { if (ev.key === "Enter" && lauf) { const t = eingabe.value; eingabe.value = ""; await api("lauf/eingabe", { id: lauf.id, text: t }); } } });
    const zeile = h("div", { class: "eingabezeile" }, h("span", { class: "prompt" }, "›"), eingabe);
    const ausgabe = h("span", {});
    // Das Eingabefeld nur, wenn das Programm input() benutzt oder der Film Eingaben vorgibt (Durchsicht T16, W1,
    // 26.10.: „Warum erscheint in der Shell hier eine Eingabezeile?“ -- bei einem Fenster fragt niemand nach Text)
    const mitEingabe = /\binput\s*\(/.test(ed ? ed.text() : "") || (Array.isArray(vorgabe) && vorgabe.length > 0);
    konsole.append(ausgabe);
    if (mitEingabe) konsole.append(zeile);
    if (Array.isArray(vorgabe) && vorgabe.length) (async () => {
      const meinLauf = lauf;
      for (const text of vorgabe) {
        await schlafen(700);
        if (lauf !== meinLauf || !zeile.isConnected) return;
        for (const c of text) { eingabe.value += c; await schlafen(70); }
        await schlafen(250);
        if (lauf !== meinLauf) return;
        eingabe.value = "";
        try { await api("lauf/eingabe", { id: meinLauf.id, text }); } catch (e) { return; }
      }
    })();
    let ab = 0, klicks = 0;
    while (true) {
      let b;
      try { b = await api("lauf/lesen", { id: lauf.id, ab }); } catch (e) { schreiben("\n" + e.message, "fehlertext"); break; }
      if (b.text) {
        ausgabe.append(b.text);
        // Endlosschleife mit print: die Shell behält nur das Ende, sonst friert die Seite ein (Messlauf 22.10.)
        if (ausgabe.textContent.length > 60000) { const t = ausgabe.textContent; ausgabe.textContent = "… (so viel Ausgabe, dass nur das Ende zu sehen ist) …\n" + t.slice(t.indexOf("\n", t.length - 30000) + 1); }
        konsole.scrollTop = 1e9;
      }
      // Fehler in einer Knopf-Funktion (Teil III, 25.10.): Das Fenster läuft weiter, das Programm endet nicht mit
      // Fehler -- der Satz kommt deshalb sofort, je Klick, mitten in die Ausgabe
      if (b.klickfehler && b.klickfehler_zahl > klicks) {
        const neu = b.klickfehler.slice(Math.max(0, b.klickfehler.length - (b.klickfehler_zahl - klicks)));
        for (const f of neu) {
          ausgabe.append(h("span", { class: "satz klickfehler" }, "Beim Klick" + (f.zeile ? ", Zeile " + f.zeile : "") + ": " + f.satz));
          if (f.zeile && ed) ed.markieren(f.zeile, "fehler");
        }
        if (klicks === 0) { const fb = fehlerbuchHinweis(b.fehlerbuch); if (fb) ausgabe.append(fb); }
        klicks = b.klickfehler_zahl; konsole.scrollTop = 1e9;
      }
      ab = b.bis;
      if (b.fertig) {
        zeile.remove();
        if (b.fehler) {
          const f = b.fehler;
          konsole.append(h("span", { class: "satz" }, (f.zeile ? "Zeile " + f.zeile + ": " : "") + f.satz), fehlerbuchHinweis(b.fehlerbuch));
          if (f.zeile && ed) ed.markieren(f.zeile, "fehler");
        } else if (b.gestoppt) konsole.append(h("span", { class: "satz" }, "— angehalten (" + b.gestoppt + ") —"));
        else konsole.append(h("span", { class: "satz" }, "— Programm beendet —"));
        break;
      }
      await schlafen(200);
    }
    lauf = null; startKnopf.disabled = false; stoppKnopf.disabled = true;
    if (opts.nachLauf) opts.nachLauf();
  }
  async function stopp() { if (lauf) await api("lauf/stopp", { id: lauf.id }); }

  const startKnopf = h("button", { class: "primaer", onclick: () => ausfuehren() }, "▶ Ausführen");
  const stoppKnopf = h("button", { class: "gefahr", onclick: stopp, disabled: true }, "■ Stopp");
  werkzeuge.append(startKnopf, stoppKnopf);
  // Debugger (bis 17.10. „⏺ Aufzeichnen“; Lehrer 14.10.: „Was macht Aufzeichnen?“ -- der Knopf sagt es
  // selbst; 17.10.: „ich würde den Debugger auch Debugger nennen“). Nach Eingaben fragt er nur, wenn das
  // Programm input() benutzt -- Vorschlag aus EINGABEN des Themas.
  if (!opts.ohneAufzeichnung) werkzeuge.append(h("button", { class: "debugger-knopf", title: "Debugger: Das Programm läuft einmal durch, und ihr geht danach Schritt für Schritt hindurch – welche Zeile als Nächstes dran ist, was in den Variablen steht und was die Shell bis dahin zeigt.", onclick: async () => {
    await speichern();
    // ohne Dialog (24.10.): Der Debugger haelt an jedem input() an, getippt wird in seiner Shell
    aufzeichnung(ich, Object.assign({}, opts, { eingaben: () => [] }));
  } }, zeichen(KAEFER_ZEICHEN, "z-kaefer"), "Debugger"));
  for (const k of opts.zusatzKnoepfe || []) werkzeuge.append(k(ich));
  const schriftKnoepfe = (art, name) => h("span", { class: "schrift", "data-art": art }, h("span", { class: "schrift-name" }, name),
    h("button", { class: "ruhig", title: name + ": Schrift kleiner", onclick: () => schriftAendern(-1, art) }, "A−"),
    h("button", { class: "ruhig", title: name + ": Schrift größer", onclick: () => schriftAendern(1, art) }, "A+"));
  werkzeuge.append(schriftKnoepfe("code", "Code"), schriftKnoepfe("shell", "Shell"), status);
  ich.laden = laden; ich.speichern = speichern; ich.ausfuehren = ausfuehren; ich.konsoleLeeren = konsoleLeeren;
  // Der Code-Film startet den Debugger selbst (+ debugger, 24.10.): ohne Dialog -- Eingaben aus dem Vorschlag des Themas
  ich.debuggerStarten = async (vorgabe) => {
    if (ich._dbg && ich._dbg.offen()) return ich._dbg;
    await speichern();
    const eingaben = vorgabe || (/\binput\s*\(/.test(ich.text()) ? (opts.eingabenVorschlag || []) : []);
    return aufzeichnung(ich, Object.assign({}, opts, { eingaben: () => eingaben }));
  };
  ich.debuggerZu = () => { if (ich._dbg && ich._dbg.offen()) ich._dbg.schliessen(); };
  ich.laeuft = () => !!lauf; ich.stopp = stopp;
  ich.setzen = t => { if (ed) { ed.setzen(t); } };
  ich.standZeigen = (neu, alt) => ed ? ed.standZeigen(neu, alt) : null;
  ich.standAnimieren = (neu, alt, opt) => ed ? ed.standAnimieren(neu, alt, opt || {}) : null;
  ich.laeuftAnimation = () => !!(ed && ed.laeuftAnimation());
  ich.hatWeg = (neu, alt) => !!(ed && ed.hatWeg(neu, alt));
  ich.wegMarkieren = (neu, alt) => ed ? ed.wegMarkieren(neu, alt) : null;
  ich.kopieMarkieren = (neu, alt) => ed ? ed.kopieMarkieren(neu, alt) : null;
  ich.ladenDann = f => { if (ed) f(); else nachLaden.push(f); };
  ich.animationFertig = () => { if (ed) ed.animationFertig(); };
  ich.text = () => ed ? ed.text() : "";
  return ich;
}


// Ein Trenner über einem Element (Shell, Regie): ziehen ändert seine Höhe, der Browser merkt sie sich,
// Doppelklick setzt zurück (Lehrer 14.10.: „per Ziehen einstellen, wie viel man vom Code bzw. von der Shell sieht").
function hoehenTrenner(ziel, schluessel, beschriftung) {
  const t = h("div", { class: "trenner-quer", title: "Ziehen: Höhe ändern · Doppelklick: zurücksetzen" }, beschriftung ? h("span", {}, beschriftung) : null);
  const name = "lernraum.hoehe." + schluessel;
  let gemerkt = null; try { gemerkt = localStorage.getItem(name); } catch (e) {}
  if (gemerkt) { ziel.style.height = gemerkt; ziel.style.flex = "0 0 auto"; ziel.style.maxHeight = "none"; }
  t.addEventListener("pointerdown", ev => {
    ev.preventDefault(); t.classList.add("aktiv"); t.setPointerCapture(ev.pointerId);
    const unten = ziel.getBoundingClientRect().bottom;
    const rahmen = (ziel.parentElement || document.body).getBoundingClientRect();
    const ziehen = e => { const px = Math.max(48, Math.min(rahmen.height - 120, unten - e.clientY)); ziel.style.height = px + "px"; ziel.style.flex = "0 0 auto"; ziel.style.maxHeight = "none"; };
    const ende = () => { t.classList.remove("aktiv"); t.removeEventListener("pointermove", ziehen); t.removeEventListener("pointerup", ende); try { localStorage.setItem(name, ziel.style.height); } catch (e) {} };
    t.addEventListener("pointermove", ziehen); t.addEventListener("pointerup", ende);
  });
  t.addEventListener("dblclick", () => { ziel.style.height = ""; ziel.style.flex = ""; ziel.style.maxHeight = ""; try { localStorage.removeItem(name); } catch (e) {} });
  return t;
}

// Ein senkrechter Trenner zwischen zwei Spalten eines Rasters (24.10.: Vortrag Editor | Text, Debugger Code | Variablen):
// ziehen setzt die Breite der linken Spalte als CSS-Variable am Raster, der Browser merkt sie sich; Doppelklick: zurueck.
function spaltenTrenner(raster, schluessel, variable) {
  const t = h("div", { class: "trenner spalte", title: "Ziehen: Breite ändern · Doppelklick: zurücksetzen" });
  const name = "lernraum.teilung." + schluessel;
  let gemerkt = null; try { gemerkt = localStorage.getItem(name); } catch (e) {}
  if (gemerkt) raster.style.setProperty(variable, gemerkt);
  t.addEventListener("pointerdown", ev => {
    ev.preventDefault(); t.classList.add("aktiv"); t.setPointerCapture(ev.pointerId);
    const links = raster.getBoundingClientRect().left;
    const ziehen = e => { const px = Math.max(200, Math.min(raster.clientWidth - 220, e.clientX - links)); raster.style.setProperty(variable, px + "px"); };
    const ende = () => { t.classList.remove("aktiv"); t.removeEventListener("pointermove", ziehen); t.removeEventListener("pointerup", ende); try { localStorage.setItem(name, raster.style.getPropertyValue(variable)); } catch (e) {} };
    t.addEventListener("pointermove", ziehen); t.addEventListener("pointerup", ende);
  });
  t.addEventListener("dblclick", () => { raster.style.removeProperty(variable); try { localStorage.removeItem(name); } catch (e) {} });
  return t;
}
// Ein Griff unter einem Bereich: ziehen setzt dessen Hoehe als CSS-Variable (Debugger in der Uebung, 24.10.)
function hoehenGriff(el, schluessel, variable, beschriftung) {
  const t = h("div", { class: "trenner-quer", title: "Ziehen: Höhe ändern · Doppelklick: zurücksetzen" }, beschriftung ? h("span", {}, beschriftung) : null);
  const name = "lernraum.hoehe." + schluessel;
  let gemerkt = null; try { gemerkt = localStorage.getItem(name); } catch (e) {}
  if (gemerkt) el.style.setProperty(variable, gemerkt);
  t.addEventListener("pointerdown", ev => {
    ev.preventDefault(); t.classList.add("aktiv"); t.setPointerCapture(ev.pointerId);
    const oben = el.getBoundingClientRect().top;
    const ziehen = e => { el.style.setProperty(variable, Math.max(120, e.clientY - oben - 40) + "px"); };
    const ende = () => { t.classList.remove("aktiv"); t.removeEventListener("pointermove", ziehen); t.removeEventListener("pointerup", ende); try { localStorage.setItem(name, el.style.getPropertyValue(variable)); } catch (e) {} };
    t.addEventListener("pointermove", ziehen); t.addEventListener("pointerup", ende);
  });
  t.addEventListener("dblclick", () => { el.style.removeProperty(variable); try { localStorage.removeItem(name); } catch (e) {} });
  return t;
}

// Kopieren-Knopf an jedem Codeblock (Lehrer 14.10.: per Copy-Paste einfügen statt abtippen).
function kopierKnoepfe(el) {
  el.querySelectorAll("pre.code").forEach(pre => {
    if (pre.parentElement.classList.contains("code-huelle") || pre.closest(".pruef, .stufen")) return;   // Frage und Stufen-Beispiel: nichts zu kopieren (Stufe 3 schreibt man selbst)
    const huelle = h("div", { class: "code-huelle" }); pre.replaceWith(huelle); huelle.append(pre);
    const knopf = h("button", { class: "kopieren ruhig", title: "Code kopieren – dann im Editor mit Strg+V (Mac: ⌘+V) einfügen", onclick: async ev => {
      ev.stopPropagation();
      const text = pre.textContent;
      try { await navigator.clipboard.writeText(text); }
      catch (e) { const ta = h("textarea", {}); ta.value = text; document.body.append(ta); ta.select(); try { document.execCommand("copy"); } catch (e2) {} ta.remove(); }
      knopf.textContent = "✓ kopiert"; setTimeout(() => { knopf.textContent = "Kopieren"; }, 1500);
    } }, "Kopieren");
    huelle.append(knopf);
  });
}
