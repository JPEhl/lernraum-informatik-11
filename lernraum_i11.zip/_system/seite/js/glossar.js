/* Lernraum · glossar.js -- Glossar (Seite und Begriffe im Text), Bereich „Üben und Nachschlagen“.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Glossar (Galerie 15.10., Rang 6) ───────────────────────────────────────────────
// Entsteht in bauen.py aus den ::: definition-Blöcken aller Themen, ohne Zusatztext:
// Begriff · Definition · eingeführt · erklärt · vorkommend. Wohnt im Bereich „Üben und
// Nachschlagen“ der Kursseite (Regel 2: kein neuer Knopf in der Kopfleiste) und erscheint
// erst, wenn es Begriffe gibt (Regel 4).
function glossar() { return Z.inhalt.glossar || []; }
// Was die Klasse schon sehen darf (Film der Schuelerfassung 25.10., Regel 16.10. „was erst später kommt, verwirrt
// nur“): Begriffe bis zum spätesten begonnenen Thema -- oder bis zum Thema, das gerade offen ist. Das Pult zeigt alles.
function glossarRang(pfad) {
  const alle = []; for (const r of (Z.inhalt.reihen || [])) for (const t of r.themen) alle.push(r.kennung + "/" + t.kennung);
  return alle.indexOf(pfad);
}
function glossarGrenze() {
  if (Z.lehrer) return Infinity;
  let g = -1;
  for (const r of (Z.inhalt.reihen || [])) for (const t of r.themen) { const p = r.kennung + "/" + t.kennung; if (themaBegonnen(p)) g = Math.max(g, glossarRang(p)); }
  const m = location.hash.match(/\/t\/([^/]+)\/([^/]+)/);
  if (m) g = Math.max(g, glossarRang(decodeURIComponent(m[1]) + "/" + decodeURIComponent(m[2])));
  return g;
}
function glossarSichtbar(e, grenze) { return glossarRang(e.eingefuehrt.thema) <= grenze; }
function glossarOrtAdresse(o) { return adr("t/" + o.thema + "/" + o.ort); }
function glossarOrtLink(o, mitThema) { return h("a", { href: glossarOrtAdresse(o) }, (mitThema ? "Thema " + o.nr + " · " : "") + o.label); }
function glossarId(begriff) { return "g-" + begriff.toLowerCase().replace(/[^a-z0-9äöüß]+/g, "-"); }

function glossarSeite(haupt, ziel) {
  kopfZeichnen([["Glossar", adr("glossar")]]);
  const grenze = glossarGrenze(), alleG = glossar(), G = alleG.filter(e => glossarSichtbar(e, grenze));
  const s = h("div", { class: "seite glossar" }, h("h1", {}, "Glossar"),
    h("p", { class: "unter" }, "Alle Begriffe aus den Definitionen, mit Fundstellen"));
  if (!G.length) { s.append(h("p", { class: "leer" }, "Noch keine Begriffe. Sie kommen, sobald du in einem Thema arbeitest.")); haupt.append(s); return; }
  // Alphabet: Buchstaben mit Begriff springen, die anderen bleiben leise
  const erste = new Set(G.map(e => e.begriff[0].toUpperCase()));
  const abc = h("div", { class: "g-abc" });
  for (const b of "ABCDEFGHIJKLMNOPQRSTUVWXYZ") {
    const e = G.find(x => x.begriff[0].toUpperCase() === b);
    abc.append(erste.has(b) ? h("a", { href: "#", onclick: ev => { ev.preventDefault(); document.getElementById(glossarId(e.begriff)).scrollIntoView({ block: "start", behavior: "smooth" }); } }, b) : h("span", {}, b));
  }
  const dl = h("dl", { class: "g-liste" });
  for (const e of G) {
    const wo = h("div", { class: "wo" }, "eingeführt: ", glossarOrtLink(e.eingefuehrt, true));
    if (e.erklaert) wo.append(" · erklärt: ", glossarOrtLink(e.erklaert, e.erklaert.nr !== e.eingefuehrt.nr));
    const vk = e.vorkommend.filter(v => glossarRang(v.thema) <= grenze);
    dl.append(h("dt", { id: glossarId(e.begriff) }, e.begriff), h("dd", {}, h("div", { html: e.html }), wo, vk.length ? glossarFundstellen(Object.assign({}, e, { vorkommend: vk })) : null));
  }
  s.append(h("div", { class: "g-karte" }, abc, dl));
  const spaeter = alleG.length - G.length;
  if (spaeter) s.append(h("p", { class: "leer g-spaeter" }, spaeter + (spaeter === 1 ? " weiterer Begriff kommt" : " weitere Begriffe kommen") + " mit den nächsten Themen."));
  haupt.append(s);
  if (ziel) { const z = document.getElementById(glossarId(ziel)); history.replaceState(null, "", adr("glossar")); if (z) requestAnimationFrame(() => { z.scrollIntoView({ block: "start" }); z.classList.add("puls"); }); }
}

// Wo ein Begriff sonst vorkommt: zugeklappt (Lehrer 15.10.: „etwas kürzer, oder aufklappbar, wenn
// man mehr Stellen braucht“), aufgeklappt je Thema eine Zeile -- Vortrag 2 · 3 · 5 | Erklärung … | Übung 1 · 2.
function glossarFundstellen(e) {
  const n = e.vorkommend.reduce((s, v) => s + v.orte.length, 0);
  const themen = e.vorkommend.map(v => v.nr);
  const box = h("details", { class: "g-mehr" }, h("summary", {}, "vorkommend: " + n + (n === 1 ? " Stelle" : " Stellen") + " in Thema " + (themen.length > 1 ? themen.slice(0, -1).join(", ") + " und " + themen.at(-1) : themen[0])));
  for (const v of e.vorkommend) {
    const zeile = h("div", { class: "g-thema" }, h("b", {}, "Thema " + v.nr + " · " + v.titel));
    for (const [art, name] of [["vortrag", "Vortrag"], ["erklaerung", "Erklärung"], ["uebung", "Übung"]]) {
      const orte = v.orte.filter(o => o.ort.split("/")[0] === art); if (!orte.length) continue;
      const teil = h("span", { class: "g-art" }, name + " ");
      orte.forEach((o, i) => teil.append(i ? " · " : "", h("a", { href: glossarOrtAdresse(Object.assign({ thema: v.thema }, o)), title: o.label }, art === "erklaerung" ? o.label.replace(/^Erklärung · /, "") : o.ort.split("/")[1])));
      zeile.append(teil);
    }
    box.append(zeile);
  }
  return box;
}

// Im Text: das erste Vorkommen eines Begriffs je Abschnitt (Erklärung: je Überschrift; Übung: je
// Aufgabe) gepunktet unterstrichen; Zeigen öffnet die Definition. Eigener Tag glossar-wort --
// er verschiebt keine nth-of-type-Anker. Nicht in Code, Überschriften, Kästen, Fragen, Knöpfen.
const GLOSSAR_NICHT = "pre, code, h1, h2, h3, h4, .definition, .pruef, .stufen, .merke, a, button, input, textarea, glossar-wort";
function glossarMarkieren(root) {
  const grenze = glossarGrenze(), G = glossar().filter(e => glossarSichtbar(e, grenze)); if (!G.length || !root) return;
  const form = new Map(); G.forEach(e => e.formen.forEach(f => form.set(f, e)));
  const esc = t => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const muster = new RegExp("(?<![\\p{L}\\p{N}_])(?:" + [...form.keys()].sort((a, b) => b.length - a.length).map(esc).join("|") + ")(?![\\p{L}\\p{N}_])", "gu");
  const knoten = []; let abschnitt = 0;
  const gang = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, { acceptNode: n => {
    if (n.nodeType === 1) { if (n.tagName === "H3") abschnitt++; return n.matches(GLOSSAR_NICHT) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_SKIP; }
    return NodeFilter.FILTER_ACCEPT; } });
  for (let n = gang.nextNode(); n; n = gang.nextNode()) knoten.push([n, abschnitt]);
  const gesehen = new Set();
  for (const [n, ab] of knoten) {
    const text = n.nodeValue; muster.lastIndex = 0; let m, pos = 0; const teile = [];
    while ((m = muster.exec(text))) {
      const e = form.get(m[0]); const k = ab + "|" + e.begriff;
      if (gesehen.has(k)) continue;
      gesehen.add(k);
      teile.push(text.slice(pos, m.index), glossarWort(m[0], e)); pos = m.index + m[0].length;
    }
    if (!teile.length) continue;
    teile.push(text.slice(pos));
    n.replaceWith(...teile.filter(t => t !== ""));
  }
}
function glossarWort(text, e) {
  const w = document.createElement("glossar-wort");
  w.textContent = text; w.tabIndex = 0; w.dataset.begriff = e.begriff;
  w.addEventListener("mouseenter", () => glossarTipp(w, e)); w.addEventListener("focus", () => glossarTipp(w, e));
  w.addEventListener("mouseleave", () => glossarTippWeg(400)); w.addEventListener("blur", () => glossarTippWeg(400));
  return w;
}
const GT = { el: null, takt: null };
function glossarTipp(w, e) {
  clearTimeout(GT.takt);
  if (!GT.el) {
    GT.el = h("div", { class: "glossar-tipp", role: "tooltip" });
    GT.el.addEventListener("mouseenter", () => clearTimeout(GT.takt)); GT.el.addEventListener("mouseleave", () => glossarTippWeg(200));
    document.body.append(GT.el);
  }
  GT.el.textContent = "";
  GT.el.append(h("div", { class: "def-kopf" }, h("span", { class: "def-chip" }, "Definition"), " ", e.begriff), h("div", { html: e.html }),
    h("a", { href: adr("glossar/" + encodeURIComponent(e.begriff)) }, "Im Glossar ›"));
  GT.el.hidden = false;
  const r = w.getBoundingClientRect(), b = GT.el.getBoundingClientRect();
  GT.el.style.left = Math.max(8, Math.min(innerWidth - b.width - 8, r.left)) + "px";
  GT.el.style.top = (r.bottom + b.height + 12 > innerHeight ? r.top - b.height - 8 : r.bottom + 8) + "px";
}
function glossarTippWeg(ms) { clearTimeout(GT.takt); GT.takt = setTimeout(() => { if (GT.el) GT.el.hidden = true; }, ms); }
window.addEventListener("hashchange", () => { if (GT.el) GT.el.hidden = true; });

// ─── Üben und Nachschlagen (Kursseite) ──────────────────────────────────────────────
// Der eine Ort für alles, was die Klasse zum Wiederholen braucht (Bauliste, Regel 2): Glossar und
// Fehlerbuch (B2, fehlerbuch.js); Lernkarten, „Ich kann …“ kommen dazu, sobald sie Inhalt haben.
function nachschlagenBereich() {
  const karten = [];
  const grenze = glossarGrenze(), G = glossar().filter(e => glossarSichtbar(e, grenze));
  if (G.length) karten.push(h("a", { class: "nachschlagkarte", href: adr("glossar") }, h("div", { class: "nr" }, "Glossar"),
    h("div", { class: "titel" }, G.length + (G.length === 1 ? " Begriff" : " Begriffe")), h("div", {}, G.map(e => e.begriff).join(" · "))));
  const fb = fehlerbuchKarte(); if (fb) karten.push(fb);
  const ik = ichKannKarte(); if (ik) karten.push(ik);
  const lk = lernkartenKarte(); if (lk) karten.push(lk);
  if (!karten.length) return null;
  return h("section", { class: "nachschlagen nur-ohne-beamer" }, h("h2", {}, "Üben und Nachschlagen"), h("div", { class: "nachschlagliste" }, karten));
}
