/* Lernraum · uebung.js -- Übung, Trenner der Übung, Werkstatt, Lösung.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Übung ───────────────────────────────────────────────────────────────────────────
// Haken bei Papieraufgaben: Zeichen · kurz (Kopfzeile) · Klasse · lang (Knopf)
const HAKEN = [["✓", "stimmt", "stimmt", "stimmt"], ["✎", "Fehler gefunden", "fehler", "Fehler gefunden und verstanden"], ["?", "Lösung unklar", "frage", "verstehe die Lösung nicht"]];
// Sterne (Lehrer 16.10.): Die Rechnung macht der Server (dieselbe wie in der Übersicht), die Seite
// zeigt sie. Z.sterne[thema] = {aufgaben: {nr: {sterne, max}}, summe, max, mindest, ohne_stern}.
function sterneVon(a) { const t = a.kennung.replace(/\/[^/]+$/, ""); return (((Z.sterne || {})[t] || {}).aufgaben || {})[a.nr]; }
function sterneZeichen(n, max) { return "★".repeat(n) + "☆".repeat(Math.max(0, max - n)); }
function aufgabeFertig(a) {
  const s = aufgabenStand(a.kennung);
  if ((a.sterne || []).length && sterneVon(a)) return sterneVon(a).sterne >= 1;
  // Auf der Seite (Puzzle, Vorhersage, Prüffrage, Fall): fertig = alles darin gelöst
  if (a.art === "seite") return puzzleGeloest(a) && vorhersageGeloest(a) && fragenGeloest(a) && planGeloest(a) && fallStand(a).every((ak, i) => (ak.gefunden || []).length === (a._fallZahl || [])[i]);
  return a.art === "papier" ? !!s.haken : !!(s.selbstcheck && s.selbstcheck.von && s.selbstcheck.passt === s.selbstcheck.von);
}
// Was die Klasse an der Aufgabe schon getan hat (Lehrerwahl 17.10., Fassung B): offen · angefangen ·
// geschafft (mindestens ★, sonst fertig) · alle (die höchste Stufe geschafft). Nur Schülerfassung.
function aufgabeZustand(a) {
  const sv = sterneVon(a), s = aufgabenStand(a.kennung), t = a.kennung.replace(/\/[^/]+$/, "");
  if (sv) { if (sv.max && sv.sterne >= sv.max) return "alle"; if (sv.sterne >= 1) return "ok"; }
  else if (aufgabeFertig(a)) return "ok";
  const probiert = (liste, quelle) => (liste || []).some(n => ((Z.stand[quelle] || {})[t + "/" + n] || {}).versuche);
  const an = (sv && (sv.versucht || []).length) || s.haken || (s.selbstcheck && s.selbstcheck.passt) || (s.hilfen || []).length
    || probiert(a.vorhersage, "vorhersagen") || probiert(a.fragen, "fragen") || probiert(a.parsons, "puzzles") || probiert(a.fall, "faelle")
    || (a.plan || []).some(n => !!(Z.stand.plaene || {})[t + "/" + n]);     // ein gespeicherter Plan ist angefangen
  return an ? "halb" : "offen";
}
const ZUSTAND = { alle: ["★", "alle Stufen geschafft"], ok: ["✓", "geschafft"], halb: ["◐", "angefangen"], offen: ["", "noch offen"] };
// Eine Stelle in einer zugeklappten Aufgabe: der Anker bleibt, nur sieht man ihn nicht. Zeichen
// (Nadeln, Anmerkungen, Haken) sitzen dann an der Kopfzeile, nebeneinander; „an der Stelle
// zeigen“ klappt die Aufgabe auf.
function zugeklappteAufgabe(el) { const b = el && el.closest(".aufgabe.zu"); return b && !el.closest(".ak") ? b : null; }
// Auch die Erklärung verbirgt etwas (Block B): die Stufen eines Beispiels, die nicht gewählt sind,
// und die Begründung einer Wahl, die noch niemand angeklickt hat. Zeichen dort sitzen am Knopf der
// Stufe bzw. an der Legende der Frage; „an der Stelle zeigen“ macht die Stelle sichtbar.
function verborgenerOrt(el) {
  const teil = el && el.closest(".stufen > [hidden]");
  if (teil && teil.parentElement._stufeKnopf) return { griff: teil.parentElement._stufeKnopf(teil), zeigen: () => teil.parentElement._stufeZeigen(teil) };
  // Stern-Stufe einer Aufgabe, die gerade nicht gewählt ist (16.10.): Zeichen sitzen am Reiter der Stufe
  const st = el && el.closest("section.stern-stufe[hidden]");
  if (st && st._reiter) return { griff: st._reiter, zeigen: () => st._waehlen() };
  const w = el && el.closest(".pruef > .pf-warum[hidden]");
  if (w) return { griff: w.parentElement.querySelector("legend"), zeigen: () => { w.hidden = false; } };
  return null;
}
function stelleAufklappen(el) { const b = zugeklappteAufgabe(el); if (b && b._aufklappen) b._aufklappen(); const v = verborgenerOrt(el); if (v) v.zeigen(); }
function kopfOrt(b, i) { const r = b.getBoundingClientRect(), k = $(".ak", b).getBoundingClientRect(); return [r.left + 3 + (i || 0) * 16, k.top + k.height / 2]; }   // linker Rand, auf Höhe der Kopfzeile -- verdeckt den Titel nicht
function zeichenOrt(el, dx, dy, belegt) {
  const b = zugeklappteAufgabe(el);
  if (!b) {
    const v = verborgenerOrt(el);
    if (v) { const g = v.griff.getBoundingClientRect(), i = belegt ? (belegt.get(v.griff) || 0) : 0; if (belegt) belegt.set(v.griff, i + 1); return [g.left + 3 + i * 16, g.top + g.height / 2]; }
    const r = el.getBoundingClientRect(); return [r.left + r.width * dx, r.top + r.height * dy];
  }
  const i = belegt ? (belegt.get(b) || 0) : 0;
  if (belegt) belegt.set(b, i + 1);
  return kopfOrt(b, i);
}
// PRIMM (Galerie Rang 13, Lehrer 17.10.: Fassung C „nur im Pult“): je Aufgabe ihre Etappe als Etikett
// im Kopf, oben ein Kasten mit allen Etappen des Themas -- Lücken fallen beim Planen auf. Die Klasse
// sieht nichts davon (die Schülerfassung trägt das Attribut gar nicht), der Beamer auch nicht.
// Eigene Tags (small im Kopf, details oben): die nth-of-type-Anker der Nadeln bleiben.
const PRIMM_ETAPPEN = [["vorhersagen", "P"], ["ausführen", "R"], ["untersuchen", "I"], ["ändern", "M"], ["selbst machen", "M"]];
function primmMarke(etappen) {
  if (!etappen || !etappen.length) return null;
  const m = h("small", { class: "primm nur-ohne-beamer", title: "PRIMM -- nur im Pult" });
  etappen.forEach((e, i) => m.append(...(i ? [" · "] : []), h("b", {}, (PRIMM_ETAPPEN.find(x => x[0] === e) || [e, "?"])[1]), e));
  return m;
}
// „Wie im Abitur“ (Lehrer 17.10., gebaut mit Thema 6): die Aufgabe ist wie eine Abituraufgabe
// geschnitten -- Operator und Bewertungseinheiten. Die Klasse sieht es (anders als PRIMM): Der Zuschnitt
// soll wiedererkannt werden. Eigener Tag (small), damit die nth-of-type-Anker der Nadeln bleiben.
function abiturMarke(abi) {
  if (!abi) return null;
  return h("small", { class: "abitur", title: "So ist auch eine Abituraufgabe geschnitten: Operator „" + abi.operator + "“, " + abi.be + " Bewertungseinheiten" }, "wie im Abitur · " + abi.be + " BE");
}
function primmUebersicht(T) {
  const A = T.thema.uebung.aufgaben;
  if (!A.some(a => (a.primm || []).length)) return null;
  const wo = e => A.filter(a => (a.primm || []).includes(e));
  const nennen = l => [l.filter(a => a.teil !== "kuer"), l.filter(a => a.teil === "kuer")].map((x, i) => x.length ? (i ? "Kür " : "Aufgabe ") + x.map(a => a.nr).join(", ") : "").filter(Boolean).join(", ");
  const vortrag = (T.thema.vortrag || []).filter(s => s.art === "code" || s.art === "html").map(s => s.nr);
  // Ausführen verlangt die Übung nicht (wie K3): Code läuft im Vortrag, jede Vorhersage danach
  const fehlt = PRIMM_ETAPPEN.map(x => x[0]).filter(e => e !== "ausführen" && !wo(e).length);
  const zeilen = PRIMM_ETAPPEN.map(([e, b]) => {
    let wer = nennen(wo(e));
    if (e === "ausführen" && vortrag.length) wer += (wer ? " · " : "") + "im Vortrag (Schritt " + vortrag.join(", ") + ")";
    return h("tr", { class: wer ? "" : "fehlt" }, h("td", {}, h("b", {}, b), " " + e), h("td", {}, wer || "fehlt"));
  });
  const merk = "lernraum.primm.zu";
  let zu = false; try { zu = localStorage.getItem(merk) === "1"; } catch (e) {}
  const box = h("details", { class: "primm-bilanz nur-ohne-beamer" + (fehlt.length ? " luecke" : "") },
    h("summary", {}, "PRIMM in diesem Thema", h("span", { class: "pb-nur" }, " · nur im Pult"), fehlt.length ? h("span", { class: "pb-fehlt" }, " · fehlt: " + fehlt.join(", ")) : null),
    h("table", {}, h("tbody", {}, ...zeilen)));
  box.open = !zu || !!fehlt.length;
  // Mit Lücke immer offen -- dann merkt sie sich nichts (sonst überschriebe das toggle beim Öffnen die Wahl für die anderen Themen)
  if (!fehlt.length) box.addEventListener("toggle", () => { try { localStorage.setItem(merk, box.open ? "0" : "1"); } catch (e) {} });
  return box;
}
function uebungSeite(haupt, T, extra) {
  const U = T.thema.uebung;
  const wrap = h("div", { class: "uebung" });
  const links = h("div", { class: "aufgaben" });
  const rechts = h("div", { class: "arbeit" });
  wrap.append(links, trenner(wrap), rechts); haupt.append(wrap);
  const frei = Z.lehrer || !!(Z.stand.kennwoerter || {})[T.pfad];
  links.append(h("div", { html: U.einleitung }));
  // Die Sternleiste (16.10.): nur für die Person (und dich) -- nie am Beamer
  // eigener Tag (aside), kein div: sonst verrutschen die nth-of-type-Anker der Aufgaben (Lehre aus Block A)
  const sternLeiste = h("aside", { class: "sterne-leiste nur-ohne-beamer" }); sternLeiste.hidden = true;
  links.append(sternLeiste);
  if (Z.lehrer) { const pb = primmUebersicht(T); if (pb) links.append(pb); }
  let sternUhr = null;
  function sterneLaden() {
    // Im Pult keine eigenen Sterne (Lehrer 16.10.): dort zählt, wo der Unterricht steht (Kursseite),
    // nicht, was du beim Vorbereiten ausprobiert hast. Die Sterne der Klasse zeigt die Übersicht.
    if (Z.lehrer) return;
    clearTimeout(sternUhr);
    sternUhr = setTimeout(async () => {
      let r; try { r = await api("sterne", { thema: T.pfad }); } catch (e) { return; }
      const s = r.sterne[T.pfad];
      (Z.sterne = Z.sterne || {})[T.pfad] = s;
      sternLeiste.hidden = !s; sternLeiste.textContent = "";
      if (s) {
        const pflicht = U.aufgaben.filter(a => (a.sterne || []).length && a.teil === "pflicht").length;
        sternLeiste.classList.toggle("geschafft", s.geschafft);
        sternLeiste.append(h("span", { class: "sl-zahl" }, "★ " + s.summe), h("span", {}, " von " + s.max + (s.mindest ? " · Ziel " + s.mindest : "")),
          h("span", { class: "sl-teil" }, " · jede Pflichtaufgabe mit ★: " + (pflicht - s.ohne_stern.length) + " von " + pflicht),
          ...(s.geschafft ? [h("span", { class: "sl-ok" }, " · geschafft")] : []));   // append(null) schrieb „null“ (16.10.)
      }
      U.aufgaben.forEach(a => { if (a._standZeigen) a._standZeigen(); });
    }, 150);
  }
  const pfad = "themen/" + T.pfad + "/" + T.thema.arbeitsdatei;
  const checkPanel = h("div", { class: "selbstcheck" }); checkPanel.hidden = true;

  // Aufgaben zuklappbar (Galerie 15.10., Rang 1): offen ist die, an der man sitzt; die anderen
  // zeigen nur ihre Kopfzeile mit dem Stand. Zu heißt eine Klasse am Kasten -- die Struktur
  // bleibt gleich, damit Nadeln, Anmerkungen und Werkbuch-Haken ihre Anker behalten.
  const boxen = [];
  const merkSchluessel = "lernraum.uebung.offen." + Z.kurs + "/" + T.pfad;
  function aufklappen(kennung, merken) {
    for (const [k, b, kopf] of boxen) { b.classList.toggle("zu", k !== kennung); kopf.setAttribute("aria-expanded", String(k === kennung)); }
    if (merken) try { localStorage.setItem(merkSchluessel, kennung || "-"); } catch (e) {}
    rechtsZeigen(kennung);
  }
  // Aufgabenart „Plan“ (19.10., Fassung B): Ist eine Aufgabe mit Plan offen, steht rechts ihr Plan statt der
  // Arbeitsdatei (die sie nicht braucht); jede andere Aufgabe bringt die Arbeitsdatei zurueck. Je Aufgabe ein
  // Feld, einmal gebaut (der Plan bleibt beim Hin- und Herklappen stehen).
  // Seit T10 (21.10.): Hat die Aufgabe Stufen, steht der Plan nur bei der Stufe, in der er steht -- in
  // „Wer hält den Rekord?“ ist ★ der Plan, ★★ der Code in der Arbeitsdatei (a._planSichtbar).
  const planFelder = {};
  let offenKennung = "";
  function rechtsZeigen(kennung) {
    offenKennung = kennung;
    if (!rechts.childNodes.length) return;            // beim ersten Aufklappen steht der Editor noch nicht
    const a = U.aufgaben.find(x => x.kennung === kennung && (x.plan || []).length && (!x._planSichtbar || x._planSichtbar()));
    Object.values(planFelder).forEach(f => { f.hidden = true; f._sichern(); });
    rechts.classList.toggle("plan-an", !!a);
    if (!a) return;
    if (!planFelder[kennung]) { planFelder[kennung] = planFeld(T, a, () => { if (a._standZeigen) a._standZeigen(); sterneLaden(); }); rechts.append(planFelder[kennung]); }
    planFelder[kennung].hidden = false;
  }
  let freiGetrennt = false;
  for (const a of U.aufgaben) {
    // Pflicht und freiwillig getrennt (Lehrerwahl 17.10., Fassung B): Pflicht mit Balken links, vor der ersten
    // freiwilligen Aufgabe (Vorrat oder Kuer) ein Strich „Ab hier freiwillig“ -- eigener Tag, damit die
    // Nadel-Anker (nth-of-type der div) bleiben, wo sie waren
    if (a.teil !== "pflicht" && !freiGetrennt && U.aufgaben.some(x => x.teil === "pflicht")) { links.append(h("ab-hier-frei", {}, "Ab hier freiwillig")); freiGetrennt = true; }
    // Eine eingeschobene Aufgabe (2a, B2) steht in einem eigenen Tag: die Anker der Aufgaben dahinter bleiben
    const box = h(a.einschub ? "section" : "div", { class: "aufgabe " + a.teil + " " + a.art });
    const standEl = h("span", { class: "stand" });
    const marke = Z.lehrer ? null : h("stand-marke", {});
    const kopf = h("div", { class: "ak", role: "button", tabindex: "0", title: "Auf- und zuklappen" }, marke, h("span", { class: "nr" }, "Aufgabe " + a.nr), a.titel ? h("span", { class: "titel" }, a.titel) : null, h("span", { class: "teil" }, a.teil === "kuer" ? "Kür" : a.teil), a.art === "papier" ? h("span", { class: "teil papier" }, "Papier") : null, abiturMarke(a.abitur), sozialMarke(a.sozialform), primmMarke(a.primm), standEl);
    const umschalten = () => aufklappen(box.classList.contains("zu") ? a.kennung : "", true);
    kopf.addEventListener("click", umschalten);
    kopf.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); umschalten(); } });
    box._aufklappen = () => aufklappen(a.kennung, true);
    boxen.push([a.kennung, box, kopf]);
    box.append(kopf);
    const html = h("div", { html: a.html }); bilderPfad(html, T.pfad); kopierKnoepfe(html); glossarMarkieren(html); box.append(html);
    // Aufgabenarten (B2): Puzzle und Fall -- nach jeder Prüfung den Stand in der Kopfzeile nachziehen
    const nachher = () => { standZeigen(); sterneLaden(); };
    // Stern-Stufen (Lehrer 16.10.): oben eine Leiste ★ · ★★ · ★★★ -- man wählt eine, nur sie ist zu sehen.
    // Die anderen bleiben im DOM (hidden), damit Nadeln und Anmerkungen ihre Anker behalten.
    const stufenEl = [...html.querySelectorAll("section.stern-stufe")];
    if (stufenEl.length) {
      const wahlSchluessel = "lernraum.sternstufe." + Z.kurs + "/" + a.kennung;
      const leiste = h("nav", { class: "stern-wahl", "aria-label": "Stufe wählen" });
      const waehlen = (sec, merken) => {
        stufenEl.forEach(x => { x.hidden = x !== sec; x._reiter.classList.toggle("aktiv", x === sec); x._reiter.setAttribute("aria-pressed", String(x === sec)); });
        if (merken) try { localStorage.setItem(wahlSchluessel, sec.dataset.stufe); } catch (e) {}
        if (offenKennung === a.kennung) rechtsZeigen(a.kennung);     // Plan oder Arbeitsdatei, je nach Stufe
      };
      if ((a.plan || []).length) a._planSichtbar = () => stufenEl.some(x => !x.hidden && x.querySelector("figure.plan"));
      stufenEl.forEach(sec => {
        const n = +sec.dataset.stufe, titel = (sec.querySelector(".stufe-kopf") || {}).textContent || "";
        sec._reiter = h("button", { type: "button", class: "sw-knopf", title: titel.trim(), onclick: () => waehlen(sec, true) }, "★".repeat(n));
        sec._waehlen = () => waehlen(sec, true);
        leiste.append(sec._reiter);
      });
      html.prepend(leiste);
      a._stufenMarkieren = () => {
        const sv = sterneVon(a), geschafft = (sv && sv.stufen) || {}, versucht = (sv && sv.versucht) || [];
        stufenEl.forEach(sec => { const n = sec.dataset.stufe, g = !!geschafft[n], v = !g && versucht.map(String).includes(n);
          sec._reiter.classList.toggle("geschafft", g); sec._reiter.classList.toggle("versucht", v); sec._reiter.classList.toggle("offen", !Z.lehrer && !g && !v); });
      };
      let gemerkt = null; try { gemerkt = localStorage.getItem(wahlSchluessel); } catch (e) {}
      waehlen(stufenEl.find(x => x.dataset.stufe === gemerkt) || stufenEl[0], false);
    }
    html.querySelectorAll("figure.parsons").forEach(f => parsonsPuzzle(f, T, a, nachher));
    html.querySelectorAll("figure.fall").forEach(f => fallAkte(f, T, a, nachher));
    a._fallZahl = [...html.querySelectorAll("figure.fall")].map(f => +f.dataset.fehler);
    // Durchsicht T3 (16.10.): Vorhersage und Prüffrage in der Übung -- digital statt Papier
    html.querySelectorAll("figure.vorhersage").forEach(f => vorhersageTabelle(f, T, a, nachher));
    html.querySelectorAll("fieldset.pruef").forEach(f => { const q = pruefFrage(f, T); q.beimLoesen = nachher; });
    // Hilfen
    const hilfen = h("div", { class: "hilfen" });
    for (let st = 1; st <= a.hilfen; st++) {
      const text = h("div", { class: "hilfe-text" }); text.hidden = true;
      const knopf = h("button", { class: "hilfe-knopf ruhig", onclick: async () => {
        try { const r = await api("hilfe/oeffnen", { kennung: a.kennung, stufe: st, papier: a.art !== "code" });
          if (r.gesperrt) { meldung(r.text); return; }
          if (r.stand) Z.stand = r.stand; text.hidden = false; text.textContent = ""; text.append(h("div", { class: "hs" }, "Hilfe " + st), h("div", { html: r.html })); kopierKnoepfe(text); knopf.hidden = true; standZeigen(); }
        catch (e) { meldung(e.message, "fehler"); }
      } }, "Hilfe " + st + (st === 1 || a.art !== "code" ? "" : " (nach einem Ausführen)"));
      hilfen.append(knopf, text);
      if ((aufgabenStand(a.kennung).hilfen || []).includes(st)) knopf.click();
    }
    box.append(hilfen);
    // Haken bei Papier
    if (a.art === "papier") {
      const hk = h("div", { class: "haken" }, h("span", {}, "Nach dem Nachprüfen: "));
      for (const [sym, , , name] of HAKEN) {
        const b = h("button", { class: aufgabenStand(a.kennung).haken === sym ? "aktiv" : "", title: name, onclick: async () => { const r = await api("stand/aufgabe", { kennung: a.kennung, haken: sym }); Z.stand.aufgaben[a.kennung] = r.aufgabe; hk.querySelectorAll("button").forEach(x => x.classList.toggle("aktiv", x.textContent === sym)); standZeigen(); } }, sym);
        hk.append(b);
      }
      box.append(hk);
    }
    // Lösung inline, wenn frei
    if (frei) {
      const l = h("div", { class: "loesung-inline" }); l.hidden = true;
      box.append(h("button", { class: "ruhig", onclick: async () => { if (!l.hidden) { l.hidden = true; return; } const r = await api("loesung/lesen", { thema: T.pfad }); l.textContent = ""; l.append(h("div", { html: (r.loesung.aufgaben || {})[a.nr] || "<span class=leer>keine Lösung hinterlegt</span>" })); kopierKnoepfe(l); l.hidden = false; } }, "Lösung"), l);
    }
    // Der Stand in der Kopfzeile: Haken (Papier) · Selbstcheck n / m · Hilfe k offen
    function standZeigen() {
      const s = aufgabenStand(a.kennung); const teile = [];
      const sv = sterneVon(a);
      if (a._stufenMarkieren) a._stufenMarkieren();
      if (sv) teile.push(h("span", { class: "st-sterne nur-ohne-beamer" + (sv.sterne ? " gruen" : ""), title: sv.sterne + " von " + sv.max + " Sternen" }, sterneZeichen(sv.sterne, sv.max)));
      if (s.haken) teile.push(h("span", { class: "st-haken " + (HAKEN.find(x => x[0] === s.haken) || [, , ""])[2] }, s.haken + " " + (HAKEN.find(x => x[0] === s.haken) || [, ""])[1]));
      if (s.selbstcheck && s.selbstcheck.von) teile.push(h("span", { class: "st-check" + (s.selbstcheck.passt === s.selbstcheck.von ? " gruen" : "") }, "Selbstcheck " + s.selbstcheck.passt + " / " + s.selbstcheck.von));
      if (a.parsons) { const g = puzzleGeloest(a), p = (Z.stand.puzzles || {})[a.kennung.replace(/\/[^/]+$/, "") + "/" + a.parsons[0]] || {}; if (g || p.versuche) teile.push(h("span", { class: "st-check" + (g ? " gruen" : "") }, g ? "Puzzle gelöst" : "Puzzle: " + p.falsch + " falsch")); }
      if (a.fall) { const ak = fallStand(a)[0], fz = box.querySelector("figure.fall"); if (ak.versuche && fz) teile.push(h("span", { class: "st-check" + ((ak.gefunden || []).length === +fz.dataset.fehler ? " gruen" : "") }, "Akte " + (ak.gefunden || []).length + " / " + fz.dataset.fehler)); }
      // alle Vorhersagen der Aufgabe, nicht nur die erste (17.10.: „Vorhersage 5 / 5“ stand da, obwohl ★★ noch falsch war)
      if (a.vorhersage) { const t = a.kennung.replace(/\/[^/]+$/, ""), vs = a.vorhersage.map(n => (Z.stand.vorhersagen || {})[t + "/" + n] || {}), g = vorhersageGeloest(a);
        if (g || vs.some(v => v.versuche)) teile.push(h("span", { class: "st-check" + (g ? " gruen" : "") }, g ? (vs.length > 1 ? "Vorhersagen gelöst" : "Vorhersage gelöst") : vs.length > 1 ? "Vorhersagen " + vs.filter(v => v.geloest).length + " / " + vs.length + " gelöst" : "Vorhersage: " + (vs[0].richtig || []).filter(x => x).length + " / " + (vs[0].richtig || []).length)); }
      if (a.plan) { const p = (Z.stand.plaene || {})[a.kennung.replace(/\/[^/]+$/, "") + "/" + a.plan[0]] || {};
        if (p.versuche) teile.push(h("span", { class: "st-check" + (p.geloest ? " gruen" : "") }, "Plan " + p.ok + " / " + p.von));
        else if (p.quelle) teile.push(h("span", { class: "st-check" }, "Plan gespeichert")); }
      if (a.fragen) { const n = a.fragen.filter(q => ((Z.stand.fragen || {})[a.kennung.replace(/\/[^/]+$/, "") + "/" + q] || {}).geloest).length; if (n) teile.push(h("span", { class: "st-check" + (n === a.fragen.length ? " gruen" : "") }, "Fragen " + n + " / " + a.fragen.length)); }
      if ((s.hilfen || []).length) teile.push(h("span", {}, "Hilfe " + Math.max(...s.hilfen) + " offen"));
      standEl.textContent = ""; teile.forEach((t, i) => standEl.append(i ? " · " : "", t));
      if (marke) { const z = aufgabeZustand(a); marke.className = z; marke.textContent = ZUSTAND[z][0]; marke.title = ZUSTAND[z][1];
        ["alle", "ok", "halb", "offen"].forEach(x => box.classList.toggle("zustand-" + x, x === z)); }
    }
    standZeigen(); a._standZeigen = standZeigen;
    links.append(box);
  }
  // Welche offen ist, merkt sich der Browser (wie Teilung und Schrift) -- sonst die erste, die noch nicht fertig ist.
  let gemerkt = null; try { gemerkt = localStorage.getItem(merkSchluessel); } catch (e) {}
  if (gemerkt !== null && (gemerkt === "-" || U.aufgaben.some(a => a.kennung === gemerkt))) aufklappen(gemerkt === "-" ? "" : gemerkt, false);
  else aufklappen((["pflicht", "vorrat", "kuer"].map(t => U.aufgaben.find(a => a.teil === t && !aufgabeFertig(a))).find(Boolean) || {}).kennung || "", false);
  // Sprung aus Erklärung oder Glossar („Zur Übung, Aufgabe 3“): diese aufklappen, hinscrollen, dann
  // die Adresse ohne Nummer -- sonst wäre es für Nadeln und Urteile eine eigene Ansicht.
  const ziel = extra && U.aufgaben.find(a => a.nr === extra);
  if (extra) history.replaceState(null, "", adr("t/" + T.pfad + "/uebung"));
  if (ziel) { aufklappen(ziel.kennung, true); const b = boxen.find(x => x[0] === ziel.kennung)[1]; requestAnimationFrame(() => b.scrollIntoView({ block: "start" })); }
  sterneLaden();
  // Mini-Exit
  const me = h("textarea", { placeholder: "Ein Satz …" }); me.value = aufgabenStand(T.pfad + "/miniexit").miniexit || "";
  me.addEventListener("blur", () => api("stand/aufgabe", { kennung: T.pfad + "/miniexit", miniexit: me.value }).catch(() => {}));
  links.append(h("div", { class: "miniexit" }, h("div", { html: T.thema.miniexit || "<p><b>Ein Satz für dich:</b> Was kann ich jetzt, wo hakt es noch?</p>" }), me));
  // Abgabe
  const abgabeInfo = h("div", {});
  const anmZahl = h("span", {});
  api("anmerkungen/lesen", { thema: T.pfad }).then(a => { const n = a.anmerkungen.length; anmZahl.textContent = n ? " Deine " + n + " Anmerkung" + (n === 1 ? "" : "en") + " zu diesem Thema gehen mit." : ""; }).catch(() => {});
  // Mit wem? (Weg 3, 13.10.; seit 17.10. hier statt im Zahnrad -- Lehrer: gefragt, wenn es zaehlt,
  // vorbelegt mit dem letzten; Paare wechseln im Informatikraum). Leer = allein.
  const pa0 = Z.stand.partner || {};
  const pvor = h("input", { value: pa0.vorname || "", placeholder: "Vorname", autocomplete: "off", "aria-label": "Vorname deiner Partner*in" });
  const pnach = h("input", { value: pa0.nachname || "", placeholder: "Nachname", autocomplete: "off", "aria-label": "Nachname deiner Partner*in" });
  const partnerInfo = h("div", {});
  async function partnerSpeichern() {
    const a = await api("stand/partner", { partner_vorname: pvor.value, partner_nachname: pnach.value }); Z.stand = a.stand; partnerZeigen();
  }
  function partnerZeigen() {
    const pa = Z.stand.partner || {}; partnerInfo.textContent = "";
    if (!pa.name) return;
    const info = h("div", {});
    partnerInfo.append(h("p", {}, "Damit ", h("b", {}, pa.name), " selbst abgeben kann, gibst du deinen Stand mit: ",
      h("button", { onclick: async () => { try { const r = await api("stand/partnerzip", {}); info.textContent = ""; info.append(h("p", { class: "ok" }, "Für " + r.fuer + ": ", h("a", { href: "/" + r.datei, download: true }, r.datei.split("/").pop()), " (" + Math.round(r.groesse / 1024) + " KB) – per Stick oder Mail mitgeben; die Datei kommt im Zahnrad unter „Stand hereinnehmen“ hinein.")); } catch (e) { info.textContent = e.message; info.className = "fehler"; } } }, "Stand für " + (pa.vorname || pa.name) + " mitnehmen")), info);
  }
  [pvor, pnach].forEach(f => f.addEventListener("change", () => partnerSpeichern().catch(() => {})));
  partnerZeigen();
  links.append(h("div", { class: "abgabe" }, h("h3", {}, "Abgabe"), h("p", {}, "Eine ZIP mit deinem Programm und deinem Stand zu diesem Thema. Die lädst du im Schulportal hoch – Pflicht ist das Hochladen, nicht das Fertigsein.", anmZahl),
    Z.lehrer ? null : h("div", { class: "partner-wahl" }, h("label", {}, "Mit wem hast du gearbeitet?"), pvor, pnach, h("span", { class: "leer" }, "leer lassen, wenn du allein warst")),
    h("button", { class: "primaer", onclick: async () => { try { if (!Z.lehrer) await partnerSpeichern(); const r = await api("abgabe/erzeugen", { thema: T.pfad }); abgabeInfo.textContent = ""; abgabeInfo.append(h("p", { class: "ok" }, "Erzeugt: ", h("a", { href: "/" + r.datei, download: true }, r.datei.split("/").pop()), " (" + Math.round(r.groesse / 1024 * 10) / 10 + " KB) – liegt in ", h("code", {}, r.pfad))); } catch (e) { abgabeInfo.textContent = e.message; abgabeInfo.className = "fehler"; } } }, "Abgabe erzeugen"), abgabeInfo,
    Z.lehrer ? null : partnerInfo));

  // rechts: Editor
  const checkKnopf = () => h("button", { onclick: selbstcheck }, "✔ Selbstcheck");
  const ed = arbeitsEditor({ pfad, thema: T.pfad, ort: "uebung", zusatzKnoepfe: [checkKnopf], aufzeichnungsZiel: null, eingabenVorschlag: T.thema.eingaben });
  rechts.append(h("div", {}, h("b", {}, T.thema.arbeitsdatei), " – deine Arbeitsdatei. Sie wird beim Ausführen gespeichert."), ed.box, hoehenTrenner(ed.konsole, "shell-uebung", "Shell"), ed.konsole, checkPanel);
  ed.laden();
  rechtsZeigen(offenKennung);
  // Der Selbstcheck lässt sich wieder schließen (Lehrer 14.10.)
  const checkZu = () => h("button", { class: "ruhig zu", title: "Selbstcheck schließen", onclick: () => { checkPanel.hidden = true; } }, "✕");
  async function selbstcheck() {
    await ed.speichern(); checkPanel.hidden = false; checkPanel.textContent = ""; checkPanel.append(h("div", { class: "sk" }, "Selbstcheck läuft …", checkZu()));
    let r; try { r = await api("selbstcheck", { thema: T.pfad }); } catch (e) { checkPanel.textContent = ""; checkPanel.append(h("div", { class: "sk fehler" }, e.message, checkZu())); return; }
    Z.stand = r.stand; const E = r.ergebnis; checkPanel.textContent = "";
    const passt = E.ergebnisse.filter(x => x.stand === "passt").length, spaeter = E.ergebnisse.filter(x => x.stand === "spaeter").length;
    checkPanel.append(h("div", { class: "sk" }, E.titel, h("span", { class: "summe" }, E.fehler ? "" : passt + " von " + (E.ergebnisse.length - spaeter) + " passen" + (spaeter ? ", " + spaeter + " noch nicht dran" : "")), checkZu()));
    if (E.fehler) { checkPanel.append(h("div", { class: "naechster fehler" }, E.fehler.text, h("div", { class: "leer" }, E.fehler.original))); if (E.fehler.zeile && ed.ed) ed.ed.markieren(E.fehler.zeile, "fehler"); }
    if (E.abbruch) { checkPanel.append(h("div", { class: "abbruch" }, "⚠ " + E.abbruch.text, h("div", { class: "leer" }, E.abbruch.original))); if (E.abbruch.zeile && ed.ed) ed.ed.markieren(E.abbruch.zeile, "fehler"); }
    for (const e of E.ergebnisse) checkPanel.append(h("div", { class: "ze " + e.stand }, h("span", { class: "z-stand" }, { passt: "✓ passt", offen: "✗ noch nicht", spaeter: "· noch nicht dran" }[e.stand]), h("span", {}, e.titel), e.stand === "offen" ? h("span", { class: "z-text" }, " – " + e.text) : null));
    for (const a of U.aufgaben) if (a._standZeigen) a._standZeigen();
    sterneLaden();
  }
}

// Der Trenner der Uebung: ziehen aendert die Teilung, der Browser merkt sie sich
// (Lehrer 13.10.: "Es braucht Moeglichkeiten, um die Teil-Fenster anzupassen").
function trenner(wrap) {
  const t = h("div", { class: "trenner", title: "Ziehen: Teilung ändern · Doppelklick: zurücksetzen" });
  let gemerkt = null; try { gemerkt = localStorage.getItem("lernraum.teilung"); } catch (e) {}
  if (gemerkt) wrap.style.setProperty("--teilung", gemerkt);
  t.addEventListener("pointerdown", ev => {
    ev.preventDefault(); t.classList.add("aktiv"); t.setPointerCapture(ev.pointerId);
    const links = wrap.getBoundingClientRect().left;
    const ziehen = e => { const px = Math.max(240, Math.min(wrap.clientWidth - 360, e.clientX - links)); wrap.style.setProperty("--teilung", px + "px"); };
    const ende = () => { t.classList.remove("aktiv"); t.removeEventListener("pointermove", ziehen); t.removeEventListener("pointerup", ende); try { localStorage.setItem("lernraum.teilung", wrap.style.getPropertyValue("--teilung")); } catch (e) {} };
    t.addEventListener("pointermove", ziehen); t.addEventListener("pointerup", ende);
  });
  t.addEventListener("dblclick", () => { wrap.style.removeProperty("--teilung"); try { localStorage.removeItem("lernraum.teilung"); } catch (e) {} });
  return t;
}

// ─── Werkstatt ─────────────────────────────────────────────────────────────────────────
function werkstattSeite(haupt, T) {
  // der Satz darunter kommt von der Werkstatt selbst (bis 15.10. stand hier der des Regals fuer jede)
  const w = (window.Werkstaetten || {})[T.thema.werkstatt] || {};
  const s = h("div", { class: "seite" }, h("h2", {}, "Werkstatt"), h("p", {}, w.einleitung || "Erst ohne Code, dann „als Python zeigen“."));
  const el = h("div", {}); s.append(el); haupt.append(s);
  werkstattEinbauen(el, T.thema.werkstatt, T, T.thema.werkstatt_optionen);   // z. B. die Struktogramme des Themas (19.10.)
}

// ─── Lösung ───────────────────────────────────────────────────────────────────────────
function loesungSeite(haupt, T) {
  const frei = Z.lehrer || !!(Z.stand.kennwoerter || {})[T.pfad];
  if (!frei) {
    const feld = h("input", { placeholder: "Kennwort", autofocus: true });
    const fehl = h("p", { class: "fehler" });
    const senden = async () => { try { const r = await api("loesung/freischalten", { thema: T.pfad, kennwort: feld.value }); Z.stand = r.stand; zeichnen(); } catch (e) { fehl.textContent = e.message; } };
    feld.addEventListener("keydown", ev => { if (ev.key === "Enter") senden(); });
    haupt.append(h("div", { class: "kennwortfeld" }, h("h2", {}, zeichen(SCHLOSS_ZEICHEN, "z-schloss"), "Lösung"), h("p", {}, "Das Kennwort zu diesem Thema sagt dir dein Lehrer. Einmal eingeben – danach bleibt die Lösung offen, auch auf einem anderen Rechner mit deinem Stand."), feld, h("p", {}, h("button", { class: "primaer", onclick: senden }, "Freischalten")), fehl));
    return;
  }
  // Links die Aufgaben, rechts die Lösung der angeklickten (Lehrer 23.10.: „rechts die Lösung bei Klick auf die
  // jeweilige Aufgabe … bei Code als Code, bei Zeichnung als Zeichnung, bei Text als Text“). Python-Code steht im
  // Editor (lesen, kopieren), Shell-Ausgaben als Shell, Bilder und Text wie geschrieben. „Dein Code“ ist ein Eintrag.
  const wrap = h("div", { class: "loesung-seite zweiteilig" });
  const links = h("nav", { class: "spalte loesung-liste", "aria-label": "Aufgaben" }, h("h2", {}, "Lösung"));
  const rechts = h("div", { class: "spalte loesung-detail" });
  wrap.append(links, rechts); haupt.append(wrap);
  // Kennwort verdeckt, ein Auge zeigt es (Lehrer 23.10.: „als Punkte darstellen und nur bei Klick auf ein Auge daneben
  // sichtbar machen“) -- immer acht Punkte, damit die Länge nichts verrät
  if (Z.lehrer && T.thema.kennwort) {
    const PUNKTE = "••••••••";
    const wert = h("b", { class: "kennwort-wert" }, PUNKTE);
    let offen = false;
    const auge = h("button", { type: "button", class: "ruhig kennwort-auge", title: "Kennwort zeigen", "aria-label": "Kennwort zeigen", "aria-pressed": "false", onclick: () => {
      offen = !offen; wert.textContent = offen ? T.thema.kennwort : PUNKTE;
      auge.title = offen ? "Kennwort verbergen" : "Kennwort zeigen"; auge.setAttribute("aria-label", auge.title);
      auge.setAttribute("aria-pressed", String(offen)); auge.classList.toggle("offen", offen);
    } }, zeichen(AUGE_ZEICHEN));
    links.append(h("p", { class: "nur-ohne-beamer hinweis kennwort-zeile" }, "Kennwort für die Klasse: ", wert, auge));
  }
  const eintraege = [], knoepfe = h("div", { class: "loesung-knoepfe" }); links.append(knoepfe);
  const merkName = "lernraum.loesung." + T.pfad;
  let eigenerCode = null;   // der Editor mit der Arbeitsdatei: einmal gebaut, beim Wechsel nur umgehängt
  function zeige(k) {
    const e = eintraege[k]; if (!e) return;
    eintraege.forEach((x, i) => x.knopf.classList.toggle("aktiv", i === k));
    try { localStorage.setItem(merkName, e.id); } catch (err) {}
    rechts.textContent = "";
    rechts.append(h("h2", {}, e.titel));
    e.zeigen(rechts);
  }
  function eintrag(id, titel, zusatz, zeigen) {
    const k = eintraege.length;
    const knopf = h("button", { type: "button", class: "loesung-eintrag", onclick: () => zeige(k) }, h("span", { class: "le-titel" }, titel), zusatz ? h("small", {}, zusatz) : "");
    eintraege.push({ id, titel, knopf, zeigen }); knoepfe.append(knopf);
  }
  // Code als Code: jeder Python-Block der Lösung wird ein Editor zum Lesen; Ausgaben (```text) wie die Shell
  function ausformen(div) {
    div.querySelectorAll("pre.code").forEach(pre => {
      const code = pre.textContent.replace(/\n$/, "");
      if (pre.classList.contains("lang-python")) { const b = h("div", { class: "editorbox loesung-code" }); pre.replaceWith(b); editor(b, code, "python", null, true); b.append(codeKopierKnopf(code)); }
      else if (pre.classList.contains("lang-text")) { const k = h("div", { class: "konsole loesung-shell" }, code); pre.replaceWith(k); }
    });
    bilderPfad(div, T.pfad);
    return div;
  }
  api("loesung/lesen", { thema: T.pfad }).then(r => {
    const L = r.loesung;
    for (const a of T.thema.uebung.aufgaben) if ((L.aufgaben || {})[a.nr]) {
      const art = [{ pflicht: "Pflicht", vorrat: "Vorrat", kuer: "Kür" }[a.teil], { code: "im Editor", seite: "auf der Seite", papier: "auf Papier" }[a.art]].filter(Boolean).join(" · ");
      eintrag("a" + a.nr, "Aufgabe " + a.nr + (a.titel ? " · " + a.titel : ""), art, ziel => ziel.append(ausformen(h("div", { class: "loesung-text", html: L.aufgaben[a.nr] }))));
    }
    if (L.html) eintrag("allgemein", "Zur ganzen Übung", "", ziel => ziel.append(ausformen(h("div", { class: "loesung-text", html: L.html }))));
    for (const [name, text] of Object.entries(L.dateien || {})) eintrag("datei:" + name, name, "die ganze Lösungsdatei", ziel => { const b = h("div", { class: "editorbox loesung-code gross" }); ziel.append(b); editor(b, text, "python", null, true); b.append(codeKopierKnopf(text)); });
    eintrag("eigen", "Dein Code", T.thema.arbeitsdatei, ziel => {
      if (!eigenerCode) { eigenerCode = arbeitsEditor({ pfad: "themen/" + T.pfad + "/" + T.thema.arbeitsdatei, thema: T.pfad, ort: "loesung", ohneAufzeichnung: true }); eigenerCode.laden(); eigenerCode.teile = [eigenerCode.box, hoehenTrenner(eigenerCode.konsole, "shell-loesung", "Shell"), eigenerCode.konsole]; }
      ziel.append(...eigenerCode.teile);
    });
    let start = 0; try { const m = localStorage.getItem(merkName); const i = eintraege.findIndex(x => x.id === m); if (i >= 0) start = i; } catch (err) {}
    zeige(start);
  }).catch(e => links.append(h("p", { class: "fehler" }, e.message)));
}
// Ein Knopf, der Code kopiert -- wie kopierKnoepfe, nur für einen Editor statt eines pre
function codeKopierKnopf(text) {
  const knopf = h("button", { type: "button", class: "kopieren ruhig", title: "Code kopieren – dann im Editor mit Strg+V (Mac: ⌘+V) einfügen", onclick: async () => {
    try { await navigator.clipboard.writeText(text); knopf.textContent = "Kopiert"; } catch (e) { knopf.textContent = "Nicht kopiert"; }
    setTimeout(() => { knopf.textContent = "Kopieren"; }, 1500);
  } }, "Kopieren");
  return knopf;
}
