"""Loesungen verschluesseln -- mit nichts als der Standardbibliothek.

Es gibt kein AES in der Standardbibliothek. Deshalb:
  Schluessel   = PBKDF2-HMAC-SHA256(Kennwort, Salz, 200 000 Runden)
  Stromchiffre = SHA-256(Schluessel_enc || Nonce || Zaehler) Block fuer
                 Block, XOR mit dem Klartext (ein Zaehlerstrom)
  Echtheit     = HMAC-SHA256(Schluessel_mac, Salz || Nonce || Geheimtext)

Aufbau der Datei: b"KOLS1" + Salz(16) + Nonce(16) + Geheimtext + Tag(32).
Ohne Kennwort ist der Inhalt nicht lesbar; mit falschem Kennwort schlaegt
die Echtheitspruefung an, bevor etwas entschluesselt wird.
"""
import hashlib
import hmac
import secrets

MAGIE = b"KOLS1"
RUNDEN = 200_000


def _schluessel(kennwort, salz):
    grund = hashlib.pbkdf2_hmac("sha256", kennwort.encode("utf-8"), salz, RUNDEN, 32)
    return (hashlib.sha256(grund + b"enc").digest(),
            hashlib.sha256(grund + b"mac").digest())


def _strom(k_enc, nonce, laenge):
    aus = bytearray()
    zaehler = 0
    while len(aus) < laenge:
        aus += hashlib.sha256(k_enc + nonce + zaehler.to_bytes(8, "big")).digest()
        zaehler += 1
    return bytes(aus[:laenge])


def verschluesseln(klartext: bytes, kennwort: str) -> bytes:
    salz, nonce = secrets.token_bytes(16), secrets.token_bytes(16)
    k_enc, k_mac = _schluessel(kennwort, salz)
    geheim = bytes(a ^ b for a, b in zip(klartext, _strom(k_enc, nonce, len(klartext))))
    tag = hmac.new(k_mac, salz + nonce + geheim, "sha256").digest()
    return MAGIE + salz + nonce + geheim + tag


def entschluesseln(daten: bytes, kennwort: str) -> bytes:
    """Liefert den Klartext oder wirft ValueError (falsches Kennwort,
    beschaedigte Datei)."""
    if not daten.startswith(MAGIE) or len(daten) < len(MAGIE) + 16 + 16 + 32:
        raise ValueError("keine verschluesselte Loesungsdatei")
    k = len(MAGIE)
    salz, nonce = daten[k:k + 16], daten[k + 16:k + 32]
    geheim, tag = daten[k + 32:-32], daten[-32:]
    k_enc, k_mac = _schluessel(kennwort, salz)
    soll = hmac.new(k_mac, salz + nonce + geheim, "sha256").digest()
    if not hmac.compare_digest(soll, tag):
        raise ValueError("falsches Kennwort")
    return bytes(a ^ b for a, b in zip(geheim, _strom(k_enc, nonce, len(geheim))))


def kennwort_erzeugen(laenge=3):
    """Ein Kennwort, das man vor der Klasse sagen kann: drei kurze Woerter."""
    woerter = ("apfel birne tanne eule fuchs igel kiesel lampe moos nebel orgel pilz "
               "quelle regen segel tulpe ufer vogel wiese zebra anker brot dachs "
               "esche feder gabel hafen insel kerze linde motte nadel ofen pfad "
               "rabe sattel tinte wolke zahn").split()
    return "-".join(secrets.choice(woerter) for _ in range(laenge))
