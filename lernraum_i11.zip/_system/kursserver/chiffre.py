"""Loesungen verschluesseln -- mit nichts als der Standardbibliothek.

Es gibt kein AES in der Standardbibliothek. Deshalb:
  Schluessel   = PBKDF2-HMAC-SHA256(Kennwort, Salz, 200 000 Runden)
  Stromchiffre = SHA-256(Schluessel_enc || Nonce || Zaehler) Block fuer
                 Block, XOR mit dem Klartext (ein Zaehlerstrom)
  Echtheit     = HMAC-SHA256(Schluessel_mac, Salz || Nonce || Geheimtext)

Aufbau der Datei: b"KOLS1" + Salz(16) + Nonce(16) + Geheimtext + Tag(32).
Ohne Kennwort ist der Inhalt nicht lesbar; mit falschem Kennwort schlaegt
die Echtheitspruefung an, bevor etwas entschluesselt wird.
"""
import hashlib
import hmac
import secrets

MAGIE = b"KOLS1"
RUNDEN = 200_000


def _schluessel(kennwort, salz):
    grund = hashlib.pbkdf2_hmac("sha256", kennwort.encode("utf-8"), salz, RUNDEN, 32)
    return (hashlib.sha256(grund + b"enc").digest(),
            hashlib.sha256(grund + b"mac").digest())


def _strom(k_enc, nonce, laenge):
    aus = bytearray()
    zaehler = 0
    while len(aus) < laenge:
        aus += hashlib.sha256(k_enc + nonce + zaehler.to_bytes(8, "big")).digest()
        zaehler += 1
    return bytes(aus[:laenge])


def verschluesseln(klartext: bytes, kennwort: str) -> bytes:
    salz, nonce = secrets.token_bytes(16), secrets.token_bytes(16)
    k_enc, k_mac = _schluessel(kennwort, salz)
    geheim = bytes(a ^ b for a, b in zip(klartext, _strom(k_enc, nonce, len(klartext))))
    tag = hmac.new(k_mac, salz + nonce + geheim, "sha256").digest()
    return MAGIE + salz + nonce + geheim + tag


def entschluesseln(daten: bytes, kennwort: str) -> bytes:
    """Liefert den Klartext oder wirft ValueError (falsches Kennwort,
    beschaedigte Datei)."""
    if not daten.startswith(MAGIE) or len(daten) < len(MAGIE) + 16 + 16 + 32:
        raise ValueError("keine verschluesselte Loesungsdatei")
    k = len(MAGIE)
    salz, nonce = daten[k:k + 16], daten[k + 16:k + 32]
    geheim, tag = daten[k + 32:-32], daten[-32:]
    k_enc, k_mac = _schluessel(kennwort, salz)
    soll = hmac.new(k_mac, salz + nonce + geheim, "sha256").digest()
    if not hmac.compare_digest(soll, tag):
        raise ValueError("falsches Kennwort")
    return bytes(a ^ b for a, b in zip(geheim, _strom(k_enc, nonce, len(geheim))))


# Kennwoerter erzeugt seit dem 16.11.2026 werkstatt/lernraum/kennwort.py (vier Woerter aus einem Vorrat von mindestens
# 1500) -- hier, in der Schuelerfassung, steht kein Wortvorrat mehr. Bis dahin: drei von 39 Woertern, in 20 Minuten
# durchprobiert.
