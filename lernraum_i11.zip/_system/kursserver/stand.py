"""Der Stand: _stand/stand.json -- was eine Person in diesem Lernraum
getan hat. Eine Datei, klein, mailbar, zusammenfuehrbar.

Aufgabenkennung = "<reihe>/<thema>/<nr>" (Namen, nie Nummern), damit ein
Umbau der Reihenfolge keinen Stand verliert. Je Thema steht ein Inhalts-Hash,
damit die Uebersicht weiss, welche Fassung beantwortet wurde.
"""
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import time
import zipfile

VERSION = 1
LK_TAGE = {1: 0, 2: 2, 3: 4, 4: 8, 5: 16}   # Lernkarten: nach wie vielen Tagen ein Fach wieder dran ist (seite/js/lernkarten.js zeigt sie)


def jetzt():
    return datetime.datetime.now().isoformat(timespec="seconds")


# OneDrive (Lehrer 25.10.: „manche Schueler werden OneDrive nutzen wollen, kann da beim Lernstand was kaputt
# gehen? Sollte nicht so sein.“) -- unter Windows haelt OneDrive eine Datei, die es gerade hochlaedt, kurz fest;
# os.replace scheitert dann mit PermissionError. Kurz warten und noch einmal, statt ein Speichern zu verlieren.
def ersetzen(tmp, ziel, versuche=12):
    for i in range(versuche):
        try:
            os.replace(tmp, ziel)
            return
        except PermissionError:
            if i == versuche - 1:
                raise
            time.sleep(0.25)


def schreiben(ziel, text):
    """Eine Textdatei ganz oder gar nicht schreiben (erst daneben, dann ersetzen)."""
    ziel = pathlib.Path(ziel)
    tmp = ziel.with_name(ziel.name + ".tmp")
    tmp.write_text(text, "utf-8", newline="\n")
    ersetzen(tmp, ziel)


def leer(kurs=""):
    return {"version": VERSION, "kurs": kurs, "name": "", "vorname": "",
            "nachname": "", "partner": {}, "lesestelle": {}, "kennwoerter": {},
            "aufgaben": {}, "themen": {}, "fragen": {}, "stufen": {},
            "puzzles": {}, "faelle": {}, "vorhersagen": {}, "plaene": {}, "fehlerbuch": {}, "einschaetzung": {}, "lernkarten": {},
            "gespeichert": jetzt()}


class Stand:
    def __init__(self, wurzel, kurs=""):
        self.wurzel = pathlib.Path(wurzel)
        self.pfad = self.wurzel / "_stand" / "stand.json"
        self.daten = leer(kurs)
        if self.pfad.exists():
            try:
                self.daten.update(json.loads(self.pfad.read_text("utf-8")))
            except (OSError, ValueError):
                kaputt = self.pfad.with_suffix(".kaputt.json")
                shutil.copy(self.pfad, kaputt)
        if kurs:
            self.daten["kurs"] = kurs

    def speichern(self):
        self.daten["gespeichert"] = jetzt()
        self.pfad.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.pfad.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.daten, ensure_ascii=False, indent=1), "utf-8")
        ersetzen(tmp, self.pfad)

    # -- Teile -------------------------------------------------------------
    def aufgabe(self, kennung):
        return self.daten["aufgaben"].setdefault(kennung, {})

    def eintragen(self, kennung, **werte):
        a = self.aufgabe(kennung)
        a.update(werte)
        a["zeit"] = jetzt()
        self.speichern()
        return a

    def thema(self, kennung):
        return self.daten["themen"].setdefault(kennung, {})

    def frage(self, kennung, wahl, richtig):
        """Prueffrage der Erklaerung (Galerie Rang 5): keine Note -- gemerkt wird, ob sie
        geloest ist (der Abschnitt gilt dann als gelesen), die erste Wahl und die Versuche
        bis dahin. Nach dem Loesen zaehlt nichts mehr; Nachlesen der anderen Wahlen ist frei."""
        f = self.daten.setdefault("fragen", {}).setdefault(kennung, {})
        if not f.get("geloest"):
            f.setdefault("erste", wahl)
            f["versuche"] = f.get("versuche", 0) + 1
            f["geloest"] = bool(richtig)
            if richtig:
                f["wahl"] = wahl        # die richtige Wahl: daran rechnet die Uebersicht die Sterne nach
            f["zeit"] = jetzt()
            self.speichern()
        return f

    def stufe(self, kennung, stufe=None, luecken=None):
        """Beispiel in Stufen (Galerie Rang 7): die zuletzt gewaehlte Stufe und ob die
        Luecken einmal ganz gestimmt haben."""
        s = self.daten.setdefault("stufen", {}).setdefault(kennung, {})
        if stufe in (1, 2, 3):
            s["stufe"] = stufe
        if luecken:
            s["luecken"] = True
        s["zeit"] = jetzt()
        self.speichern()
        return s

    def puzzle(self, kennung, falsch, geloest, programm=None):
        """Parsons-Puzzle (Galerie Rang 8): wie oft geprueft, wie viele zuletzt falsch, ob geloest.
        Geloest bleibt geloest; danach zaehlt nichts mehr."""
        p = self.daten.setdefault("puzzles", {}).setdefault(kennung, {})
        if not p.get("geloest"):
            p["versuche"] = p.get("versuche", 0) + 1
            p["falsch"] = falsch
            p["geloest"] = bool(geloest)
            p["programm"] = list(programm or [])[:60]     # das zuletzt gepruefte Programm: die Seite legt es wieder hin
            p["zeit"] = jetzt()
            self.speichern()
        return p

    def vorhersage(self, kennung, antworten, einzeln):
        """Vorhersage (Durchsicht T3, 16.10.): die zuletzt geprueften Antworten, welche stimmten,
        Versuche. Geloest = alle stimmen; geloest bleibt geloest, danach zaehlt nichts mehr."""
        v = self.daten.setdefault("vorhersagen", {}).setdefault(kennung, {})
        if not v.get("geloest"):
            v["versuche"] = v.get("versuche", 0) + 1
            v["antworten"] = [str(x)[:200] for x in antworten][:40]
            v["richtig"] = [bool(x) for x in einzeln]
            v["geloest"] = bool(einzeln) and all(einzeln)
            v["zeit"] = jetzt()
            self.speichern()
        return v

    def plan(self, kennung, quelle, titel, ergebnis=None):
        """Plan (Aufgabenart „Plan“, 19.10.2026): das Struktogramm der Klasse in der Sprache von
        struktogramm.py, sein Titel, und -- wenn die Proben liefen -- wie viele Faelle stimmten.
        Anders als beim Puzzle bleibt „geloest“ NICHT stehen: Der Plan kann danach noch geaendert
        werden; die Sterne rechnet der Server ohnehin aus der Quelle nach (sterne.py)."""
        p = self.daten.setdefault("plaene", {}).setdefault(kennung, {})
        p["quelle"] = str(quelle)[:20000]
        p["titel"] = str(titel or "")[:200]
        if ergebnis is not None:
            p["versuche"] = p.get("versuche", 0) + 1
            p["ok"], p["von"] = ergebnis["ok"], ergebnis["von"]
            p["geloest"] = ergebnis["von"] > 0 and ergebnis["ok"] == ergebnis["von"]
        p["zeit"] = jetzt()
        self.speichern()
        return p

    def fall(self, kennung, gefunden, falsch):
        """Fall (Debug-Detektiv, Rang 10): die gefundenen Zeilen (nur dazu, nie weg), falsche
        Verdachte und Versuche -- die Akte."""
        f = self.daten.setdefault("faelle", {}).setdefault(kennung, {})
        f["gefunden"] = sorted(set(f.get("gefunden", [])) | set(gefunden))
        f["falsch"] = f.get("falsch", 0) + falsch
        f["versuche"] = f.get("versuche", 0) + 1
        f["zeit"] = jetzt()
        self.speichern()
        return f

    def fehler(self, fehler, thema, ort, code):
        """Mein Fehlerbuch (Rang 9): je Fehlerart (NameError ...) wie oft, je Thema gezaehlt,
        zuerst und zuletzt wo, die letzte Meldung samt Codezeile. Die Notiz schreibt die Person."""
        art = fehler.get("art") or "Fehler"
        e = self.daten.setdefault("fehlerbuch", {}).setdefault(art, {"themen": {}})
        wo = {"thema": thema, "ort": ort, "zeit": jetzt()}
        e["themen"][thema] = e["themen"].get(thema, 0) + 1
        e["anzahl"] = sum(e["themen"].values())
        e.setdefault("erste", wo)
        e["letzte"] = dict(wo, meldung=str(fehler.get("original", ""))[:200], zeile=fehler.get("zeile"), code=code[:200])
        e["satz"] = fehler.get("satz", "")
        self.speichern()
        return e

    def fehlernotiz(self, art, notiz):
        e = self.daten.setdefault("fehlerbuch", {}).get(art)
        if e is None:
            return None
        e["notiz"] = notiz[:300]
        e["notiz_zeit"] = jetzt()
        self.speichern()
        return e

    def einschaetzen(self, kennung, runde, stufe):
        """„Ich kann …“ (Galerie Rang 11, 16.10.): je Satz (<reihe>/<satz>) und Runde (1 Mitte der Reihe,
        2 Ende, 3 vor der Klausur) eine Stufe 1-4 (noch nicht · ansatzweise · meistens · sicher).
        0 = zurueckgenommen -- bleibt als Eintrag mit Zeit, damit es beim Zusammenfuehren gewinnt."""
        e = self.daten.setdefault("einschaetzung", {}).setdefault(kennung, {})
        e[str(runde)] = {"stufe": stufe, "zeit": jetzt()}
        self.speichern()
        return e

    def lernkarte(self, kennung, gewusst, heute=None):
        """Lernkarten (Galerie Rang 15, 16.10.): Leitner mit fuenf Faechern. Ohne Eintrag liegt eine Karte
        in Fach 1 und ist dran. „Wusste ich“ schiebt sie ein Fach weiter -- aber nur, wenn sie dran war
        (sonst liesse sich eine Karte an einem Nachmittag nach Fach 5 klicken); „Noch nicht“ legt sie
        immer zurueck in Fach 1. Wann sie wieder dran ist: LK_TAGE nach dem Fach."""
        heute = heute or datetime.date.today()
        e = self.daten.setdefault("lernkarten", {}).setdefault(kennung, {"fach": 1})
        dran = e.get("faellig", "") <= heute.isoformat()
        if gewusst:
            e["gewusst"] = e.get("gewusst", 0) + 1
            if dran:
                e["fach"] = min(5, int(e.get("fach", 1)) + 1)
                e["faellig"] = (heute + datetime.timedelta(days=LK_TAGE[e["fach"]])).isoformat()
        else:
            e["nicht"] = e.get("nicht", 0) + 1
            e["fach"], e["faellig"] = 1, heute.isoformat()
        e["zeit"] = jetzt()
        self.speichern()
        return e

    def oeffentlich(self):
        """Das, was die Seite sehen darf (alles -- der Stand gehoert der
        Person selbst; Namen zeigt die Seite nur ohne Beamer)."""
        return self.daten

    # -- Zusammenfuehren -----------------------------------------------------
    def zusammenfuehren(self, anderer, arbeitsdateien_anderer):
        """Fuehrt einen zweiten Stand hinein. Regeln (KONZEPT Block 6):
        je Aufgabe gewinnt der NEUERE Eintrag; Hilfen, Haken, Kennwoerter
        werden vereinigt; Arbeitsdateien: die neuere gewinnt, die andere
        bleibt als .konflikt-Datei liegen und wird gemeldet."""
        bericht = {"uebernommen": [], "behalten": [], "konflikte": [],
                   "kennwoerter": 0}
        if not self.daten.get("name") and anderer.get("name"):
            # Neuer Rechner, eigene ZIP: der Name kommt mit (Lehrer 14.10.: Themen erst mit Name oder ZIP)
            for k in ("name", "vorname", "nachname"):
                self.daten[k] = anderer.get(k, "")
            bericht["name"] = self.daten["name"]
        if not self.daten.get("partner") and anderer.get("partner"):
            self.daten["partner"] = dict(anderer["partner"])     # Partnerarbeit (Weg 3): die Partnerin reist mit
        for kw, wert in anderer.get("kennwoerter", {}).items():
            if kw not in self.daten["kennwoerter"]:
                self.daten["kennwoerter"][kw] = wert
                bericht["kennwoerter"] += 1
        for kennung, fremd in anderer.get("aufgaben", {}).items():
            eigen = self.daten["aufgaben"].get(kennung)
            if eigen is None:
                self.daten["aufgaben"][kennung] = fremd
                bericht["uebernommen"].append(kennung)
                continue
            neuer = fremd if fremd.get("zeit", "") > eigen.get("zeit", "") else eigen
            aelter = eigen if neuer is fremd else fremd
            verschmolzen = dict(aelter)
            verschmolzen.update(neuer)
            verschmolzen["hilfen"] = sorted(set(eigen.get("hilfen", [])) | set(fremd.get("hilfen", [])))
            if eigen.get("versucht") or fremd.get("versucht"):        # versuchte Stern-Stufen (16.10.)
                verschmolzen["versucht"] = sorted(set(eigen.get("versucht", [])) | set(fremd.get("versucht", [])))
            self.daten["aufgaben"][kennung] = verschmolzen
            (bericht["uebernommen"] if neuer is fremd else bericht["behalten"]).append(kennung)
        # Prueffragen und Stufen: geloest bleibt geloest, sonst gewinnt der neuere Eintrag
        for teil in ("fragen", "stufen"):
            hier = self.daten.setdefault(teil, {})
            for kennung, fremd in (anderer.get(teil) or {}).items():
                eigen = hier.get(kennung)
                if eigen is None:
                    hier[kennung] = dict(fremd)
                    continue
                neuer, aelter = (fremd, eigen) if fremd.get("zeit", "") > eigen.get("zeit", "") else (eigen, fremd)
                v = dict(aelter)
                v.update(neuer)
                for k in ("geloest", "luecken"):
                    if eigen.get(k) or fremd.get(k):
                        v[k] = True
                if teil == "fragen" and eigen.get("geloest") != fremd.get("geloest"):
                    v.update({k: (eigen if eigen.get("geloest") else fremd).get(k) for k in ("erste", "versuche")})
                hier[kennung] = v
        # Puzzles: geloest bleibt geloest. Faelle: gefundene Zeilen vereinigt, Zaehler das Groessere.
        for kennung, fremd in (anderer.get("puzzles") or {}).items():
            hier = self.daten.setdefault("puzzles", {})
            eigen = hier.get(kennung)
            if eigen is None or (fremd.get("geloest") and not eigen.get("geloest")) or (
                    not eigen.get("geloest") and fremd.get("zeit", "") > eigen.get("zeit", "")):
                hier[kennung] = dict(fremd)
        for kennung, fremd in (anderer.get("vorhersagen") or {}).items():
            hier = self.daten.setdefault("vorhersagen", {})
            eigen = hier.get(kennung)
            if eigen is None or (fremd.get("geloest") and not eigen.get("geloest")) or (
                    not eigen.get("geloest") and fremd.get("zeit", "") > eigen.get("zeit", "")):
                hier[kennung] = dict(fremd)
        # Plaene: der zuletzt geaenderte gilt (ein Plan wird ueberarbeitet, nicht gesammelt)
        for kennung, fremd in (anderer.get("plaene") or {}).items():
            hier = self.daten.setdefault("plaene", {})
            eigen = hier.get(kennung)
            if eigen is None or fremd.get("zeit", "") > eigen.get("zeit", ""):
                hier[kennung] = dict(fremd)
        for kennung, fremd in (anderer.get("faelle") or {}).items():
            hier = self.daten.setdefault("faelle", {})
            eigen = hier.setdefault(kennung, {})
            eigen["gefunden"] = sorted(set(eigen.get("gefunden", [])) | set(fremd.get("gefunden", [])))
            for k in ("falsch", "versuche"):
                eigen[k] = max(eigen.get(k, 0), fremd.get(k, 0))
            eigen["zeit"] = max(eigen.get("zeit", ""), fremd.get("zeit", ""))
        # Fehlerbuch: Zaehlungen je Thema das Groessere (eine Stand-ZIP, die hin- und zurueckreist,
        # zaehlt nicht doppelt), zuerst das Fruehere, zuletzt das Spaetere, die neuere Notiz.
        for art, fremd in (anderer.get("fehlerbuch") or {}).items():
            hier = self.daten.setdefault("fehlerbuch", {})
            eigen = hier.setdefault(art, {"themen": {}})
            for t, n in (fremd.get("themen") or {}).items():
                eigen["themen"][t] = max(eigen["themen"].get(t, 0), n)
            eigen["anzahl"] = sum(eigen["themen"].values())
            if fremd.get("erste") and (not eigen.get("erste") or fremd["erste"].get("zeit", "") < eigen["erste"].get("zeit", "")):
                eigen["erste"] = fremd["erste"]
            if fremd.get("letzte") and (not eigen.get("letzte") or fremd["letzte"].get("zeit", "") > eigen["letzte"].get("zeit", "")):
                eigen["letzte"] = fremd["letzte"]
                eigen["satz"] = fremd.get("satz", eigen.get("satz", ""))
            if fremd.get("notiz") and fremd.get("notiz_zeit", "") > eigen.get("notiz_zeit", ""):
                eigen["notiz"], eigen["notiz_zeit"] = fremd["notiz"], fremd["notiz_zeit"]
        # „Ich kann …“: je Satz und Runde gewinnt die neuere Einschaetzung (auch ein Zuruecknehmen)
        for kennung, runden in (anderer.get("einschaetzung") or {}).items():
            if not isinstance(runden, dict):
                continue
            hier = self.daten.setdefault("einschaetzung", {}).setdefault(kennung, {})
            for runde, fremd in runden.items():
                if isinstance(fremd, dict) and fremd.get("zeit", "") > (hier.get(runde) or {}).get("zeit", ""):
                    hier[runde] = dict(fremd)
        # Lernkarten: je Karte gewinnt der neuere Eintrag (Fach und wann sie dran ist); die Zaehler das Groessere
        for kennung, fremd in (anderer.get("lernkarten") or {}).items():
            if not isinstance(fremd, dict):
                continue
            hier = self.daten.setdefault("lernkarten", {})
            eigen = hier.get(kennung) or {}
            v = dict(fremd) if fremd.get("zeit", "") > eigen.get("zeit", "") else dict(eigen)
            for k in ("gewusst", "nicht"):
                if eigen.get(k) or fremd.get(k):
                    v[k] = max(eigen.get(k, 0), fremd.get(k, 0))
            hier[kennung] = v
        for kennung, fremd in anderer.get("themen", {}).items():
            eigen = self.thema(kennung)
            if not eigen or fremd.get("zeit", "") > eigen.get("zeit", ""):
                eigen.update(fremd)
        for rel, (inhalt, zeit) in arbeitsdateien_anderer.items():
            ziel = self.wurzel / rel
            if not ziel.exists():
                ziel.parent.mkdir(parents=True, exist_ok=True)
                ziel.write_bytes(inhalt)
                bericht["uebernommen"].append(rel)
                continue
            eigen_inhalt = ziel.read_bytes()
            if eigen_inhalt == inhalt:
                continue
            eigen_zeit = datetime.datetime.fromtimestamp(ziel.stat().st_mtime).isoformat(timespec="seconds")
            if zeit > eigen_zeit:
                konflikt = ziel.with_name(ziel.stem + ".konflikt_" + eigen_zeit.replace(":", "-") + ziel.suffix)
                konflikt.write_bytes(eigen_inhalt)
                ziel.write_bytes(inhalt)
                bericht["konflikte"].append({"datei": rel, "gewinner": "mitgebracht",
                                             "verlierer": str(konflikt.relative_to(self.wurzel))})
            else:
                konflikt = ziel.with_name(ziel.stem + ".konflikt_" + zeit.replace(":", "-") + ziel.suffix)
                konflikt.write_bytes(inhalt)
                bericht["konflikte"].append({"datei": rel, "gewinner": "hier",
                                             "verlierer": str(konflikt.relative_to(self.wurzel))})
        self.speichern()
        return bericht


KONFLIKTE = pathlib.Path("_stand") / "konflikte"


def konfliktkopien_einarbeiten(wurzel, stand):
    """War derselbe Ordner auf zwei Rechnern offen, legt der Cloud-Speicher eine Kopie neben stand.json
    (OneDrive: stand-SCHULPC.json, iCloud: stand 2.json, Dropbox: stand (… conflicted copy …).json). Beim Start:
    jede hineinfuehren -- dieselben Regeln wie „Stand hereinnehmen“, nichts geht verloren -- und danach nach
    _stand/konflikte/ legen. Gibt die Namen der eingearbeiteten Kopien zurueck."""
    wurzel = pathlib.Path(wurzel)
    namen = []
    for p in sorted((wurzel / "_stand").glob("stand*.json")):
        if p.name == "stand.json" or p.name.endswith(".kaputt.json"):
            continue
        try:
            anderer = json.loads(p.read_text("utf-8"))
        except (OSError, ValueError):
            continue
        if not isinstance(anderer, dict) or not isinstance(anderer.get("aufgaben"), dict):
            continue
        stand.zusammenfuehren(anderer, {})
        ziel = wurzel / KONFLIKTE
        ziel.mkdir(parents=True, exist_ok=True)
        z = ziel / p.name
        n = 2
        while z.exists():
            z = ziel / ("%s_%d%s" % (p.stem, n, p.suffix))
            n += 1
        ersetzen(p, z)
        namen.append(p.name)
    return namen


def themen_hash(ordner):
    """Inhalts-Hash eines Themenordners: alle Quelldateien ausser der
    Arbeitsdatei-Aenderungen -- dafuer nimmt bauen.py die Quelle."""
    h = hashlib.sha256()
    for p in sorted(pathlib.Path(ordner).rglob("*")):
        if p.is_file() and not p.name.endswith((".pyc", ".konflikt")):
            h.update(p.name.encode())
            h.update(p.read_bytes())
    return h.hexdigest()[:12]


def arbeitsdateien(inhalt, wurzel):
    """Alle Arbeitsdateien (uebung + vortrag-Arbeitskopien) relativ zur Wurzel."""
    aus = []
    for reihe in inhalt["reihen"]:
        for thema in reihe["themen"]:
            basis = pathlib.Path("themen") / reihe["kennung"] / thema["kennung"]
            if thema.get("arbeitsdatei"):
                aus.append(str(basis / thema["arbeitsdatei"]))
            for s in thema.get("vortrag", []):
                if s.get("art") in ("code", "html") and s.get("arbeit"):
                    aus.append(str(basis / "vortrag" / s["arbeit"]))
    return [a for a in aus if (pathlib.Path(wurzel) / a).exists()]


def stand_zip(wurzel, inhalt, stand, ziel):
    """stand_<Name>.zip: Stand + Arbeitsdateien. Mailbar klein."""
    wurzel = pathlib.Path(wurzel)
    with zipfile.ZipFile(ziel, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("stand.json", json.dumps(stand.daten, ensure_ascii=False, indent=1))
        for rel in arbeitsdateien(inhalt, wurzel):
            p = wurzel / rel
            info = zipfile.ZipInfo(rel.replace("\\", "/"),
                                   datetime.datetime.fromtimestamp(p.stat().st_mtime).timetuple()[:6])
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, p.read_bytes())
    return ziel


def stand_zip_lesen(daten_bytes):
    """Gibt (stand_dict, {rel: (bytes, iso_zeit)}) aus einer Stand- oder Abgabe-ZIP."""
    import io
    with zipfile.ZipFile(io.BytesIO(daten_bytes)) as z:
        namen = z.namelist()
        if "stand.json" not in namen:
            raise ValueError("In der ZIP fehlt stand.json -- das ist kein Stand.")
        stand = json.loads(z.read("stand.json").decode("utf-8"))
        dateien = {}
        for n in namen:
            if n == "stand.json" or n.endswith("/"):
                continue
            info = z.getinfo(n)
            zeit = datetime.datetime(*info.date_time).isoformat(timespec="seconds")
            dateien[n] = (z.read(n), zeit)
    return stand, dateien


# -- Speicherstaende (Lehrerwunsch 16.10.2026) ------------------------------------
# Auf dem Stick ist ohnehin alles gespeichert; was fehlte, war der Weg ZURUECK: wer seine
# Datei kaputt gemacht hat, konnte nur „zum Start“. Jetzt liegt bei jedem Start eine Sicherung
# in _stand/sicherungen/ (die letzten 10), dazu Speicherstaende von Hand (die letzten 20). Vor
# jedem Zurueckgehen wird der Stand selbst gesichert -- auch das Zurueckgehen laesst sich
# zuruecknehmen. Eine Sicherung ist eine Stand-ZIP (dasselbe Format wie „Stand mitnehmen“).
SICHERUNGEN = pathlib.Path("_stand") / "sicherungen"
# "ende": der Knopf „Beenden“ oben rechts (Lehrer 25.10.: „damit die Seite korrekt geschlossen wird … dann würde
# dort auch der Speicherstand korrekt am Ende angelegt werden“)
ARTEN = {"start": ("beim Start", 10), "ende": ("beim Beenden", 10), "vorher": ("vor dem Zurückgehen", 10),
         "hand": ("von Hand", 20)}


def _fingerabdruck(wurzel, inhalt, stand):
    """Woran man erkennt, dass sich seit der letzten Sicherung nichts getan hat (ohne die Zeit
    des letzten Speicherns): dann legt der Start keine neue an."""
    h = hashlib.sha256()
    d = {k: v for k, v in stand.daten.items() if k not in ("gespeichert", "lesestelle")}
    h.update(json.dumps(d, sort_keys=True, ensure_ascii=False).encode("utf-8"))
    for rel in arbeitsdateien(inhalt, wurzel):
        h.update(rel.encode())
        h.update((pathlib.Path(wurzel) / rel).read_bytes())
    return h.hexdigest()[:16]


def sicherungen(wurzel):
    """Die Sicherungen, neueste zuerst: {name, zeit, art, wie, groesse, notiz}."""
    ordner = pathlib.Path(wurzel) / SICHERUNGEN
    aus = []
    for p in sorted(ordner.glob("*.zip"), reverse=True) if ordner.is_dir() else []:
        teile = p.stem.split("_")
        if len(teile) < 3 or teile[2] not in ARTEN:
            continue
        notiz = ""
        try:
            with zipfile.ZipFile(p) as z:
                notiz = json.loads(z.comment.decode("utf-8") or "{}").get("notiz", "")
        except (OSError, ValueError, zipfile.BadZipFile):
            continue
        zeit = teile[0] + "T" + teile[1].replace("-", ":")
        aus.append({"name": p.name, "zeit": zeit, "art": teile[2], "wie": ARTEN[teile[2]][0],
                    "groesse": p.stat().st_size, "notiz": notiz})
    return aus


def sicherung_anlegen(wurzel, inhalt, stand, art, notiz=""):
    """Legt eine Sicherung an und raeumt alte derselben Art weg. Beim Start: keine, wenn sich
    seit der neuesten Sicherung nichts geaendert hat. Gibt den Eintrag zurueck (oder None)."""
    wurzel = pathlib.Path(wurzel)
    if art in ("start", "ende") and not stand.daten.get("name"):
        return None        # ohne Namen gibt es nichts zu schuetzen (frische Fassung, K4-Probestart)
    finger = _fingerabdruck(wurzel, inhalt, stand)
    vorhanden = sicherungen(wurzel)
    if art in ("start", "ende") and vorhanden:
        try:
            with zipfile.ZipFile(wurzel / SICHERUNGEN / vorhanden[0]["name"]) as z:
                if json.loads(z.comment.decode("utf-8") or "{}").get("finger") == finger:
                    return None
        except (OSError, ValueError, zipfile.BadZipFile):
            pass
    ordner = wurzel / SICHERUNGEN
    ordner.mkdir(parents=True, exist_ok=True)
    stempel = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    ziel = ordner / ("%s_%s.zip" % (stempel, art))
    n = 2
    while ziel.exists():                       # zwei in derselben Sekunde
        ziel = ordner / ("%s_%s_%d.zip" % (stempel, art, n))
        n += 1
    stand_zip(wurzel, inhalt, stand, ziel)
    with zipfile.ZipFile(ziel, "a") as z:
        z.comment = json.dumps({"finger": finger, "notiz": str(notiz)[:80]}, ensure_ascii=False).encode("utf-8")
    behalten = ARTEN[art][1]
    alte = [s for s in sicherungen(wurzel) if s["art"] == art][behalten:]
    for s in alte:
        try:
            (ordner / s["name"]).unlink()
        except OSError:
            pass
    return next((s for s in sicherungen(wurzel) if s["name"] == ziel.name), None)


def sicherung_zurueck(wurzel, inhalt, stand, name):
    """Geht zu einer Sicherung zurueck: erst den jetzigen Stand sichern („vor dem Zurueckgehen“),
    dann Stand und Arbeitsdateien aus der Sicherung ERSETZEN (nicht zusammenfuehren -- beim
    Zusammenfuehren gewinnt der neuere Code, und das waere gerade der kaputte)."""
    wurzel = pathlib.Path(wurzel)
    if name not in {s["name"] for s in sicherungen(wurzel)}:
        raise ValueError("Diese Sicherung gibt es nicht.")
    daten = (wurzel / SICHERUNGEN / name).read_bytes()
    alt, dateien = stand_zip_lesen(daten)
    sicherung_anlegen(wurzel, inhalt, stand, "vorher")
    erlaubt = set(arbeitsdateien(inhalt, wurzel))
    zurueck = []
    for rel, (inhalt_bytes, _zeit) in dateien.items():
        if rel in erlaubt:                      # nur Arbeitsdateien, nie etwas anderes
            (wurzel / rel).write_bytes(inhalt_bytes)
            zurueck.append(rel)
    kurs = stand.daten.get("kurs", "")
    stand.daten = leer(kurs)
    stand.daten.update(alt)
    stand.daten["kurs"] = kurs or alt.get("kurs", "")
    stand.speichern()
    return {"dateien": zurueck}
