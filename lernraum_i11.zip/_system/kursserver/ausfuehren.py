"""Programme ausfuehren: ein Unterprozess mit demselben Python, das start.py
gestartet hat. Ausgabe wird gestreamt, ein Stopp beendet den Prozess, ein
Traceback wird in Zeile + deutschen Satz + Original zerlegt.

Kein Zeitlimit beim normalen Ausfuehren -- tkinter-Fenster laufen, bis man
sie schliesst (KONZEPT Block 6). Zeitlimits haben nur Selbstcheck und
Aufzeichnung.
"""
import os
import pathlib
import re
import subprocess
import sys
import threading
import time
import uuid

_LAEUFE = {}
_SPERRE = threading.Lock()

# Ein deutscher Satz je Fehlerart -- die Diagnose, nicht der Ausweg.
DEUTSCH = {
    "SyntaxError": "Python versteht diese Zeile nicht: Irgendwo fehlt oder stört ein Zeichen.",
    "IndentationError": "Die Einrückung stimmt nicht: Diese Zeile steht zu weit links oder rechts.",
    "NameError": "Ein Name wird benutzt, den Python hier nicht kennt – Tippfehler oder noch nicht angelegt.",
    "TypeError": "Zwei Dinge passen nicht zusammen – etwa Text und Zahl, oder ein Aufruf mit den falschen Angaben.",
    "ValueError": "Der Wert hat die richtige Art, aber den falschen Inhalt – etwa int() mit einem Text, der keine Zahl ist.",
    "IndexError": "Diesen Platz gibt es in der Liste nicht – die Plätze heißen 0 bis Anzahl minus 1.",
    "KeyError": "Diesen Schlüssel gibt es nicht.",
    "AttributeError": "Das Ding hat keine solche Eigenschaft oder Methode – Tippfehler oder falsche Art.",
    "ZeroDivisionError": "Durch null kann man nicht teilen.",
    "ModuleNotFoundError": "Diese Bibliothek gibt es hier nicht.",
    "ImportError": "Aus dieser Bibliothek lässt sich das nicht holen.",
    "RecursionError": "Eine Funktion ruft sich immer wieder selbst, ohne Ende.",
    "FileNotFoundError": "Diese Datei gibt es nicht.",
    "UnboundLocalError": "Der Name wird in der Funktion benutzt, bevor er dort einen Wert bekommt.",
    "KeyboardInterrupt": "Das Programm ist angehalten worden.",
}


def umgebung():
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def fehler_lesen(ausgabe, datei):
    """Traceback -> {"zeile": n, "art": ..., "satz": ..., "original": ...} oder None."""
    if "Traceback (most recent call last)" not in ausgabe and "Error" not in ausgabe:
        return None
    zeilen = ausgabe.rstrip().splitlines()
    original = ""
    art = ""
    for z in reversed(zeilen):
        m = re.match(r"^(\w+(?:Error|Exception|Interrupt|Warning))\b(.*)$", z.strip())
        if m:
            art, original = m.group(1), z.strip()
            break
    if not art:
        return None
    zeile = None
    name = pathlib.Path(datei).name
    for z in zeilen:
        m = re.search(r'File "([^"]+)", line (\d+)', z)
        if m and pathlib.Path(m.group(1)).name == name:
            zeile = int(m.group(2))     # die LETZTE Stelle in der Arbeitsdatei
    return {"zeile": zeile, "art": art, "satz": DEUTSCH.get(art, "Das Programm ist mit einem Fehler abgebrochen."),
            "original": original}


class Lauf:
    def __init__(self, datei, argumente=None, zeitlimit=None, modul=None, env_extra=None):
        self.id = uuid.uuid4().hex[:10]
        self.datei = pathlib.Path(datei)
        self.ausgabe = []          # Liste von Textstuecken
        self.weg = 0               # so viele Stuecke vorne sind schon verworfen (Endlosschleife, s. _anhaengen)
        self.zeichen = 0           # Zeichen, die noch in self.ausgabe stehen
        self._sperre = threading.Lock()
        self.begrenzt = modul is None   # der Debugger (modul=aufzeichnen.py) braucht jedes Ereignis, nichts gekuerzt
        self.fertig = False
        self.code = None
        self.gestoppt = False
        self.zeitlimit = zeitlimit
        self.fehlerbuch = None     # server.py: {thema, ort} -- dann zaehlt eine rote Meldung im Fehlerbuch
        self.start = time.time()
        befehl = [sys.executable, "-u"]
        if modul:
            befehl += modul
        befehl += [str(self.datei)] + list(argumente or [])
        env = umgebung()
        if env_extra:
            env.update(env_extra)
        self.prozess = subprocess.Popen(
            befehl, cwd=str(self.datei.parent), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE)
        threading.Thread(target=self._lesen, daemon=True).start()
        if zeitlimit:
            threading.Thread(target=self._wecker, daemon=True).start()

    def _lesen(self):
        # Stueckweise, wie es ankommt -- nicht zeilenweise: Die Eingabeaufforderung von input() („> “) hat kein
        # Zeilenende und blieb bis zur naechsten Zeile liegen; das Echo der Eingabe ueberholte sie (Code-Film, 21.10.).
        # Der schrittweise Dekoder zerreisst kein Zeichen, das auf zwei Stuecke faellt (Umlaute).
        import codecs
        dek = codecs.getincrementaldecoder("utf-8")("replace")
        with self.prozess.stdout:
            while True:
                roh = self.prozess.stdout.read1(65536)
                if not roh:
                    break
                text = dek.decode(roh)
                if text:
                    self._anhaengen(text)
            rest = dek.decode(b"", final=True)
            if rest:
                self._anhaengen(rest)
        self.code = self.prozess.wait()
        self.fertig = True

    def _wecker(self):
        while not self.fertig:
            if time.time() - self.start > self.zeitlimit:
                self.stopp(grund="Zeitlimit")
                return
            time.sleep(0.2)

    def stopp(self, grund="Stopp"):
        if not self.fertig:
            self.gestoppt = grund
            try:
                self.prozess.terminate()
                try:
                    self.prozess.wait(timeout=1.5)
                except subprocess.TimeoutExpired:
                    self.prozess.kill()
            except OSError:
                pass

    def eingabe(self, text, echo=True):
        """Eine Zeile an stdin des Programms -- fuer input(). echo=False: der Debugger (die Aufzeichnung
        meldet die Eingabe selbst als Ereignis; ein rohes Echo stuende zwischen den JSON-Zeilen)."""
        if self.fertig:
            return False
        try:
            self.prozess.stdin.write((text + "\n").encode("utf-8"))
            self.prozess.stdin.flush()
            if echo:
                self._anhaengen(text + "\n")      # Echo, wie in einer Shell
            return True
        except (OSError, ValueError):
            return False

    # Eine Endlosschleife mit print (T10, „eine Zeile weg“) schreibt Megabytes in Sekunden: Der Server behaelt nur
    # das Ende (AUFHEBEN Zeichen), eine Antwort traegt hoechstens LESEN Zeichen -- sonst wuchs der Speicher ohne
    # Grenze, und die Seite fror ein, weil jede Abfrage alles seit der letzten mitbrachte (Messlauf 22.10.).
    AUFHEBEN = 400_000
    LESEN = 40_000

    def _anhaengen(self, text):
        with self._sperre:
            self.ausgabe.append(text)
            self.zeichen += len(text)
            while self.begrenzt and self.zeichen > self.AUFHEBEN and len(self.ausgabe) > 1:
                self.zeichen -= len(self.ausgabe.pop(0))
                self.weg += 1

    def text(self, ab=0):
        """Der Text ab Stueck ab (gezaehlt seit dem Start) und das Ende; zu viel auf einmal kommt gekuerzt, vorn ein
        Vermerk."""
        with self._sperre:
            von = max(ab - self.weg, 0)
            text = "".join(self.ausgabe[von:])
            bis = self.weg + len(self.ausgabe)
            luecke = ab < self.weg
        if self.begrenzt and len(text) > self.LESEN:
            text, luecke = text[-self.LESEN:], True
            if "\n" in text[:2000]:
                text = text[text.index("\n") + 1:]     # an einer Zeilengrenze anfangen
        if luecke:
            text = "\n… (so viel Ausgabe, dass nur das Ende zu sehen ist) …\n" + text
        return text, bis

    def bericht(self, ab=0):
        text, bis = self.text(ab)
        aus = {"id": self.id, "text": text, "bis": bis, "fertig": self.fertig,
               "code": self.code, "gestoppt": self.gestoppt}
        if self.fertig and self.code not in (0, None):
            with self._sperre:
                alles = "".join(self.ausgabe)
            aus["fehler"] = fehler_lesen(alles, self.datei)
        return aus


def starten(datei, **kw):
    lauf = Lauf(datei, **kw)
    with _SPERRE:
        _LAEUFE[lauf.id] = lauf
        # alte, fertige Laeufe vergessen
        for k in [k for k, v in _LAEUFE.items() if v.fertig and time.time() - v.start > 600]:
            del _LAEUFE[k]
    return lauf


def holen(lauf_id):
    return _LAEUFE.get(lauf_id)


def alle_stoppen():
    for lauf in list(_LAEUFE.values()):
        lauf.stopp()


def einmal(befehl, cwd, zeitlimit, env_extra=None, isoliert=True):
    """Ein Unterprozess bis zum Ende, mit Zeitlimit -- fuer Selbstcheck und
    Nachlaufen. Gibt (code, text, zeit_ueberschritten)."""
    env = umgebung()
    if env_extra:
        env.update(env_extra)
    voll = [sys.executable]
    if isoliert:
        voll.append("-I")
    voll += befehl
    try:
        p = subprocess.run(voll, cwd=str(cwd), env=env, capture_output=True,
                           timeout=zeitlimit, stdin=subprocess.DEVNULL)
        return p.returncode, (p.stdout + p.stderr).decode("utf-8", "replace"), False
    except subprocess.TimeoutExpired as e:
        text = ((e.stdout or b"") + (e.stderr or b"")).decode("utf-8", "replace")
        return None, text, True
