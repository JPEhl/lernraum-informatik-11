"""Die Jahresuebersicht des Lehrerpults (Lehrerwunsch 16.10.2026).

Die Uebersicht selbst speichert nichts (Abgaben nur im Speicher). Was der Lehrer davon
fuer das Schuljahr behalten will, uebernimmt er per Knopf: je Person und Thema die Werte,
die die Uebersicht ohnehin ausrechnet -- abgegeben (wann), Sterne nachgerechnet, Ziel,
Pflichtaufgaben ohne Stern, versuchte hoehere Stufen, Hilfen, mit wem, Mini-Exit ja/nein.
Kein Code, keine Abgabe-ZIP, kein Freitext.

Lehrerentscheidungen 16.10.: Klarnamen (B, „die Daten sind in meinem persoenlichen
OneDrive“) -- die Datei liegt in den Spuren des Pults (kurse/<kurs>/_jahr/), wird nie
abgezogen, nie ins Projekt uebernommen. Uebernehmen per Knopf (nie automatisch: sonst
landen Probelaeufe im Schuljahr). Eine neuere Abgabe ersetzt die aeltere, die aeltere
bleibt als Datum stehen; je Thema eine Frist, danach heisst eine Abgabe „verspaetet“.
Die Note gibt der Lehrer ausserhalb -- hier steht nur ihre Grundlage.
"""
import datetime
import json
import pathlib
import re

ORDNER = "_jahr"
DATEI = "schuljahr.json"


def _pfad(Z):
    return pathlib.Path(Z.wurzel) / ORDNER / DATEI


def laden(Z):
    p = _pfad(Z)
    if p.is_file():
        try:
            d = json.loads(p.read_text("utf-8"))
        except ValueError:
            d = None
            kaputt = p.with_suffix(".kaputt.json")
            p.replace(kaputt)              # nie still verwerfen: liegt daneben
        if d:
            d.setdefault("personen", {})
            d.setdefault("eintraege", {})
            d.setdefault("fristen", {})
            return d
    return {"kurs": Z.inhalt.get("kurs", ""), "personen": {}, "eintraege": {}, "fristen": {}}


def speichern(Z, d):
    p = _pfad(Z)
    p.parent.mkdir(parents=True, exist_ok=True)
    d["gespeichert"] = datetime.datetime.now().isoformat(timespec="seconds")
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), "utf-8")
    tmp.replace(p)


def themen(Z):
    """Die Themen des Kurses in Reihenfolge -- die Spalten."""
    aus = []
    for r in Z.inhalt["reihen"]:
        for t in r["themen"]:
            aus.append({"pfad": r["kennung"] + "/" + t["kennung"], "nr": t.get("nr"), "titel": t.get("titel", ""),
                        "mindest": (t.get("uebung") or {}).get("sterne_mindest")})
    return aus


def _eintrag(z):
    """Aus einer Zeile des Uebersicht-Berichts: nur, was fuer das Schuljahr zaehlt."""
    s = z.get("sterne")
    e = {"abgegeben": z.get("abgegeben", ""), "hilfen": z.get("hilfen") or 0, "partner": z.get("partner", ""),
         "miniexit": bool((z.get("miniexit") or "").strip()), "hinweis": z.get("hinweis") or ""}
    if s:
        versucht = []
        for nr, a in (s.get("aufgaben") or {}).items():
            v = max(a.get("versucht") or [0])
            if v > a.get("sterne", 0):
                versucht.append({"nr": nr, "stufe": v})
        e.update(sterne=s.get("summe", 0), max=s.get("max", 0), mindest=s.get("mindest"), geschafft=bool(s.get("geschafft")),
                 ohne_stern=list(s.get("ohne_stern") or []), nachgerechnet=bool(s.get("nachgerechnet")), versucht=versucht)
    sc = z.get("selbstcheck")
    if sc:
        e["selbstcheck"] = [sc.get("passt", 0), sc.get("von", 0)]
    return e


def uebernehmen(Z, uebersicht):
    """Schreibt die geltenden Abgaben der geladenen Uebersicht ins Schuljahr. Nur Personen aus
    der Kursliste (sonst waeren die Namen nicht verlaesslich). Gibt einen Bericht zurueck."""
    if not uebersicht.personen:
        raise ValueError("Erst die Kursliste aus dem Schulportal hineinziehen -- sie macht die Namen verlässlich.")
    bericht = uebersicht.bericht()
    d = laden(Z)
    heute = datetime.date.today().isoformat()
    for p in uebersicht.personen:
        d["personen"].setdefault(p["nachname"] + " " + p["vorname"], {"seit": heute})
    neu = ersetzt = gleich = aelter = 0
    jetzt = datetime.datetime.now().isoformat(timespec="seconds")
    for z in bericht["zeilen"]:
        if z.get("fehlt") or not z.get("thema") or z.get("name") not in d["personen"]:
            continue
        e = _eintrag(z)
        e["uebernommen"] = jetzt
        je = d["eintraege"].setdefault(z["name"], {})
        alt = je.get(z["thema"])
        if alt is None:
            neu += 1
        elif e["abgegeben"] > alt.get("abgegeben", ""):
            e["frueher"] = (alt.get("frueher") or []) + [alt.get("abgegeben", "")]     # Nachabgabe: die alte bleibt als Datum
            ersetzt += 1
        elif e["abgegeben"] == alt.get("abgegeben", ""):
            e["frueher"] = alt.get("frueher") or []
            gleich += 1                     # dieselbe Abgabe noch einmal (z.B. jetzt nachgelaufen)
        else:
            aelter += 1                     # eine aeltere Abgabe ersetzt nie eine neuere
            continue
        je[z["thema"]] = e
    d["zuletzt"] = jetzt
    speichern(Z, d)
    return {"neu": neu, "ersetzt": ersetzt, "gleich": gleich, "aelter": aelter, "personen": len(d["personen"])}


def frist(Z, thema, datum):
    if thema not in {t["pfad"] for t in themen(Z)}:
        raise ValueError("Dieses Thema gibt es nicht.")
    d = laden(Z)
    if datum:
        if not re.fullmatch(r"\d{4}-\d\d-\d\d", datum):
            raise ValueError("Datum als JJJJ-MM-TT.")
        d["fristen"][thema] = datum
    else:
        d["fristen"].pop(thema, None)
    speichern(Z, d)
    return d


def entfernen(Z, name, thema):
    d = laden(Z)
    je = d["eintraege"].get(name) or {}
    if thema in je:
        del je[thema]
        speichern(Z, d)
    return d
