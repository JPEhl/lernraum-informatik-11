"""Der lokale Server der Arbeitsseite -- http.server aus der Standardbibliothek.

Sicherheit (KONZEPT Block 6, so macht es Jupyter):
  * bindet NUR an 127.0.0.1, zufaelliger Port
  * Zufallsschluessel je Start: steht einmal in der Startadresse (?k=...),
    wird Cookie (HttpOnly, SameSite=Strict); jede Anfrage ohne ihn: 403
  * jede schreibende oder ausfuehrende Anfrage (POST /api/...) prueft
    zusaetzlich den Origin-Header gegen die eigene Adresse
  * ausgeliefert werden nur Dateien unterhalb des Lernraums, und davon
    nur Seite, Bilder und HTML-Arbeitsdateien; alles andere geht ueber die API
  * Content-Security-Policy default-src 'self': kein Fremdzugriff, auch nicht
    aus Versehen (K5 prueft die Meta-Zeile der Seite)
"""
import base64
import datetime
import functools
import http.server
import json
import mimetypes
import os
import pathlib
import secrets
import shutil
import socket
import sys
import threading
import time
import urllib.parse
import webbrowser
import zipfile

from . import aktualisieren as akt, ausfuehren, chiffre, stand as standmodul, werkbuch as werkbuchmodul

HIER = pathlib.Path(__file__).resolve().parent
STATISCH_ERLAUBT = ("_system/seite/",)
TEXTENDUNGEN = (".py", ".html", ".txt", ".md", ".css", ".js", ".json")


class Pult:
    """Was dem ganzen Pult gehoert, nicht einem Kurs: Schluessel, Port, Server, Beamer.

    Ein Lehrerpult traegt mehrere Kurse (Lehrerentscheidung 14.10.2026): _system/pult.json
    nennt sie in Reihenfolge, jeder wohnt in kurse/<kurs>/ mit eigenen Themen, eigener
    Regie und eigenen lebenden Daten (_durchsicht/, _stand/, abgaben/). Offen ist immer
    genau einer; gewechselt wird nur bei Beamer AUS. Ein Lernraum (Schuelerfassung) ist
    ein Pult mit genau einem Kurs, dessen Wurzel die Pult-Wurzel ist."""

    def __init__(self, wurzel):
        self.wurzel = pathlib.Path(wurzel).resolve()
        self.beamer = False
        self.schluessel = secrets.token_urlsafe(24)
        self.port = None
        self.server = None
        self.start = time.time()
        pj = self.wurzel / "_system" / "pult.json"
        self.mehrere = pj.exists()
        if self.mehrere:
            liste = json.loads(pj.read_text("utf-8"))["kurse"]
            self.kurse = {e["kurs"]: Zustand(self.wurzel / e["ordner"], self) for e in liste}
        else:
            z = Zustand(self.wurzel, self)
            self.kurse = {z.kurs: z}
        self.aktiv = next(iter(self.kurse))

    @property
    def z(self):
        return self.kurse[self.aktiv]

    def liste(self):
        return [{"kurs": k, "titel": z.inhalt.get("titel", k), "untertitel": z.inhalt.get("untertitel", "")}
                for k, z in self.kurse.items()]

    def seite(self, rel):
        """Eine Datei der Seite (_system/seite/...) -- sie gehoert dem Pult, nicht einem Kurs."""
        try:
            voll = (self.wurzel / rel).resolve()
            voll.relative_to(self.wurzel / "_system" / "seite")
        except (ValueError, OSError):
            return None
        return voll


def _beim_pult(name):
    return property(lambda self: getattr(self.pult, name), lambda self, v: setattr(self.pult, name, v))


class Zustand:
    """Ein Kurs: seine Themen, sein Stand, seine Uebersicht, seine Durchsicht."""
    beamer = _beim_pult("beamer")
    schluessel = _beim_pult("schluessel")
    port = _beim_pult("port")
    server = _beim_pult("server")
    start = _beim_pult("start")

    def __init__(self, wurzel, pult):
        self.pult = pult
        self.wurzel = pathlib.Path(wurzel).resolve()
        self.inhalt = json.loads((self.wurzel / "_system" / "inhalt.json").read_text("utf-8"))
        self.kurs = self.inhalt.get("kurs", "")
        self.fassung = self.inhalt.get("fassung", "schueler")
        self.lehrer = self.fassung == "lehrer"
        hilfen = self.wurzel / "_system" / "hilfen.json"
        self.hilfen = json.loads(hilfen.read_text("utf-8")) if hilfen.exists() else {}
        stoff = self.wurzel / "_system" / "pruefstoff.json"     # B2: Puzzle-Reihenfolge, Fehlerzeilen der Faelle
        self.pruefstoff = json.loads(stoff.read_text("utf-8")) if stoff.exists() else {}
        self.stand = standmodul.Stand(self.wurzel, self.kurs)
        self.uebersicht = None           # nur im Speicher: schliessen = weg
        self.besprechung = []            # anonymisierte Stuecke
        self.aufzeichnungen = {}
        self.akt_info = None             # fassung.json, zuletzt gesucht
        self.akt_eingang = None          # SHA-256 der geprueften Eingangs-ZIP

    # -- Themen finden -----------------------------------------------------
    def thema(self, kennung):
        """kennung = "<reihe>/<thema>" -> (reihe, thema) oder (None, None)."""
        try:
            r, t = kennung.split("/", 1)
        except ValueError:
            return None, None
        for reihe in self.inhalt["reihen"]:
            if reihe["kennung"] == r:
                for thema in reihe["themen"]:
                    if thema["kennung"] == t:
                        return reihe, thema
        return None, None

    def themenordner(self, kennung):
        return self.wurzel / "themen" / kennung

    def rel(self, pfad):
        """Einen Pfad relativ zur Wurzel sicher aufloesen -- oder None."""
        try:
            voll = (self.wurzel / pfad).resolve()
            voll.relative_to(self.wurzel)
        except (ValueError, OSError):
            return None
        return voll

    def darf_schreiben(self, relpfad):
        """Nur Arbeitsdateien: die Arbeitsdatei eines Themas und die
        Arbeitskopien der Codeschritte (nicht _start/_ziel, nie pruefung.py,
        nie loesung*)."""
        p = pathlib.PurePosixPath(relpfad.replace("\\", "/"))
        if len(p.parts) < 4 or p.parts[0] != "themen":
            return False
        name = p.name
        if name.startswith("loesung") or name == "pruefung.py" or name.endswith(("_start.py", "_ziel.py", "_start.html", "_ziel.html")):
            return False
        return p.suffix in (".py", ".html", ".txt")

    def darf_lesen(self, relpfad):
        p = pathlib.PurePosixPath(relpfad.replace("\\", "/"))
        if p.parts and p.parts[0] == "themen":
            if p.name.startswith("loesung") and not self.lehrer:
                return False
            return p.suffix in TEXTENDUNGEN
        if self.lehrer and p.parts and p.parts[:2] == ("_system", "lehrer"):
            return True
        return False


class _Offen:
    """Z: der Zustand des gerade offenen Kurses. Jede Stelle, die Z.<x> liest oder
    setzt, meint ihn -- nach einem Kurswechsel den neuen. Wer sich einen Kurs MERKT
    (die Uebersicht), bekommt P.z, nie Z."""
    def __getattr__(self, name):
        return getattr(P.z, name)

    def __setattr__(self, name, wert):
        setattr(P.z, name, wert)


P = None        # das Pult (ein Lernraum ist ein Pult mit einem Kurs)
Z = _Offen()    # der offene Kurs
def cookie_name():
    """Der Name des Anmelde-Cookies: je Port ein eigener (siehe _cookie_schluessel)."""
    return "k%d" % (Z.port or 0)


# Anfragen, die auch dann gelten, wenn die Seite noch einen anderen Kurs zeigt
KURSFREI = {"inhalt", "kurs/waehlen", "system", "beenden", "beamer"}


class Antwort(Exception):
    def __init__(self, status, text):
        self.status, self.text = status, text


def api(name=None, post=True, lehrer=False, ohne_beamer=False):
    def deko(f):
        f._api = (name or f.__name__.replace("api_", "").replace("_", "/"), post, lehrer, ohne_beamer)
        return f
    return deko


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "Lernraum/1"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):   # still, ausser bei --laut
        if getattr(self.server, "laut", False):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    # -- Helfer --------------------------------------------------------------
    def _senden(self, status, inhalt: bytes, typ="text/html; charset=utf-8", extra=None):
        self.send_response(status)
        self.send_header("Content-Type", typ)
        self.send_header("Content-Length", str(len(inhalt)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(inhalt)

    def _json(self, daten, status=200):
        self._senden(status, json.dumps(daten, ensure_ascii=False).encode("utf-8"),
                     "application/json; charset=utf-8")

    def _text(self, status, text):
        self._senden(status, text.encode("utf-8"), "text/plain; charset=utf-8")

    def _cookie_schluessel(self):
        """Das Cookie heisst nach dem Port (k8790, k8791): Der Browser trennt Cookies nicht nach Port,
        und zwei Server auf 127.0.0.1 -- Pult und Lernraum, zwei Lernraeume -- ueberschrieben sich
        sonst gegenseitig das „k“; der zuerst geoeffnete Tab blieb bei „Die Seite laedt“ stehen
        (Lehrer 17.10.). Das alte „k“ gilt nur noch, wenn das eigene fehlt (Skripte, Tests)."""
        werte = {}
        for teil in self.headers.get("Cookie", "").split(";"):
            k, _, v = teil.strip().partition("=")
            werte.setdefault(k, v)
        return werte.get(cookie_name(), werte.get("k", self.headers.get("X-Schluessel", "")))

    def _angemeldet(self):
        return secrets.compare_digest(self._cookie_schluessel(), Z.schluessel)

    def _eigene_adresse(self):
        return "http://127.0.0.1:%d" % Z.port

    # -- GET -----------------------------------------------------------------
    def do_GET(self):
        url = urllib.parse.urlsplit(self.path)
        pfad = urllib.parse.unquote(url.path)
        frage = urllib.parse.parse_qs(url.query)
        if pfad == "/" and "k" in frage:
            if secrets.compare_digest(frage["k"][0], Z.schluessel):
                self.send_response(303)
                self.send_header("Set-Cookie", "%s=%s; Path=/; HttpOnly; SameSite=Strict" % (cookie_name(), Z.schluessel))
                self.send_header("Location", "/")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            return self._text(403, "Der Schluessel stimmt nicht. Bitte start.py neu starten.")
        if not self._angemeldet():
            return self._senden(403, SPERRSEITE.encode("utf-8"))
        if pfad == "/":
            return self._datei(P.wurzel / "_system" / "seite" / "index.html")
        if pfad.startswith("/api/"):
            return self._api(pfad[5:], None)
        rel = pfad.lstrip("/")
        voll = P.seite(rel) if rel.startswith(STATISCH_ERLAUBT) else Z.rel(rel)
        if voll is None or not voll.is_file():
            return self._text(404, "Nicht gefunden.")
        erlaubt = rel.startswith(STATISCH_ERLAUBT) \
            or (rel.startswith("themen/") and "/bilder/" in rel) \
            or (rel.startswith("themen/") and rel.endswith(".html") and not pathlib.Path(rel).name.startswith("loesung")) \
            or (rel.startswith("abgaben/") and rel.endswith(".zip")) \
            or (rel.startswith("_stand/") and rel.endswith(".zip")) \
            or (Z.lehrer and rel.startswith("_system/lehrer/") and not Z.beamer)
        if not erlaubt:
            return self._text(403, "Diese Datei liefert der Server nicht aus.")
        return self._datei(voll)

    def _datei(self, voll):
        typ, _ = mimetypes.guess_type(str(voll))
        typ = typ or "application/octet-stream"
        if typ.startswith("text/") or typ in ("application/javascript", "application/json"):
            typ += "; charset=utf-8"
        daten = voll.read_bytes()
        extra = {}
        if voll.suffix == ".html":
            try:
                rel = voll.relative_to(Z.wurzel).as_posix()
            except ValueError:
                rel = ""                  # die Seite selbst (gehoert dem Pult)
            if rel.startswith("themen/"):
                # HTML-Arbeitsdateien der Klasse (E.2-Vorgriff): Stil erlaubt,
                # Skripte nie -- die Vorschau ist eine Seite, kein Programm.
                extra["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'self'"
            else:
                # style-src 'unsafe-inline': CodeMirror fuegt sein Stylesheet
                # selbst ein (style-mod). Skripte bleiben strikt 'self'.
                extra["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-src 'self'; frame-ancestors 'self'"
        if voll.suffix == ".zip":
            extra["Content-Disposition"] = 'attachment; filename="%s"' % voll.name
        self._senden(200, daten, typ, extra)

    # -- POST ----------------------------------------------------------------
    def do_POST(self):
        pfad = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
        if not self._angemeldet():
            return self._json({"fehler": "nicht angemeldet -- start.py neu starten"}, 403)
        if self.headers.get("Origin", "") != self._eigene_adresse():
            return self._json({"fehler": "Anfrage von fremder Herkunft abgelehnt"}, 403)
        laenge = int(self.headers.get("Content-Length") or 0)
        if laenge > 64 * 1024 * 1024:
            return self._json({"fehler": "zu gross"}, 413)
        roh = self.rfile.read(laenge) if laenge else b"{}"
        try:
            daten = json.loads(roh.decode("utf-8") or "{}")
        except ValueError:
            return self._json({"fehler": "kein JSON"}, 400)
        if not pfad.startswith("/api/"):
            return self._json({"fehler": "unbekannt"}, 404)
        return self._api(pfad[5:], daten)

    def _api(self, name, daten):
        f = API.get(name)
        if f is None:
            return self._json({"fehler": "unbekannte Anfrage: " + name}, 404)
        _, post, lehrer, ohne_beamer = f._api
        if post and daten is None:
            return self._json({"fehler": "nur POST"}, 405)
        if lehrer and not Z.lehrer:
            return self._json({"fehler": "nur in der Lehrerfassung"}, 403)
        # Die Seite sagt, welchen Kurs sie zeigt. Ist inzwischen ein anderer offen
        # (zweiter Tab, Wechsel), wird nichts in den falschen Kurs geschrieben.
        kurs = self.headers.get("X-Kurs", "")
        if kurs and kurs != P.aktiv and name not in KURSFREI:
            return self._json({"fehler": "Im Pult ist inzwischen ein anderer Kurs offen.",
                               "kurs_gewechselt": True, "aktiv": P.aktiv}, 409)
        if ohne_beamer and Z.beamer:
            return self._json({"fehler": "Beamer ist an -- erst ausschalten"}, 423)
        try:
            return self._json(f(daten if daten is not None else {}))
        except Antwort as a:
            return self._json({"fehler": a.text}, a.status)
        except Exception as e:  # noqa: BLE001 -- die Seite soll den Fehler sehen
            import traceback
            return self._json({"fehler": "%s: %s" % (type(e).__name__, e),
                               "wo": traceback.format_exc()[-800:]}, 500)


SPERRSEITE = """<!doctype html><meta charset="utf-8"><title>Lernraum</title>
<body style="font-family:system-ui;max-width:36em;margin:4em auto;line-height:1.5">
<h1>Diese Seite gehört zu einem laufenden start.py</h1>
<p>Die Adresse gilt nur mit dem Schlüssel aus der Thonny-Shell. Bitte
<b>start.py</b> in Thonny mit F5 starten (oder neu starten) — der Browser
geht dann von selbst auf.</p></body>"""


# ======================================================================
#  Die API. Jede Funktion bekommt das JSON der Anfrage und gibt JSON zurueck.
# ======================================================================
API = {}


def _reg(f):
    API[f._api[0]] = f
    return f


@_reg
@api("inhalt", post=False)
def api_inhalt(d):
    inhalt = dict(Z.inhalt)
    if Z.beamer:
        inhalt = _ohne_lehrerteile(inhalt)
    return {"inhalt": inhalt, "lehrer": Z.lehrer, "beamer": Z.beamer,
            "stand": Z.stand.oeffentlich() if not Z.beamer else _stand_ohne_namen(),
            "python": sys.version.split()[0], "wurzel": str(Z.wurzel),
            "kurs": P.aktiv, "kurse": P.liste() if Z.lehrer else [], "pult": P.mehrere}


@_reg
@api("kurs/waehlen", lehrer=True, ohne_beamer=True)
def api_kurs_waehlen(d):
    """Den offenen Kurs wechseln -- nur bei Beamer AUS (sonst 423, siehe api()):
    am Beamer wechselt nie unbemerkt der Kurs."""
    kurs = str(d.get("kurs", ""))
    if kurs not in P.kurse:
        raise Antwort(404, "Diesen Kurs traegt das Pult nicht: " + kurs)
    P.aktiv = kurs
    return {"kurs": kurs}


def _stand_ohne_namen():
    s = dict(Z.stand.daten)
    s["name"] = s["vorname"] = s["nachname"] = ""
    s["partner"] = {}
    return s


def _ohne_lehrerteile(inhalt):
    """Bei Beamer AN: Kennwoerter raus (die Regie bleibt, sie ist nur ein Reiter)."""
    inhalt = json.loads(json.dumps(inhalt))
    for r in inhalt["reihen"]:
        for t in r["themen"]:
            t.pop("kennwort", None)
    return inhalt


def _nicht_im_pult(was):
    """Name, Partner und Stand-ZIPs gehoeren der Klasse (Lehrer 17.10.: „Warum kann ich in der
    Lehrerversion meinen Namen eingeben und Staende einlesen?“) -- das Pult gibt nichts ab."""
    if Z.lehrer:
        raise Antwort(403, "Im Lehrerpult gibt es %s -- das gehört zum Lernraum der Klasse." % was)


def _partner_setzen(d):
    pv = str(d.get("partner_vorname", "")).strip()[:60]
    pn = str(d.get("partner_nachname", "")).strip()[:60]
    Z.stand.daten["partner"] = {"vorname": pv, "nachname": pn, "name": (pv + " " + pn).strip()} if (pv or pn) else {}


@_reg
@api("stand/name")
def api_stand_name(d):
    _nicht_im_pult("keinen eigenen Namen")
    Z.stand.daten["vorname"] = str(d.get("vorname", "")).strip()[:60]
    Z.stand.daten["nachname"] = str(d.get("nachname", "")).strip()[:60]
    Z.stand.daten["name"] = (Z.stand.daten["vorname"] + " " + Z.stand.daten["nachname"]).strip()
    # Die Partnerin wird seit dem 17.10. bei der Abgabe eingetragen (stand/partner); ein alter Aufruf
    # mit Partnerfeldern setzt sie weiter, einer ohne laesst sie stehen.
    if "partner_vorname" in d or "partner_nachname" in d:
        _partner_setzen(d)
    Z.stand.speichern()
    return {"ok": True, "stand": Z.stand.daten}


@_reg
@api("stand/partner")
def api_stand_partner(d):
    """Partnerarbeit (Weg 3, 13.10.; Ort seit 17.10. die Abgabe): wer mit dir gearbeitet hat --
    gefragt, wenn es zaehlt, vorbelegt mit dem letzten. Leer = allein."""
    _nicht_im_pult("keine Partner*in")
    _partner_setzen(d)
    Z.stand.speichern()
    return {"ok": True, "stand": Z.stand.daten}


@_reg
@api("stand/lesestelle")
def api_stand_lesestelle(d):
    Z.stand.daten["lesestelle"][str(d.get("thema", ""))] = d.get("wo", {})
    Z.stand.speichern()
    return {"ok": True}


@_reg
@api("unterricht/lesezeichen", lehrer=True)
def api_unterricht_lesezeichen(d):
    """Das Lesezeichen (Lehrer 19.10., Fassung A: „manuell einstellen … nach jeder Stunde als kleinen
    Marker“): Ein Klick auf „Hier aufgehört“ merkt je Thema die Stelle (Reiter, Vortragsschritt,
    Fahrplan-Marker) mit Datum und macht sie zu „Beim naechsten Mal weiter“; weg=True nimmt es wieder
    weg. Von selbst merkt das Pult nichts mehr -- bis dahin merkte es jedes Oeffnen (16.10.; ab 17.10.
    mit Stundenplan nur in der Stunde), und ohne Stundenplan stand die Vorbereitung als Unterricht da."""
    thema = str(d.get("thema", ""))
    reiter = str(d.get("reiter", ""))
    if not thema or reiter not in ("vortrag", "erklaerung", "uebung", "werkstatt", "loesung"):
        raise Antwort(400, "Thema oder Reiter fehlt")
    u = Z.stand.daten.setdefault("unterricht", {"themen": {}, "zuletzt": ""})
    themen = u.setdefault("themen", {})
    if d.get("weg"):
        themen.pop(thema, None)
        if u.get("zuletzt") == thema:
            u["zuletzt"] = ""
    else:
        t = {"zeit": standmodul.jetzt(), "reiter": reiter}
        if reiter == "vortrag":
            try:
                t["schritt"] = max(1, int(d.get("schritt") or 1))
            except (TypeError, ValueError):
                t["schritt"] = 1
            m = d.get("marker")
            t["marker"] = int(m) if isinstance(m, int) and m > 0 else 0
        themen[thema] = t
        u["zuletzt"] = thema
    Z.stand.speichern()
    return {"ok": True, "unterricht": u}


@_reg
@api("stand/aufgabe")
def api_stand_aufgabe(d):
    """Haken (✓ ✎ ?), Mini-Exit, Notizen -- alles, was die Seite je Aufgabe merkt."""
    kennung = str(d.get("kennung", ""))
    if not kennung:
        raise Antwort(400, "Aufgabenkennung fehlt")
    werte = {k: v for k, v in d.items() if k in ("haken", "miniexit", "notiz")}
    return {"ok": True, "aufgabe": Z.stand.eintragen(kennung, **werte)}


@_reg
@api("stand/frage")
def api_stand_frage(d):
    """Eine Wahl bei einer Prueffrage der Erklaerung. Ob sie stimmt, sagt der Inhalt
    (bauen.py: thema['fragen'][name]['richtig']) -- nicht die Seite."""
    kennung = str(d.get("kennung", ""))
    thema_k, _, name = kennung.rpartition("/")
    _, thema = Z.thema(thema_k)
    f = (thema or {}).get("fragen", {}).get(name)
    if f is None:
        raise Antwort(404, "Diese Frage gibt es nicht: " + kennung)
    try:
        wahl = int(d.get("wahl", -1))
    except (TypeError, ValueError):
        raise Antwort(400, "Wahl fehlt")
    richtig = frage_richtig(kennung)
    return {"ok": True, "richtig": wahl == richtig, "frage": Z.stand.frage(kennung, wahl, wahl == richtig)}


def frage_richtig(kennung):
    """Die richtige Wahl -- aus dem Fingerabdruck im Pruefstoff (16.10.: nicht mehr im Inhalt
    der Schuelerfassung)."""
    from .abdruck import wahl_abdruck
    q = (Z.pruefstoff.get("fragen") or {}).get(kennung) or {}
    return next((i for i in range(q.get("wahlen", 0)) if wahl_abdruck(kennung, i) == q.get("abdruck")), None)


@_reg
@api("stand/stufe")
def api_stand_stufe(d):
    """Beispiel in Stufen: welche Stufe offen ist, und ob die Luecken gestimmt haben."""
    kennung = str(d.get("kennung", ""))
    thema_k, _, name = kennung.rpartition("/")
    _, thema = Z.thema(thema_k)
    st = (thema or {}).get("stufen", {}).get(name)
    if st is None:
        raise Antwort(404, "Dieses Beispiel gibt es nicht: " + kennung)
    einzeln = None
    if "antworten" in d:
        antworten = [str(x) for x in (d.get("antworten") or [])] + [""] * len(st["loesungen"])
        einzeln = [luecke_stimmt(a, l) for a, l in zip(antworten, st["loesungen"])]
    stufe = d.get("stufe")
    return {"ok": True, "einzeln": einzeln,
            "stufe": Z.stand.stufe(kennung, stufe if isinstance(stufe, int) else None, bool(einzeln) and all(einzeln))}


@_reg
@api("stand/puzzle")
def api_stand_puzzle(d):
    """Parsons-Puzzle: die Seite schickt die Zeilen IHRES Programms (Text, in Reihenfolge), der
    Server sagt nur, wie viele noch nicht stimmen -- nicht welche (Galerie Rang 8)."""
    kennung = str(d.get("kennung", ""))
    p = Z.pruefstoff.get("parsons", {}).get(kennung)
    if p is None:
        raise Antwort(404, "Dieses Puzzle gibt es nicht: " + kennung)
    programm = [str(x) for x in (d.get("reihenfolge") or [])][:60]
    falsch = puzzle_falsch(programm, puzzle_zeilen(kennung, p))
    return {"ok": True, "falsch": falsch, "geloest": falsch == 0,
            "puzzle": Z.stand.puzzle(kennung, falsch, falsch == 0, programm)}


def puzzle_zeilen(kennung, p):
    """Die Reihenfolge eines Puzzles -- verschleiert im Pruefstoff (16.10.)."""
    from .abdruck import entschleiern
    return json.loads(entschleiern(kennung, "parsons", p["geheim"]))


def puzzle_falsch(programm, loesung):
    """Wie viele Zeilen noch nicht stimmen: Zeilen im Programm, die nicht zur laengsten richtig
    geordneten Folge gehoeren (falscher Platz, Ablenker), plus Zeilen der Loesung, die noch ganz
    fehlen. Eine verrutschte Zeile zaehlt so einmal, nicht fuer jede Zeile danach."""
    n, m = len(programm), len(loesung)
    t = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n):
        for j in range(m):
            t[i + 1][j + 1] = t[i][j] + 1 if programm[i] == loesung[j] else max(t[i][j + 1], t[i + 1][j])
    gemeinsam = t[n][m]
    rest = list(programm)
    fehlen = 0
    for z in loesung:
        if z in rest:
            rest.remove(z)
        else:
            fehlen += 1
    return (n - gemeinsam) + fehlen


@_reg
@api("sterne")
def api_sterne(d):
    """Sterne der Themen (Lehrer 16.10.): eines (thema) oder alle -- dieselbe Rechnung wie in der
    Uebersicht, hier aus dem Stand dieses Lernraums."""
    from .sterne import thema_sterne
    aus = {}
    for r in Z.inhalt["reihen"]:
        for t in r["themen"]:
            pfad = r["kennung"] + "/" + t["kennung"]
            if d.get("thema") and d["thema"] != pfad:
                continue
            if any(a.get("sterne") for a in t["uebung"]["aufgaben"]):
                aus[pfad] = thema_sterne(pfad, t, Z.stand.daten, Z.pruefstoff)
    return {"sterne": aus}


@_reg
@api("stand/vorhersage")
def api_stand_vorhersage(d):
    """Vorhersage: die Seite schickt die Antworten, der Server sagt je Feld, ob sie stimmt. Die
    richtigen Antworten stehen nur im Pruefstoff, nie in der Seite."""
    kennung = str(d.get("kennung", ""))
    v = Z.pruefstoff.get("vorhersagen", {}).get(kennung)
    if v is None:
        raise Antwort(404, "Diese Vorhersage gibt es nicht: " + kennung)
    from .abdruck import antwort_stimmt
    antworten = [str(x) for x in (d.get("antworten") or [])][:40] + [""] * len(v["abdruecke"])
    einzeln = [antwort_stimmt(kennung, a, abd) for a, abd in zip(antworten, v["abdruecke"])]
    return {"ok": True, "einzeln": einzeln, "geloest": all(einzeln),
            "vorhersage": Z.stand.vorhersage(kennung, antworten[:len(einzeln)], einzeln)}


def plan_finden(kennung):
    """kennung = <reihe>/<thema>/<name> -> die Faelle aus dem Thema (oder None)."""
    pfad, _, name = kennung.rpartition("/")
    _, th = Z.thema(pfad)
    return ((th or {}).get("plaene") or {}).get(name)


@_reg
@api("stand/plan")
def api_stand_plan(d):
    """Plan (19.10.2026): die Seite schickt das Struktogramm (Sprache von struktogramm.py). Mit
    proben=True laeuft es mit den Faellen der Aufgabe -- gerechnet HIER (kursserver/plan.py), mit
    demselben Laeufer, der die Sterne im Pult aus der Abgabe nachrechnet."""
    from . import plan as planlauf
    kennung = str(d.get("kennung", ""))
    spec = plan_finden(kennung)
    if spec is None:
        raise Antwort(404, "Diesen Plan gibt es nicht: " + kennung)
    quelle, titel = str(d.get("quelle", ""))[:20000], str(d.get("titel", ""))[:200]
    ergebnis = planlauf.pruefen(quelle, spec["proben"]) if d.get("proben") else None
    return {"ok": True, "ergebnis": ergebnis, "plan": Z.stand.plan(kennung, quelle, titel, ergebnis)}


@_reg
@api("stand/fall")
def api_stand_fall(d):
    """Fall (Debug-Detektiv): die Seite schickt die verdaechtigten Zeilen, der Server sagt je
    Zeile Treffer (mit Befund) oder sauber. Ohne Verdacht: nur die Akte lesen (zaehlt nichts)."""
    kennung = str(d.get("kennung", ""))
    f = Z.pruefstoff.get("faelle", {}).get(kennung)
    if f is None:
        raise Antwort(404, "Diesen Fall gibt es nicht: " + kennung)
    try:
        verdacht = sorted({int(z) for z in (d.get("verdacht") or [])})[:60]
    except (TypeError, ValueError):
        raise Antwort(400, "Verdacht unlesbar")
    from .abdruck import zeile_abdruck, entschleiern
    zahl = f["zahl"]
    ist_fehler = lambda z: zeile_abdruck(kennung, z) in f["befunde"]
    # Hoechstens so viele Verdachte auf einmal, wie Fehler noch offen sind -- sonst findet, wer
    # alles anklickt, alles (Lehrer 16.10., Durchsicht T3). Die Seite sperrt vorher; das hier
    # ist die Sperre, auf die es ankommt.
    schon = {z for z in (Z.stand.daten.get("faelle") or {}).get(kennung, {}).get("gefunden", []) if ist_fehler(z)}
    neu = [z for z in verdacht if z not in schon]
    if len(neu) > zahl - len(schon):
        raise Antwort(400, "Höchstens %d Verdacht%s auf einmal – so viele Fehler sind noch offen."
                      % (zahl - len(schon), "" if zahl - len(schon) == 1 else "e"))
    treffer = [z for z in verdacht if ist_fehler(z)]
    sauber = [z for z in verdacht if not ist_fehler(z)]
    akte = Z.stand.fall(kennung, treffer, len(sauber)) if verdacht else (Z.stand.daten.get("faelle") or {}).get(kennung, {})
    gefunden = akte.get("gefunden", [])
    # Befundtexte sind mit ihrer Zeile verschleiert: lesbar erst, wenn die Zeile gefunden ist
    return {"ok": True, "treffer": treffer, "sauber": sauber, "zahl": zahl,
            "befunde": {str(z): entschleiern(kennung, "z%d" % z, f["befunde"][zeile_abdruck(kennung, z)]) for z in gefunden if ist_fehler(z)},
            "code": f["code"] if verdacht or gefunden or akte.get("versuche") else "", "akte": akte}


@_reg
@api("stand/fehlernotiz")
def api_stand_fehlernotiz(d):
    """Mein Fehlerbuch: die eigene Notiz zu einer Fehlerart."""
    e = Z.stand.fehlernotiz(str(d.get("art", "")), str(d.get("notiz", "")).strip())
    if e is None:
        raise Antwort(404, "Diese Fehlerart steht nicht im Fehlerbuch.")
    return {"ok": True, "eintrag": e}


RUNDEN = {1: "Mitte der Reihe", 2: "Ende der Reihe", 3: "vor der Klausur"}


def raster_saetze(reihe_k=None):
    """{<reihe>/<satz>: (reihe, satz)} aus dem Kompetenzraster im Inhalt."""
    aus = {}
    for r in Z.inhalt.get("reihen", []):
        if reihe_k and r["kennung"] != reihe_k:
            continue
        for g in r.get("raster") or []:
            for s in g["saetze"]:
                aus[r["kennung"] + "/" + s["kennung"]] = (r, s)
    return aus


@_reg
@api("stand/einschaetzung")
def api_stand_einschaetzung(d):
    """„Ich kann …“ (Galerie Rang 11, Lehrer 16.10.: vier Stufen, drei Runden, nur anonym gezaehlt):
    Stufe 1-4 je Satz und Runde, 0 nimmt sie zurueck. Nur die Klasse -- das Pult schaetzt nichts ein."""
    if Z.lehrer:
        raise Antwort(403, "Im Lehrerpult schätzt niemand sich ein -- die Zählung der Klasse steht in der Übersicht.")
    kennung = str(d.get("kennung", ""))
    if kennung not in raster_saetze():
        raise Antwort(404, "Diesen Satz gibt es nicht: " + kennung)
    try:
        runde, stufe = int(d.get("runde")), int(d.get("stufe"))
    except (TypeError, ValueError):
        raise Antwort(400, "Runde und Stufe fehlen")
    if runde not in RUNDEN or not 0 <= stufe <= 4:
        raise Antwort(400, "Runde 1-3, Stufe 0-4")
    return {"ok": True, "eintrag": Z.stand.einschaetzen(kennung, runde, stufe)}


@_reg
@api("stand/lernkarte")
def api_stand_lernkarte(d):
    """Lernkarten (Galerie Rang 15, 16.10.): „Wusste ich“ / „Noch nicht“ zu einer Karte. Fach und wann sie
    wieder dran ist, rechnet der Stand (stand.lernkarte). Nur die Klasse -- im Pult sind sie zum Ansehen."""
    if Z.lehrer:
        raise Antwort(403, "Im Lehrerpult übt niemand -- die Karten sind hier nur zum Ansehen.")
    kennung = str(d.get("kennung", ""))
    if not any(c["id"] == kennung for c in Z.inhalt.get("lernkarten") or []):
        raise Antwort(404, "Diese Karte gibt es nicht: " + kennung)
    if not isinstance(d.get("gewusst"), bool):
        raise Antwort(400, "gewusst: true oder false")
    return {"ok": True, "eintrag": Z.stand.lernkarte(kennung, d["gewusst"])}


def luecke_stimmt(antwort, loesung):
    """Gleich bis auf Leerzeichen ausserhalb von Text und die Art der geraden Anfuehrungszeichen
    (' oder ", beides ist Python). Typografische Anfuehrungszeichen bleiben falsch -- die
    versteht Python nicht. Die Seite fragt hier nach, je Luecke."""
    def normal(t):
        aus, innen = [], None
        for c in t.strip():
            if innen:
                aus.append('"' if c == innen else c)
                if c == innen:
                    innen = None
            elif c in "\"'":
                innen = c
                aus.append('"')
            elif not c.isspace():
                aus.append(c)
        return "".join(aus)
    return normal(antwort) == normal(loesung)


@_reg
@api("datei/lesen")
def api_datei_lesen(d):
    rel = str(d.get("pfad", ""))
    voll = Z.rel(rel)
    if voll is None or not Z.darf_lesen(rel):
        raise Antwort(403, "Diese Datei gibt der Server nicht heraus: " + rel)
    if not voll.is_file():
        raise Antwort(404, "Datei fehlt: " + rel)
    return {"pfad": rel, "text": voll.read_text("utf-8", errors="replace"),
            "zeit": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(voll.stat().st_mtime))}


@_reg
@api("datei/schreiben")
def api_datei_schreiben(d):
    rel = str(d.get("pfad", ""))
    voll = Z.rel(rel)
    if voll is None or not Z.darf_schreiben(rel):
        raise Antwort(403, "Diese Datei darf die Seite nicht schreiben: " + rel)
    text = str(d.get("text", ""))
    if voll.exists() and voll.read_text("utf-8", errors="replace") == text:
        return {"ok": True, "unveraendert": True}
    voll.parent.mkdir(parents=True, exist_ok=True)
    standmodul.schreiben(voll, text)        # ganz oder gar nicht, mit Wiederholung (OneDrive, 25.10.)
    return {"ok": True}


@_reg
@api("datei/zuruecksetzen")
def api_datei_zuruecksetzen(d):
    """Codeschritt: Arbeitskopie <- _start (zurueck) oder <- _ziel (aufdecken)."""
    rel = str(d.get("pfad", ""))
    quelle = str(d.get("auf", "start"))
    voll = Z.rel(rel)
    if voll is None or not Z.darf_schreiben(rel) or quelle not in ("start", "ziel"):
        raise Antwort(403, "nicht erlaubt")
    von = voll.with_name(voll.stem + "_" + quelle + voll.suffix)
    if not von.exists():
        raise Antwort(404, "Vorlage fehlt: " + von.name)
    shutil.copyfile(von, voll)
    return {"ok": True, "text": voll.read_text("utf-8", errors="replace")}


# -- Ausfuehren ----------------------------------------------------------------
@_reg
@api("lauf/start")
def api_lauf_start(d):
    rel = str(d.get("pfad", ""))
    voll = Z.rel(rel)
    if voll is None or not Z.darf_lesen(rel) or voll.suffix != ".py":
        raise Antwort(403, "nicht ausfuehrbar: " + rel)
    if "text" in d:                      # erst speichern, dann starten
        api_datei_schreiben({"pfad": rel, "text": d["text"]})
    lauf = ausfuehren.starten(voll)
    thema = str(d.get("thema", ""))
    # Mein Fehlerbuch (Rang 9): jede rote Meldung aus der Shell -- nur in der Schuelerfassung,
    # nie im Lehrerpult. Selbstcheck und Aufzeichnung laufen nicht hier durch (zaehlen nicht).
    if thema and not Z.lehrer:
        lauf.fehlerbuch = {"thema": thema, "ort": str(d.get("ort", ""))[:40]}
    if thema:
        t = Z.stand.thema(thema)
        t["letzter_lauf"] = standmodul.jetzt()
        t["zeit"] = t["letzter_lauf"]
        Z.stand.speichern()
    return lauf.bericht()


@_reg
@api("lauf/lesen")
def api_lauf_lesen(d):
    lauf = ausfuehren.holen(str(d.get("id", "")))
    if lauf is None:
        raise Antwort(404, "diesen Lauf gibt es nicht (mehr)")
    b = lauf.bericht(int(d.get("ab", 0)))
    fb = lauf.fehlerbuch
    # ein Fehler in einer Knopf-Funktion zaehlt wie ein Abbruch (das Fenster laeuft weiter, Teil III)
    if fb and (b.get("fehler") or b.get("klickfehler")) and not lauf.gestoppt:
        if "eingetragen" not in fb:
            f = b.get("fehler") or b["klickfehler"][0]
            code = ""
            try:
                if f.get("zeile"):
                    code = lauf.datei.read_text("utf-8", errors="replace").splitlines()[f["zeile"] - 1].strip()
            except (OSError, IndexError):
                pass
            e = Z.stand.fehler(f, fb["thema"], fb["ort"], code)
            fb["eingetragen"] = {"art": f.get("art", ""), "anzahl": e["anzahl"]}
        b["fehlerbuch"] = fb["eingetragen"]
    return b


@_reg
@api("lauf/eingabe")
def api_lauf_eingabe(d):
    lauf = ausfuehren.holen(str(d.get("id", "")))
    if lauf is None:
        raise Antwort(404, "diesen Lauf gibt es nicht (mehr)")
    return {"ok": lauf.eingabe(str(d.get("text", "")))}


@_reg
@api("lauf/stopp")
def api_lauf_stopp(d):
    lauf = ausfuehren.holen(str(d.get("id", "")))
    if lauf is not None:
        lauf.stopp()
    return {"ok": True}


# -- Aufzeichnen -------------------------------------------------------------------
@_reg
@api("aufzeichnen/start")
def api_aufzeichnen_start(d):
    rel = str(d.get("pfad", ""))
    voll = Z.rel(rel)
    if voll is None or not Z.darf_lesen(rel) or voll.suffix != ".py":
        raise Antwort(403, "nicht ausfuehrbar: " + rel)
    if "text" in d:
        api_datei_schreiben({"pfad": rel, "text": d["text"]})
    eingaben = [str(x) for x in d.get("eingaben", [])][:50]
    lauf = ausfuehren.Lauf(voll, zeitlimit=600, modul=[str(HIER / "aufzeichnen.py")],
                           env_extra={"LERNRAUM_EINGABEN": json.dumps(eingaben)})
    Z.aufzeichnungen[lauf.id] = lauf
    return {"id": lauf.id}


@_reg
@api("aufzeichnen/lesen")
def api_aufzeichnen_lesen(d):
    lauf = Z.aufzeichnungen.get(str(d.get("id", "")))
    if lauf is None:
        raise Antwort(404, "diese Aufzeichnung gibt es nicht")
    text, bis = lauf.text(int(d.get("ab", 0)))
    ereignisse, rest = [], []
    for zeile in text.splitlines():
        if zeile.startswith("{"):
            try:
                ereignisse.append(json.loads(zeile))
                continue
            except ValueError:
                pass
        if zeile.strip():
            rest.append(zeile)
    return {"id": lauf.id, "ereignisse": ereignisse, "sonst": "\n".join(rest),
            "bis": bis, "fertig": lauf.fertig, "code": lauf.code, "gestoppt": lauf.gestoppt}


@_reg
@api("aufzeichnen/eingabe")
def api_aufzeichnen_eingabe(d):
    """Die Aufzeichnung wartet an einem input() (24.10.): die Zeile, die in der Shell des Debuggers getippt wurde."""
    lauf = Z.aufzeichnungen.get(str(d.get("id", "")))
    if lauf is None:
        raise Antwort(404, "diese Aufzeichnung gibt es nicht")
    return {"ok": lauf.eingabe(str(d.get("text", ""))[:500], echo=False)}


@_reg
@api("aufzeichnen/stopp")
def api_aufzeichnen_stopp(d):
    lauf = Z.aufzeichnungen.get(str(d.get("id", "")))
    if lauf is not None:
        lauf.stopp()
    return {"ok": True}


# -- Selbstcheck ---------------------------------------------------------------------
def selbstcheck_laufen(themenordner, pruefung, arbeitsdatei, zeitlimit=30):
    code, text, zu_lang = ausfuehren.einmal(
        [str(HIER / "pruefen.py"), str(pruefung), str(arbeitsdatei), "--json"],
        cwd=themenordner, zeitlimit=zeitlimit)
    if zu_lang:
        return {"titel": "Selbstcheck", "ergebnisse": [], "fehler": {
            "text": "Der Selbstcheck ist nach %d Sekunden abgebrochen worden. Laeuft das Programm vielleicht endlos?" % zeitlimit,
            "zeile": None, "original": ""}, "zeitlimit": True, "roh": text[-2000:]}
    marke = "@@SELBSTCHECK@@"
    if marke in text:
        try:
            return json.loads(text.split(marke, 1)[1].splitlines()[0])
        except ValueError:
            pass
    return {"titel": "Selbstcheck", "ergebnisse": [], "fehler": {
        "text": "Der Selbstcheck konnte nicht laufen.", "zeile": None, "original": text[-1500:]}}


@_reg
@api("selbstcheck")
def api_selbstcheck(d):
    kennung = str(d.get("thema", ""))
    reihe, thema = Z.thema(kennung)
    if thema is None:
        raise Antwort(404, "Thema unbekannt: " + kennung)
    ordner = Z.themenordner(kennung)
    arbeit = ordner / thema.get("arbeitsdatei", "")
    pruefung = ordner / "pruefung.py"
    if not pruefung.exists():
        raise Antwort(404, "Zu diesem Thema gibt es keinen Selbstcheck.")
    if "text" in d:
        api_datei_schreiben({"pfad": "themen/%s/%s" % (kennung, thema["arbeitsdatei"]), "text": d["text"]})
    ergebnis = selbstcheck_laufen(ordner, pruefung, arbeit)
    # in den Stand: je Aufgabe passt/von und je Stufe (Sterne, 16.10.), dazu das Ganze am Thema
    from .sterne import selbstcheck_je
    je = selbstcheck_je(ergebnis.get("ergebnisse", []))
    for nr, z in je.items():
        # versucht bleibt versucht (16.10.): jede Stufe, deren Pruefungen einmal dran waren
        alt = (Z.stand.daten.get("aufgaben") or {}).get(kennung + "/" + nr, {}).get("versucht") or []
        z_versucht = sorted(set(alt) | {int(s) for s, w in z.get("stufen", {}).items() if w[0] > 0})
        Z.stand.eintragen(kennung + "/" + nr, versucht=z_versucht)
        Z.stand.eintragen(kennung + "/" + nr, selbstcheck=z)
    t = Z.stand.thema(kennung)
    t["selbstcheck"] = {"passt": sum(1 for e in ergebnis.get("ergebnisse", []) if e["stand"] == "passt"),
                        "von": len(ergebnis.get("ergebnisse", [])), "fehler": bool(ergebnis.get("fehler"))}
    t["zeit"] = standmodul.jetzt()
    t["hash"] = thema.get("hash", "")
    Z.stand.speichern()
    from .pruefen import als_text
    ergebnis["text"] = als_text(ergebnis)
    return {"ergebnis": ergebnis, "stand": Z.stand.daten}


# -- Hilfestufen ------------------------------------------------------------------------
@_reg
@api("hilfe/oeffnen")
def api_hilfe_oeffnen(d):
    """Hilfe 1 jederzeit; jede weitere erst, wenn die Arbeitsdatei seit dem
    Oeffnen der vorigen Stufe einmal ausgefuehrt wurde (Block 5, Nr. 3).
    Papieraufgaben: alle Stufen sofort."""
    kennung = str(d.get("kennung", ""))
    stufe = int(d.get("stufe", 1))
    stufen = Z.hilfen.get(kennung)
    if not stufen or stufe < 1 or stufe > len(stufen):
        raise Antwort(404, "Diese Hilfe gibt es nicht.")
    a = Z.stand.aufgabe(kennung)
    offen = set(a.get("hilfen", []))
    zeiten = a.get("hilfe_zeiten", {})
    papier = bool(d.get("papier", False))
    if stufe in offen:
        return {"stufe": stufe, "html": stufen[stufe - 1]["html"], "frei": True}
    if stufe > 1 and not papier:
        thema_k = kennung.rsplit("/", 1)[0]
        letzter_lauf = Z.stand.thema(thema_k).get("letzter_lauf", "")
        vorige = zeiten.get(str(stufe - 1), "")
        if (stufe - 1) not in offen:
            raise Antwort(423, "Erst Hilfe %d." % (stufe - 1))
        if not letzter_lauf or letzter_lauf <= vorige:
            return {"stufe": stufe, "gesperrt": True,
                    "text": "Hilfe %d gibt es, nachdem du dein Programm einmal ausgefuehrt hast." % stufe}
    offen.add(stufe)
    zeiten[str(stufe)] = standmodul.jetzt()
    Z.stand.eintragen(kennung, hilfen=sorted(offen), hilfe_zeiten=zeiten)
    return {"stufe": stufe, "html": stufen[stufe - 1]["html"], "stand": Z.stand.daten}


# -- Loesung ----------------------------------------------------------------------------
def _loesung_lesen(kennung, kennwort):
    ordner = Z.themenordner(kennung)
    offen = ordner / "loesung.json"
    if Z.lehrer and offen.exists():
        return json.loads(offen.read_text("utf-8"))
    enc = ordner / "loesung.enc"
    if not enc.exists():
        raise Antwort(404, "Zu diesem Thema gibt es keine Loesung.")
    if not kennwort:
        raise Antwort(423, "Kennwort fehlt.")
    try:
        klar = chiffre.entschluesseln(enc.read_bytes(), kennwort.strip().lower())
    except ValueError:
        raise Antwort(403, "Das Kennwort stimmt nicht.")
    return json.loads(klar.decode("utf-8"))


@_reg
@api("loesung/freischalten")
def api_loesung_freischalten(d):
    kennung = str(d.get("thema", ""))
    kennwort = str(d.get("kennwort", "")).strip().lower()
    loesung = _loesung_lesen(kennung, kennwort)
    if not Z.lehrer:
        Z.stand.daten["kennwoerter"][kennung] = kennwort
        Z.stand.speichern()
    return {"loesung": loesung, "stand": Z.stand.daten}


@_reg
@api("loesung/lesen")
def api_loesung_lesen(d):
    kennung = str(d.get("thema", ""))
    kennwort = Z.stand.daten["kennwoerter"].get(kennung, "")
    if not Z.lehrer and not kennwort:
        raise Antwort(423, "Noch nicht freigeschaltet.")
    return {"loesung": _loesung_lesen(kennung, kennwort)}


# -- Abgabe und Stand -----------------------------------------------------------------
def _name_fuer_datei(s):
    import unicodedata
    def rein(t):
        t = unicodedata.normalize("NFC", t)
        return "".join(c for c in t if c.isalnum() or c in "-_")
    return rein(s.get("nachname", "")) or "Nachname", rein(s.get("vorname", "")) or "Vorname"


def _fehlerbuch_auszug(s, thema):
    """Was vom Fehlerbuch mit der Abgabe eines Themas reist: je Fehlerart, die in DIESEM Thema
    vorkam, die Zahl dort, der Satz, die letzte Meldung und die eigene Notiz."""
    aus = {}
    for art, e in (s.get("fehlerbuch") or {}).items():
        n = (e.get("themen") or {}).get(thema, 0)
        if n:
            aus[art] = {"anzahl": n, "satz": e.get("satz", ""), "notiz": e.get("notiz", ""),
                        "letzte": e.get("letzte") if (e.get("letzte") or {}).get("thema") == thema else None}
    return aus


@_reg
@api("abgabe/erzeugen")
def api_abgabe_erzeugen(d):
    kennung = str(d.get("thema", ""))
    reihe, thema = Z.thema(kennung)
    if thema is None:
        raise Antwort(404, "Thema unbekannt")
    s = Z.stand.daten
    if not s.get("nachname") or not s.get("vorname"):
        raise Antwort(400, "Erst den Namen eintragen (Zahnrad oben rechts).")
    nach, vor = _name_fuer_datei(s)
    name = "abgabe_%s_%s_%s_%s.zip" % (s.get("kurs", "kurs"), thema["kennung"], nach, vor)
    ziel = Z.wurzel / "abgaben" / name
    ziel.parent.mkdir(exist_ok=True)
    auszug = {"version": s["version"], "kurs": s["kurs"], "name": s["name"],
              "vorname": s["vorname"], "nachname": s["nachname"],
              "partner": s.get("partner") or {},
              "thema": kennung, "hash": thema.get("hash", ""),
              "abgegeben": standmodul.jetzt(),
              "aufgaben": {k: v for k, v in s["aufgaben"].items() if k.startswith(kennung + "/")},
              "themen": {kennung: s["themen"].get(kennung, {})},
              "fragen": {k: v for k, v in (s.get("fragen") or {}).items() if k.startswith(kennung + "/")},
              "stufen": {k: v for k, v in (s.get("stufen") or {}).items() if k.startswith(kennung + "/")},
              "puzzles": {k: v for k, v in (s.get("puzzles") or {}).items() if k.startswith(kennung + "/")},
              "faelle": {k: v for k, v in (s.get("faelle") or {}).items() if k.startswith(kennung + "/")},
              "vorhersagen": {k: v for k, v in (s.get("vorhersagen") or {}).items() if k.startswith(kennung + "/")},
              "plaene": {k: v for k, v in (s.get("plaene") or {}).items() if k.startswith(kennung + "/")},
              "fehlerbuch": _fehlerbuch_auszug(s, kennung),
              # „Ich kann …“ der Reihe: reist mit jeder Abgabe, die Uebersicht zaehlt ohne Namen
              "einschaetzung": {k: v for k, v in (s.get("einschaetzung") or {}).items() if k.startswith(reihe["kennung"] + "/")},
              # Lernkarten: alle (eine Karte gehoert keinem einzelnen Thema allein), die Uebersicht zaehlt ohne Namen
              "lernkarten": dict(s.get("lernkarten") or {})}
    ordner = Z.themenordner(kennung)
    with zipfile.ZipFile(ziel, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("stand.json", json.dumps(auszug, ensure_ascii=False, indent=1))
        arbeit = ordner / thema.get("arbeitsdatei", "")
        if arbeit.is_file():
            z.write(arbeit, "themen/%s/%s" % (kennung, arbeit.name))
        anm = anmerkungen_laden(kennung)
        if anm:
            z.writestr("anmerkungen.json", json.dumps({"thema": kennung, "anmerkungen": anm}, ensure_ascii=False, indent=1))
        fotos = ordner / "fotos"
        if fotos.is_dir():
            for f in sorted(fotos.iterdir()):
                z.write(f, "themen/%s/fotos/%s" % (kennung, f.name))
    return {"datei": "abgaben/" + name, "groesse": ziel.stat().st_size, "pfad": str(ziel)}


@_reg
@api("stand/zip")
def api_stand_zip(d):
    _nicht_im_pult("keine Stand-ZIP")
    nach, vor = _name_fuer_datei(Z.stand.daten)
    name = "stand_%s_%s.zip" % (nach, vor)
    ziel = Z.wurzel / "_stand" / name
    standmodul.stand_zip(Z.wurzel, Z.inhalt, Z.stand, ziel)
    return {"datei": "_stand/" + name, "groesse": ziel.stat().st_size, "pfad": str(ziel)}


@_reg
@api("sicherung/liste")
def api_sicherung_liste(d):
    """Speicherstaende (Lehrerwunsch 16.10.): beim Start automatisch, von Hand per Knopf."""
    return {"sicherungen": standmodul.sicherungen(Z.wurzel)}


@_reg
@api("sicherung/anlegen")
def api_sicherung_anlegen(d):
    s = standmodul.sicherung_anlegen(Z.wurzel, Z.inhalt, Z.stand, "hand", str(d.get("notiz", "")))
    return {"sicherung": s, "sicherungen": standmodul.sicherungen(Z.wurzel)}


@_reg
@api("sicherung/zurueck")
def api_sicherung_zurueck(d):
    if Z.lehrer:
        raise Antwort(403, "Im Lehrerpult gibt es keine Speicherstände.")
    try:
        bericht = standmodul.sicherung_zurueck(Z.wurzel, Z.inhalt, Z.stand, str(d.get("name", "")))
    except ValueError as e:
        raise Antwort(400, str(e))
    return {"ok": True, "bericht": bericht, "stand": Z.stand.daten, "sicherungen": standmodul.sicherungen(Z.wurzel)}


@_reg
@api("stand/partnerzip")
def api_stand_partnerzip(d):
    """Stand-ZIP fuer die Partnerin (Weg 3): dieselben Dateien und Eintraege, aber
    mit getauschten Namen -- sie nimmt sie mit und fuehrt sie zuhause zusammen;
    danach hat jede ihren eigenen Stand und gibt selbst ab."""
    _nicht_im_pult("keine Partner*in")
    s = Z.stand.daten
    pa = s.get("partner") or {}
    if not pa.get("nachname") or not pa.get("vorname"):
        raise Antwort(400, "Erst eintragen, mit wem ihr gearbeitet habt (bei der Abgabe).")
    kopie = json.loads(json.dumps(s))
    kopie["vorname"], kopie["nachname"], kopie["name"] = pa["vorname"], pa["nachname"], pa["name"]
    kopie["partner"] = {"vorname": s["vorname"], "nachname": s["nachname"], "name": s["name"]}
    kopie["lesestelle"] = {}
    kopie["einschaetzung"] = {}      # „Ich kann …“ schaetzt jede selbst ein -- das reist nicht zur Partnerin
    kopie["lernkarten"] = {}         # Lernkarten uebt jede fuer sich

    class _Tmp:
        daten = kopie
    nach, vor = _name_fuer_datei(pa)
    name = "stand_fuer_%s_%s.zip" % (nach, vor)
    ziel = Z.wurzel / "_stand" / name
    standmodul.stand_zip(Z.wurzel, Z.inhalt, _Tmp(), ziel)
    return {"datei": "_stand/" + name, "groesse": ziel.stat().st_size, "pfad": str(ziel), "fuer": pa["name"]}


@_reg
@api("stand/zusammenfuehren")
def api_stand_zusammenfuehren(d):
    """Eine Stand-ZIP (base64) hereinnehmen: neuerer Code gewinnt, Hilfen
    und Kennwoerter vereinigt, Konflikte werden gezeigt, nie still."""
    _nicht_im_pult("kein Hereinnehmen von Ständen")
    try:
        roh = base64.b64decode(str(d.get("daten", "")))
        anderer, dateien = standmodul.stand_zip_lesen(roh)
    except (ValueError, zipfile.BadZipFile) as e:
        raise Antwort(400, "Das ist keine Stand-ZIP: %s" % e)
    if anderer.get("kurs") and anderer["kurs"] != Z.stand.daten.get("kurs"):
        raise Antwort(400, "Dieser Stand gehoert zu einem anderen Kurs (%s)." % anderer["kurs"])
    erlaubt = {k: v for k, v in dateien.items() if Z.darf_schreiben(k)}
    bericht = Z.stand.zusammenfuehren(anderer, erlaubt)
    bericht["ignoriert"] = sorted(set(dateien) - set(erlaubt))
    return {"bericht": bericht, "stand": Z.stand.daten}


# -- Lehrerfassung ------------------------------------------------------------------------
@_reg
@api("beamer", lehrer=True)
def api_beamer(d):
    Z.beamer = bool(d.get("an", False))
    return {"beamer": Z.beamer}


@_reg
@api("regie", lehrer=True)
def api_regie(d):
    kennung = str(d.get("thema", ""))
    p = Z.wurzel / "_system" / "lehrer" / ("regie_" + kennung.replace("/", "_") + ".html")
    if not p.exists():
        raise Antwort(404, "keine Regie zu " + kennung)
    return {"html": p.read_text("utf-8"), "datei": str(p)}


@_reg
@api("uebersicht/laden", lehrer=True, ohne_beamer=True)
def api_uebersicht_laden(d):
    from . import uebersicht
    Z.uebersicht = uebersicht.laden(P.z, d)   # P.z, nicht Z: die Uebersicht merkt sich ihren Kurs
    return Z.uebersicht.bericht()




@_reg
@api("jahr/lesen", lehrer=True, ohne_beamer=True)
def api_jahr_lesen(d):
    """Die Jahresuebersicht (Lehrerwunsch 16.10.): je Person und Thema, was uebernommen wurde."""
    from . import jahr
    return {"jahr": jahr.laden(Z), "themen": jahr.themen(Z)}


@_reg
@api("jahr/uebernehmen", lehrer=True, ohne_beamer=True)
def api_jahr_uebernehmen(d):
    from . import jahr
    if Z.uebersicht is None:
        raise Antwort(400, "Erst Abgaben und Kursliste in der Übersicht laden.")
    try:
        return {"bericht": jahr.uebernehmen(Z, Z.uebersicht)}
    except ValueError as e:
        raise Antwort(400, str(e))


@_reg
@api("jahr/frist", lehrer=True, ohne_beamer=True)
def api_jahr_frist(d):
    from . import jahr
    try:
        return {"jahr": jahr.frist(Z, str(d.get("thema", "")), str(d.get("datum", "")))}
    except ValueError as e:
        raise Antwort(400, str(e))


@_reg
@api("jahr/entfernen", lehrer=True, ohne_beamer=True)
def api_jahr_entfernen(d):
    from . import jahr
    return {"jahr": jahr.entfernen(Z, str(d.get("name", "")), str(d.get("thema", "")))}


@_reg
@api("uebersicht/nachlaufen", lehrer=True, ohne_beamer=True)
def api_uebersicht_nachlaufen(d):
    if Z.uebersicht is None:
        raise Antwort(400, "Erst Abgaben laden.")
    Z.uebersicht.nachlaufen(an=bool(d.get("an", True)))
    return Z.uebersicht.bericht()


@_reg
@api("uebersicht/lesen", post=False, lehrer=True, ohne_beamer=True)
def api_uebersicht_lesen(d):
    if Z.uebersicht is None:
        return {"leer": True}
    return Z.uebersicht.bericht()


@_reg
@api("uebersicht/code", lehrer=True, ohne_beamer=True)
def api_uebersicht_code(d):
    if Z.uebersicht is None:
        raise Antwort(400, "Erst Abgaben laden.")
    return Z.uebersicht.code(int(d.get("nr", 0)))


@_reg
@api("uebersicht/vergessen", lehrer=True)
def api_uebersicht_vergessen(d):
    if Z.uebersicht is not None:
        Z.uebersicht.aufraeumen()
    Z.uebersicht = None
    Z.besprechung = []
    return {"ok": True}


@_reg
@api("besprechung/waehlen", lehrer=True, ohne_beamer=True)
def api_besprechung_waehlen(d):
    """Stuecke bei Beamer AUS waehlen; sie bekommen eine Nummer, keinen Namen."""
    if Z.uebersicht is None:
        raise Antwort(400, "Erst Abgaben laden.")
    Z.besprechung = Z.uebersicht.anonym([int(n) for n in d.get("nummern", [])],
                                         [[int(x[0]), str(x[1])] for x in d.get("plaene", []) if isinstance(x, list) and len(x) == 2])
    return {"anzahl": len(Z.besprechung)}


@_reg
@api("besprechung/lesen", post=False, lehrer=True)
def api_besprechung_lesen(d):
    return {"stuecke": Z.besprechung}


@_reg
@api("system", post=False)
def api_system(d):
    return {"python": sys.version, "wurzel": str(Z.wurzel), "lehrer": Z.lehrer, "kurs": P.aktiv,
            "sekunden": round(time.time() - Z.start, 1)}


@_reg
@api("beenden")
def api_beenden(d):
    # Knopf „Beenden“ (Lehrer 25.10.): erst eine Sicherung „beim Beenden“ (nur wenn sich etwas getan hat),
    # dann stoppt der Server -- die Antwort geht noch hinaus, laufende Programme stoppt das finally in starten()
    gesichert = False
    if not Z.lehrer:
        try:
            gesichert = standmodul.sicherung_anlegen(Z.wurzel, Z.inhalt, Z.stand, "ende") is not None
        except Exception as e:  # noqa: BLE001
            print("  (Sicherung beim Beenden nicht moeglich: %s)" % e)
    threading.Timer(0.5, Z.server.shutdown).start()
    return {"ok": True, "gesichert": gesichert}


class Server(http.server.ThreadingHTTPServer):
    """http.server fragt beim Binden socket.getfqdn() -- auf diesem Mac
    35 Sekunden DNS-Wartezeit (gemessen 2026-10-13, P1: 35,8 s statt < 5 s).
    Wir binden an 127.0.0.1 und wissen den Namen schon."""
    daemon_threads = True

    def server_bind(self):
        import socketserver
        socketserver.TCPServer.server_bind(self)
        self.server_name = "127.0.0.1"
        self.server_port = self.server_address[1]


# ======================================================================
def freier_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# -- Anmerkungen (Schueler): Nadeln der Klasse, je Thema eine Datei --------------------
# Lehrerwunsch 14.10.: die Klasse setzt Nadeln wie der Lehrer in der Durchsicht --
# eine Zeile und eine Art (frage · fehler · idee). Die Datei reist mit der Abgabe;
# die Uebersicht zeigt alle gemischt OHNE Namen, die Lehrerfassung blendet je Stelle
# einen Zaehler ein (auch am Beamer, dort ohne Text). Anonym ist nur die Anzeige:
# die Abgabe-ZIP traegt den Namen -- das sagt die Seite der Klasse auch.
ANMERKUNG_ARTEN = ("frage", "fehler", "idee")


def _anmerkungen_pfad(kennung):
    return Z.wurzel / "_anmerkungen" / (kennung.replace("/", "_") + ".json")


def anmerkungen_pruefen(liste):
    """Nur, was eine Anmerkung braucht -- und hoechstens 60 je Thema."""
    if not isinstance(liste, list):
        raise Antwort(400, "Anmerkungen: erwartet eine Liste")
    aus = []
    for a in liste[:60]:
        if not isinstance(a, dict) or a.get("art") not in ANMERKUNG_ARTEN:
            continue
        aus.append({"nr": int(a.get("nr") or len(aus) + 1), "art": a["art"], "text": str(a.get("text", ""))[:200],
                    "route": str(a.get("route", ""))[:200], "titel": str(a.get("titel", ""))[:200],
                    "anker": str(a.get("anker", ""))[:400] or None, "ausschnitt": str(a.get("ausschnitt", ""))[:120],
                    "dx": float(a.get("dx") or 0.5), "dy": float(a.get("dy") or 0.5),
                    "x": float(a.get("x") or 0), "y": float(a.get("y") or 0), "zeit": str(a.get("zeit", ""))[:40]})
    return aus


def anmerkungen_laden(kennung):
    p = _anmerkungen_pfad(kennung)
    if p.exists():
        try:
            return anmerkungen_pruefen(json.loads(p.read_text("utf-8")).get("anmerkungen", []))
        except (ValueError, AttributeError, Antwort):
            pass
    return []


@_reg
@api("anmerkungen/lesen")
def api_anmerkungen_lesen(d):
    kennung = str(d.get("thema", ""))
    if Z.thema(kennung)[1] is None:
        raise Antwort(404, "Thema unbekannt")
    return {"anmerkungen": anmerkungen_laden(kennung)}


@_reg
@api("anmerkungen/schreiben")
def api_anmerkungen_schreiben(d):
    kennung = str(d.get("thema", ""))
    if Z.thema(kennung)[1] is None:
        raise Antwort(404, "Thema unbekannt")
    liste = anmerkungen_pruefen(d.get("anmerkungen"))
    p = _anmerkungen_pfad(kennung)
    p.parent.mkdir(exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps({"thema": kennung, "anmerkungen": liste, "gespeichert": standmodul.jetzt()}, ensure_ascii=False, indent=1), "utf-8")
    standmodul.ersetzen(tmp, p)
    return {"ok": True, "anzahl": len(liste)}


@_reg
@api("anmerkungen/klasse", lehrer=True)
def api_anmerkungen_klasse(d):
    """Die Anmerkungen aller geladenen Abgaben zu einer Ansicht -- ohne Namen.
    Am Beamer nur Stelle, Art und Zahl, kein Text."""
    if Z.uebersicht is None:
        return {"leer": True, "stellen": []}
    route = str(d.get("route", ""))
    stellen = {}
    for a in Z.uebersicht.alle_anmerkungen():
        if a["route"] != route:
            continue
        k = a["anker"] or "%d,%d" % (a["x"], a["y"])
        s = stellen.setdefault(k, {"anker": a["anker"], "dx": a["dx"], "dy": a["dy"], "x": a["x"], "y": a["y"],
                                   "frage": 0, "fehler": 0, "idee": 0, "texte": []})
        s[a["art"]] += 1
        if not Z.beamer and a["text"]:
            s["texte"].append({"art": a["art"], "text": a["text"]})
    return {"leer": False, "stellen": list(stellen.values())}


# -- Durchsicht (Lehrer): Nadeln und Urteile auf der lebenden Seite ------------------
# Das Gegenstueck zu Folien-/Buch-/Dateifilm in Mathe (Lehrerwunsch 2026-10-13):
# der Lehrer markiert direkt auf der Seite, die Datei liegt im Lehrerpult,
# werkstatt/lernraum/durchsicht_lesen.py liest sie. Nur Lehrer, nie am Beamer.
def _durchsicht_pfad():
    return Z.wurzel / "_durchsicht" / "durchsicht.json"


def _durchsicht_laden():
    p = _durchsicht_pfad()
    if p.exists():
        try:
            d = json.loads(p.read_text("utf-8"))
            if isinstance(d, dict):
                d.setdefault("nadeln", [])
                d.setdefault("urteile", {})
                return d
        except ValueError:
            pass
    return {"nadeln": [], "urteile": {}}


@_reg
@api("durchsicht/lesen", post=False, lehrer=True, ohne_beamer=True)
def api_durchsicht_lesen(d):
    return {"daten": _durchsicht_laden()}


@_reg
@api("durchsicht/schreiben", lehrer=True, ohne_beamer=True)
def api_durchsicht_schreiben(d):
    daten = d.get("daten")
    if not isinstance(daten, dict) or not isinstance(daten.get("nadeln"), list) or not isinstance(daten.get("urteile"), dict):
        raise Antwort(400, "Durchsicht: erwartet {nadeln: [...], urteile: {...}}")
    daten = {"nadeln": daten["nadeln"], "urteile": daten["urteile"],
             "kurs": Z.inhalt.get("kurs", ""), "gespeichert": standmodul.jetzt()}
    p = _durchsicht_pfad()
    p.parent.mkdir(exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(daten, ensure_ascii=False, indent=1), "utf-8")
    standmodul.ersetzen(tmp, p)
    return {"ok": True, "anzahl": len(daten["nadeln"])}


# -- Werkbuch (Lehrer): was angemerkt wurde und was daraus wurde ------------------------
# Lehrerentscheidung 14.10.: drei Quellen in einer Liste (Durchsicht, nach der Stunde,
# Klasse). Gebaut liegt es in _system/lehrer/werkbuch.json (aus der versionierten
# Kursquelle); was seither auf der Seite dazukam, steht lebend in _durchsicht/ und
# erscheint hier mit Status "neu", bis werkbuch.py es uebernommen hat. Nie am Beamer.
def _werkbuch_gebaut():
    d = werkbuchmodul.laden(Z.wurzel / "_system" / "lehrer" / "werkbuch.json")
    d.setdefault("themen", {})
    return d


@_reg
@api("werkbuch/lesen", lehrer=True, ohne_beamer=True)
def api_werkbuch_lesen(d):
    gebaut = _werkbuch_gebaut()
    themen = {k: {"eintraege": list(v.get("eintraege", [])), "urteile": dict(v.get("urteile", {}))} for k, v in gebaut["themen"].items()}
    da = {e.get("id") for v in themen.values() for e in v["eintraege"]}
    lebend = werkbuchmodul.lebende_eintraege(_durchsicht_laden(), werkbuchmodul.laden(_klasse_pfad()))
    for e in lebend:
        if e["id"] in da:
            continue
        e["status"], e["nr"] = "neu", None
        themen.setdefault(werkbuchmodul.thema_von(e["route"]), {"eintraege": [], "urteile": {}})["eintraege"].append(e)
    # Kommentare des Lehrers (14.10.): die gebauten stehen im Eintrag, die lebenden kommen dazu
    lebende_k = werkbuchmodul.laden(_kommentare_pfad()).get("kommentare", [])
    for v in themen.values():
        for e in v["eintraege"]:
            gebaut_k = [dict(k) for k in e.get("kommentare", [])]
            zeiten = {k.get("zeit") for k in gebaut_k}
            e["kommentare"] = gebaut_k + [dict(k, lebend=True) for k in lebende_k if k.get("id") == e.get("id") and k.get("zeit") not in zeiten]
    return {"gebaut": gebaut.get("gebaut", ""), "themen": themen}


def _kommentare_pfad():
    return Z.wurzel / "_durchsicht" / "kommentare.json"


@_reg
@api("werkbuch/kommentar", lehrer=True, ohne_beamer=True)
def api_werkbuch_kommentar(d):
    """Ein eigener Kommentar des Lehrers zu einem Werkbuch-Eintrag -- fuer die spaetere
    Umsetzung (Lehrerwunsch 14.10.). {id, text} haengt an; {id, zeit, loeschen} nimmt
    einen noch nicht eingelesenen wieder weg. werkbuch.py uebernehmen holt sie ins Werkbuch."""
    kid = str(d.get("id", ""))[:80]
    if not kid:
        raise Antwort(400, "Kommentar: Eintrag fehlt")
    p = _kommentare_pfad()
    liste = werkbuchmodul.laden(p).get("kommentare", [])
    if d.get("loeschen"):
        liste = [k for k in liste if not (k.get("id") == kid and k.get("zeit") == d.get("zeit"))]
        neu = None
    else:
        text = str(d.get("text", "")).strip()[:2000]
        if not text:
            raise Antwort(400, "Kommentar ist leer")
        neu = {"id": kid, "text": text, "zeit": standmodul.jetzt()}
        liste.append(neu)
    p.parent.mkdir(exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps({"kommentare": liste}, ensure_ascii=False, indent=1), "utf-8")
    standmodul.ersetzen(tmp, p)
    return {"ok": True, "kommentar": neu}


def _klasse_pfad():
    return Z.wurzel / "_durchsicht" / "klasse.json"


@_reg
@api("werkbuch/klasse", lehrer=True, ohne_beamer=True)
def api_werkbuch_klasse(d):
    """Die Anmerkungen der geladenen Abgaben ins Werkbuch -- OHNE Namen (die Uebersicht
    selbst speichert weiter nichts). Doppelte (schon uebernommen oder schon im
    gebauten Werkbuch) zaehlen als "schon da"."""
    if Z.uebersicht is None:
        raise Antwort(400, "Erst Abgaben laden.")
    p = _klasse_pfad()
    vorher = werkbuchmodul.laden(p).get("nadeln", [])
    da = {werkbuchmodul.kennung(dict(n, quelle="klasse")) for n in vorher}
    da |= {e.get("id") for v in _werkbuch_gebaut()["themen"].values() for e in v.get("eintraege", [])}
    neu = []
    for a in Z.uebersicht.alle_anmerkungen():
        n = {"quelle": "klasse", "route": a["route"], "titel": a["titel"], "anker": a["anker"],
             "dx": a["dx"], "dy": a["dy"], "x": a["x"], "y": a["y"], "text": a["ausschnitt"],
             "notiz": a["text"], "art": a["art"], "zeit": a["zeit"]}
        k = werkbuchmodul.kennung(n)
        if k in da:
            continue
        da.add(k)
        neu.append(n)
    if neu:
        p.parent.mkdir(exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps({"nadeln": vorher + neu, "gespeichert": standmodul.jetzt()}, ensure_ascii=False, indent=1), "utf-8")
        standmodul.ersetzen(tmp, p)
    return {"neu": len(neu), "schon": len(Z.uebersicht.alle_anmerkungen()) - len(neu)}


# -- Aktualisierung (Weg B, Lehrerentscheidung 14.10.) -------------------------------
# Nur auf Knopfdruck, nur in der Schuelerfassung. Python geht ins Netz, nie die Seite.
# Einspielen nur, was vorher geprueft wurde (SHA der Eingangs-ZIP), danach beendet
# sich der Server -- die neue Fassung laeuft erst nach einem Neustart von start.py.
def _nur_schueler():
    if Z.lehrer:
        raise Antwort(403, "Das Lehrerpult kommt aus dem Projekt (Abzug in den OneDrive-Ordner) -- hier wird es nicht aktualisiert.")


def _eingang():
    return Z.wurzel / akt.ARBEIT / "eingang.zip"


def _pruefen_und_merken():
    try:
        plan = akt.pruefen(Z.wurzel, _eingang())
    except akt.Abgelehnt as e:
        _eingang().unlink(missing_ok=True)
        Z.akt_eingang = None
        raise Antwort(400, str(e))
    Z.akt_eingang = akt.sha256(_eingang().read_bytes())
    return {"plan": akt.zusammenfassung(plan)}


@_reg
@api("aktualisierung/suchen")
def api_aktualisierung_suchen(d):
    _nur_schueler()
    adresse = Z.inhalt.get("aktualisierung", "")
    if not adresse:
        return {"ohne_adresse": True, "hier": Z.inhalt.get("fassung_nr", 0)}
    try:
        Z.akt_info = akt.suchen(adresse, Z.inhalt)
    except akt.Abgelehnt as e:
        raise Antwort(502, str(e))
    return {"info": Z.akt_info, "hier": Z.inhalt.get("fassung_nr", 0)}


@_reg
@api("aktualisierung/holen")
def api_aktualisierung_holen(d):
    _nur_schueler()
    if not Z.akt_info or not Z.akt_info.get("neu"):
        raise Antwort(400, "Erst nach einer neuen Fassung suchen.")
    try:
        akt.holen(Z.inhalt["aktualisierung"], Z.akt_info, _eingang())
    except akt.Abgelehnt as e:
        raise Antwort(502, str(e))
    return _pruefen_und_merken()


@_reg
@api("aktualisierung/hereinnehmen")
def api_aktualisierung_hereinnehmen(d):
    """Der Handweg: dieselbe ZIP von Hand (Stick, Mail, Schulportal) -- ohne Netz."""
    _nur_schueler()
    try:
        roh = base64.b64decode(str(d.get("daten", "")), validate=True)
    except ValueError:
        raise Antwort(400, "Die Datei kam nicht lesbar an.")
    if len(roh) > akt.GRENZE_ZIP:
        raise Antwort(400, "Die Datei ist zu gross fuer eine Aktualisierung.")
    _eingang().parent.mkdir(exist_ok=True)
    _eingang().write_bytes(roh)
    return _pruefen_und_merken()


@_reg
@api("aktualisierung/einspielen")
def api_aktualisierung_einspielen(d):
    _nur_schueler()
    if not Z.akt_eingang or not _eingang().exists():
        raise Antwort(400, "Erst eine Aktualisierung pruefen lassen (suchen oder von Hand hereinnehmen).")
    try:
        bericht = akt.einspielen(Z.wurzel, _eingang(), Z.akt_eingang)
    except akt.Abgelehnt as e:
        raise Antwort(400, str(e))
    _eingang().unlink(missing_ok=True)
    Z.akt_eingang = None
    ausfuehren.alle_stoppen()
    threading.Timer(1.5, Z.server.shutdown).start()
    return {"bericht": bericht, "neustart": True}


SPERRE = "_laeuft.json"          # dieselbe Datei kennt werkstatt/lernraum/pultort.py
# Lebenszeichen (16.10.): ■ Stopp in Thonny beendet das Programm hart, ohne Aufraeumen -- die Sperre
# bliebe liegen. Deshalb erneuert das laufende Pult sie alle 2 Minuten („lebt“); ohne Lebenszeichen
# seit 10 Minuten gilt sie als erloschen (Spielraum fuer die Verzoegerung von OneDrive).
LEBENSZEICHEN_S = 120
ERLOSCHEN_S = 600


_KENNUNG = None


def rechner_kennung():
    """Eine feste Kennung dieses Rechners (22.10.: der Mac heisst je nach Netz „Mac.fritz.box“ oder
    „MacBook-Air-….local“ -- am Namen gemessen galt die eigene alte Sperre als fremd, und das Aufraeumen
    beim Stoppen liess sie liegen). Quelle ist die Geraetekennung des Systems (Mac: IOPlatformUUID,
    Windows: MachineGuid, Linux: /etc/machine-id), sonst eine einmal angelegte Datei im Benutzerordner;
    gehasht und gekuerzt. uuid.getnode() taugt nicht: unter Python 3.11 auf dem Mac jedes Mal eine
    andere Zufallszahl. Dieselbe Rechnung steht in werkstatt/lernraum/pultort.py."""
    global _KENNUNG
    if _KENNUNG:
        return _KENNUNG
    import hashlib
    import re as _re
    import subprocess
    roh = ""
    try:
        if sys.platform == "darwin":
            aus = subprocess.run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], capture_output=True, text=True, timeout=5).stdout
            m = _re.search(r'"IOPlatformUUID" = "([^"]+)"', aus)
            roh = m.group(1) if m else ""
        elif sys.platform.startswith("win"):
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                                winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)) as k:
                roh = winreg.QueryValueEx(k, "MachineGuid")[0]
        elif pathlib.Path("/etc/machine-id").is_file():
            roh = pathlib.Path("/etc/machine-id").read_text().strip()
    except Exception:  # noqa: BLE001 -- dann eben die Datei
        roh = ""
    if not roh:
        datei = pathlib.Path.home() / ".lernraum-rechner"
        try:
            roh = datei.read_text("utf-8").strip()
        except OSError:
            roh = ""
        if not roh:
            roh = secrets.token_hex(16)
            try:
                datei.write_text(roh, "utf-8")
            except OSError:
                pass
    _KENNUNG = hashlib.sha256(("lernraum-" + roh).encode()).hexdigest()[:12]
    return _KENNUNG


def _gleicher_rechner(s):
    """Stammt die Sperre von diesem Rechner? Mit Kennung danach, sonst (alte Sperre) nach dem Namen."""
    if s.get("kennung"):
        return s["kennung"] == rechner_kennung()
    return s.get("rechner") == socket.gethostname()


def _sperre_lebt(s):
    import datetime
    try:
        zuletzt = datetime.datetime.fromisoformat(s.get("lebt") or s.get("seit", ""))
    except (TypeError, ValueError):
        return False
    return (datetime.datetime.now() - zuletzt).total_seconds() < ERLOSCHEN_S


def _sperre_pruefen(wurzel, argv):
    """Das Lehrerpult wohnt in OneDrive (Block 3, 16.10.): Laeuft es schon auf einem ANDEREN
    Rechner (Schule / zu Hause), schreiben zwei Server in dieselben Spuren und OneDrive legt
    Konfliktkopien an. Deshalb fragt der Start nach. Eine Sperre desselben Rechners ist ein
    Rest (Absturz) und wird ersetzt; ohne Lebenszeichen seit 10 Minuten gilt sie als erloschen.
    Gibt False zurueck, wenn nicht gestartet werden soll."""
    import datetime
    p = pathlib.Path(wurzel) / SPERRE
    hier = socket.gethostname()
    if p.is_file() and "--trotzdem" not in argv:
        try:
            s = json.loads(p.read_text("utf-8"))
        except (OSError, ValueError):
            s = {}
        if s.get("rechner") and not _gleicher_rechner(s) and _sperre_lebt(s):
            print()
            if Z.lehrer:
                print("  Das Lehrerpult laeuft gerade auf %s (seit %s Uhr)." % (s["rechner"], s.get("seit", "")[11:16]))
                print("  Zwei Pulte gleichzeitig schreiben in dieselben Dateien -- dort erst stoppen.")
            else:
                print("  Dein Lernraum ist gerade auf einem anderen Rechner offen (%s, seit %s Uhr)."
                      % (s["rechner"], s.get("seit", "")[11:16]))
                print("  Zwei offene Lernräume schreiben in dieselben Dateien – dort erst „Beenden“.")
            try:
                antwort = input("  Trotzdem hier starten? (j/n) ").strip().lower()
            except EOFError:
                antwort = "n"
            if antwort not in ("j", "ja", "y"):
                print("  Nicht gestartet.")
                return False
    import datetime as _dt
    seit = _dt.datetime.now().isoformat(timespec="seconds")

    def schreiben():
        try:
            p.write_text(json.dumps({"rechner": hier, "kennung": rechner_kennung(), "seit": seit, "pid": os.getpid(),
                                     "lebt": _dt.datetime.now().isoformat(timespec="seconds")}, ensure_ascii=False), "utf-8")
        except OSError:
            pass

    def herzschlag():
        while True:
            time.sleep(LEBENSZEICHEN_S)
            try:
                s = json.loads(p.read_text("utf-8"))
            except (OSError, ValueError):
                s = {}
            if s.get("pid") not in (None, os.getpid()) or (s.get("rechner") and not _gleicher_rechner(s)):
                return              # jemand hat mit „trotzdem“ uebernommen -- nicht zurueckschreiben
            schreiben()
    schreiben()
    threading.Thread(target=herzschlag, daemon=True).start()
    # SIGTERM (pkill, Abmelden) wie Strg+C behandeln: dann laeuft das Aufraeumen und die Sperre geht
    try:
        import signal

        def _beenden(*_):
            raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, _beenden)
    except (ValueError, OSError, AttributeError):
        pass
    return True


def _sperre_loesen(wurzel):
    p = pathlib.Path(wurzel) / SPERRE
    try:
        s = json.loads(p.read_text("utf-8"))
        if _gleicher_rechner(s) and s.get("pid") == os.getpid():
            p.unlink()
    except (OSError, ValueError):
        pass


def starten(wurzel, argv=()):
    global P
    argv = list(argv)
    P = Pult(wurzel)
    # Seit 25.10. auch der Lernraum der Klasse: Wer ihn in OneDrive legt, kann ihn auf zwei Rechnern zugleich
    # oeffnen (in der Schule nicht beendet, zuhause gestartet) -- dann gewinnt ein stand.json, der andere Stand
    # waere weg. Auf dem Stick ist die Sperre harmlos: derselbe Rechner ersetzt sie, ohne Lebenszeichen erlischt sie.
    sperren = True
    if sperren and not _sperre_pruefen(P.wurzel, argv):
        return
    if "--schluessel" in argv:
        Z.schluessel = argv[argv.index("--schluessel") + 1]
    port = int(argv[argv.index("--port") + 1]) if "--port" in argv else freier_port()
    server = Server(("127.0.0.1", port), Handler)
    server.laut = "--laut" in argv
    Z.port = server.server_address[1]
    Z.server = server
    adresse = "http://127.0.0.1:%d/?k=%s" % (Z.port, Z.schluessel)
    print()
    print("  Lehrerpult:" if Z.lehrer else "  Lernraum:  ", P.wurzel)
    if P.mehrere:
        print("  Kurse:     ", " · ".join(e["titel"] for e in P.liste()))
    print("  Fassung:   ", "Lehrer" if Z.lehrer else "Schueler", "| Python", sys.version.split()[0])
    print("  Adresse:   ", adresse)
    print()
    print("  Der Browser geht von selbst auf. Falls nicht: Adresse oben kopieren.")
    if Z.lehrer:
        print("  Beenden: dieses Programm stoppen (in Thonny: der rote Knopf).")
    else:
        print("  Beenden: oben rechts auf der Seite „Beenden“ (oder in Thonny der rote Knopf).")
    sys.stdout.flush()
    # Speicherstand beim Start (Lehrerwunsch 16.10.): nur in der Schuelerfassung, nur wenn sich
    # seit der letzten Sicherung etwas getan hat; ein Fehler hier haelt den Start nie auf
    if not Z.lehrer:
        try:
            k = standmodul.konfliktkopien_einarbeiten(Z.wurzel, Z.stand)
            if k:
                print("  Zwei Fassungen deines Stands gefunden (%s) – zusammengeführt, nichts geht verloren." % ", ".join(k))
        except Exception as e:  # noqa: BLE001
            print("  (Kopie des Stands nicht eingearbeitet: %s)" % e)
        try:
            standmodul.sicherung_anlegen(Z.wurzel, Z.inhalt, Z.stand, "start")
        except Exception as e:  # noqa: BLE001
            print("  (Sicherung beim Start nicht moeglich: %s)" % e)
    if "--ohne-browser" not in argv:
        threading.Timer(0.3, lambda: webbrowser.open(adresse)).start()
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        if sperren:
            _sperre_loesen(P.wurzel)
        ausfuehren.alle_stoppen()
        for z in P.kurse.values():
            for a in z.aufzeichnungen.values():
                a.stopp()
            if z.uebersicht is not None:
                z.uebersicht.aufraeumen()
        server.server_close()
        if Z.lehrer:
            print("Server beendet.")
        else:
            print()
            print("  Lernraum beendet – dein Stand ist gespeichert. Jetzt kannst du den Stick abziehen.")
            print("  Weiter geht es wieder mit start.py (grüner Pfeil).")
