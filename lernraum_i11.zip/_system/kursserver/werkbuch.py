"""Das Werkbuch je Thema -- ein Ort fuer alles, was angemerkt wurde, und was daraus wurde
(Lehrerentscheidung 2026-10-14).

Drei Quellen in einer Liste:
  durchsicht  die Nadeln und Urteile des Lehrers im Durchsicht-Modus
  stunde      seine Beobachtungen nach der Stunde (Regie-Reiter „Nach der Stunde“
              oder eine Nadel mit „Woher: nach der Stunde“)
  klasse      Anmerkungen der Klasse, aus der Uebersicht uebernommen -- OHNE Namen

Lebend (unversioniert, in der Lehrerfassung):
  _durchsicht/durchsicht.json   {nadeln: [...], urteile: {...}}   Nadeln tragen quelle
  _durchsicht/klasse.json       {nadeln: [...]}                    aus der Uebersicht
Versioniert (in der Kursquelle, je Thema eine Datei):
  werkbuch/<reihe>_<thema>.json  {thema, eintraege: [...], urteile: {...}}
  werkbuch/_kurs.json            was keinem Thema gehoert (Kursseite, Uebersicht)
Gebaut (nur Lehrerfassung):
  _system/lehrer/werkbuch.json   {themen: {"<reihe>/<thema>": {...}, "_kurs": {...}}}

Dieses Modul liegt in der Laufzeit, weil der Server dieselbe Kennung je Eintrag
rechnen muss wie werkstatt/lernraum/werkbuch.py beim Uebernehmen -- sonst
stuende eine Nadel doppelt da (einmal lebend, einmal im Werkbuch).
"""
import hashlib
import json

QUELLEN = ("durchsicht", "stunde", "klasse")
STATUS = ("offen", "eingearbeitet", "frage", "bewusst_nicht")
STATUS_TEXT = {"offen": "offen", "eingearbeitet": "eingearbeitet", "frage": "Frage an dich",
               "bewusst_nicht": "bewusst nicht"}


def kennung(n):
    """Die Kennung eines lebenden Eintrags. Neue Nadeln bringen eine mit (die Seite
    vergibt sie); alte haben nur ihre Zeit -- die ist je Person eindeutig genug.
    Anmerkungen der Klasse: Hash ueber Stelle, Text und Zeit (zwei Schuelerinnen
    koennen in derselben Millisekunde schreiben, aber nicht dasselbe am selben Ort)."""
    if n.get("id"):
        return str(n["id"])
    q = n.get("quelle") or "durchsicht"
    if q == "klasse":
        roh = "|".join(str(n.get(k) or "") for k in ("route", "anker", "notiz", "zeit"))
        return "k-" + hashlib.sha1(roh.encode("utf-8")).hexdigest()[:10]
    return q[0] + "-" + str(n.get("zeit") or "")


def urteil_kennung(route):
    return "u-" + route


def thema_von(route):
    """'t/abenteuer/anfang/vortrag/3' -> 'abenteuer/anfang'; sonst '_kurs'."""
    teile = (route or "").split("/")
    if len(teile) >= 3 and teile[0] == "t":
        return teile[1] + "/" + teile[2]
    return "_kurs"


def eintrag_aus_nadel(n):
    """Lebende Nadel (Lehrer oder Klasse) -> Werkbuch-Eintrag. notiz ist der Text,
    text der Ausschnitt an der Stelle (so heissen sie in durchsicht.json)."""
    q = n.get("quelle") or "durchsicht"
    e = {"id": kennung(n), "quelle": q, "route": n.get("route", ""), "titel": n.get("titel", ""),
         "anker": n.get("anker"), "dx": n.get("dx"), "dy": n.get("dy"), "x": n.get("x"), "y": n.get("y"),
         "ausschnitt": (n.get("text") or "")[:120], "text": n.get("notiz") or "",
         "stapel": n.get("stapel", "") if q != "klasse" else "", "zeit": n.get("zeit", ""),
         "status": "offen", "wie": "", "commit": "", "wirksam": ""}
    if q == "klasse":
        e["art"] = n.get("art", "")
    return e


def eintrag_aus_urteil(route, u):
    """Ein Urteil MIT Notiz ist ein Befund wie eine Nadel -- ohne Stelle, an der Ansicht."""
    return {"id": urteil_kennung(route), "quelle": "durchsicht", "route": route, "titel": u.get("titel", ""),
            "anker": None, "ausschnitt": "", "text": "Urteil „%s“: %s" % (u.get("urteil") or "–", u.get("notiz", "")),
            "stapel": "", "zeit": u.get("zeit", ""), "status": "offen", "wie": "", "commit": "", "wirksam": ""}


def lebende_eintraege(durchsicht, klasse):
    """Alle lebenden Eintraege als Werkbuch-Eintraege (Status offen)."""
    aus = [eintrag_aus_nadel(n) for n in (durchsicht or {}).get("nadeln", [])]
    for route, u in ((durchsicht or {}).get("urteile") or {}).items():
        if (u.get("notiz") or "").strip():
            aus.append(eintrag_aus_urteil(route, u))
    aus += [eintrag_aus_nadel(dict(n, quelle="klasse")) for n in (klasse or {}).get("nadeln", [])]
    return aus


def laden(pfad):
    try:
        d = json.loads(pfad.read_text("utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}
