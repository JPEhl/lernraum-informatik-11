"""kursserver -- die Laufzeit des Lernraums (nur Standardbibliothek).

Quelle: werkstatt/lernraum/laufzeit/kursserver/. In jeden gebauten
Lernraum (und jedes Lehrerpult) kopiert bauen.py dieses Paket nach _system/kursserver/.
"""
