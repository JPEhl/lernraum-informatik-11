"""Plaene (Struktogramme) der Klasse durchlaufen -- fuer die Aufgabenart „Plan“ (19.10.2026).

Lehrerwahl aus den Attrappen Runde 3 (werkstatt/informatik/planung/struktogramm_werkstatt/): Die
Klasse baut ihren Plan im Lernraum, er laeuft mit den Faellen („Proben“) aus der Aufgabe, und ein
Stern zaehlt, wenn alle stimmen -- im Pult AUS DER ABGABE NACHGERECHNET, wie der Selbstcheck. Darum
rechnet der Server selbst; die Seite zeigt nur, was er sagt.

DIESELBE RECHNUNG WIE IM BROWSER: seite/werkstatt/struktogramm.js (Kern: lesen, werten, lauf).
test/plan_gleichlauf.py laesst dieselben Plaene durch beide laufen. Wer hier etwas aendert, aendert
es dort auch. Bewusst eigenstaendig: Der Server laeuft auch auf dem Stick der Klasse, ohne
werkstatt/_scripts/struktogramm.py -- die Sprache ist dieselbe, gelesen wird wie dort.

Sprache: Einrueckung je vier Leerzeichen, „wiederhole solange <Bedingung>“, seit Thema 10 (21.10.) auch
„wiederhole für i = <a> bis <b>“ (bis schliesst ein, wie im Abitur) und „wiederhole für jedes x in <Liste>“,
„wenn <Bedingung> [| a:b]“, „sonst“; Anweisungen „x = <Ausdruck>“, „liste[i] = <Ausdruck>“, „x = Eingabe …“,
„Ausgabe: <Ausdruck>“, seit Thema 12 (23.10.) „Rückgabe <Ausdruck>“ (wie im Abitur, LA 2024 „Rückgabe 0“:
der Wert steht als „Rückgabe: …“ in den Ausgaben, und der Lauf endet sofort, auch mitten in einer
Schleife), sonst ein Kasten in Worten (laeuft als Platzhalter mit; „einen Zug ausführen“ tut, was es
im Spiel tut).
Ausdruecke in Abitur-Sprache: = vergleicht, und · oder · nicht, ≠ < > ≤ ≥, + − * / // %, Listen [a, b],
Platz liste[i] (von hinten mit -1), len(…) als einzige Funktion.
Seit Thema 13 (23.10.) Parameter: „Algorithmus ziel(raum, richtung)“ -- die Werte kommen aus den Faellen
(je Parameter ein Wert) oder im Vortrag aus aufruf="ziel(…)" (signatur, argumente, aufruf_werte).
Festgelegt fuer beide Seiten: Wahrheitswerte heissen in der Ausgabe True/False, eine ganze Zahl steht
ohne „.0“, Text + Zahl haengt an („Punkte: " + punkte), eine Liste steht wie bei print: ['lampe', 'stick'].
"""
import copy
import re

GRENZE = 5000          # Schritte je Probe -- danach „endet nicht“ (eine Endlosschleife)


class PlanFehler(Exception):
    pass


# ─── Lesen (wie struktogramm.py lesen()) ──────────────────────────────────────────────
def lesen(quelle):
    zeilen = []
    for roh in str(quelle).split("\n"):
        if not roh.strip() or roh.strip().startswith("#"):
            continue
        tief = len(roh) - len(roh.lstrip(" "))
        if tief % 4:
            raise PlanFehler("Einrückung kein Vielfaches von vier: " + roh.strip())
        zeilen.append((tief // 4, roh.strip()))
    pos = 0

    def block(stufe):
        nonlocal pos
        knoten = []
        while pos < len(zeilen):
            s, text = zeilen[pos]
            if s < stufe:
                break
            if s > stufe:
                raise PlanFehler("unerwartet tief: " + text)
            if text == "sonst":
                break
            pos += 1
            if text.startswith("wiederhole "):
                kopf = text[11:].strip()
                if kopf.startswith("für"):
                    kopf_lesen(kopf)       # ein kaputter für-Kopf ist schon beim Lesen ein Fehler (Baufehler)
                knoten.append({"art": "schleife", "kopf": kopf, "rumpf": block(stufe + 1)})
            elif text.startswith("wenn "):
                bed = text[5:].split("|")[0].strip()
                ja, nein = block(stufe + 1), []
                if pos < len(zeilen) and zeilen[pos] == (stufe, "sonst"):
                    pos += 1
                    nein = block(stufe + 1)
                knoten.append({"art": "wenn", "bed": bed, "ja": ja, "nein": nein})
            else:
                rueckgabe(text)            # „Rückgabe“ ohne Ausdruck ist schon beim Lesen ein Fehler (Baufehler)
                knoten.append({"art": "anweisung", "text": text})
        return knoten

    baum = block(0)
    if pos != len(zeilen):
        raise PlanFehler("hängengeblieben bei: " + zeilen[pos][1])
    return baum


# ─── Ausdruecke ───────────────────────────────────────────────────────────────────────
_TOK = re.compile(r'\s*("(?:[^"]*)"|\d+(?:\.\d+)?|//|<=|>=|!=|[=≠<>≤≥+\-−*/%()\[\],]|[A-Za-zÄÖÜäöüß_][\wÄÖÜäöüß]*)')


def _zerlegen(t):
    t, toks, pos = t.strip(), [], 0
    while pos < len(t):
        m = _TOK.match(t, pos)
        if not m:
            raise PlanFehler("nicht lesbar: " + t[pos:])
        toks.append(m.group(1))
        pos = m.end()
    return toks


PYTHON_WORT = {"and": "und", "or": "oder", "not": "nicht"}


def _python_hinweis(toks):
    """Wer Python in einen Kasten schreibt (T6-Regie: „schreiben welche wieder Python in die Kästen“),
    bekommt die Struktogramm-Sprache gesagt -- gleich in struktogramm.js."""
    for a, b in zip(toks, toks[1:] + [None]):
        if a == "=" and b == "=":
            raise PlanFehler("SyntaxError: Im Struktogramm vergleicht ein einfaches = (nicht ==)")
        if a in PYTHON_WORT:
            raise PlanFehler("SyntaxError: Im Struktogramm heißt es „%s“ statt „%s“" % (PYTHON_WORT[a], a))


def ausdruck(text):
    toks, i = _zerlegen(text), [0]
    _python_hinweis(toks)

    def sieh():
        return toks[i[0]] if i[0] < len(toks) else None

    def nimm():
        i[0] += 1
        return toks[i[0] - 1] if i[0] - 1 < len(toks) else None

    def erwarte(z):
        if nimm() != z:
            raise PlanFehler("SyntaxError: hier fehlt „%s“: %s" % (z, text))

    def oder():
        a = und()
        while sieh() == "oder":
            nimm()
            a = ("oder", a, und())
        return a

    def und():
        a = nicht()
        while sieh() == "und":
            nimm()
            a = ("und", a, nicht())
        return a

    def nicht():
        if sieh() == "nicht":
            nimm()
            return ("nicht", nicht())
        return vgl()

    def vgl():
        a = summe()
        if sieh() in ("=", "≠", "!=", "<", ">", "≤", "≥", "<=", ">="):
            op = nimm()
            a = (op, a, summe())
        return a

    def summe():
        a = produkt()
        while sieh() in ("+", "-", "−"):
            op = "-" if nimm() == "−" else toks[i[0] - 1]
            a = (op, a, produkt())
        return a

    def produkt():
        a = atom()
        while sieh() in ("*", "/", "//", "%"):
            op = nimm()
            a = (op, a, atom())
        return a

    def atom():
        t = nimm()
        if t is None:
            raise PlanFehler("Ausdruck endet zu früh: " + text)
        if t in ("-", "−"):
            return ("-", ("wert", 0), atom())          # Vorzeichen: -7 ist 0 - 7
        if t == "(":
            a = ("klammer", oder())
            erwarte(")")
        elif t == "[":
            items = []
            if sieh() != "]":
                items.append(oder())
                while sieh() == ",":
                    nimm()
                    items.append(oder())
            erwarte("]")
            a = ("liste", items)
        elif t.startswith('"'):
            a = ("wert", t[1:-1])
        elif t[0].isdigit():
            a = ("wert", float(t) if "." in t else int(t))
        elif not re.match(r"^[A-Za-zÄÖÜäöüß_]", t):
            raise PlanFehler("SyntaxError: an dieser Stelle fehlt ein Wert oder Name (steht dort „%s“)" % t)
        elif t in ("wahr", "True"):
            a = ("wert", True)
        elif t in ("falsch", "False"):
            a = ("wert", False)
        elif sieh() == "(":
            if t != "len":
                raise PlanFehler("SyntaxError: Die Werkstatt kennt als Funktion nur len(…), nicht „%s(…)“" % t)
            nimm()
            a = ("aufruf", t, oder())
            erwarte(")")
        else:
            a = ("name", t)
        while sieh() == "[":
            nimm()
            a = ("index", a, oder())
            erwarte("]")
        return a

    baum = oder()
    if i[0] < len(toks):
        raise PlanFehler("übrig: " + " ".join(toks[i[0]:]))
    return baum


def _in_liste(w):
    if isinstance(w, str):
        return '"%s"' % w if "'" in w and '"' not in w else "'%s'" % w.replace("'", "\\'")
    return zeig(w)


def zeig(w):
    """Ausgabe eines Werts -- gleich in struktogramm.js (K.zeig); eine Liste wie bei print."""
    if isinstance(w, bool):
        return "True" if w else "False"
    if isinstance(w, float) and w.is_integer():
        return str(int(w))
    if isinstance(w, list):
        return "[" + ", ".join(_in_liste(x) for x in w) + "]"
    return str(w)


def _zahl(w):
    return isinstance(w, (int, float)) and not isinstance(w, bool)


def gleich(x, y):
    """= wie === im Browser: Zahlen untereinander (3 = 3.0), sonst nur gleiche Art; ein Wahrheitswert
    ist nie eine Zahl (in Python waere True == 1). Listen Element fuer Element."""
    if isinstance(x, list) and isinstance(y, list):
        return len(x) == len(y) and all(gleich(a, b) for a, b in zip(x, y))
    if isinstance(x, bool) or isinstance(y, bool):
        return isinstance(x, bool) and isinstance(y, bool) and x == y
    if _zahl(x) and _zahl(y):
        return x == y
    return type(x) is type(y) and x == y


def platz(L, j, schreiben=False):
    """Ein Platz in [ ] -- wie K.platz: ganze Zahl (2.0 zaehlt, im Browser gibt es kein 2.0), von hinten
    mit -1; daneben ein IndexError mit Pythons Wortlaut."""
    if not isinstance(L, (list, str)):
        raise PlanFehler("TypeError: %s ist keine Liste – [ ] geht nur bei Listen und Text" % zeig(L))
    if not _zahl(j) or not float(j).is_integer():
        raise PlanFehler("TypeError: der Platz in [ ] muss eine ganze Zahl sein (steht dort %s)" % zeig(j))
    j = int(j)
    if j < -len(L) or j >= len(L):
        raise PlanFehler("IndexError: %s%s index out of range" % ("string" if isinstance(L, str) else "list", " assignment" if schreiben else ""))
    return j + len(L) if j < 0 else j


def werten(a, v):
    art = a[0]
    if art == "wert":
        return a[1]
    if art == "name":
        if a[1] not in v:
            raise PlanFehler("NameError: name '%s' is not defined" % a[1])
        return v[a[1]]
    if art == "klammer":
        return werten(a[1], v)
    if art == "nicht":
        return not werten(a[1], v)
    if art == "oder":
        return werten(a[1], v) or werten(a[2], v)
    if art == "und":
        return werten(a[1], v) and werten(a[2], v)
    if art == "liste":
        return [werten(e, v) for e in a[1]]
    if art == "index":
        L = werten(a[1], v)
        return L[platz(L, werten(a[2], v))]
    if art == "aufruf":
        L = werten(a[2], v)
        if not isinstance(L, (list, str)):
            raise PlanFehler("TypeError: len geht nur bei Listen und Text (steht dort %s)" % zeig(L))
        return len(L)
    x, y = werten(a[1], v), werten(a[2], v)
    # Rechnen mit Wahrheitswerten ist ein TypeError (im Browser ist true keine Zahl; in Python waere True + 1 = 2)
    if art in ("+", "-", "*", "/", "//", "%") and not (art == "+" and (isinstance(x, str) or isinstance(y, str))) \
            and (isinstance(x, bool) or isinstance(y, bool)):
        raise PlanFehler("TypeError: %s und %s lassen sich nicht mit %s verbinden" % (zeig(x), zeig(y), art))
    # wie im Browser: rechnen nur mit Zahlen ("ab" * 2 waere in Python abab), + auch Liste + Liste,
    # Listen lassen sich nicht ordnen
    if (art in ("-", "*", "/", "//", "%") and not (_zahl(x) and _zahl(y))) \
            or (art == "+" and not (isinstance(x, str) or isinstance(y, str)) and not (_zahl(x) and _zahl(y))
                and not (isinstance(x, list) and isinstance(y, list))) \
            or (art in ("<", ">", "≤", "≥", "<=", ">=") and (isinstance(x, list) or isinstance(y, list))):
        raise PlanFehler("TypeError: %s und %s lassen sich nicht mit %s verbinden" % (zeig(x), zeig(y), art))
    try:
        if art == "+":
            return zeig(x) + zeig(y) if isinstance(x, str) or isinstance(y, str) else x + y
        if art == "=":
            return gleich(x, y)
        if art in ("≠", "!="):
            return not gleich(x, y)
        if art in ("<", ">", "≤", "≥", "<=", ">=") and (isinstance(x, str) != isinstance(y, str)):
            raise TypeError()
        if art == "<":
            return x < y
        if art == ">":
            return x > y
        if art in ("≤", "<="):
            return x <= y
        if art in ("≥", ">="):
            return x >= y
        if art == "-":
            return x - y
        if art == "*":
            return x * y
        if art == "/":
            return x / y
        if art == "//":
            return x // y
        if art == "%":
            return x % y
    except ZeroDivisionError:
        raise PlanFehler("ZeroDivisionError: division by zero")
    except TypeError:
        raise PlanFehler("TypeError: %s und %s lassen sich nicht mit %s verbinden" % (zeig(x), zeig(y), art))
    raise PlanFehler("unbekannt: " + art)


# ─── Schleifenkopf, Platz-Zuweisung, Rückgabe (wie K.kopf, K.platzZuweisung, K.rueckgabe) ─
_NAME = r"[A-Za-zÄÖÜäöüß_][\wÄÖÜäöüß]*"
_RUECKGABE = re.compile(r"^Rückgabe(?![\wÄÖÜäöüß])\s*:?\s*(.*)$")


def rueckgabe(t):
    """„Rückgabe <Ausdruck>“ (Thema 12, 23.10.; auch „Rückgabe: …“) -> der Ausdruck als Text, sonst None.
    Ohne Ausdruck ein Fehler: Das Abitur gibt immer etwas zurück („Rückgabe 0“, „Rückgabe MaxIndex“)."""
    m = _RUECKGABE.match(str(t).strip())
    if not m:
        return None
    if not m.group(1).strip():
        raise PlanFehler("SyntaxError: Hinter „Rückgabe“ fehlt der Wert, der zurückgegeben wird – z. B. „Rückgabe summe“")
    return m.group(1).strip()


_SIGNATUR = re.compile(r"^Algorithmus\s+(" + _NAME + r")\(([^()]*)\)\s*$")


def signatur(titel):
    """„Algorithmus ziel(raum, richtung)“ (Thema 13, 23.10.) -> (name, [parameter]), sonst None. Die Klammer
    haengt ohne Leerzeichen am Namen: „Algorithmus spiel (grob)“ ist ein Name mit Bemerkung. Wie K.signatur."""
    m = _SIGNATUR.match(str(titel or "").strip())
    if not m:
        return None
    p = [x.strip() for x in m.group(2).split(",")] if m.group(2).strip() else []
    return (m.group(1), p) if all(re.fullmatch(_NAME, x) for x in p) else None


def argumente(aufruf):
    """„ziel("flur", "westen")“ -> ['"flur"', '"westen"'] (Kommas der obersten Ebene); ohne Klammer None. Wie K.argumente."""
    t = str(aufruf or "").strip()
    a = t.find("(")
    if a < 0 or not t.endswith(")"):
        return None
    teile, tief, text, akt = [], 0, None, ""
    for c in t[a + 1:-1]:
        if text:
            if c == text:
                text = None
            akt += c
            continue
        if c in "\"'":
            text = c
            akt += c
            continue
        tief += (c in "([") - (c in ")]")
        if c == "," and tief == 0:
            teile.append(akt.strip())
            akt = ""
            continue
        akt += c
    if akt.strip() or teile:
        teile.append(akt.strip())
    return teile


def aufruf_werte(titel, aufruf):
    """Die Startwerte eines Aufrufs: Argumente NACH PLATZ in die Parameter des Titels. Fehler -> PlanFehler
    (fuer den Bau: ein Struktogramm mit Parametern braucht im Thema aufruf="name(…)")."""
    sig = signatur(titel)
    if not sig:
        if str(aufruf or "").strip():
            raise PlanFehler("aufruf=\"%s\", aber der Titel „%s“ hat keine Parameter" % (aufruf, titel))
        return {}
    name, par = sig
    if not par and not str(aufruf or "").strip():
        return {}                  # „Algorithmus gib_durchschnitt()“ (T12): nichts mitzugeben
    arg = argumente(aufruf)
    if arg is None:
        raise PlanFehler("„%s“ hat Parameter -- es fehlt aufruf=\"%s(…)\" mit %d Argument(en)" % (titel, name, len(par)))
    if not aufruf.strip().startswith(name + "("):
        raise PlanFehler("aufruf=\"%s\" ruft nicht %s(…)" % (aufruf, name))
    if len(arg) != len(par):
        raise PlanFehler("%s(%s) braucht %d Argument(e), aufruf=\"%s\" hat %d" % (name, ", ".join(par), len(par), aufruf, len(arg)))
    return {p: werten(ausdruck(x), {}) for p, x in zip(par, arg)}


def kopf_lesen(kopf):
    """solange <Bedingung> · für i = <a> bis <b> · für jedes x in <Liste> (auch jede, jeden, jeder)."""
    t = str(kopf).strip()
    m = re.match(r"^für\s+(?:jedes|jeden|jede|jeder)\s+(%s)\s+in\s+(.+)$" % _NAME, t)
    if m:
        return {"art": "jedes", "name": m.group(1), "liste": ausdruck(m.group(2))}
    m = re.match(r"^für\s+(%s)\s*(?:=|von)\s*(.+?)\s+bis\s+(.+)$" % _NAME, t)
    if m:
        return {"art": "zaehl", "name": m.group(1), "von": ausdruck(m.group(2)), "bis": ausdruck(m.group(3))}
    if re.match(r"^für\b", t):
        raise PlanFehler("SyntaxError: Ein Kopf mit „für“ heißt „für i = 0 bis 4“ oder „für jedes ding in rucksack“")
    return {"art": "solange", "bed": ausdruck(re.sub(r"^solange\s+", "", t))}


def platz_zuweisung(t):
    """liste[i] = Wert -> (name, platz, rechts) oder None."""
    m = re.match(r"^(%s)\s*\[" % _NAME, t)
    if not m:
        return None
    tief, in_text, j = 0, False, m.end() - 1
    while j < len(t):
        c = t[j]
        if c == '"':
            in_text = not in_text
        elif not in_text and c == "[":
            tief += 1
        elif not in_text and c == "]":
            tief -= 1
            if tief == 0:
                break
        j += 1
    if j >= len(t):
        return None
    r = re.match(r"^\s*=(?!=)\s*(.+)$", t[j + 1:])
    return (m.group(1), t[m.end():j], r.group(1)) if r else None


def _ganz(w, wo):
    if not _zahl(w) or not float(w).is_integer():
        raise PlanFehler("TypeError: „für … bis“ braucht ganze Zahlen (%s: %s)" % (wo, zeig(w)))
    return int(w)


# ─── Durchlaufen ──────────────────────────────────────────────────────────────────────
RAUM_TEXT = {"flur": "Der Flur. Nur deine Lampe leuchtet.", "informatikraum": "Der Informatikraum. 24 Rechner schlafen.",
             "lehrerzimmer": "Das Lehrerzimmer. Es riecht nach altem Kaffee.",
             "keller": "Der Keller. Rohre, Staub, ein Schacht im Boden.", "tor": "Das Haupttor. Draußen ist Nacht."}


# Die Wege wie im Spiel (Lageplan, ohne Schluessel) -- wie in struktogramm.js; bis 25.10. kannte der Zug
# „gehe tor“, einen Befehl, den es im Spiel nie gab (Reihensichtung Teil I).
RICHTUNGEN = ("norden", "osten", "süden", "westen")
WEGE = {"flur": {"norden": "tor", "osten": "informatikraum", "süden": "lehrerzimmer", "westen": "keller"},
        "informatikraum": {"westen": "flur"}, "lehrerzimmer": {"norden": "flur"}, "keller": {"osten": "flur"}}


def _zug(v, ausgaben, traegt):
    """„einen Zug ausführen“ -- wie in struktogramm.js (zug): die Texte des Spiels (Stand nach Thema 7, kurz),
    traegt = was getragen wird (am Anfang die Lampe; ohne Lampe ist schau stockdunkel)."""
    e = "" if v.get("eingabe") is None else str(v.get("eingabe"))
    if e == "ende":
        ausgaben.append("Du setzt dich auf die Treppe und wartest auf den Morgen.")
    elif e in RICHTUNGEN:
        ziel = WEGE.get(v.get("raum"), {}).get(e)
        if not ziel:
            ausgaben.append("Da ist eine Wand.")
        else:
            v["raum"] = ziel
            ausgaben.append("Du schließt das Tor auf." if ziel == "tor" else "Du stehst jetzt im " + ziel + ".")
    elif e.startswith("nimm "):
        d = e[5:].strip()
        traegt.append(d)
        ausgaben.append("Du nimmst: " + d)
    elif e.startswith("lege "):
        d = e[5:].strip()
        if d in traegt:
            traegt.remove(d)
            ausgaben.append("Du legst weg: " + d)
        else:
            ausgaben.append("Das hast du nicht.")
    elif e == "schau":
        if "lampe" not in traegt:
            ausgaben.append("Stockdunkel. Du siehst nicht einmal, wo du die Lampe hingelegt hast.")
        else:
            ausgaben.append(RAUM_TEXT.get(v.get("raum"), "Du siehst dich um."))
    elif e == "hilfe":
        ausgaben.append("Befehle: norden, osten, süden, westen, schau, nimm <ding>, lege <ding>, hilfe, ende")
    else:
        ausgaben.append("Das verstehe ich nicht. Tippe hilfe.")


class _Endlos(Exception):
    pass


class _Wartet(Exception):
    pass


class _Rueckgabe(Exception):
    """Eine Rückgabe beendet den ganzen Lauf -- auch aus einer Schleife oder Verzweigung heraus."""


def laufen(baum, werte=None, eingaben=None):
    """Ein Lauf: gibt {"ausgaben": [...], "endet": bool, "fehler": str|None, "grund": ""}; nach einer
    Rückgabe steht ihr Wert als letzte Zeile „Rückgabe: …“ in den Ausgaben (so prüft ihn eine Probe)."""
    v = copy.deepcopy(dict(werte or {}))      # eine Liste im Fall darf der Lauf aendern, die naechste Probe nicht
    eingaben = list(eingaben or [])
    ausgaben, schritte, traegt = [], [0], ["lampe"]

    def schritt():
        schritte[0] += 1
        if schritte[0] > GRENZE:
            raise _Endlos()

    def block(kn):
        for k in kn:
            schritt()
            if k["art"] == "anweisung":
                t = k["text"]
                m = re.match(r"^Ausgabe:\s*(.*)$", t)
                if m:
                    ausgaben.append(zeig(werten(ausdruck(m.group(1)), v)))
                    continue
                r = rueckgabe(t)
                if r is not None:
                    ausgaben.append("Rückgabe: " + zeig(werten(ausdruck(r), v)))
                    raise _Rueckgabe()
                m = re.match(r"^([a-zA-Z_]\w*)\s*=\s*Eingabe\b", t)
                if m:
                    if not eingaben:
                        raise _Wartet()
                    v[m.group(1)] = eingaben.pop(0)
                    continue
                m = re.match(r"^([a-zA-Z_]\w*)\s*=\s*(.+)$", t)
                pz = None if m else platz_zuweisung(t)
                if m:
                    v[m.group(1)] = werten(ausdruck(m.group(2)), v)
                elif pz:
                    if pz[0] not in v:
                        raise PlanFehler("NameError: name '%s' is not defined" % pz[0])
                    L = v[pz[0]]
                    if isinstance(L, str):
                        raise PlanFehler("TypeError: In einem Text lässt sich kein Zeichen ersetzen")
                    j = platz(L, werten(ausdruck(pz[1]), v), True)
                    L[j] = werten(ausdruck(pz[2]), v)
                elif t == "einen Zug ausführen":
                    _zug(v, ausgaben, traegt)
            elif k["art"] == "schleife":
                kp = kopf_lesen(k["kopf"])
                if kp["art"] == "solange":
                    while werten(kp["bed"], v):
                        schritt()
                        block(k["rumpf"])
                    continue
                # für: Grenzen einmal am Anfang (wie range), die Liste beim Laufen (wie Python)
                if kp["art"] == "zaehl":
                    a, b = _ganz(werten(kp["von"], v), "von"), _ganz(werten(kp["bis"], v), "bis")
                else:
                    L = werten(kp["liste"], v)
                    if not isinstance(L, (list, str)):
                        raise PlanFehler("TypeError: „für jedes“ läuft nur über eine Liste oder einen Text (steht dort %s)" % zeig(L))
                j = 0
                while (a + j <= b) if kp["art"] == "zaehl" else (j < len(L)):
                    v[kp["name"]] = a + j if kp["art"] == "zaehl" else L[j]
                    schritt()
                    block(k["rumpf"])
                    j += 1
            else:
                block(k["ja"] if werten(ausdruck(k["bed"]), v) else k["nein"])

    try:
        block(baum)
        return {"ausgaben": ausgaben, "endet": True, "fehler": None, "grund": ""}
    except _Rueckgabe:
        return {"ausgaben": ausgaben, "endet": True, "fehler": None, "grund": ""}
    except _Endlos:
        return {"ausgaben": ausgaben, "endet": False, "fehler": None, "grund": "endet nicht"}
    except _Wartet:
        return {"ausgaben": ausgaben, "endet": False, "fehler": None, "grund": "wartet auf eine Eingabe"}
    except PlanFehler as e:
        return {"ausgaben": ausgaben, "endet": False, "fehler": str(e), "grund": "bricht ab"}
    except RecursionError:
        return {"ausgaben": ausgaben, "endet": False, "fehler": "zu tief verschachtelt", "grund": "bricht ab"}


# ─── Proben ───────────────────────────────────────────────────────────────────────────
def _teilen(s):
    """An den Kommas trennen, die nicht in [ ], ( ) oder "…" stehen (seit T10: namen = ["a", "b"], …)."""
    teile, tief, in_text, jetzt = [], 0, False, ""
    for c in s:
        if c == '"':
            in_text = not in_text
        elif not in_text and c in "[(":
            tief += 1
        elif not in_text and c in "])":
            tief -= 1
        if c == "," and not tief and not in_text:
            teile.append(jetzt)
            jetzt = ""
        else:
            jetzt += c
    teile.append(jetzt)
    return [x.strip() for x in teile if x.strip()]


def _fest(a):
    """Ein Startwert muss fest sein: Wert, Liste aus festen Werten, Zahl mit Vorzeichen."""
    if a[0] == "wert":
        return a[1]
    if a[0] == "liste":
        return [_fest(x) for x in a[1]]
    if a[0] == "-" and a[1] == ("wert", 0) and a[2][0] == "wert" and _zahl(a[2][1]):
        return -a[2][1]
    raise PlanFehler("kein fester Wert")


def proben_lesen(text):
    """Je Zeile:  name = Wert, name = Wert => soll   (soll: Ausgabezeilen mit „ / “ getrennt, oder „endet“;
    eine Rückgabe ist die Zeile „Rückgabe: 4500“ -- seit Thema 12, 23.10.)
    Befehle fuer Eingabe-Kaesten als  Befehle: schau | norden  . Gibt (proben, unlesbar)."""
    proben, unlesbar = [], []
    for z in str(text).split("\n"):
        if not z.strip():
            continue
        if "=>" not in z:
            unlesbar.append(z.strip())
            continue
        links, _, rechts = z.rpartition("=>")
        werte, eingaben, reihe = {}, [], []
        try:
            for teil in _teilen(links):
                m = re.match(r"^Befehle\s*:\s*(.*)$", teil)
                if m:
                    eingaben = [x.strip() for x in m.group(1).split("|") if x.strip()]
                    reihe.append(("Befehle", " | ".join(eingaben)))
                    continue
                m = re.match(r"^([a-zA-Z_]\w*)\s*=\s*(.+)$", teil)
                if not m:
                    raise PlanFehler(teil)
                werte[m.group(1)] = _fest(ausdruck(m.group(2)))
                reihe.append((m.group(1), m.group(2).strip()))
        except PlanFehler:
            unlesbar.append(z.strip())
            continue
        soll = rechts.strip()
        proben.append({"werte": werte, "eingaben": eingaben, "zeigen": reihe,
                       "soll": None if soll == "endet" else [x.strip() for x in soll.split(" / ")]})
    return proben, unlesbar


def pruefen(quelle, proben):
    """Der Plan der Klasse gegen die Proben: je Probe {ausgaben, endet, fehler, grund, ok} --
    dazu ein Fehler, wenn der Plan selbst nicht lesbar ist."""
    try:
        baum = lesen(quelle)
    except PlanFehler as e:
        return {"lesbar": False, "fehler": str(e), "proben": [], "ok": 0, "von": len(proben)}
    aus = []
    for p in proben:
        r = laufen(baum, p["werte"], p["eingaben"])
        r["ok"] = r["endet"] and not r["fehler"] and (p["soll"] is None or r["ausgaben"] == p["soll"])
        aus.append(r)
    return {"lesbar": True, "fehler": None, "proben": aus, "ok": sum(1 for r in aus if r["ok"]), "von": len(proben)}
