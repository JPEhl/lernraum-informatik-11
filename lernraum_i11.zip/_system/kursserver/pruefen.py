"""pruefen -- der Selbstcheck ohne pytest (nur Standardbibliothek).

Eine Pruefdatei (pruefung.py im Themenordner) sieht so aus:

    from pruefen import erwarte, noch_nicht_dran, arbeit, quelltext

    def pruefe_10_liste_da():
        \"\"\"Aufgabe 1 · Es gibt eine Liste namens rucksack\"\"\"
        erwarte(isinstance(getattr(arbeit(), "rucksack", None), list),
                "Noch keine Liste namens rucksack gefunden.")

Drei Zustaende, nicht zwei (wie seit dem 2026-09-01 in conftest.py):
    passt            -- hingesehen, zufrieden
    offen            -- hingesehen, etwas gefunden (erwarte() schlug an)
    spaeter          -- konnte nicht hinsehen, Voraussetzung fehlt (noch_nicht_dran())

Diagnose, keine Wegweisung: Die Meldung sagt, WAS nicht stimmt, nie wo der
Ausweg steht (sonst spielt der Check die gestufte Hilfe aus).

Aufruf (so ruft es der Server, isoliert, mit Zeitlimit von aussen):
    python -I pruefen.py <pruefung.py> <arbeitsdatei.py> [--json | --text]

Die Arbeitsdatei laeuft EINMAL in diesem Prozess, mit stillgelegtem
tkinter-mainloop und ohne input(); die Pruefungen sehen genau das Fenster,
das die Klasse gebaut hat, kein zweites.
"""
import inspect
import json
import pathlib
import re
import runpy
import sys
import textwrap
import time
import traceback
import types


class NochNichtDran(Exception):
    pass


class Offen(AssertionError):
    pass


class _ZuLang(BaseException):
    """Die Arbeitsdatei laeuft laenger als die Zeitgrenze -- fast immer eine Endlosschleife.
    BaseException, damit ein `except Exception` der Klasse sie nicht verschluckt."""


# Zeitgrenze je Lauf (Laden, jedes Anspielen, jede Pruefung). Vorher brach erst der Server nach 30 s
# den GANZEN Selbstcheck ab -- eine Endlosschleife in der Kuer kostete auch die Pflicht (Reihensichtung
# Teil I, 25.10., T8 Quersumme mit `z // 10` ohne Zuweisung).
ZEITGRENZE = 4.0
ENDLOS = ("Das Programm läuft hier endlos weiter. Ändert sich in der Schleife etwas, "
          "das die Bedingung irgendwann falsch macht?")


def _mit_zeitgrenze(fn, sekunden=None):
    """fn() ausfuehren; dauert es laenger als die Zeitgrenze, fliegt _ZuLang (ueber sys.settrace,
    also auch unter Windows, wo es kein SIGALRM gibt)."""
    ende = time.monotonic() + (ZEITGRENZE if sekunden is None else sekunden)
    zaehler = [0]

    def spur(frame, ereignis, arg):
        zaehler[0] += 1
        if zaehler[0] % 1000 == 0 and time.monotonic() > ende:
            raise _ZuLang()
        return spur
    alt = sys.gettrace()
    sys.settrace(spur)
    try:
        return fn()
    finally:
        sys.settrace(alt)


_ARBEIT = None
_QUELLE = ""
_ARBEITSDATEI = None
_EINGABEN = []
_AUSGABE = None


def ausgabe():
    """Alles, was die Arbeitsdatei beim Anspielen gedruckt hat."""
    return _AUSGABE.getvalue() if _AUSGABE is not None else ""


def erwarte(bedingung, meldung="passt noch nicht"):
    """Wie assert, aber mit Pflicht zur Meldung."""
    if not bedingung:
        raise Offen(meldung)


def noch_nicht_dran(grund=""):
    """Die Pruefung kann noch nicht hinsehen -- dritter Zustand."""
    raise NochNichtDran(grund)


def braucht(bedingung, grund=""):
    if not bedingung:
        noch_nicht_dran(grund)


def arbeit():
    """Das Modul der Arbeitsdatei, so wie sie gelaufen ist."""
    return _ARBEIT


def quelltext():
    return _QUELLE


def ohne_kommentare():
    return "\n".join(z for z in _QUELLE.splitlines() if not z.strip().startswith("#"))


def eigene_kommentare(vorgegeben=(), mindestlaenge=12):
    """Kommentarzeilen, die nicht aus der Vorlage stammen -- fuer Aufgaben,
    die eine Beobachtung verlangen (geprueft wird, DASS etwas dasteht)."""
    return [z.strip() for z in _QUELLE.splitlines()
            if z.strip().startswith("#") and len(z.strip()) > mindestlaenge
            and not any(v in z for v in vorgegeben)]


def anspielen(eingaben):
    """Die Arbeitsdatei noch einmal laufen lassen, mit anderen Eingaben (Sterne, 16.10.): So
    prueft eine Kuer das VERHALTEN an mehreren Befehlen, nicht eine hingeschriebene Antwort.
    Gibt (ausgabe, namen) zurueck; bricht das Programm ab, endet die Ausgabe dort."""
    import io
    global _AUSGABE
    alt_ein, alt_aus, alt_out = list(_EINGABEN), _AUSGABE, sys.stdout
    _EINGABEN[:] = [str(x) for x in eingaben]
    puffer = io.StringIO()
    _AUSGABE = puffer
    ns = {"__name__": "anspielen", "__file__": str(_ARBEITSDATEI)}
    sys.stdout = puffer
    endlos = False
    try:
        _mit_zeitgrenze(lambda: exec(compile(_QUELLE, str(_ARBEITSDATEI), "exec"), ns))      # noqa: S102
    except _ZuLang:
        endlos = True
    except BaseException:       # noqa: BLE001 -- Abbruch oder Ende der Eingaben: so weit ist es gekommen
        pass
    finally:
        sys.stdout, _AUSGABE = alt_out, alt_aus
        _EINGABEN[:] = alt_ein
    if endlos:
        raise Offen(ENDLOS)
    return puffer.getvalue(), ns


def funktion(name):
    f = getattr(_ARBEIT, name, None)
    return f if isinstance(f, types.FunctionType) else None


def _still_stellen():
    """mainloop still, input() verboten -- nur in DIESEM Prozess, der nach
    der Pruefung endet. Das Fenster der Klasse ist ein anderer Prozess."""
    try:
        import tkinter as tk
        tk.Misc.mainloop = lambda self, n=0: None
        tk.Tk.mainloop = lambda self, n=0: None
    except ImportError:
        pass
    import builtins

    def eingabe(frage=""):
        """input() bekommt die EINGABEN der Pruefdatei, der Reihe nach.
        Sind sie aufgebraucht, endet das Programm (wie ein geschlossenes
        Fenster) -- es haengt nie."""
        if _AUSGABE is not None:
            _AUSGABE.write(str(frage))
        if not _EINGABEN:
            raise SystemExit(0)
        antwort = _EINGABEN.pop(0)
        if _AUSGABE is not None:
            _AUSGABE.write(antwort + "\n")
        return antwort
    builtins.input = eingabe


def _arbeit_laden(pfad):
    global _ARBEIT, _QUELLE, _ARBEITSDATEI, _AUSGABE
    import io
    _ARBEITSDATEI = pathlib.Path(pfad).resolve()
    _QUELLE = _ARBEITSDATEI.read_text("utf-8", errors="replace")
    stem = _ARBEITSDATEI.stem
    sys.path.insert(0, str(_ARBEITSDATEI.parent))
    _AUSGABE = io.StringIO()
    ns = {"__name__": stem, "__file__": str(_ARBEITSDATEI)}
    code = compile(_QUELLE, str(_ARBEITSDATEI), "exec")
    alt = sys.stdout
    sys.stdout = _AUSGABE
    abbruch = None
    try:
        _mit_zeitgrenze(lambda: exec(code, ns))      # noqa: S102 -- die Arbeitsdatei IST der Pruefgegenstand
    except SystemExit:
        pass                # EINGABEN aufgebraucht oder eigenes exit(): so weit ist es gekommen
    except _ZuLang:
        abbruch = {"text": ENDLOS, "zeile": None, "original": "Zeitgrenze %g s" % ZEITGRENZE}
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist Befund, nicht Ende der Pruefung
        # Die Namen, die bis zum Abbruch entstanden sind, bleiben pruefbar:
        # ein Spiel, das bei 'lege lampe' abbricht, hat Aufgabe 1 vielleicht
        # schon richtig -- das soll der Check sagen koennen (gesehen an den
        # Beispielabgaben, 2026-10-13: "0 von 0" fuer eine halbe Loesung).
        tb = traceback.extract_tb(sys.exc_info()[2])
        zeile = None
        for fr in tb:
            if pathlib.Path(fr.filename).resolve() == _ARBEITSDATEI:
                zeile = fr.lineno
        abbruch = {"text": "Das Programm bricht beim Anspielen ab" + (" in Zeile %d" % zeile if zeile else "") + ".",
                   "zeile": zeile, "original": "%s: %s" % (type(e).__name__, e)}
    finally:
        sys.stdout = alt
    modul = types.ModuleType(stem)
    modul.__dict__.update(ns)
    modul.__file__ = str(_ARBEITSDATEI)
    sys.modules[stem] = modul
    _ARBEIT = modul
    return abbruch


def _pruefungen_laden(pfad):
    pfad = pathlib.Path(pfad).resolve()
    sys.modules["pruefen"] = sys.modules[__name__]
    ns = runpy.run_path(str(pfad), run_name="pruefung")
    funktionen = [(n, f) for n, f in ns.items()
                  if n.startswith("pruefe_") and isinstance(f, types.FunctionType)]
    funktionen.sort(key=lambda nf: nf[1].__code__.co_firstlineno)
    titel = ns.get("TITEL", "Selbstcheck")
    _EINGABEN[:] = list(ns.get("EINGABEN", []))
    return titel, funktionen


def _titel(f, name):
    doc = (f.__doc__ or "").strip().splitlines()
    if doc:
        return doc[0].strip()
    return name.replace("pruefe_", "").replace("_", " ").capitalize()


def laufen(pruefung, arbeitsdatei):
    """Gibt das Ergebnis als Dict: {titel, ergebnisse: [...], fehler: ...}."""
    _still_stellen()
    aus = {"titel": "Selbstcheck", "ergebnisse": [], "fehler": None}
    try:
        titel, funktionen = _pruefungen_laden(pruefung)
    except Exception as e:  # noqa: BLE001
        aus["fehler"] = {"text": "Die Pruefdatei selbst ist kaputt (kein Fehler der Klasse).",
                         "zeile": None, "original": "%s: %s" % (type(e).__name__, e)}
        return aus
    aus["titel"] = titel
    try:
        aus["abbruch"] = _arbeit_laden(arbeitsdatei)
    except SyntaxError as e:
        aus["fehler"] = {"text": "Die Datei laesst sich nicht lesen: Python versteht Zeile %s nicht." % e.lineno,
                         "zeile": e.lineno, "original": "%s: %s" % (type(e).__name__, e.msg)}
        return aus
    except BaseException as e:  # noqa: BLE001 -- der Fehler der Arbeitsdatei ist Inhalt
        tb = traceback.extract_tb(sys.exc_info()[2])
        zeile = None
        for fr in tb:
            if pathlib.Path(fr.filename).resolve() == _ARBEITSDATEI:
                zeile = fr.lineno
        aus["fehler"] = {"text": "Die Datei bricht beim Start ab" + (" in Zeile %d" % zeile if zeile else "") + ".",
                         "zeile": zeile, "original": "%s: %s" % (type(e).__name__, e)}
        return aus
    for name, f in funktionen:
        eintrag = {"name": name, "titel": _titel(f, name), "stand": "passt", "text": ""}
        try:
            _mit_zeitgrenze(f, ZEITGRENZE * 2)
        except _ZuLang:
            eintrag["stand"] = "offen"
            eintrag["text"] = ENDLOS
        except NochNichtDran as e:
            eintrag["stand"] = "spaeter"
            eintrag["text"] = str(e)
        except AssertionError as e:
            eintrag["stand"] = "offen"
            eintrag["text"] = str(e) or "passt noch nicht"
        except Exception as e:  # noqa: BLE001 -- Fehler IN der Pruefung: ehrlich melden
            eintrag["stand"] = "offen"
            eintrag["text"] = "Beim Pruefen ging etwas schief: %s: %s" % (type(e).__name__, e)
        aus["ergebnisse"].append(eintrag)
    return aus


def gruppe(titel):
    # „Aufgabe 3 ★★ · …“: die Sterne gehoeren zur Gruppe (Stufe der Aufgabe, 16.10.)
    m = re.match(r"(Aufgabe \d+\w?(?:\s*\u2605+)?|K\xfcr|Kuer|Vorrat|Grundlage)\s*\xb7\s*(.*)", titel)
    return (m.group(1), m.group(2)) if m else (titel, "")


def als_text(ergebnis, breite=46, zeile=66):
    """Die Klartextfassung -- wie der pytest-Nachspann seit dem 02.09.:
    je Aufgabe eine Zeile, genau EIN naechster Schritt im Detail."""
    z = []
    z.append("  " + ergebnis["titel"])
    z.append("  " + "-" * (breite + 18))
    if ergebnis["fehler"]:
        z.append("  " + ergebnis["fehler"]["text"])
        for t in textwrap.wrap(ergebnis["fehler"]["original"], zeile):
            z.append("      " + t)
        z.append("  " + "-" * (breite + 18))
        return "\n".join(z)
    if ergebnis.get("abbruch"):
        z.append("  !! " + ergebnis["abbruch"]["text"])
        for t in textwrap.wrap(ergebnis["abbruch"]["original"], zeile):
            z.append("      " + t)
    gruppen, folge = {}, []
    for e in ergebnis["ergebnisse"]:
        g, rest = gruppe(e["titel"])
        if g not in gruppen:
            gruppen[g] = []
            folge.append(g)
        gruppen[g].append(e)
    for g in folge:
        ee = gruppen[g]
        passt = sum(1 for e in ee if e["stand"] == "passt")
        offen = sum(1 for e in ee if e["stand"] == "offen")
        if passt == len(ee):
            stand = "passt"
        elif passt == 0 and offen == 0:
            stand = "noch nicht dran"
        elif passt == 0:
            stand = "steht noch aus"
        else:
            stand = "%d von %d %s" % (passt, len(ee), "passt" if passt == 1 else "passen")
        z.append("  %-*s  %s" % (breite, g, stand))
    naechste = next((e for e in ergebnis["ergebnisse"] if e["stand"] == "offen"), None)
    if naechste:
        z.append("")
        z.append("  Der naechste Schritt -- " + naechste["titel"] + ":")
        for t in textwrap.wrap(naechste["text"], zeile):
            z.append("      " + t)
    z.append("  " + "-" * (breite + 18))
    alle = len(ergebnis["ergebnisse"])
    passt = sum(1 for e in ergebnis["ergebnisse"] if e["stand"] == "passt")
    spaeter = sum(1 for e in ergebnis["ergebnisse"] if e["stand"] == "spaeter")
    if passt == alle and alle:
        z.append("  Alle %d passen -- fertig!" % alle)
    else:
        satz = "  %d von %d passen." % (passt, alle - spaeter)
        if spaeter:
            satz += " %d %s noch nicht dran." % (spaeter, "ist" if spaeter == 1 else "sind")
        z.append(satz)
    return "\n".join(z)


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    form = "--json" if "--json" in argv else "--text"
    pruefung, arbeitsdatei = argv[0], argv[1]
    ergebnis = laufen(pruefung, arbeitsdatei)
    if form == "--json":
        sys.__stdout__.write("\n@@SELBSTCHECK@@" + json.dumps(ergebnis, ensure_ascii=False) + "\n")
    else:
        sys.__stdout__.write("\n" + als_text(ergebnis) + "\n")
    sys.__stdout__.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
