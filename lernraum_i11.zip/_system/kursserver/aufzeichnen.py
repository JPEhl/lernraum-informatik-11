"""Aufzeichnung: ein Programm laeuft einmal, und jeder Schritt wird notiert --
Zeile, Werte der Variablen, Objekte. Danach kann man auf der Seite vor- und
zurueckgehen (Python-Tutor-Art, ohne fremden Server).

Laeuft als EIGENER Unterprozess:
    python -u aufzeichnen.py <datei>
und schreibt JSON-Zeilen nach stdout -- eine je Ablauf-Ereignis --, die der
Server einsammelt. Ausgaben des Programms (print) landen im selben Strom als
{"art": "ausgabe"}.

tkinter: Vom Programmstart bis mainloop() ist der erste Ablauf. Danach ist
JEDER Aufruf eines Callbacks aus der Ereignisschleife ein eigener Ablauf
("Klick: hoch"). Machbarkeit am 2026-10-12 belegt (Probe im Scratchpad,
danach hier): Der Trace-Haken der Thread bleibt gesetzt, wenn Tcl zurueck
in Python ruft; ein Frame aus der Arbeitsdatei, dessen Vater NICHT aus der
Arbeitsdatei ist, beginnt waehrend mainloop einen neuen Ablauf.

Grenze: GRENZE Schritte insgesamt (Endlosschleife) -> Hinweis, Abbruch.
"""
import json
import runpy
import sys
import traceback
import types

GRENZE = 5000
KUERZE = 60
TIEFE = 2

_DATEI = None
_ablauf_nr = 0
_schritte = 0
_im_mainloop = False
_gestoppt = False
_ausgabe_puffer = []
_objekte_sicht = {}


def _senden(**d):
    sys.__stdout__.write(json.dumps(d, ensure_ascii=False) + "\n")
    sys.__stdout__.flush()


class _Ausgabe:
    """print() des Programms faengt hier -- als Ereignis in der Aufzeichnung,
    damit die Seite sagen kann, bei welchem Schritt was gedruckt wurde."""
    def write(self, s):
        if s:
            _senden(art="ausgabe", text=s, ablauf=_ablauf_nr, schritt=_schritte)

    def flush(self):
        pass


def _wert(v, tiefe=0, objekte=None):
    """Einfache Werte als Text, zusammengesetzte als Verweis auf ein Objekt
    (nach id), damit zwei Namen auf dieselbe Liste als EIN Kasten erscheinen."""
    if v is None or isinstance(v, (bool, int, float)):
        return {"art": "wert", "text": repr(v)}
    if isinstance(v, str):
        t = repr(v)
        return {"art": "wert", "text": t if len(t) <= KUERZE else t[:KUERZE] + "…'"}
    if isinstance(v, (types.ModuleType, types.FunctionType, types.BuiltinFunctionType, type)):
        name = getattr(v, "__name__", "?")
        art = {types.ModuleType: "Modul", types.FunctionType: "Funktion",
               types.BuiltinFunctionType: "Funktion"}.get(type(v), "Klasse")
        return {"art": "wert", "text": art + " " + name}
    if objekte is None:
        return {"art": "wert", "text": repr(v)[:KUERZE]}
    oid = id(v)
    if oid not in objekte:
        objekte[oid] = {"typ": type(v).__name__}
        if tiefe <= TIEFE:
            if isinstance(v, (list, tuple, set, frozenset)):
                objekte[oid]["inhalt"] = [_wert(x, tiefe + 1, objekte) for x in list(v)[:50]]
                if len(v) > 50:
                    objekte[oid]["mehr"] = len(v) - 50
            elif isinstance(v, dict):
                objekte[oid]["inhalt"] = [[_wert(k, tiefe + 1, objekte), _wert(x, tiefe + 1, objekte)]
                                          for k, x in list(v.items())[:50]]
            elif hasattr(v, "__dict__") and not type(v).__module__.startswith("tkinter"):
                objekte[oid]["inhalt"] = [[{"art": "wert", "text": k}, _wert(x, tiefe + 1, objekte)]
                                          for k, x in list(vars(v).items())[:30] if not k.startswith("_")]
            else:
                objekte[oid]["text"] = repr(v)[:KUERZE]
        else:
            objekte[oid]["text"] = "…"
    return {"art": "ref", "id": str(oid)}


def _rahmen(frame, objekte):
    lok = {}
    glob = {}
    for k, v in frame.f_globals.items():
        if k.startswith("__") or isinstance(v, types.ModuleType):
            continue
        glob[k] = _wert(v, 0, objekte)
    if frame.f_code.co_name != "<module>":
        for k, v in frame.f_locals.items():
            if not k.startswith("__"):
                lok[k] = _wert(v, 0, objekte)
    return glob, lok


def _stapel(frame):
    namen = []
    f = frame
    while f is not None and f.f_code.co_filename == _DATEI:
        namen.append(f.f_code.co_name)
        f = f.f_back
    return list(reversed(namen))


def _trace(frame, ereignis, arg):
    global _ablauf_nr, _schritte, _gestoppt
    if _gestoppt or frame.f_code.co_filename != _DATEI:
        return None
    if _im_mainloop and ereignis == "call" and (
            frame.f_back is None or frame.f_back.f_code.co_filename != _DATEI):
        _ablauf_nr += 1
        _senden(art="ablauf", nr=_ablauf_nr, name="Klick: " + frame.f_code.co_name + "()")
    if ereignis in ("line", "call", "return", "exception"):
        _schritte += 1
        if _schritte > GRENZE:
            _gestoppt = True
            _senden(art="grenze", schritte=GRENZE,
                    text="Nach %d Schritten ist Schluss. Laeuft das Programm vielleicht endlos?" % GRENZE)
            sys.settrace(None)
            raise SystemExit(3)
        objekte = {}
        glob, lok = _rahmen(frame, objekte)
        d = {"art": "schritt", "ablauf": _ablauf_nr, "ereignis": ereignis,
             "zeile": frame.f_lineno, "funktion": frame.f_code.co_name,
             "stapel": _stapel(frame), "global": glob, "lokal": lok, "objekte": objekte}
        if ereignis == "return":
            d["rueckgabe"] = _wert(arg, 0, objekte)
        if ereignis == "exception":
            d["ausnahme"] = "%s: %s" % (arg[0].__name__, arg[1])
        _senden(**d)
    return _trace


def _tk_umbauen():
    try:
        import tkinter as tk
    except ImportError:
        return
    import os
    original = tk.Misc.mainloop
    # Nur fuer Tests (25.10., Teil III): LERNRAUM_KLICKS = JSON-Liste von Knopf-Beschriftungen, "feld=text" tippt
    # ins erste Textfeld; die Klicks laufen aus der Ereignisschleife wie echte, danach schliesst das Fenster.
    try:
        klicks = json.loads(os.environ.get("LERNRAUM_KLICKS", "null"))
    except ValueError:
        klicks = None

    def nachspielen(wurzel):
        offen, alle = list(wurzel.winfo_children()), []
        while offen:
            w = offen.pop(0)
            alle.append(w)
            offen[0:0] = list(w.winfo_children())
        for k in klicks:
            if k.startswith("feld="):
                for w in alle:
                    if w.winfo_class() == "Entry":
                        w.delete(0, "end")
                        w.insert(0, k[5:])
                        break
                continue
            for w in alle:
                if w.winfo_class() == "Button" and str(w.cget("text")).strip().lower() == k.strip().lower():
                    w.invoke()
                    break
        wurzel.destroy()

    def mainloop(self, n=0):
        global _im_mainloop
        _im_mainloop = True
        _senden(art="mainloop", text="Das Fenster steht. Jeder Klick wird jetzt ein eigener Ablauf. Fenster schliessen beendet die Aufzeichnung.")
        if klicks is not None:
            self.after(50, lambda: nachspielen(self))
        try:
            original(self, n)
        finally:
            _im_mainloop = False
    tk.Misc.mainloop = mainloop


def _input_umbauen():
    """input() bekommt zuerst die Eingaben, die die Seite vorab mitgibt (LERNRAUM_EINGABEN als JSON-Liste --
    der Code-Film); sind sie verbraucht, WARTET die Aufzeichnung (Lehrer 24.10.: „dass der Debugger automatisch
    stoppt, wenn man eine Eingabe in die Shell schreiben soll. So kenne ich das“): Sie meldet {"art": "warte"}
    und liest eine Zeile von stdin, die die Seite ueber aufzeichnen/eingabe schickt. Bis dahin aufgezeichnete
    Schritte kann man schon ansehen, auch rueckwaerts. stdin zu -> das Programm endet wie vorher."""
    import builtins
    import os
    try:
        vorrat = json.loads(os.environ.get("LERNRAUM_EINGABEN", "[]"))
    except ValueError:
        vorrat = []

    def eingabe(frage=""):
        _senden(art="ausgabe", text=str(frage), ablauf=_ablauf_nr, schritt=_schritte)
        if vorrat:
            antwort = vorrat.pop(0)
        else:
            _senden(art="warte", frage=str(frage), ablauf=_ablauf_nr, schritt=_schritte)
            zeile = sys.__stdin__.readline()
            if not zeile:
                _senden(art="ausgabe", text="[keine Eingabe mehr -- Ende]\n", ablauf=_ablauf_nr, schritt=_schritte)
                raise SystemExit(0)
            antwort = zeile.rstrip("\r\n")
        _senden(art="ausgabe", text=antwort + "\n", ablauf=_ablauf_nr, schritt=_schritte)
        return antwort
    builtins.input = eingabe


def main():
    global _DATEI
    _DATEI = sys.argv[1]
    _tk_umbauen()
    _input_umbauen()
    sys.stdout = _Ausgabe()
    sys.stderr = _Ausgabe()
    _senden(art="ablauf", nr=0, name="Programmstart")
    code = 0
    sys.settrace(_trace)
    try:
        runpy.run_path(_DATEI, run_name="__main__")
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else 0
    except BaseException:  # noqa: BLE001 -- der Fehler des Programms ist Inhalt
        sys.settrace(None)
        tb = traceback.format_exc()
        _senden(art="fehler", text=tb)
        code = 1
    finally:
        sys.settrace(None)
    _senden(art="ende", code=code, schritte=_schritte)
    sys.exit(code)


if __name__ == "__main__":
    main()
