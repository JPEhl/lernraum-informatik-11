"""Pruefstoff ohne Klartext (Lehrer 16.10.2026: „kann man keinen Schutz einbauen?“).

Die Klasse bekommt Rueckmeldung ohne Netz -- also muss auf ihrem Stick liegen, was „richtig“
erkennt. Lesen soll man es dort aber nicht koennen:
  * Vorhersagen, Fehlerzeilen eines Falls, die richtige Wahl einer Frage: nur FINGERABDRUECKE
    (gesalzenes SHA-256, Salz = Kennung). Ob eine Antwort stimmt, rechnet der Server aus der
    Antwort -- die Datei verraet nichts.
  * Befundtexte eines Falls: verschleiert mit der Zeile als Schluessel -- lesbar erst, wenn die
    Zeile gefunden ist.
  * Reihenfolge eines Puzzles: verschleiert (der Hinweis „noch n Zeilen falsch“ braucht sie;
    Lehrerwahl 16.10.: der Hinweis ist wichtiger). Schuetzt vor dem Lesen, nicht vor dem Knacken.
Was bleibt: Raten ueber die Seite (jeder Versuch zaehlt und steht in der Uebersicht) und wer
das Python des Lernraums auseinandernimmt. Code-Aufgaben sind ohnehin sicher: Die Uebersicht
laesst den Selbstcheck auf dem abgegebenen Code neu laufen.
"""
import base64
import hashlib
import re


def _h(salz, text):
    return hashlib.sha256((salz + "\x00" + text).encode("utf-8")).hexdigest()[:32]


def _normal(t):
    """Wie eine Luecke: Leerzeichen ausserhalb von Text zaehlen nicht, ' und " sind gleich."""
    aus, innen = [], None
    for c in t.strip():
        if innen:
            aus.append('"' if c == innen else c)
            if c == innen:
                innen = None
        elif c in "\"'":
            innen = c
            aus.append('"')
        elif not c.isspace():
            aus.append(c)
    return "".join(aus)


# -- Vorhersagen ----------------------------------------------------------------------
def antwort_abdruecke(salz, erwartet):
    """Die Fingerabdruecke aller Formen, in denen eine erwartete Antwort gelten soll."""
    s = set()
    for e in erwartet:
        s.add(_h(salz, "n:" + _normal(e)))
        if len(e) >= 2 and e[0] == e[-1] and e[0] in "\"'":
            s.add(_h(salz, "r:" + e[1:-1]))           # Text ohne Anfuehrungszeichen, jedes Zeichen zaehlt
        if e.endswith("Error"):
            s.add(_h(salz, "e:" + e.lower()))         # der Name des Fehlers genuegt
    return sorted(s)


def antwort_stimmt(salz, antwort, abdruecke):
    if not antwort.strip():
        return False
    kandidaten = ["n:" + _normal(antwort), "r:" + antwort, "r:" + antwort.rstrip("\n"), "r:" + antwort.strip()]
    kandidaten += ["e:" + m for m in re.findall(r"[a-z]*error", antwort.lower())]
    abd = set(abdruecke)
    return any(_h(salz, k) in abd for k in kandidaten)


# -- Fragen und Fehlerzeilen ----------------------------------------------------------
def wahl_abdruck(salz, i):
    return _h(salz, "w:%d" % i)


def zeile_abdruck(salz, z):
    return _h(salz, "z:%d" % int(z))


# -- Verschleiern (schnell, ohne Kennwort) ----------------------------------------------
def _strom(schluessel, laenge):
    aus, i = bytearray(), 0
    while len(aus) < laenge:
        aus += hashlib.sha256(schluessel + i.to_bytes(8, "big")).digest()
        i += 1
    return bytes(aus[:laenge])


def verschleiern(salz, wozu, text):
    roh = text.encode("utf-8")
    k = hashlib.sha256(("abdruck\x00" + salz + "\x00" + wozu).encode("utf-8")).digest()
    return base64.b64encode(bytes(a ^ b for a, b in zip(roh, _strom(k, len(roh))))).decode("ascii")


def entschleiern(salz, wozu, b64):
    roh = base64.b64decode(b64)
    k = hashlib.sha256(("abdruck\x00" + salz + "\x00" + wozu).encode("utf-8")).digest()
    return bytes(a ^ b for a, b in zip(roh, _strom(k, len(roh)))).decode("utf-8")
