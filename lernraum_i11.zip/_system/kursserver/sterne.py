"""Sterne je Aufgabe (Lehrerentscheidung 16.10.2026).

Eine Aufgabe hat Stufen (::: stufe <n> in uebung.md, n = Sternwert). Eine Stufe ist geschafft,
wenn alles stimmt, was sie prueft: Vorhersage, Pruefrage, Puzzle, Fall und Plan darin, dazu die
Selbstcheck-Pruefungen „Aufgabe N ★★ · …“ (ohne ★: Stufe 1). Die Aufgabe zaehlt so viele
Sterne wie ihre HOECHSTE geschaffte Stufe -- man darf gleich die schwerere machen. Am Ende muss
jede Pflichtaufgabe mindestens einen Stern haben und die Summe die Mindestzahl erreichen.

Eine Rechnung fuer beide Stellen: Die Seite zeigt sie aus dem Stand des Lernraums, die
Uebersicht rechnet sie aus der ABGABE nach -- Selbstcheck neu gelaufen, Antworten neu gegen den
Pruefstoff geprueft, keine gespeicherten „geloest“-Haken. Die Sterne fliessen in die Bewertung;
der Stand liegt als Datei auf dem Stick der Klasse.
"""
import re

from . import abdruck
from .pruefen import gruppe

STERN = "★"


def selbstcheck_je(ergebnisse):
    """Ergebnisse des Selbstchecks je Aufgabe und Stufe: {nr: {passt, von, stufen: {"2": [passt, von, dran]}}}
    -- dran = nicht „noch nicht dran“ (Information; als versucht zaehlt erst, was passt)."""
    je = {}
    for e in ergebnisse or []:
        g, _ = gruppe(e["titel"])
        m = g.split()
        if not (m and m[0] == "Aufgabe" and len(m) > 1):
            continue
        stufe = str(len(m[2])) if len(m) > 2 and set(m[2]) == {STERN} else "1"
        z = je.setdefault(m[1], {"passt": 0, "von": 0, "stufen": {}})
        z["von"] += 1
        z["passt"] += e["stand"] == "passt"
        s = z["stufen"].setdefault(stufe, [0, 0, 0])
        s[1] += 1
        s[0] += e["stand"] == "passt"
        s[2] += e["stand"] != "spaeter"
    return je


def _vorhersage_ok(kennung, stand, pruefstoff):
    v = (pruefstoff.get("vorhersagen") or {}).get(kennung)
    antworten = ((stand.get("vorhersagen") or {}).get(kennung) or {}).get("antworten") or []
    if not v or len(antworten) < len(v["abdruecke"]):
        return False
    return all(abdruck.antwort_stimmt(kennung, str(a), abd) for a, abd in zip(antworten, v["abdruecke"]))


def _frage_ok(kennung, name, stand, pruefstoff):
    f = (stand.get("fragen") or {}).get(kennung) or {}
    q = (pruefstoff.get("fragen") or {}).get(kennung) or {}
    return bool(f.get("geloest")) and isinstance(f.get("wahl"), int) and abdruck.wahl_abdruck(kennung, f["wahl"]) == q.get("abdruck")


def _puzzle_ok(kennung, stand, pruefstoff):
    from .server import puzzle_falsch, puzzle_zeilen
    p = (pruefstoff.get("parsons") or {}).get(kennung)
    prog = ((stand.get("puzzles") or {}).get(kennung) or {}).get("programm")
    return bool(p) and prog is not None and puzzle_falsch([str(x) for x in prog], puzzle_zeilen(kennung, p)) == 0


def _fall_ok(kennung, stand, pruefstoff):
    f = (pruefstoff.get("faelle") or {}).get(kennung)
    gef = {abdruck.zeile_abdruck(kennung, z) for z in (((stand.get("faelle") or {}).get(kennung) or {}).get("gefunden") or [])}
    return bool(f) and set(f["befunde"]) <= gef


def _plan_ok(kennung, name, stand, thema):
    """Plan (19.10.2026): aus der QUELLE nachgerechnet, nie aus dem gemerkten „geloest“ -- der Plan
    kann nach den Proben noch geaendert worden sein."""
    from . import plan as planlauf
    spec = (thema.get("plaene") or {}).get(name)
    quelle = ((stand.get("plaene") or {}).get(kennung) or {}).get("quelle")
    if not spec or not quelle:
        return False
    r = planlauf.pruefen(quelle, spec["proben"])
    return r["von"] > 0 and r["ok"] == r["von"]


def thema_sterne(pfad, thema, stand, pruefstoff, sc_je=None):
    """Sterne eines Themas. sc_je: Selbstcheck je Aufgabe (selbstcheck_je); ohne -- der zuletzt
    im Stand gemerkte (Seite). Gibt {aufgaben: {nr: {sterne, max, teil, stufen}}, summe, max,
    mindest, ohne_stern: [nr …], geschafft}."""
    aus, summe, gesamt, ohne = {}, 0, 0, []
    for a in thema["uebung"]["aufgaben"]:
        stufen = a.get("sterne") or []
        if not stufen:
            continue
        nr = a["nr"]
        sc = (sc_je or {}).get(nr) if sc_je is not None else \
            ((stand.get("aufgaben") or {}).get(pfad + "/" + nr) or {}).get("selbstcheck")
        sc_stufen = (sc or {}).get("stufen") or {}
        geschafft = {}
        for s in stufen:
            n = s["stufe"]
            pruef = []
            pruef += [_vorhersage_ok(pfad + "/" + x, stand, pruefstoff) for x in s.get("vorhersage", [])]
            pruef += [_frage_ok(pfad + "/" + x, x, stand, pruefstoff) for x in s.get("fragen", [])]
            pruef += [_puzzle_ok(pfad + "/" + x, stand, pruefstoff) for x in s.get("parsons", [])]
            pruef += [_fall_ok(pfad + "/" + x, stand, pruefstoff) for x in s.get("fall", [])]
            pruef += [_plan_ok(pfad + "/" + x, x, stand, thema) for x in s.get("plan", [])]
            p, v = (sc_stufen.get(str(n)) or [0, 0])[:2]
            if a["art"] == "code" and len(stufen) == 1 and not sc_stufen and sc and sc.get("von"):
                p, v = sc["passt"], sc["von"]          # alter Stand ohne Stufen: das Ganze zaehlt fuer Stufe 1
            if v:
                pruef.append(p == v)
            geschafft[str(n)] = bool(pruef) and all(pruef)
        sterne = max([int(n) for n, ok in geschafft.items() if ok] or [0])
        hoechst = max(s["stufe"] for s in stufen)
        # Versucht (Lehrer 16.10., nur zur Information): an der Stufe wurde etwas geprueft -- eine
        # Vorhersage, Frage, ein Puzzle oder Fall mit Versuchen, oder eine Selbstcheck-Pruefung war dran
        gemerkt = set(((stand.get("aufgaben") or {}).get(pfad + "/" + nr) or {}).get("versucht") or [])
        versucht = []
        for s in stufen:
            n = s["stufe"]
            spuren = [((stand.get(art) or {}).get(pfad + "/" + x) or {}).get("versuche", 0)
                      for art, liste in (("vorhersagen", s.get("vorhersage", [])), ("fragen", s.get("fragen", [])),
                                         ("puzzles", s.get("parsons", [])), ("faelle", s.get("fall", [])),
                                         ("plaene", s.get("plan", []))) for x in liste]
            # Code-Stufe: versucht, sobald eine ihrer Pruefungen passt -- „noch nicht“ meldet der
            # Selbstcheck schon im Startzustand (16.10., am Bild der Uebersicht gefunden)
            teilweise = (sc_stufen.get(str(n)) or [0, 0])[0] > 0
            if any(spuren) or n in gemerkt or teilweise or geschafft[str(n)]:
                versucht.append(n)
        aus[nr] = {"sterne": sterne, "max": hoechst, "teil": a["teil"], "stufen": geschafft, "versucht": versucht}
        gesamt += hoechst
        # Nur die PFLICHT muss einen Stern haben: Vorrat steht seit dem 17.10. unter „Ab hier
        # freiwillig“ (vorher zaehlte alles ausser der Kuer -- mit dem Vorrat in T4/T8/T9 erreichte
        # niemand das Ziel, der ihn ausliess; beim Bau von T9 an den Beispielabgaben gefunden, 19.10.)
        if a["teil"] == "pflicht" and not sterne:
            ohne.append(nr)
        summe += sterne
    mindest = thema["uebung"].get("sterne_mindest", 0)
    return {"aufgaben": aus, "summe": summe, "max": gesamt, "mindest": mindest, "ohne_stern": ohne,
            "geschafft": bool(aus) and not ohne and summe >= mindest}
