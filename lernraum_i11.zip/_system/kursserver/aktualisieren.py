"""Aktualisierung im laufenden Schuljahr (Lehrerentscheidung 2026-10-14, Weg B).

Eine Aktualisierung ist eine ZIP mit der ganzen gebauten Schuelerfassung und
ihrem Manifest (_system/manifest.json: je Datei SHA-256 und Art). Sie kommt
  * per Knopf: Python holt fassung.json von der festen Adresse des Kurses
    (inhalt.json "aktualisierung"), zeigt die Aenderungsliste, holt die ZIP
    und prueft ihre SHA-256 gegen fassung.json -- NUR auf Knopfdruck;
  * von Hand (ohne Netz): dieselbe ZIP ueber die Kursseite hereinnehmen.
Die Seite selbst geht nie ins Netz (CSP bleibt 'self').

Ersetzt wird, was der Kurs mitbringt: start.py, _system/ (Seite, Server,
Inhalt), Themeninhalte. BEWAHRT wird, was der Person gehoert: _stand/,
_anmerkungen/, abgaben/ (die Pfade sind in der ZIP verboten) und die
Arbeitsdateien (Art "arbeit": nur angelegt, wenn sie fehlen, nie ersetzt).

Sorgfalt, in dieser Reihenfolge:
  1. pruefen     jeder Name: relativ, ohne "..", ohne Backslash, kein Symlink,
                 nur erlaubte Ziele; Groessen begrenzt; Manifest == Inhalt der
                 ZIP, SHA-256 je Datei; Kurs gleich; Fassungsnummer GROESSER
  2. entpacken   nach _aktualisierung/neu/ (gleiches Laufwerk -> os.replace)
  3. sichern     was ersetzt oder entfernt wird -> _aktualisierung/alt/
  4. Protokoll   _aktualisierung/laeuft.json: was zurueck, was weg muss
  5. tauschen    Datei fuer Datei (os.replace); inhalt.json und Manifest zuletzt
  6. fertig      Protokoll weg, Verlauf fortschreiben
Scheitert 5, wird sofort zurueckgerollt. Stirbt der Prozess mittendrin, rollt
start.py beim naechsten Start mit demselben Protokoll zurueck -- kein halber
Stand. Das Format von laeuft.json ist darum fest: {"zurueck": [...], "weg": [...]}.
"""
import hashlib
import json
import os
import pathlib
import posixpath
import shutil
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

MANIFEST = "_system/manifest.json"
ERLAUBT_DATEIEN = ("start.py", "SO_FAENGST_DU_AN.pdf")   # bis 25.10. die .md
ERLAUBT_ORDNER = ("_system/", "themen/")
VERBOTEN = ("_system/lehrer/",)
ARTEN = ("system", "inhalt", "arbeit")
GRENZE_ANZAHL = 5000
GRENZE_ENTPACKT = 80 * 1024 * 1024
GRENZE_ZIP = 40 * 1024 * 1024
GRENZE_JSON = 256 * 1024
ARBEIT = "_aktualisierung"


class Abgelehnt(Exception):
    """Eine Aktualisierung, die nicht eingespielt wird -- der Text geht an die Seite."""


def sha256(daten):
    return hashlib.sha256(daten).hexdigest()


def name_pruefen(name):
    """Ein Name aus der ZIP -> derselbe Name, wenn er ein erlaubtes Ziel ist; sonst Abgelehnt.
    Zip-Slip: absolute Pfade, Laufwerke, '..', '.', Backslashes, leere Teile -- alles raus."""
    if not isinstance(name, str) or not name or "\\" in name or "\x00" in name:
        raise Abgelehnt("Unerlaubter Dateiname in der ZIP: %r" % name)
    if name.startswith("/") or (len(name) > 1 and name[1] == ":"):
        raise Abgelehnt("Absoluter Pfad in der ZIP: %s" % name)
    teile = name.split("/")
    if any(t in ("", ".", "..") for t in teile) or posixpath.normpath(name) != name:
        raise Abgelehnt("Pfad mit '..' oder Leerstelle in der ZIP: %s" % name)
    if name.startswith(VERBOTEN):
        raise Abgelehnt("Die ZIP will Lehrerdateien schreiben: %s" % name)
    if not (name in ERLAUBT_DATEIEN or name.startswith(ERLAUBT_ORDNER)):
        raise Abgelehnt("Die ZIP will etwas ausserhalb von Seite und Themen schreiben: %s" % name)
    return name


def ist_symlink(info):
    return (info.external_attr >> 16) & 0o170000 == 0o120000


def inhalt_lesen(wurzel):
    try:
        return json.loads((pathlib.Path(wurzel) / "_system" / "inhalt.json").read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def manifest_lesen(wurzel):
    try:
        return json.loads((pathlib.Path(wurzel) / MANIFEST).read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def pruefen(wurzel, zip_pfad, erwartet_sha=None):
    """Prueft eine Aktualisierungs-ZIP gegen diesen Lernraum und gibt den Plan
    zurueck -- schreibt NICHTS. Jede Unstimmigkeit ist ein Abgelehnt."""
    wurzel = pathlib.Path(wurzel)
    zip_pfad = pathlib.Path(zip_pfad)
    if zip_pfad.stat().st_size > GRENZE_ZIP:
        raise Abgelehnt("Die ZIP ist zu gross (%d MB)." % (zip_pfad.stat().st_size // 2**20))
    if erwartet_sha and sha256(zip_pfad.read_bytes()) != erwartet_sha:
        raise Abgelehnt("Die Pruefsumme der ZIP stimmt nicht mit fassung.json ueberein -- "
                        "unvollstaendig geladen oder veraendert. Nichts eingespielt.")
    try:
        z = zipfile.ZipFile(zip_pfad)
    except zipfile.BadZipFile:
        raise Abgelehnt("Das ist keine ZIP-Datei.")
    with z:
        infos = z.infolist()
        if len(infos) > GRENZE_ANZAHL:
            raise Abgelehnt("Zu viele Dateien in der ZIP.")
        namen, summe = set(), 0
        for i in infos:
            if ist_symlink(i):
                raise Abgelehnt("Die ZIP enthaelt eine Verknuepfung (Symlink): %s" % i.filename)
            if i.filename.endswith("/"):
                name_pruefen(i.filename.rstrip("/"))
                continue
            name_pruefen(i.filename)
            if i.filename in namen:
                raise Abgelehnt("Datei doppelt in der ZIP: %s" % i.filename)
            namen.add(i.filename)
            summe += i.file_size
            if summe > GRENZE_ENTPACKT:
                raise Abgelehnt("Die ZIP waere entpackt zu gross.")
        if MANIFEST not in namen:
            raise Abgelehnt("Das ist keine Aktualisierung: das Manifest fehlt.")
        if z.getinfo(MANIFEST).file_size > GRENZE_JSON:
            raise Abgelehnt("Manifest zu gross.")
        try:
            m = json.loads(z.read(MANIFEST).decode("utf-8"))
        except ValueError:
            raise Abgelehnt("Das Manifest ist unlesbar.")
        hier = inhalt_lesen(wurzel)
        if m.get("kurs") != hier.get("kurs"):
            raise Abgelehnt("Diese Aktualisierung gehoert zu einem anderen Kurs (%s, hier %s)." % (m.get("kurs"), hier.get("kurs")))
        try:
            nr, alt_nr = int(m.get("fassung_nr")), int(hier.get("fassung_nr") or 0)
        except (TypeError, ValueError):
            raise Abgelehnt("Die Fassungsnummer im Manifest ist keine Zahl.")
        if nr == alt_nr:
            raise Abgelehnt("Fassung %d ist schon da -- nichts zu tun." % nr)
        if nr < alt_nr:
            raise Abgelehnt("Fassung %d ist aelter als die hier (Fassung %d) -- zurueck geht es nie." % (nr, alt_nr))
        dateien = m.get("dateien")
        if not isinstance(dateien, dict) or set(dateien) != namen - {MANIFEST}:
            fehlt = sorted(set(dateien or {}) ^ (namen - {MANIFEST}))[:3]
            raise Abgelehnt("Manifest und ZIP passen nicht zusammen (%s)." % ", ".join(fehlt))
        for rel, d in dateien.items():
            if d.get("art") not in ARTEN or (d["art"] == "arbeit" and not rel.startswith("themen/")):
                raise Abgelehnt("Unbekannte Art im Manifest: %s" % rel)
            if sha256(z.read(rel)) != d.get("sha256"):
                raise Abgelehnt("Datei veraendert oder beschaedigt: %s" % rel)
    # -- der Plan: was ersetzt, neu angelegt, bewahrt, entfernt wird -------------
    plan = {"nr": nr, "alt_nr": alt_nr, "datum": m.get("fassung_datum", ""), "aenderungen": list(m.get("aenderungen") or []),
            "ersetzen": [], "neu": [], "arbeit_neu": [], "arbeit_bewahrt": [], "entfernen": [],
            "themen_neu": [t for t in (m.get("themen") or {}) if t not in (manifest_lesen(wurzel).get("themen") or {})],
            "themen": m.get("themen") or {}}
    for rel, d in sorted(dateien.items()):
        da = (wurzel / rel).is_file()
        if d["art"] == "arbeit":
            plan["arbeit_bewahrt" if da else "arbeit_neu"].append(rel)
        else:
            plan["ersetzen" if da else "neu"].append(rel)
    alt = manifest_lesen(wurzel).get("dateien") or {}
    for rel, d in sorted(alt.items()):
        if rel in dateien or d.get("art") == "arbeit":
            continue
        try:
            name_pruefen(rel)
        except Abgelehnt:
            continue
        if (wurzel / rel).is_file():
            plan["entfernen"].append(rel)
    return plan


def zusammenfassung(plan):
    """Fuer die Seite: Zahlen statt Dateilisten, dazu die Aenderungsliste."""
    return {"nr": plan["nr"], "alt_nr": plan["alt_nr"], "datum": plan["datum"], "aenderungen": plan["aenderungen"],
            "themen_neu": [plan["themen"].get(t, t) for t in plan["themen_neu"]],
            "zahlen": {k: len(plan[k]) for k in ("ersetzen", "neu", "entfernen", "arbeit_neu", "arbeit_bewahrt")}}


# -- Zurueckrollen: dieselbe Logik steht in start.py (laeuft, bevor kursserver geladen ist) --
def zurueckrollen(wurzel):
    """Gibt True zurueck, wenn ein abgebrochener Tausch zurueckgerollt wurde."""
    wurzel = pathlib.Path(wurzel)
    a = wurzel / ARBEIT
    j = a / "laeuft.json"
    if not j.exists():
        return False
    p = json.loads(j.read_text("utf-8"))
    for rel in p.get("weg", []):
        z = wurzel / rel
        if z.is_file():
            z.unlink()
    for rel in p.get("zurueck", []):
        q = a / "alt" / rel
        if q.is_file():
            (wurzel / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(q, wurzel / rel)
    j.unlink()
    shutil.rmtree(a / "neu", ignore_errors=True)
    shutil.rmtree(a / "alt", ignore_errors=True)
    return True


def einspielen(wurzel, zip_pfad, erwartet_sha=None, _scheitern_nach=None):
    """Prueft, entpackt, sichert, tauscht. Gibt den Bericht zurueck oder wirft
    Abgelehnt -- dann ist der Lernraum wie vorher. _scheitern_nach: nur fuer
    den Test (wirft nach so vielen Tauschschritten)."""
    wurzel = pathlib.Path(wurzel)
    zurueckrollen(wurzel)                      # ein alter Abbruch zuerst
    plan = pruefen(wurzel, zip_pfad, erwartet_sha)
    a = wurzel / ARBEIT
    shutil.rmtree(a / "neu", ignore_errors=True)
    shutil.rmtree(a / "alt", ignore_errors=True)
    (a / "neu").mkdir(parents=True)
    (a / "alt").mkdir(parents=True)
    schreiben = plan["ersetzen"] + plan["neu"] + plan["arbeit_neu"]
    # inhalt.json und Manifest zuletzt: die Fassungsnummer kippt erst, wenn alles andere da ist
    letzte = [r for r in ("_system/inhalt.json",) if r in schreiben]
    schreiben = [r for r in schreiben if r not in letzte] + letzte + [MANIFEST]
    with zipfile.ZipFile(zip_pfad) as z:
        m = json.loads(z.read(MANIFEST).decode("utf-8"))
        for rel in schreiben:
            daten = z.read(rel)
            if rel != MANIFEST and sha256(daten) != m["dateien"][rel]["sha256"]:
                raise Abgelehnt("Datei beim Entpacken veraendert: %s" % rel)
            ziel = a / "neu" / rel
            ziel.parent.mkdir(parents=True, exist_ok=True)
            ziel.write_bytes(daten)
    vorher = [r for r in schreiben if (wurzel / r).is_file()]
    for rel in vorher + plan["entfernen"]:
        ziel = a / "alt" / rel
        ziel.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(wurzel / rel, ziel)
    protokoll = {"nr": plan["nr"], "alt_nr": plan["alt_nr"], "zeit": time.strftime("%Y-%m-%dT%H:%M:%S"),
                 "zurueck": vorher + plan["entfernen"], "weg": [r for r in schreiben if r not in vorher]}
    tmp = a / "laeuft.tmp"
    tmp.write_text(json.dumps(protokoll, ensure_ascii=False), "utf-8")
    tmp.replace(a / "laeuft.json")
    schritte = 0
    try:
        for rel in plan["entfernen"]:
            (wurzel / rel).unlink()
            schritte += 1
            if _scheitern_nach is not None and schritte >= _scheitern_nach:
                raise OSError("Testabbruch")
        for rel in schreiben:
            ziel = wurzel / rel
            ziel.parent.mkdir(parents=True, exist_ok=True)
            os.replace(a / "neu" / rel, ziel)
            schritte += 1
            if _scheitern_nach is not None and schritte >= _scheitern_nach:
                raise OSError("Testabbruch")
    except OSError as e:
        zurueckrollen(wurzel)
        raise Abgelehnt("Beim Tauschen ging etwas schief (%s) -- alles ist zurueckgerollt, der Lernraum ist wie vorher." % e)
    verlauf = a / "verlauf.json"
    try:
        alt = json.loads(verlauf.read_text("utf-8")) if verlauf.exists() else []
    except ValueError:
        alt = []
    alt.append({"von": plan["alt_nr"], "auf": plan["nr"], "zeit": protokoll["zeit"], "zahlen": zusammenfassung(plan)["zahlen"]})
    verlauf.write_text(json.dumps(alt, ensure_ascii=False, indent=1), "utf-8")
    (a / "laeuft.json").unlink()
    shutil.rmtree(a / "neu", ignore_errors=True)
    shutil.rmtree(a / "alt", ignore_errors=True)
    return zusammenfassung(plan)


# -- Netz (nur auf Knopfdruck) -------------------------------------------------------
def _adresse_pruefen(adresse):
    u = urllib.parse.urlsplit(adresse)
    if u.scheme == "https" or (u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost")):
        return adresse
    raise Abgelehnt("Die Adresse der Aktualisierung muss mit https:// beginnen: %s" % adresse)


def _laden(adresse, grenze, zeit=15):
    req = urllib.request.Request(_adresse_pruefen(adresse), headers={"User-Agent": "Lernraum-Aktualisierung/1", "Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=zeit, context=ssl.create_default_context()) as r:
            daten = r.read(grenze + 1)
    except urllib.error.HTTPError as e:
        raise Abgelehnt("Der Server antwortet mit %d (%s)." % (e.code, adresse))
    except (urllib.error.URLError, OSError) as e:
        grund = getattr(e, "reason", e)
        raise Abgelehnt("Keine Verbindung (%s). Ohne Netz geht es von Hand: die Aktualisierungs-ZIP "
                        "über „Von Hand hereinnehmen“ wählen." % grund)
    if len(daten) > grenze:
        raise Abgelehnt("Antwort zu gross: %s" % adresse)
    return daten


def suchen(adresse, inhalt):
    """fassung.json holen und lesen -- schreibt nichts."""
    try:
        f = json.loads(_laden(adresse, GRENZE_JSON).decode("utf-8"))
    except ValueError:
        raise Abgelehnt("fassung.json ist unlesbar.")
    if f.get("kurs") != inhalt.get("kurs"):
        raise Abgelehnt("Unter dieser Adresse liegt ein anderer Kurs (%s)." % f.get("kurs"))
    try:
        nr = int(f["nr"])
    except (KeyError, TypeError, ValueError):
        raise Abgelehnt("fassung.json nennt keine Fassungsnummer.")
    if not isinstance(f.get("sha256"), str) or not isinstance(f.get("zip"), str):
        raise Abgelehnt("fassung.json nennt keine ZIP mit Pruefsumme.")
    return {"nr": nr, "datum": str(f.get("datum", "")), "aenderungen": [str(x) for x in f.get("aenderungen") or []][:60],
            "zip": f["zip"], "sha256": f["sha256"], "groesse": int(f.get("groesse") or 0),
            "neu": nr > int(inhalt.get("fassung_nr") or 0)}


def holen(adresse, info, ziel):
    """Die ZIP neben fassung.json holen und gegen deren Pruefsumme pruefen."""
    url = urllib.parse.urljoin(adresse, info["zip"])
    daten = _laden(url, GRENZE_ZIP, zeit=90)
    if sha256(daten) != info["sha256"]:
        raise Abgelehnt("Die geholte ZIP passt nicht zur Pruefsumme in fassung.json -- nichts eingespielt. Spaeter noch einmal versuchen.")
    ziel = pathlib.Path(ziel)
    ziel.parent.mkdir(parents=True, exist_ok=True)
    ziel.write_bytes(daten)
    return ziel
