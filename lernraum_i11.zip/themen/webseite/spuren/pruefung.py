from pruefen import erwarte, braucht, seite, weg

TITEL = "Links und Bilder · Selbstcheck"

# Fingerabdrücke der Startseiten in gepaecksuche/: Solange eine Seite so ist wie am Anfang, ist ihre Aufgabe
# „noch nicht dran“ -- am Start steht genau EINE Pflichtprüfung aus: der kaputte Link in Keflavík.
# Ändert sich ein Starttext, hier neu eintragen:
#   python3 -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1]).read().strip().encode()).hexdigest()[:12])" gepaecksuche/<datei>
START = {"lissabon.html": "3d302146554b", "helsinki.html": "4c883d4eeac9"}
STATIONEN = ["checkin.html", "gepaeckband.html", "keflavik.html", "lissabon.html", "helsinki.html", "fundbuero.html"]
DAVOR = {"gepaeckband.html": "checkin.html", "keflavik.html": "gepaeckband.html", "lissabon.html": "keflavik.html",
         "helsinki.html": "lissabon.html", "fundbuero.html": "helsinki.html"}


def angefangen(name):
    s = seite(name)
    braucht(s.da, "Die Datei %s fehlt im Ordner." % name)
    braucht(s.abdruck != START.get(name), "Noch nicht angefangen.")
    return s


def ziele(name):
    return [h for h, _, _ in seite(name).links()]


def pruefe_10_kef_kaputt():
    """Aufgabe 2 · Keflavík: kein Link auf eine Datei, die es nicht gibt"""
    kaputt = seite("keflavik.html").kaputte_links()
    erste = kaputt[0] if kaputt else ("", 0)
    erwarte(not kaputt, "In Zeile %d führt ein Link auf %s -- diese Datei gibt es im Ordner nicht." % (erste[1], erste[0]))


def pruefe_15_kef_lis():
    """Aufgabe 2 · Keflavík: LIS führt nach Lissabon"""
    # Seit dem Umbau (16.11.): „kein kaputter Link“ bestand auch, wer den Link löschte oder ihm das href nahm.
    braucht(not seite("keflavik.html").kaputte_links(), "Erst der kaputte Link.")
    erwarte("lissabon.html" in ziele("keflavik.html"), "Von Keflavík führt noch kein Link nach Lissabon.")


def pruefe_20_kef_zurueck():
    """Aufgabe 2 · Keflavík: „Zurück zum Gepäckband“ führt zum Gepäckband"""
    s = seite("keflavik.html")
    braucht(not s.kaputte_links(), "Erst der kaputte Link.")
    zurueck = [h for h, text, _ in s.links() if "Gepäckband" in text]
    erwarte(zurueck and all(h == "gepaeckband.html" for h in zurueck), "Der Link „Zurück zum Gepäckband“ führt noch woandershin.")


def pruefe_30_lis_hel():
    """Aufgabe 2 · Lissabon: HEL führt nach Helsinki"""
    angefangen("lissabon.html")
    erwarte("helsinki.html" in ziele("lissabon.html"), "Von Lissabon führt noch kein Link nach Helsinki.")


def pruefe_40_hel_ausgezeichnet():
    """Aufgabe 2 ★★ · Helsinki: ausgezeichnet, mit Links ins Fundbüro und zum Sperrgepäck"""
    s = angefangen("helsinki.html")
    erwarte(s.text("h1") == "Helsinki", "Helsinki hat noch keine Überschrift h1.")
    erwarte(not s.lose_texte(), s.meldung_lose())
    erwarte("fundbuero.html" in ziele("helsinki.html"), "Von Helsinki führt noch kein Link ins Fundbüro.")
    erwarte("sperrgepaeck.html" in ziele("helsinki.html"), "Von Helsinki führt noch kein Link zum Sperrgepäck.")
    erwarte(not s.kaputte_links(), "Ein Link in Helsinki führt auf eine Datei, die es nicht gibt.")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_50_weg():
    """Aufgabe 2 ★★ · Vom Check-in bis ins Fundbüro durchklickbar"""
    angefangen("helsinki.html")
    w = weg("checkin.html", "fundbuero.html")
    erwarte(w is not None, "Vom Check-in aus kommt man noch nicht durchklickbar bis ins Fundbüro.")


def _bilder_da():
    return [n for n in STATIONEN if any(src for src, _, _ in seite(n).bilder())]


def pruefe_60_bilder():
    """Aufgabe 3 · Ein Bild in jeder Station"""
    braucht(_bilder_da(), "Noch nicht angefangen.")
    fehlt = [n for n in STATIONEN if not any(src for src, _, _ in seite(n).bilder())]
    erwarte(not fehlt, "Noch ohne Bild: %s." % ", ".join(fehlt))
    falsch = ["%s (%s)" % (n, src) for n in STATIONEN for src, _ in seite(n).fehlende_bilder()]
    erwarte(not falsch, "Ein Bild nennt eine Datei, die es nicht gibt: %s." % (falsch[0] if falsch else ""))


# Was auf GERADE DIESEM Bild zu sehen ist (Wortteile, klein; kein „Koffer“, der ist überall; ohne den Namen der Station -- „Bild von Helsinki“ beschreibt
# nichts). Bis 08.11. galt jedes alt ab drei Wörtern, auch „Ein schönes Bild hier“ (Lauf i11: misst den Namen, nicht
# die Sache). Ändert sich ein Bild, hier nachziehen; die Lösung in loesung/ muss bestehen.
ZU_SEHEN = {
    "checkin.svg": ["schalter", "waage", "tafel", "abflug", "anzeige"],
    "gepaeckband.svg": ["band", "7", "sieben", "halle", "aufkleber", "kef", "lamelle"],
    "keflavik.svg": ["flugzeug", "flieger", "rollfeld", "windsack", "wind", "schnee", "piste", "triebwerk"],
    "lissabon.svg": ["surf", "möwe", "moewe", "band", "3", "drei", "sonne", "vogel"],
    "helsinki.svg": ["schnee", "verschneit", "wagen", "terminal", "winter", "flocke", "kalt"],
    "fundbuero.svg": ["tür", "tuer", "regal", "klingel", "fenster", "schalter", "tresen", "zettel", "lost"],
}


def _zeigt(src, alt):
    woerter = ZU_SEHEN.get(src.rsplit("/", 1)[-1])
    if woerter is None:
        return True
    klein = alt.lower()
    return any(w in klein for w in woerter)


def pruefe_70_alt():
    """Aufgabe 3 ★★ · Jedes Bild sagt in Worten, was zu sehen ist"""
    braucht(_bilder_da(), "Noch nicht angefangen.")
    alle = [(n, src, (alt or "").strip()) for n in STATIONEN for src, alt, _ in seite(n).bilder()]
    kurz = [n for n, _, alt in alle if len(alt.split()) < 3]
    erwarte(not kurz, "Ein alt fehlt oder sagt zu wenig (ein Satz): %s." % (kurz[0] if kurz else ""))
    texte = [alt.lower() for _, _, alt in alle]
    doppelt = [n for n, _, alt in alle if texte.count(alt.lower()) > 1]
    erwarte(not doppelt, "Zwei Bilder haben dasselbe alt (%s) -- jedes Bild zeigt etwas anderes."
            % (doppelt[0] if doppelt else ""))
    leer = [n for n, src, alt in alle if not _zeigt(src, alt)]
    erwarte(not leer, "Das alt in %s sagt noch nicht, was gerade DIESES Bild zeigt. Seht es euch an: Was ist dort "
            "anders als auf den anderen Bildern?" % (leer[0] if leer else ""))


def _zurueck_da():
    return [n for n, davor in DAVOR.items() if davor in ziele(n)]


def pruefe_80_zurueck():
    """Aufgabe 6 ★★ · Jede Station führt zurück zur Station davor"""
    da = _zurueck_da()
    braucht(len(da) >= 2, "Noch nicht angefangen.")
    fehlt = [n for n in DAVOR if n not in da]
    erwarte(not fehlt, "Noch ohne Link zurück: %s." % ", ".join(fehlt))


def pruefe_90_start():
    """Aufgabe 6 ★★★ · Jede Station führt zur Startseite"""
    braucht(any("index.html" in ziele(n) for n in STATIONEN), "Noch nicht angefangen.")
    fehlt = [n for n in STATIONEN if "index.html" not in ziele(n)]
    erwarte(not fehlt, "Noch ohne Link zur Startseite: %s." % ", ".join(fehlt))


def pruefe_95_bild_als_link():
    """Aufgabe 8 ★★★ · Am Check-in ist das Bild ein Link zum Gepäckband"""
    s = seite("checkin.html")
    braucht(s.bilder(), "Noch nicht angefangen.")
    erwarte(any(a.finde("img") and a.attribute.get("href") == "gepaeckband.html" for a in s.elemente("a")),
            "Das Bild am Check-in ist noch kein Link zum Gepäckband.")
