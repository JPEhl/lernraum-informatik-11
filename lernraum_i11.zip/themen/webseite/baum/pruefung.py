from pruefen import erwarte, braucht, seite

TITEL = "Jede Station gleich gebaut · Selbstcheck"

# Fingerabdrücke der Startseiten in gepaecksuche/: Solange eine Seite so ist wie am Anfang, ist ihre Aufgabe
# „noch nicht dran“ -- am Start steht genau EINE Pflichtprüfung aus: die offene Liste in Lissabon.
# Ändert sich ein Starttext, hier neu eintragen:
#   python3 -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1]).read().strip().encode()).hexdigest()[:12])" gepaecksuche/<datei>
START = {"helsinki.html": "80039836e5da", "keflavik.html": "7a6b67656765", "index.html": "9a0cae664a85",
         "tuba.html": "4c73e906dd52"}
STATIONEN = ["checkin.html", "gepaeckband.html", "keflavik.html", "lissabon.html", "helsinki.html", "fundbuero.html"]
REISE = ["checkin.html", "gepaeckband.html", "keflavik.html", "lissabon.html", "helsinki.html", "fundbuero.html"]


def angefangen(name):
    s = seite(name)
    braucht(s.da, "Die Datei %s fehlt im Ordner." % name)
    braucht(s.abdruck != START.get(name), "Noch nicht angefangen.")
    return s


def kinder(k):
    return [c for c in k.kinder if not isinstance(c, str)]


def bau_fehler(name):
    """Was am Bau der Station nicht passt, oder der leere Text."""
    s = seite(name)
    teile = [k.tag for k in kinder(s.erstes("body"))]
    if teile != ["header", "main", "nav"]:
        return "%s: Direkt in body stehen %s -- es sollen header, main, nav sein." % (name, ", ".join(teile) or "keine Elemente")
    if not s.erstes("header").finde("h1"):
        return "%s: Im header steht keine Überschrift h1." % name
    nav = s.erstes("nav")
    if not (nav.finde("ul") or nav.finde("ol")) or not nav.finde("a"):
        return "%s: In nav steht keine Liste mit Links." % name
    if not all(a.eltern.tag == "li" for a in nav.finde("a")):
        return "%s: Ein Link in nav steht nicht in einem li." % name
    return ""


def pruefe_10_lissabon_liste():
    """Aufgabe 2 · Lissabon: Die Liste ist geschlossen"""
    s = seite("lissabon.html")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_20_helsinki_kreuz():
    """Aufgabe 2 ★★ · Helsinki: Nichts steht überkreuz"""
    s = angefangen("helsinki.html")
    kreuz = s.ueberkreuzt[0] if s.ueberkreuzt else ("", 0, "")
    erwarte(not s.ueberkreuzt, "In Zeile %d schließt </%s>, obwohl <%s> darin noch offen ist." % (kreuz[1], kreuz[0], kreuz[2]))
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_25_helsinki_liste():
    """Aufgabe 2 ★★ · Helsinki: Jeder Listenpunkt steht in einer Liste"""
    s = angefangen("helsinki.html")
    lose = [li for li in s.elemente("li") if li.eltern.tag not in ("ul", "ol")]
    zeile = lose[0].zeile if lose else 0
    erwarte(not lose, "In Zeile %d steht ein li, aber sein Elternelement ist keine Liste." % zeile)


def pruefe_30_zwei_stationen():
    """Aufgabe 3 · Keflavík und Lissabon: header, main, nav"""
    angefangen("keflavik.html")
    for name in ("keflavik.html", "lissabon.html"):
        fehler = bau_fehler(name)
        erwarte(not fehler, fehler)


def pruefe_40_alle_stationen():
    """Aufgabe 3 ★★ · Alle sechs Stationen gleich gebaut"""
    angefangen("keflavik.html")
    braucht(not bau_fehler("keflavik.html") and not bau_fehler("lissabon.html"), "Erst Keflavík und Lissabon.")
    fehlt = [bau_fehler(n) for n in STATIONEN if bau_fehler(n)]
    erwarte(not fehlt, fehlt[0] if fehlt else "")
    erwarte(not seite("helsinki.html").erstes("main").finde("br"), "In Helsinki stehen noch br im main -- jeder Satz wird ein Absatz.")


def _reise(k):
    """Die Ziele der Links in einer ol, in ihrer Folge."""
    return [a.attribute.get("href") for ol in k.finde("ol") for a in ol.finde("a")]


def pruefe_50_reise():
    """Aufgabe 5 ★★ · Die Startseite zeigt die Reise als ol"""
    s = angefangen("index.html")
    erwarte(_reise(s.wurzel) == REISE, "Auf der Startseite steht noch keine ol mit den sechs Stationen in der Reihenfolge der Reise.")


def pruefe_60_reise_nav():
    """Aufgabe 5 ★★★ · Die Reise steht in nav, auch am Check-in"""
    s = angefangen("index.html")
    braucht(_reise(s.wurzel) == REISE, "Erst die Liste auf der Startseite.")
    for name in ("index.html", "checkin.html"):
        navs = seite(name).elemente("nav")
        erwarte(any(_reise(n) == REISE for n in navs), "%s: Die Reise steht noch nicht in nav." % name)


def form(k):
    return (k.tag, [form(c) for c in kinder(k)])


TUBA = ("body", [("header", [("h1", []), ("img", [])]),
                 ("main", [("p", []), ("ul", [("li", []), ("li", []), ("li", [])])]),
                 ("nav", [("ul", [("li", [("a", [])])])])])


def pruefe_70_tuba():
    """Aufgabe 6 ★★★ · Die Tuba hat den vorgegebenen Baum"""
    s = angefangen("tuba.html")
    erwarte(form(s.erstes("body")) == TUBA, "Der Baum von tuba.html sieht noch anders aus als der vorgegebene.")
    ziele = [h for h, _, _ in s.links()]
    erwarte("sperrgepaeck.html" in ziele, "Der Link in der Tuba führt noch nicht zum Sperrgepäck.")
    erwarte(not s.fehlende_bilder(), "Das Bild nennt eine Datei, die es nicht gibt.")
