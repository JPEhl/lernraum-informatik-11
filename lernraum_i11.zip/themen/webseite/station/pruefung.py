from pruefen import erwarte, braucht, seite

TITEL = "Eine Station ist eine Seite · Selbstcheck"

# Fingerabdrücke der Startseiten in gepaecksuche/: Solange eine Seite so ist wie am Anfang, ist ihre Aufgabe
# „noch nicht dran“ (drei Zustände -- am Start steht genau EINE Pflichtprüfung aus: die Überschrift von Keflavík).
# Ändert sich ein Starttext, hier neu eintragen:
#   python3 -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1]).read().strip().encode()).hexdigest()[:12])" gepaecksuche/<datei>
START = {"gepaeckband.html": "a933f3a776b9", "lissabon.html": "223d5942d9c5", "checkin.html": "2c8688fd368e"}


def angefangen(name):
    s = seite(name)
    braucht(s.da, "Die Datei %s fehlt im Ordner." % name)
    braucht(s.abdruck != START.get(name), "Noch nicht angefangen.")
    return s


def pruefe_10_kef_geruest():
    """Aufgabe 1 · Keflavík: das Grundgerüst steht noch"""
    s = seite("keflavik.html")
    erwarte(not s.geruest_fehlt(), s.meldung_geruest())


def pruefe_20_kef_h1():
    """Aufgabe 1 · Keflavík: eine Überschrift h1"""
    erwarte(seite("keflavik.html").text("h1") == "Keflavík", "Noch keine Überschrift h1 mit dem Namen der Station.")


def pruefe_30_kef_absaetze():
    """Aufgabe 1 · Keflavík: jeder Satz in einem Absatz"""
    s = seite("keflavik.html")
    braucht(s.text("h1"), "Erst die Überschrift.")
    erwarte(not s.lose_texte(), s.meldung_lose())
    erwarte(len(s.elemente("p")) >= 3, "Noch nicht jeder Satz steht in einem eigenen Absatz.")


def pruefe_40_kef_enden():
    """Aufgabe 1 · Keflavík: jedes Tag endet"""
    s = seite("keflavik.html")
    braucht(s.elemente("p"), "Erst die Absätze.")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_50_kef_h2():
    """Aufgabe 1 ★★ · Keflavík: „Was am Griff hing“ eine Stufe kleiner"""
    s = seite("keflavik.html")
    braucht(s.elemente("p"), "Erst die Absätze.")
    erwarte(s.text("h2") == "Was am Griff hing", "„Was am Griff hing“ ist noch keine Überschrift der zweiten Stufe.")


def pruefe_60_kef_lis():
    """Aufgabe 1 ★★ · Keflavík: der Zettel LIS ist wichtig"""
    s = seite("keflavik.html")
    braucht(s.elemente("p"), "Erst die Absätze.")
    erwarte("LIS" in s.texte("strong"), "Was auf dem Zettel steht, ist noch nicht als wichtig ausgezeichnet.")


def pruefe_70_band_ende():
    """Aufgabe 3 · Gepäckband: jedes Tag endet"""
    s = angefangen("gepaeckband.html")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_80_band_body():
    """Aufgabe 3 ★★ · Gepäckband: aller Text steht im body"""
    s = angefangen("gepaeckband.html")
    draussen = s.ausserhalb()
    satz = draussen[0][:50] if draussen else ""
    erwarte(not draussen, "Ein Text steht nicht im body: „%s“. Der Browser zeigt ihn trotzdem -- die Regel nicht." % satz)


def pruefe_90_lis_geruest():
    """Aufgabe 5 ★★ · Lissabon: das Grundgerüst mit title"""
    s = angefangen("lissabon.html")
    erwarte(not s.geruest_fehlt(), s.meldung_geruest())
    erwarte(s.text("title") == "Lissabon", "Der title nennt noch nicht die Station.")
    erwarte(not s.ausserhalb(), "Ein Text steht noch außerhalb von body.")


def pruefe_92_lis_ausgezeichnet():
    """Aufgabe 5 ★★★ · Lissabon: ausgezeichnet wie Keflavík"""
    s = angefangen("lissabon.html")
    braucht(s.erstes("body") is not None, "Erst das Grundgerüst.")
    erwarte(s.text("h1") == "Lissabon", "Noch keine Überschrift h1 mit dem Namen der Station.")
    erwarte(not s.lose_texte(), s.meldung_lose())
    erwarte(s.text("h2") == "Was der Gepäckwagen sagt", "„Was der Gepäckwagen sagt“ ist noch keine Überschrift der zweiten Stufe.")
    erwarte(not s.offen(), s.meldung_offen())


def pruefe_95_checkin():
    """Aufgabe 6 ★★★ · Check-in: eine Linie und eine neue Zeile ohne neuen Absatz"""
    s = angefangen("checkin.html")
    erwarte(s.elemente("hr"), "Noch keine Linie zwischen den Absätzen.")
    erwarte(s.elemente("br"), "Das Schild steht noch nicht in einer eigenen Zeile.")
    erwarte(len(s.elemente("p")) == 2, "Die neue Zeile soll keinen neuen Absatz anfangen.")
    erwarte(not s.offen(), s.meldung_offen())
