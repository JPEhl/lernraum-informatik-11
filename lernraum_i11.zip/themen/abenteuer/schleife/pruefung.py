"""Selbstcheck zu "Die Spielschleife" -- prueft schleife.py (Aufgabe 3 und Kuer 9).

Spielt das Spiel mit einer FOLGE von Befehlen an und setzt vorher oben andere
Startwerte (Zuege, Taschen) -- so, wie die Aufgabe es vorschlaegt ("oben zuege = 3").
Geprueft wird das Verhalten: Fragt das Spiel weiter? Hoert es nach ende auf? Stimmt
der Satz nach der Schleife? Nicht der Wortlaut des Codes -- ausser in der Kuer, die
ausdruecklich nach break fragt. Verraet keine Zeile, nur woran es haengt.

Sind die Befehle aufgebraucht und das Spiel fragt trotzdem weiter, steht am Ende der
Ausgabe die Eingabeaufforderung "> " -- daran erkennt der Check, dass es nicht aufgehoert hat.
"""
import re

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen

TITEL = "Die Spielschleife · Selbstcheck"

# So spielt der Check das Programm an (wie in der Aufgabe): Lampe weg, nachsehen, Schluss
EINGABEN = ["lege lampe", "schau", "ende"]

LAMPE_AUS = "geht aus"
DRAUSSEN = "kalt und wunderbar"
TREPPE = "wartest auf den Morgen"


def _code():
    """Der Code ohne Kommentare und ohne Text in Anfuehrungszeichen."""
    return re.sub(r'"[^"]*"|\'[^\']*\'', '""', ohne_kommentare())


def _hat_schleife():
    return re.search(r"^\s*while\b", _code(), re.M) is not None


def _spiel(befehle, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte. Gibt (text, wartet):
    was nach dem Anfang in der Shell steht, und ob es danach noch einmal gefragt hat."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q
    try:
        aus, _ = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    wartet = aus.endswith("> ")
    marke = "Punkte:"
    return (aus[aus.find(marke):] if marke in aus else aus), wartet


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_schau():
    """Grundlage · Das Spiel kann noch, was es in „Der Plan vor dem Code“ konnte"""
    aus, _ = _spiel(["schau"], raum="keller")
    erwarte("Keller" in aus,
            "Im Keller sagt schau nicht mehr, wo ihr seid -- ist beim Einrücken etwas verrutscht?")


# ── Aufgabe 3 · Die Schleife im eigenen Spiel ────────────────────────────

def pruefe_30_weiter():
    """Aufgabe 3 · Nach einem Befehl fragt das Spiel weiter"""
    # Kein braucht(): Das ist der erste Schritt der Pflicht -- im Startzustand „steht noch aus“
    # mit diesem Hinweis (Reihensichtung 25.10.: vorher „noch nicht dran“ ohne naechsten Schritt).
    aus, _ = _spiel(["lege lampe", "schau"])
    erwarte("tockdunkel" in aus,
            "Nach lege lampe kommt schau nicht dran -- fragt das Spiel nach dem ersten Befehl "
            "noch einmal? Steht das Lesen des Befehls im Rumpf der Schleife?")


def pruefe_31_ende():
    """Aufgabe 3 · ende beendet das Spiel"""
    braucht(_hat_schleife())
    aus, wartet = _spiel(["lege lampe", "schau", "ende"])
    erwarte(TREPPE in aus, "Bei ende fehlt der Satz mit der Treppe (Du setzt dich auf die Treppe …).")
    erwarte(not wartet, "Nach ende fragt das Spiel weiter nach einem Befehl. Was prüft euer Kopf?")


def pruefe_32_ende_ohne_lampe_aus():
    """Aufgabe 3 · Nach ende geht die Lampe nicht aus"""
    braucht(_hat_schleife())
    aus, wartet = _spiel(["lege lampe", "schau", "ende"])
    braucht(not wartet)
    erwarte(LAMPE_AUS not in aus,
            "Nach ende steht „… geht aus“ -- dabei hat die Lampe noch Züge. Was fragt ihr nach der Schleife?")
    erwarte(DRAUSSEN not in aus, "Nach ende steht ihr draußen -- dabei seid ihr im Flur.")


def pruefe_33_eine_kette():
    """Aufgabe 3 · ende versteht das Spiel"""
    braucht(_hat_schleife())
    aus, _ = _spiel(["ende"])
    braucht(TREPPE in aus)
    erwarte("verstehe" not in aus,
            "Nach ende sagt das Spiel auch noch „Das verstehe ich nicht“. Gehört ende zur selben "
            "elif-Kette wie die anderen Befehle?")


# ── Aufgabe 3 ★★ · die Schluss-Saetze ────────────────────────────────────

def pruefe_34_tor():
    """Aufgabe 3 ★★ · Am Tor steht ihr draußen"""
    braucht(_hat_schleife())
    aus, wartet = _spiel(["norden"], gegenstand2="torschlüssel")
    erwarte(not wartet, "Mit dem Torschlüssel nach norden: Das Spiel fragt danach weiter.")
    erwarte(DRAUSSEN in aus, "Am Tor fehlt der Satz „… kalt und wunderbar.“")
    erwarte(LAMPE_AUS not in aus, "Am Tor geht auch die Lampe aus -- dabei hat sie noch Züge.")


def pruefe_35_zuege_aus():
    """Aufgabe 3 ★★ · Sind die Züge aufgebraucht, geht die Lampe aus"""
    braucht(_hat_schleife())
    aus, wartet = _spiel(["schau", "schau", "schau"], zuege=3)
    erwarte(not wartet, "Mit oben zuege = 3 fragt das Spiel nach drei Befehlen weiter.")
    erwarte(LAMPE_AUS in aus, "Nach dem letzten Zug fehlt der Satz „… geht aus.“")


def pruefe_36_letzter_zug():
    """Aufgabe 3 ★★ · Mit dem letzten Zug ans Tor: draußen"""
    braucht(_hat_schleife())
    aus, wartet = _spiel(["norden"], zuege=1, gegenstand2="torschlüssel")
    braucht(not wartet)
    erwarte(DRAUSSEN in aus and LAMPE_AUS not in aus,
            "Mit dem letzten Zug durchs Tor geht die Lampe aus, statt dass ihr draußen steht. "
            "Welche Frage stellt ihr nach der Schleife zuerst?")


# ── Aufgabe 9 · Kuer: Ausstieg mit break ────────────────────────────────

def pruefe_90_break():
    """Aufgabe 9 ★★★★ · ende verlässt die Schleife mit break"""
    braucht(re.search(r"\bbreak\b", _code()) is not None)
    kopf = re.search(r"^\s*while\b(.*)$", _code(), re.M)
    kopftext = kopf.group(1) if kopf else ""
    erwarte("eingabe" not in kopftext, "Mit break muss ende nicht mehr im Kopf der Schleife stehen.")
    aus, wartet = _spiel(["lege lampe", "schau", "ende"])
    erwarte(TREPPE in aus and not wartet, "Mit break: Nach ende fragt das Spiel weiter oder sagt den Satz mit der Treppe nicht.")
    erwarte(LAMPE_AUS not in aus, "Mit break: Nach ende geht die Lampe aus -- sie hat noch Züge.")
    aus, wartet = _spiel(["norden"], zuege=1, gegenstand2="torschlüssel")
    erwarte(DRAUSSEN in aus and LAMPE_AUS not in aus and not wartet,
            "Mit break: Mit dem letzten Zug durchs Tor steht ihr nicht draußen.")
    aus, wartet = _spiel(["schau", "schau"], zuege=2)
    erwarte(LAMPE_AUS in aus and not wartet, "Mit break: Sind die Züge aufgebraucht, geht die Lampe nicht aus.")
