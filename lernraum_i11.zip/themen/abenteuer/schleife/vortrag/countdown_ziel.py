zuege = 3

while zuege > 0:
    eingabe = input("> ")
    zuege = zuege - 1
    print("Noch", zuege, "Züge.")

print("Die Lampe geht aus.")
