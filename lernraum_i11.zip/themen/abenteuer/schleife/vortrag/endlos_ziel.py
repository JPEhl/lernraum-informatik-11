zuege = 3

while zuege > 0:
    eingabe = input("> ")
    print("Noch", zuege, "Züge.")

print("Die Lampe geht aus.")
