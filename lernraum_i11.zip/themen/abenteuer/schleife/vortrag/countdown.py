zuege = 3

eingabe = input("> ")
zuege = zuege - 1
print("Noch", zuege, "Züge.")

print("Die Lampe geht aus.")
