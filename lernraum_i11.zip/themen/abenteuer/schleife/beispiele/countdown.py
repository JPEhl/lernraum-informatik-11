zuege = 3
while zuege > 0:
    print("Noch", zuege, "Züge.")
    zuege = zuege - 1
print("Die Lampe geht aus.")
