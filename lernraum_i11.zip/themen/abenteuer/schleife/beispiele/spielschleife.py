zuege = 3
raum = "flur"
eingabe = ""
while zuege > 0 and raum != "tor" and eingabe != "ende":
    eingabe = input("> ")
    zuege = zuege - 1
    if eingabe == "norden":
        raum = "tor"
if raum == "tor":
    print("Du stehst draußen.")
elif zuege == 0:
    print("Die Lampe geht aus.")
