eingabe = "norden"
ist_norden = eingabe == "norden"
print(ist_norden)
print(type(ist_norden))
print(eingabe.startswith("nimm "))
