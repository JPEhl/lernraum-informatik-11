eingabe = "westen"
raum = "flur"
lampe_an = True
will_in_keller = eingabe == "westen" and raum == "flur"
sicher = will_in_keller and lampe_an
print("Geht es in den Keller?", will_in_keller)
print("Kommst du sicher hinunter?", sicher)
print("Stolperst du?", will_in_keller and not lampe_an)
