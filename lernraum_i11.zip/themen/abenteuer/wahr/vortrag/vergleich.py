# Eine Frage an den Befehl -- die Antwort ist ein Wert.
eingabe = "norden"
