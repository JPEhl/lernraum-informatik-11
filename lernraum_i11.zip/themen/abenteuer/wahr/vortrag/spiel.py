# Die Schule bei Nacht -- euer Spiel.
# Stand nach Thema 3 (Den Befehl lesen):
# Das Spiel liest EINEN Befehl und zerlegt ihn.
# Verstehen kann es ihn noch nicht -- das kommt
# mit den Verzweigungen.

raum = "flur"
zuege = 30
punkte = 0

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im", raum + ". Nur deine Lampe leuchtet.")
print("Punkte:", punkte)

eingabe = input("> ").lower().strip()
print("Du hast getippt:", eingabe)
print("Das sind", len(eingabe), "Zeichen. Das erste ist", eingabe[0] + ".")
ding = eingabe.replace("nimm ", "")
print("Ohne das Wort nimm bleibt:", ding)
print("Fängt der Befehl mit nimm an?", eingabe.startswith("nimm "))
print("Steckt ein Leerzeichen drin?", " " in eingabe)
