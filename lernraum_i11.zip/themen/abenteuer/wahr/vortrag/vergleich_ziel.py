# Eine Frage an den Befehl -- die Antwort ist ein Wert.
eingabe = "norden"

print(eingabe == "norden")
print(eingabe == "süden")

# Die Antwort kommt in ein Kästchen
ist_norden = eingabe == "norden"
print(ist_norden)
print(type(ist_norden))

# Erst vorhersagen: Was liegt danach in ist_norden -- und was in eingabe?
eingabe = "süden"
ist_norden = eingabe == "norden"
print(ist_norden, eingabe)

# Auch Zahlen lassen sich vergleichen
zuege = 30
print(zuege > 0)
print(zuege == 30)
print(zuege != 30)
print(zuege >= 30)
