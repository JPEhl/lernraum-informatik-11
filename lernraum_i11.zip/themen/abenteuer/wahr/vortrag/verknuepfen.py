# Die Regel am Tor: nach Norden UND den Torschlüssel.
eingabe = "norden"
raum = "flur"
hat_torschluessel = False
