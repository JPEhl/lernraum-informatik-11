# Die Regel am Tor: nach Norden UND den Torschlüssel.
eingabe = "norden"
raum = "flur"
hat_torschluessel = False

# beide Fragen müssen stimmen
will_zum_tor = eingabe == "norden" and raum == "flur"
tor_offen = will_zum_tor and hat_torschluessel
print("Geht das Tor auf?", tor_offen)

# das Gegenteil
print("Bleibt es zu?", not tor_offen)

# eine von vielen genügt
ist_richtung = eingabe == "norden" or eingabe == "osten" or eingabe == "süden" or eingabe == "westen"
print("Ist das eine Richtung?", ist_richtung)

# Erst vorhersagen: Kaffee oder Tee -- und wer beides will?
will_kaffee = True
will_tee = True
print("Die Kaffeemaschine gibt etwas:", will_kaffee or will_tee)
