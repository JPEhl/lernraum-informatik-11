# Die Schule bei Nacht -- euer Spiel.
# Daran arbeitet ihr in diesem Thema.
#
# Das Spiel liest einen Befehl und zerlegt ihn.
# Jetzt soll es Fragen stellen, die mit True
# oder False antworten -- Aufgabe 3 sagt, wie.

raum = "flur"
zuege = 30
punkte = 0

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im", raum + ". Nur deine Lampe leuchtet.")
print("Punkte:", punkte)

eingabe = input("> ").lower().strip()
print("Du hast getippt:", eingabe)
print("Das sind", len(eingabe), "Zeichen. Das erste ist", eingabe[0] + ".")
ding = eingabe.replace("nimm ", "")
print("Ohne das Wort nimm bleibt:", ding)
print("Fängt der Befehl mit nimm an?", eingabe.startswith("nimm "))
print("Steckt ein Leerzeichen drin?", " " in eingabe)
