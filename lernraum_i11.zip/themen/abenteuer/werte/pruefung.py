"""Selbstcheck zu "Worte und Werte" -- prueft werte.py (Aufgabe 3).

Das Programm braucht keine Eingaben; es wird einmal ausgeführt, dann werden
die Kästchen und die Ausgabe angesehen. Der Check verrät keine Sätze, nur
woran es hängt -- und bewertet nichts.

Ob eine Zahl aus einem Kästchen kommt, prüft er am VERHALTEN (Reihensichtung
Teil I, 25.10.): Er spielt das Programm noch einmal mit anderen Startwerten an
(oben zuege = 12, links/rechts anders) und sieht nach, ob die Ausgabe mitwandert
-- wie die Probe, die Aufgabe 3 der Klasse vorschlägt. Vorher suchte ein Muster
die 30 in Anführungszeichen und schlug auch bei print("Mit Bonus:", 30 + 1, "Züge.")
an, ohne zuege = 12 je zu probieren.
"""
import re

import pruefen
from pruefen import erwarte, braucht, arbeit, ohne_kommentare, ausgabe, anspielen

TITEL = "Worte und Werte · Selbstcheck"
EINGABEN = []

NAMEN = ("raum", "zuege", "punkte")
_FEHLT = object()


def _wert(name):
    return getattr(arbeit(), name, _FEHLT)


def _da(name):
    return _wert(name) is not _FEHLT


def _print_zeilen_ohne_text():
    """Die print-Zeilen, aus denen aller Text in Anführungszeichen entfernt ist --
    was dann noch steht, sind Namen und Zeichen."""
    zeilen = [z for z in ohne_kommentare().splitlines() if z.strip().startswith("print(")]
    return [re.sub(r'"[^"]*"|\'[^\']*\'', '""', z) for z in zeilen]


def _liest(name):
    return any(re.search(r"\b%s\b" % name, z) for z in _print_zeilen_ohne_text())


def _mit(**start):
    """Das Programm noch einmal, oben vorher andere Startwerte (zuege=12). Gibt (Ausgabe,
    Kästchen danach, alle Startwerte gesetzt?) -- wie regeln/pruefung.py _zug."""
    alt = pruefen._QUELLE
    q, gesetzt = alt, True
    for name, wert in start.items():
        q, n = re.subn(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                       q, count=1, flags=re.M)
        gesetzt = gesetzt and n == 1
    pruefen._QUELLE = q
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt
    return aus, ns, gesetzt


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


# ── Aufgabe 3 · das Spiel merkt sich etwas ───────────────────────────────

def pruefe_30_drei_kaestchen():
    """Aufgabe 3 · Es gibt die Kästchen raum, zuege und punkte"""
    fehlen = [n for n in NAMEN if not _da(n)]
    erwarte(not fehlen,
            "Es fehlt noch: %s. Ein Kästchen entsteht mit name = wert, ganz oben "
            "vor dem ersten print." % ", ".join(fehlen))


def pruefe_31_anfangswerte():
    """Aufgabe 3 · Die Kästchen haben ihre Anfangswerte"""
    braucht(all(_da(n) for n in NAMEN))
    raum, zuege, punkte = _wert("raum"), _wert("zuege"), _wert("punkte")
    erwarte(raum == "flur",
            "In raum liegt %r. Gemeint ist der Text flur, klein geschrieben, in "
            "Anführungszeichen." % (raum,))
    erwarte(isinstance(zuege, int) and not isinstance(zuege, bool),
            "In zuege liegt %r -- das ist keine Zahl. Eine Zahl steht ohne "
            "Anführungszeichen." % (zuege,))
    erwarte(isinstance(punkte, int) and not isinstance(punkte, bool) and punkte == 0,
            "In punkte liegt %r. Am Anfang hat das Spiel 0 Punkte -- als Zahl, ohne "
            "Anführungszeichen." % (punkte,))


def pruefe_32_akku_aus_zuege():
    """Aufgabe 3 · Der Akku-Satz liest zuege ab"""
    braucht(_da("zuege") and isinstance(_wert("zuege"), int))
    zuege = _wert("zuege")
    erwarte(str(zuege) + " Züge" in ausgabe(),
            "In der Shell steht nicht '%d Züge'. Der Akku-Satz soll die Zahl aus "
            "zuege zeigen." % zuege)
    werte = [n for n in (12, 17, 23) if n != zuege][:2]
    probe = [(n,) + _mit(zuege=n) for n in werte]
    erwarte(all(gesetzt and "%d Züge" % n in aus and "%d Züge" % zuege not in aus
                for n, aus, _, gesetzt in probe),
            "Mit oben zuege = %d wandert die Zahl nicht mit: In der Shell steht noch "
            "'%d Züge'. Sie steht noch fest im Text, statt aus zuege zu kommen." % (werte[0], zuege))


def pruefe_33_ort_aus_raum():
    """Aufgabe 3 · Der Satz, wo du stehst, liest raum ab"""
    braucht(_da("raum") and _wert("raum") == "flur")
    erwarte(_liest("raum"),
            "In keinem print steht raum außerhalb der Anführungszeichen -- der Ort "
            "steht noch fest im Text.")
    aus = ausgabe()
    erwarte("flur ." not in aus,
            "In der Shell steht 'flur .' mit Leerzeichen vor dem Punkt. Das Komma "
            "setzt eins; + hängt den Punkt direkt an.")
    erwarte("im flur." in aus,
            "In der Shell steht nicht 'im flur.'. Der Satz, wo du stehst, soll den "
            "Wert aus raum zeigen, mit dem Punkt direkt dahinter.")


def pruefe_34_punkte_zeile():
    """Aufgabe 3 · Ganz unten stehen die Punkte"""
    braucht(_da("punkte"))
    erwarte(_liest("punkte"),
            "Noch kein print, das punkte abliest.")
    erwarte("Punkte: 0" in ausgabe(),
            "In der Shell steht nicht 'Punkte: 0'. Vorne der Text, dahinter der "
            "Wert aus punkte.")



# ── Aufgabe 6 ★★★ · der Bonuszug ─────────────────────────────────────────

def pruefe_63_bonus():
    """Aufgabe 6 ★★★ · Mit Bonus: 31 Züge -- aus zuege gerechnet, nicht hingeschrieben"""
    braucht("Bonus" in ohne_kommentare())
    aus = ausgabe()
    erwarte("301" not in aus,
            "In der Shell steht 301: Ihr habt erst Text gemacht und dann eine \"1\" angehängt. "
            "Was in der Klammer von str(…) steht, wird zuerst ausgerechnet.")
    erwarte(re.search(r"Mit Bonus:?\s*31 Züge", aus) is not None,
            "In der Shell steht noch nicht 'Mit Bonus: 31 Züge.'.")
    probe = [(n,) + _mit(zuege=n) for n in (12, 17)]
    erwarte(all(gesetzt and re.search(r"Mit Bonus:?\s*%d Züge" % (n + 1), aus)
                for n, aus, _, gesetzt in probe),
            "Mit oben zuege = 12 bleibt der Bonuszug gleich -- die Zahl soll aus "
            "zuege kommen, nicht hingeschrieben sein.")


# ── Aufgabe 8 · Kür: tauschen ohne drittes Kästchen ──────────────────────

def pruefe_80_tausch():
    """Aufgabe 8 ★★★★ · links und rechts getauscht -- ohne drittes Kästchen"""
    braucht(_da("links") and _da("rechts"))
    links, rechts = _wert("links"), _wert("rechts")
    erwarte(links == 10 and rechts == 30,
            "Danach liegt in links %r und in rechts %r -- getauscht wäre links 10, rechts 30." % (links, rechts))
    probe = [(a, b) + _mit(links=a, rechts=b)[1:] for a, b in ((7, 19), (25, 4))]
    erwarte(all(gesetzt and ns.get("links") == b and ns.get("rechts") == a for a, b, ns, gesetzt in probe),
            "Mit anderen Startwerten (oben links = 7, rechts = 19) wird nicht getauscht -- "
            "der Tausch soll für alle Zahlen gehen, nicht nur für 30 und 10.")
    code = ohne_kommentare()
    dritte = [z.strip() for z in code.splitlines()
              if re.match(r"^\s*(?!links\b|rechts\b)[A-Za-z_]\w*\s*=", z) and re.search(r"\b(links|rechts)\b", z.split("=", 1)[1])]
    erste = dritte[0] if dritte else ""
    erwarte(not dritte, "Hier liegt ein Wert in einem dritten Kästchen: %s -- es geht nur mit + und -." % erste)
    erwarte(not re.search(r"^\s*links\s*,\s*rechts\s*=", code, re.M),
            "Das ist die Kurzform -- schön gefunden! Gefragt ist hier aber der Trick mit + und -.")
