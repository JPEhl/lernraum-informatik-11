ort = "bibliothek"
plakate = 3
print("Du stehst in der", ort + ".")
print("An der Wand: " + str(plakate) + " Plakate.")
