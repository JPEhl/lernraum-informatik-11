hand = "lampe"
tasche = "seil"
merk = hand
hand = tasche
tasche = merk
print(hand, tasche)
