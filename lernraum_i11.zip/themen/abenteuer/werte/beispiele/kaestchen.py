raum = "flur"
zuege = 30
print("Du stehst im", raum)
print("Noch", zuege, "Züge.")
