# Die Schule bei Nacht -- euer Spiel.
# Daran arbeitet ihr in diesem Thema.
#
# Noch steht jede Zahl fest im Text.
# Das Spiel soll sich merken: wo du bist,
# wie lange die Lampe reicht, wie viele
# Punkte du hast. Aufgabe 3 sagt, wie.

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für 30 Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im Flur. Nur deine Lampe leuchtet.")
