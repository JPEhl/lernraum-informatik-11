# Wo du bist, wie lange die Lampe reicht --
# bis jetzt steht beides fest im Text.

print("Du stehst im Flur.")
print("Ihr Akku reicht für 30 Züge.")
