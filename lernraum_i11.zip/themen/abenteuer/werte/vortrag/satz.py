raum = "keller"
zuege = 29

print("Du stehst im", raum, ".")
