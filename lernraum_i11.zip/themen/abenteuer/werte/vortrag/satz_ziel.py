raum = "keller"
zuege = 29

# Mit Komma: ein Leerzeichen vor dem Punkt
print("Du stehst im", raum, ".")
# Mit +: Text an Text, ohne Leerzeichen
print("Du stehst im", raum + ".")

# Text + Zahl bricht ab (TypeError):
# print("Ihr Akku reicht für " + zuege + " Züge.")
print("Ihr Akku reicht für " + str(zuege) + " Züge.")
