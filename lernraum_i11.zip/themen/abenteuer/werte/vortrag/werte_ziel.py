# Das Spiel merkt sich etwas.

raum = "flur"
zuege = 30
print("Du stehst im", raum)
print("Noch", zuege, "Züge.")

# Ein Zug vergeht: erst rechts ausrechnen, dann hinein
zuege = zuege - 1
print("Noch", zuege, "Züge.")

# Erst vorhersagen, dann ausführen: flur oder keller?
vorher = raum
raum = "keller"
print(vorher)
