# Die Schule bei Nacht -- euer Spiel.
# Stand nach Thema 1 (Ein Spiel aus Text):
# die ersten Zeilen. Das Programm erzählt den
# Anfang und kann sonst noch nichts.

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für 30 Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im Flur. Nur deine Lampe leuchtet.")
