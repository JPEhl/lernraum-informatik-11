eingabe = "nimm lampe"
