# Die Schule bei Nacht -- euer Spiel.
# Stand nach Thema 2 (Worte und Werte):
# Das Spiel merkt sich in Variablen, wo du bist
# und wie lange die Lampe noch reicht. Zahl und
# Text sind verschieden -- str() macht aus der
# Zahl Text.

raum = "flur"
zuege = 30
punkte = 0

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im", raum + ". Nur deine Lampe leuchtet.")
print("Punkte:", punkte)
