eingabe = input("> ")
print("[" + eingabe + "]")

# klein machen -- das Ergebnis kommt in ein neues Kästchen
klein = eingabe.lower()
print("[" + klein + "]")

# Erst vorhersagen: Ist der Rand danach weg?
eingabe.strip()
print("[" + eingabe + "]")

# Das Ergebnis muss in ein Kästchen
eingabe = eingabe.lower().strip()
print("[" + eingabe + "]")
