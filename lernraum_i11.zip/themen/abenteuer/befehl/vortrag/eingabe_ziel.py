# Das Spiel soll zuhören: was jemand tippt,
# kommt in ein Kästchen.

eingabe = input("> ")
print("Du hast getippt:", eingabe)
print("Das sind", len(eingabe), "Zeichen.")
