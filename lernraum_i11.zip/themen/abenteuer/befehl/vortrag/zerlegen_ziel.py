eingabe = "nimm lampe"

# das erste Zeichen -- gezählt ab 0
print(eingabe[0])
print(len(eingabe))

# Fragen an den Text: True oder False
print(eingabe.startswith("nimm "))
print("lampe" in eingabe)

# das Ding: nimm wird durch nichts ersetzt
ding = eingabe.replace("nimm ", "")
print("Du nimmst:", ding)
