# Das Spiel soll zuhören: was jemand tippt,
# kommt in ein Kästchen.
