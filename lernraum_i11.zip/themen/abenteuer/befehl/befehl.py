# Die Schule bei Nacht -- euer Spiel.
# Daran arbeitet ihr in diesem Thema.
#
# Das Spiel erzählt den Anfang und merkt
# sich Raum, Züge und Punkte. Jetzt soll es
# einen Befehl lesen -- Aufgabe 3 sagt, wie.

raum = "flur"
zuege = 30
punkte = 0

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im", raum + ". Nur deine Lampe leuchtet.")
print("Punkte:", punkte)
