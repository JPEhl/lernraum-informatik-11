"""Selbstcheck zu "Eingabe und Text" -- prueft befehl.py (Aufgabe 2, unter Mehr 7 und 8).

Spielt das Programm mit einer unordentlichen Eingabe an (Rand, groß) und
sieht sich danach die Kästchen und die Ausgabe an. Verrät keine Sätze, nur
woran es hängt -- und bewertet nichts.
"""
import ast
import re

from pruefen import erwarte, braucht, arbeit, quelltext, ohne_kommentare, ausgabe, anspielen

TITEL = "Eingabe und Text · Selbstcheck"

# Zwei Leerzeichen vorne, eins hinten, groß -- so tippt niemand absichtlich,
# aber so kommt es an.
EINGABEN = ["  Nimm Lampe "]

_FEHLT = object()


def _wert(name):
    return getattr(arbeit(), name, _FEHLT)


def _code():
    """Der Code ohne Kommentare und ohne Text in Anführungszeichen."""
    return re.sub(r'"[^"]*"|\'[^\']*\'', '""', ohne_kommentare())


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


# ── Aufgabe 2 · einen Befehl lesen ───────────────────────────────────────

def pruefe_30_liest():
    """Aufgabe 2 · Das Spiel liest einen Befehl ins Kästchen eingabe"""
    erwarte("input(" in _code(),
            "Das Spiel liest noch nichts ein. input wartet, bis jemand tippt.")
    erwarte(_wert("eingabe") is not _FEHLT,
            "Es gibt noch kein Kästchen eingabe. Der gelesene Befehl soll darin "
            "liegen.")


def pruefe_31_aufgeraeumt():
    """Aufgabe 2 · Der Befehl ist aufgeräumt: klein, ohne Rand"""
    braucht(isinstance(_wert("eingabe"), str))
    e = _wert("eingabe")
    code = _code()
    gross = e != e.lower()
    rand = e != e.strip()
    # Die Haengestelle: lower()/strip() aufgerufen, Ergebnis aber nicht zurueckgelegt
    ohne_zuweisung = re.search(r"^\s*eingabe\.(lower|strip)\(\)", code, re.M) is not None
    if ohne_zuweisung and (gross or rand):
        erwarte(False,
                "In eingabe steht noch %r. Ihr ruft eine Methode auf, aber ihr "
                "Ergebnis kommt in kein Kästchen -- der aufgeräumte Text muss "
                "zurück ins Kästchen eingabe." % e)
    erwarte(not gross,
            "In eingabe steht noch %r -- mit Großbuchstaben. Welche Methode macht "
            "alles klein?" % e)
    erwarte(not rand,
            "In eingabe steht noch %r -- mit Leerzeichen am Rand. Welche Methode "
            "nimmt sie weg?" % e)
    # zu viel aufgeräumt (Aufgabe 8, replace(" ", "")): die Wörter kleben -- hier sagen, woran es hängt
    erwarte(not (" " not in e and e == "nimmlampe"),
            "In eingabe steht %r -- klein und ohne Rand, aber das Leerzeichen "
            "zwischen den Wörtern fehlt. Es gehört zum Befehl." % e)
    # die rohe Eingabe ("  Nimm Lampe ") steht auch in der Shell -- klein steht dort nur, was das Spiel zeigt
    erwarte("nimm lampe" in ausgabe(),
            "Das Spiel zeigt noch nicht an, was getippt wurde (aufgeräumt).")


# Verhalten statt Woerter (Reihensichtung 25.10.): Die Stufe-2-Pruefungen
# spielen das Spiel mit mehreren Befehlen an und lesen nur, was NACH dem
# Befehl in der Shell steht. Die Proben sind so gewaehlt, dass weder das
# Echo aus Aufgabe 7 (GROSS! Groß! klein …) noch "Du nimmst: …" aus Stufe 3 eine
# Zahl, ein einzelnes Zeichen oder True/False liefert -- eine Aufgabe unter
# Mehr deckt also keinen Pflichtfehler zu.

def _nach(befehl):
    """Was das Spiel nach diesem Befehl in die Shell schreibt, und seine Kästchen."""
    aus, ns = anspielen([befehl])
    marke = befehl + "\n"
    return (aus[aus.find(marke) + len(marke):] if marke in aus else ""), ns


def _steht(stueck, text):
    """stueck steht für sich allein im Text -- nicht als Teil eines Worts oder einer Zahl."""
    return re.search(r"(?<![\w])%s(?![\w])" % re.escape(stueck), text) is not None


# Befehl, wie getippt -- aufgeräumt -- Anzahl der Zeichen -- erstes Zeichen
_ZERLEGEN = [("  SCHAU", "schau", 5, "s"), ("Öffne die Tür ", "öffne die tür", 13, "ö")]


def pruefe_32_zaehlen_und_erstes():
    """Aufgabe 2 ★★ · Anzahl der Zeichen und das erste Zeichen"""
    braucht(_wert("eingabe") == "nimm lampe")
    proben = [(b, sauber, n, z) + _nach(b) for b, sauber, n, z in _ZERLEGEN]
    ohne_zahl = [sauber for b, sauber, n, z, aus, ns in proben if not _steht(str(n), aus)]
    ohne_zeichen = [sauber for b, sauber, n, z, aus, ns in proben if not _steht(z, aus)]
    erwarte(not ohne_zahl,
            "Bei '%s' steht die Anzahl der Zeichen noch nicht in der Shell. "
            "len zählt sie." % (ohne_zahl + [""])[0])
    erwarte(not ohne_zeichen,
            "Bei '%s' steht das erste Zeichen noch nicht für sich in der Shell. "
            "Der Platz des ersten Zeichens hat die Nummer 0." % (ohne_zeichen + [""])[0])


def pruefe_33_ding():
    """Aufgabe 2 ★★ · Das Ding ohne nimm"""
    braucht(_wert("eingabe") == "nimm lampe")
    ding = _wert("ding")
    erwarte(ding is not _FEHLT,
            "Es gibt noch kein Kästchen ding.")
    erwarte(ding == "lampe",
            "In ding liegt %r. Es soll das Ding sein, ohne 'nimm ' davor -- auch "
            "ohne das Leerzeichen." % (ding if ding is not _FEHLT else "",))
    karte = _nach("Nimm Karte")[1].get("ding", "")
    erwarte(karte == "karte",
            "Bei 'Nimm Karte' liegt in ding %r. Es soll das Ding sein, das "
            "getippt wurde -- nicht immer dasselbe." % (karte,))


# Befehl -- fängt mit "nimm " an? -- steckt ein Leerzeichen darin?
# "benimm dich": nimm steckt darin, steht aber nicht vorne -- trennt "fängt an mit" von "enthält"
_FRAGEN = [("Nimm Seil", True, True), ("  SCHAU ", False, False), ("öffne die tür", False, True),
           ("Benimm dich", False, True)]


def pruefe_34_fragen():
    """Aufgabe 2 ★★ · Zwei Fragen mit True oder False"""
    braucht(_wert("eingabe") == "nimm lampe")
    falsch = []
    for befehl, nimm, leer in _FRAGEN:
        aus, _ = _nach(befehl)
        wahr = len(re.findall(r"\bTrue\b", aus))
        unwahr = len(re.findall(r"\bFalse\b", aus))
        # mindestens so viele -- wer noch mehr fragt (etwa nach "lampe"), ist nicht falsch
        if wahr < int(nimm) + int(leer) or unwahr < 2 - int(nimm) - int(leer):
            falsch.append(befehl.strip())
    erwarte(not falsch,
            "Bei '%s' stimmen die zwei Antworten True oder False in der Shell noch "
            "nicht: Fängt der Befehl mit 'nimm ' an? Steckt ein Leerzeichen "
            "darin?" % (falsch + [""])[0])


def pruefe_35_gross():
    """Aufgabe 2 ★★★ · Das Ding mit großem Anfangsbuchstaben -- bei jedem Ding"""
    braucht(_wert("ding") == "lampe")
    # Dinge aus zwei Woertern: Das Echo (Aufgabe 7) ruft nur das LETZTE Wort
    # (KARTE! Karte! karte …) -- "Alte karte" kann nur aus Stufe 3 kommen.
    proben = [("nimm alte karte", r"\bAlte [kK]arte\b"), ("NIMM blaues seil", r"\bBlaues [sS]eil\b")]
    fehlt = [befehl for befehl, muster in proben if not re.search(muster, _nach(befehl)[0])]
    erwarte(not fehlt,
            "Das Ding steht noch nicht mit großem Anfangsbuchstaben da -- probiert "
            "nimm alte karte: Steht das A groß da?")


# ── Aufgabe 7 · Mehr: das Echo im Keller ──────────────────────────────────

def pruefe_60_echo():
    """Aufgabe 7 ★★★★ · Das Echo -- bei jedem Befehl, auch bei einem Wort"""
    braucht(any(w in ohne_kommentare() for w in ("rfind", "capitalize", "wort")))
    proben = [("nimm lampe", "LAMPE", "Lampe", "lampe"), ("öffne die tür", "TÜR", "Tür", "tür"), ("schau", "SCHAU", "Schau", "schau")]
    fehlt = []
    for befehl, a, b, c in proben:
        aus, _ = anspielen([befehl])
        if not re.search(r"%s!\s*%s!\s*%s" % (a, b, c), aus):
            fehlt.append(befehl)
    erste = fehlt[0] if fehlt else ""
    erwarte(not fehlt,
            "Bei '%s' kommt das Echo noch nicht so zurück: GROSS! Groß! klein … -- "
            "das letzte Wort des Befehls." % erste)


# ── Aufgabe 8 · Expertenaufgabe: die feste Form, auch in der Mitte ───────

def _leer_replace():
    """Wie oft im Programm ein replace steht, das Leerzeichen durch Leerzeichen
    ersetzt -- und ob eines davon mindestens zwei Leerzeichen sucht."""
    anzahl, sucht_zwei = 0, False
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return 0, False
    for knoten in ast.walk(baum):
        if not (isinstance(knoten, ast.Call) and isinstance(knoten.func, ast.Attribute)
                and knoten.func.attr == "replace" and knoten.args):
            continue
        erstes = knoten.args[0]
        if isinstance(erstes, ast.Constant) and isinstance(erstes.value, str) and erstes.value and not erstes.value.strip(" "):
            anzahl += 1
            sucht_zwei = sucht_zwei or len(erstes.value) >= 2
    return anzahl, sucht_zwei


def _eingabe_nach(befehl):
    """Was nach diesem Befehl im Kästchen eingabe liegt ("" ohne Kästchen)."""
    wert = anspielen([befehl])[1].get("eingabe", "")
    return wert if isinstance(wert, str) else ""


def pruefe_80_feste_form():
    """Aufgabe 8 ★★★★ · Zwischen zwei Wörtern genau ein Leerzeichen -- bei 1 bis 16"""
    e = _wert("eingabe")
    # dran, sobald die Pflicht steht (oder nur noch die Wörter kleben) und das Aufräumen der Mitte begonnen ist
    braucht(isinstance(e, str) and e.replace(" ", "") == "nimmlampe")
    anzahl, sucht_zwei = _leer_replace()
    braucht(anzahl > 0 or _eingabe_nach("nimm  lampe") == "nimm lampe")
    klebt = _eingabe_nach("nimm  lampe")
    erwarte(" " in klebt,
            "Bei zwei Leerzeichen zwischen den Wörtern steht in eingabe %r -- die "
            "Wörter kleben aneinander. Zwischen zwei Wörtern soll genau ein "
            "Leerzeichen bleiben." % klebt)
    zu_viel = [k for k in range(1, 17) if _eingabe_nach("  Nimm" + " " * k + "Lampe ") != "nimm lampe"]
    k = (zu_viel + [0])[0]
    steht = _eingabe_nach("  Nimm" + " " * k + "Lampe ") if k else ""
    erwarte(not zu_viel,
            "Bei %d Leerzeichen zwischen den Wörtern steht in eingabe %r -- die "
            "feste Form hat dort genau eines." % (k, steht))
    drei = _eingabe_nach("Öffne      die   Tür")
    erwarte(drei == "öffne die tür",
            "Bei einem Befehl aus drei Wörtern steht in eingabe %r -- zwischen je "
            "zwei Wörtern soll genau ein Leerzeichen stehen." % drei)
    erwarte(anzahl <= 4,
            "Es stimmt bei jeder Zahl -- aber replace steht %d-mal für Leerzeichen "
            "da. Die Auflage sagt: höchstens viermal." % anzahl)
