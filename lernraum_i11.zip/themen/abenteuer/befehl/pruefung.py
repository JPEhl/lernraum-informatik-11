"""Selbstcheck zu "Den Befehl lesen" -- prueft befehl.py (Aufgabe 3).

Spielt das Programm mit einer unordentlichen Eingabe an (Rand, groß) und
sieht sich danach die Kästchen und die Ausgabe an. Verrät keine Sätze, nur
woran es hängt -- und bewertet nichts.
"""
import re

from pruefen import erwarte, braucht, arbeit, quelltext, ohne_kommentare, ausgabe, anspielen

TITEL = "Den Befehl lesen · Selbstcheck"

# Zwei Leerzeichen vorne, eins hinten, groß -- so tippt niemand absichtlich,
# aber so kommt es an.
EINGABEN = ["  Nimm Lampe "]

_FEHLT = object()


def _wert(name):
    return getattr(arbeit(), name, _FEHLT)


def _code():
    """Der Code ohne Kommentare und ohne Text in Anführungszeichen."""
    return re.sub(r'"[^"]*"|\'[^\']*\'', '""', ohne_kommentare())


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


# ── Aufgabe 3 · einen Befehl lesen ───────────────────────────────────────

def pruefe_30_liest():
    """Aufgabe 3 · Das Spiel liest einen Befehl ins Kästchen eingabe"""
    erwarte("input(" in _code(),
            "Das Spiel liest noch nichts ein. input wartet, bis jemand tippt.")
    erwarte(_wert("eingabe") is not _FEHLT,
            "Es gibt noch kein Kästchen eingabe. Der gelesene Befehl soll darin "
            "liegen.")


def pruefe_31_aufgeraeumt():
    """Aufgabe 3 · Der Befehl ist aufgeräumt: klein, ohne Rand"""
    braucht(isinstance(_wert("eingabe"), str))
    e = _wert("eingabe")
    code = _code()
    gross = e != e.lower()
    rand = e != e.strip()
    # Die Haengestelle: lower()/strip() aufgerufen, Ergebnis aber nicht zurueckgelegt
    ohne_zuweisung = re.search(r"^\s*eingabe\.(lower|strip)\(\)", code, re.M) is not None
    if ohne_zuweisung and (gross or rand):
        erwarte(False,
                "In eingabe steht noch %r. Ihr ruft eine Methode auf, aber ihr "
                "Ergebnis kommt in kein Kästchen -- der aufgeräumte Text muss "
                "zurück ins Kästchen eingabe." % e)
    erwarte(not gross,
            "In eingabe steht noch %r -- mit Großbuchstaben. Welche Methode macht "
            "alles klein?" % e)
    erwarte(not rand,
            "In eingabe steht noch %r -- mit Leerzeichen am Rand. Welche Methode "
            "nimmt sie weg?" % e)
    # die rohe Eingabe ("  Nimm Lampe ") steht auch in der Shell -- klein steht dort nur, was das Spiel zeigt
    erwarte("nimm lampe" in ausgabe(),
            "Das Spiel zeigt noch nicht an, was getippt wurde (aufgeräumt).")


# Verhalten statt Woerter (Reihensichtung 25.10.): Die Stufe-2-Pruefungen
# spielen das Spiel mit mehreren Befehlen an und lesen nur, was NACH dem
# Befehl in der Shell steht. Die Proben sind so gewaehlt, dass weder das
# Echo der Kuer (GROSS! Groß! klein …) noch "Du nimmst: …" aus Stufe 3 eine
# Zahl, ein einzelnes Zeichen oder True/False liefert -- die Kuer deckt also
# keinen Pflichtfehler zu.

def _nach(befehl):
    """Was das Spiel nach diesem Befehl in die Shell schreibt, und seine Kästchen."""
    aus, ns = anspielen([befehl])
    marke = befehl + "\n"
    return (aus[aus.find(marke) + len(marke):] if marke in aus else ""), ns


def _steht(stueck, text):
    """stueck steht für sich allein im Text -- nicht als Teil eines Worts oder einer Zahl."""
    return re.search(r"(?<![\w])%s(?![\w])" % re.escape(stueck), text) is not None


# Befehl, wie getippt -- aufgeräumt -- Anzahl der Zeichen -- erstes Zeichen
_ZERLEGEN = [("  SCHAU", "schau", 5, "s"), ("Öffne die Tür ", "öffne die tür", 13, "ö")]


def pruefe_32_zaehlen_und_erstes():
    """Aufgabe 3 ★★ · Anzahl der Zeichen und das erste Zeichen"""
    braucht(_wert("eingabe") == "nimm lampe")
    proben = [(b, sauber, n, z) + _nach(b) for b, sauber, n, z in _ZERLEGEN]
    ohne_zahl = [sauber for b, sauber, n, z, aus, ns in proben if not _steht(str(n), aus)]
    ohne_zeichen = [sauber for b, sauber, n, z, aus, ns in proben if not _steht(z, aus)]
    erwarte(not ohne_zahl,
            "Bei '%s' steht die Anzahl der Zeichen noch nicht in der Shell. "
            "len zählt sie." % (ohne_zahl + [""])[0])
    erwarte(not ohne_zeichen,
            "Bei '%s' steht das erste Zeichen noch nicht für sich in der Shell. "
            "Der Platz des ersten Zeichens hat die Nummer 0." % (ohne_zeichen + [""])[0])


def pruefe_33_ding():
    """Aufgabe 3 ★★ · Das Ding ohne nimm"""
    braucht(_wert("eingabe") == "nimm lampe")
    ding = _wert("ding")
    erwarte(ding is not _FEHLT,
            "Es gibt noch kein Kästchen ding.")
    erwarte(ding == "lampe",
            "In ding liegt %r. Es soll das Ding sein, ohne 'nimm ' davor -- auch "
            "ohne das Leerzeichen." % (ding if ding is not _FEHLT else "",))
    karte = _nach("Nimm Karte")[1].get("ding", "")
    erwarte(karte == "karte",
            "Bei 'Nimm Karte' liegt in ding %r. Es soll das Ding sein, das "
            "getippt wurde -- nicht immer dasselbe." % (karte,))


# Befehl -- fängt mit "nimm " an? -- steckt ein Leerzeichen darin?
_FRAGEN = [("Nimm Seil", True, True), ("  SCHAU ", False, False), ("öffne die tür", False, True)]


def pruefe_34_fragen():
    """Aufgabe 3 ★★ · Zwei Fragen mit True oder False"""
    braucht(_wert("eingabe") == "nimm lampe")
    falsch = []
    for befehl, nimm, leer in _FRAGEN:
        aus, _ = _nach(befehl)
        wahr = len(re.findall(r"\bTrue\b", aus))
        unwahr = len(re.findall(r"\bFalse\b", aus))
        # mindestens so viele -- wer noch mehr fragt (etwa nach "lampe"), ist nicht falsch
        if wahr < int(nimm) + int(leer) or unwahr < 2 - int(nimm) - int(leer):
            falsch.append(befehl.strip())
    erwarte(not falsch,
            "Bei '%s' stimmen die zwei Antworten True oder False in der Shell noch "
            "nicht: Fängt der Befehl mit 'nimm ' an? Steckt ein Leerzeichen "
            "darin?" % (falsch + [""])[0])


def pruefe_35_gross():
    """Aufgabe 3 ★★★ · Das Ding mit großem Anfangsbuchstaben -- bei jedem Ding"""
    braucht(_wert("ding") == "lampe")
    # Dinge aus zwei Woertern: Das Echo der Kuer ruft nur das LETZTE Wort
    # (KARTE! Karte! karte …) -- "Alte karte" kann nur aus Stufe 3 kommen.
    proben = [("nimm alte karte", r"\bAlte [kK]arte\b"), ("NIMM blaues seil", r"\bBlaues [sS]eil\b")]
    fehlt = [befehl for befehl, muster in proben if not re.search(muster, _nach(befehl)[0])]
    erwarte(not fehlt,
            "Das Ding steht noch nicht mit großem Anfangsbuchstaben da -- probiert "
            "nimm alte karte: Steht das A groß da?")


# ── Aufgabe 7 · Kür: das Echo im Keller ──────────────────────────────────

def pruefe_60_echo():
    """Aufgabe 7 ★★★★ · Das Echo -- bei jedem Befehl, auch bei einem Wort"""
    braucht(any(w in ohne_kommentare() for w in ("rfind", "capitalize", "wort")))
    proben = [("nimm lampe", "LAMPE", "Lampe", "lampe"), ("öffne die tür", "TÜR", "Tür", "tür"), ("schau", "SCHAU", "Schau", "schau")]
    fehlt = []
    for befehl, a, b, c in proben:
        aus, _ = anspielen([befehl])
        if not re.search(r"%s!\s*%s!\s*%s" % (a, b, c), aus):
            fehlt.append(befehl)
    erste = fehlt[0] if fehlt else ""
    erwarte(not fehlt,
            "Bei '%s' kommt das Echo noch nicht so zurück: GROSS! Groß! klein … -- "
            "das letzte Wort des Befehls." % erste)
