wunsch = "  Kaffee SCHWARZ "
wunsch = wunsch.lower().strip()
print("Erkannt:", wunsch)
print("Zeichen:", len(wunsch))
sorte = wunsch.replace("kaffee ", "")
print("Sorte:", sorte)
print("Will Kaffee?", wunsch.startswith("kaffee"))
