eingabe = input("> ")
print("Du hast getippt:", eingabe)
print("Das sind", len(eingabe), "Zeichen.")
