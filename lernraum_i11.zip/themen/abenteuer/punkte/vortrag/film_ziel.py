# Der Film dauert 135 Minuten.
print(135 / 60)
print(135 // 60)
print(135 % 60)
