# Wie lange warst du drin? Jeder Zug dauert 45 Sekunden.
gespielt = 9
sekunden = gespielt * 45
print(sekunden)
print(sekunden / 60)
minuten = sekunden // 60
rest = sekunden % 60
print("Spielzeit:", minuten, "min", rest, "s")
punkte = 30
print(punkte / minuten)
