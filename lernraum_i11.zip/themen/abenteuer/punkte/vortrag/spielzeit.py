# Wie lange warst du drin? Jeder Zug dauert 45 Sekunden.
gespielt = 9
sekunden = gespielt * 45
print(sekunden)
