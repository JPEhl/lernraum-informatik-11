"""Selbstcheck zu "Züge und Punkte" -- prueft punkte.py (Aufgabe 2 und Kuer 8).

Spielt das Spiel mit einer FOLGE von Befehlen an und setzt vorher oben andere
Startwerte (Zuege, Taschen) -- so, wie die Aufgabe es vorschlaegt ("oben zuege = 3").
Geprueft wird das Verhalten: Stimmen Punkte, Zuege und Spielzeit? Bricht etwas ab?
Nicht der Wortlaut des Codes -- ausser in der Kuer, die ausdruecklich nach % 10 und
// 10 fragt. Verraet keine Zeile, nur woran es haengt.

Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile, die der Check hinter den Code
haengt (SCHLUSS): Fehlt sie, ist es unterwegs abgebrochen -- anspielen() schneidet die
Fehlermeldung ab. Fragt das Spiel nach den Befehlen weiter, endet die Ausgabe mit "> ".
"""
import re

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen

TITEL = "Züge und Punkte · Selbstcheck"

# So spielt der Check das Programm an (wie in der Aufgabe): einstecken, nachsehen, Schluss
EINGABEN = ["nimm heft", "zeige", "ende"]

LAMPE_AUS = "geht aus"
TREPPE = "wartest auf den Morgen"
SCHLUSS = "§SCHLUSS§"


def _code():
    """Der Code ohne Kommentare und ohne Text in Anfuehrungszeichen."""
    return re.sub(r'"[^"]*"|\'[^\']*\'', '""', ohne_kommentare())


def _spiel(befehle, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte. Gibt (text, abbruch, wartet):
    was nach dem Anfang in der Shell steht, ob das Programm unterwegs abgebrochen ist, und ob es
    nach den Befehlen noch einmal gefragt hat (dann ist es nicht abgebrochen, nur nicht fertig)."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q + "\nprint(%r)\n" % SCHLUSS
    try:
        aus, _ = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    abbruch = not fertig and not wartet
    marke = "leuchtet.\n"
    return (aus[aus.find(marke) + len(marke):] if marke in aus else aus), abbruch, wartet


def _zeige(aus):
    """Was zeige zuletzt gesagt hat: alles ab dem letzten „Du trägst“."""
    i = aus.rfind("Du trägst")
    return aus[i:] if i >= 0 else ""


def _spielzeit(aus):
    """(minuten, sekunden) als Text aus der Zeile „Spielzeit: … min … s“, sonst None."""
    m = re.search(r"Spielzeit:?\s*([\d.]+)\s*min\s*([\d.]+)\s*s", aus)
    return (m.group(1), m.group(2)) if m else None


def _hat_warte():
    """Der Befehl warte -- nicht das „wartest“ im Satz für ende."""
    q = ohne_kommentare()
    return '"warte ' in q or "'warte " in q


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Die Spielschleife“ konnte"""
    aus, _, wartet = _spiel(["schau", "ende"], raum="keller")
    erwarte("Keller" in aus, "Im Keller sagt schau nicht mehr, wo ihr seid -- ist etwas verrutscht?")
    erwarte(TREPPE in aus and not wartet, "Nach ende fragt das Spiel weiter oder sagt den Satz für ende nicht.")


# ── Aufgabe 2 ★ · Punkte und Spielzeit ───────────────────────────────────

def pruefe_20_punkte():
    """Aufgabe 2 · Jedes Fundstück bringt 10 Punkte, zeige sagt sie"""
    aus, _, _ = _spiel(["nimm heft", "zeige", "ende"])
    erwarte(re.search(r"Punkte\D{0,3}10\b", _zeige(aus)) is not None,
            "Nach nimm heft sagt zeige nicht „Punkte: 10“. Bekommt ihr beim Einstecken 10 Punkte -- "
            "und sagt zeige sie?")
    # Zwei Fundstuecke nacheinander: faengt punkte = 10 statt punkte = punkte + 10 (Reihensichtung 25.10.)
    aus, _, _ = _spiel(["nimm heft", "nimm buch", "zeige", "ende"])
    erwarte(re.search(r"Punkte\D{0,3}20\b", _zeige(aus)) is not None,
            "Nach nimm heft und nimm buch sagt zeige nicht „Punkte: 20“. Kommen beim zweiten "
            "Fundstück noch einmal 10 Punkte DAZU?")


def pruefe_21_zuege_zeige():
    """Aufgabe 2 · zeige sagt, wie viele Züge übrig sind"""
    aus, _, _ = _spiel(["schau", "zeige", "ende"])
    # Erst dran, wenn zeige schon die Punkte sagt (der Schritt davor) -- im Startzustand
    # steht so nur die erste Pflichtpruefung aus (Reihensichtung 25.10.)
    braucht("Punkte" in _zeige(aus))
    erwarte(re.search(r"\b28\b", _zeige(aus)) is not None,
            "Nach zwei Befehlen (schau, zeige) sagt zeige nicht, dass 28 Züge übrig sind.")


def pruefe_22_spielzeit():
    """Aufgabe 2 · Am Ende steht die Spielzeit in Minuten und Sekunden"""
    aus, abbruch, _ = _spiel(["schau", "schau", "ende"])
    zeit = _spielzeit(aus)
    # Erst dran, wenn die Spielzeit begonnen ist: Kaestchen sekunden oder die Zeile (Reihensichtung 25.10.)
    braucht(zeit is not None or re.search(r"\bsekunden\b", _code()) is not None)
    erwarte(not abbruch, "Nach schau, schau, ende bricht das Programm ab, bevor es fertig ist.")
    erwarte(zeit is not None, "Nach dem Spiel steht keine Zeile „Spielzeit: … min … s“.")
    if zeit is not None:
        erwarte("." not in zeit[0],
                "Die Minuten haben eine Kommastelle (%s) -- welches Zeichen sagt, wie oft 60 GANZ hineinpasst?" % zeit[0])
        erwarte(zeit != ("0", "45"),
                "Nach drei Zügen steht 0 min 45 s -- zählen die Sekunden in JEDEM Durchlauf der Schleife?")
        erwarte(zeit == ("2", "15"),
                "Drei Züge sind 135 Sekunden -- es steht aber „%s min %s s“ da, nicht „2 min 15 s“." % zeit)


def pruefe_23_spielzeit_glatt():
    """Aufgabe 2 · Geht es glatt auf, steht 0 s da"""
    aus, _, _ = _spiel(["schau"] * 7 + ["ende"])
    zeit = _spielzeit(aus)
    braucht(zeit is not None)
    erwarte(zeit == ("6", "0"), "Acht Züge sind 360 Sekunden -- es müsste „6 min 0 s“ dastehen.")


# ── Aufgabe 2 ★★ · warte ─────────────────────────────────────────────────

def pruefe_24_warte():
    """Aufgabe 2 ★★ · warte 3 lässt drei Züge vergehen"""
    braucht(_hat_warte())
    aus, abbruch, wartet = _spiel(["warte 3", "schau"], zuege=5)
    erwarte(not abbruch, "Bei warte 3 bricht das Spiel ab. Was steht in der Zahl -- Text oder Zahl?")
    erwarte("verstehe" not in aus,
            "Bei warte 3 sagt das Spiel „Das verstehe ich nicht“. Steht warte in derselben elif-Kette "
            "wie die anderen Befehle?")
    erwarte(not wartet,
            "Mit oben zuege = 5: Nach warte 3 und schau müssten die Züge aufgebraucht sein -- das Spiel "
            "fragt aber weiter.")


def pruefe_25_warte_abc():
    """Aufgabe 2 ★★ · warte abc bricht nicht ab"""
    braucht(_hat_warte())
    aus, abbruch, _ = _spiel(["warte abc", "ende"])
    erwarte(TREPPE in aus and not abbruch,
            "Nach warte abc kommt ende nicht mehr dran -- bricht das Spiel bei warte abc ab? Was fragt "
            "ihr, bevor ihr int() schreibt?")


def pruefe_26_warte_zeit():
    """Aufgabe 2 ★★ · Beim Warten läuft die Spielzeit weiter"""
    braucht(_hat_warte())
    aus, _, _ = _spiel(["warte 3", "ende"])
    zeit = _spielzeit(aus)
    braucht(zeit is not None)
    erwarte(zeit == ("3", "45"),
            "warte 3 und ende sind fünf Züge, also 225 Sekunden -- es müsste „3 min 45 s“ dastehen. "
            "Laufen beim Warten für jeden Zug 45 Sekunden?")


def pruefe_27_unter_null():
    """Aufgabe 2 ★★ · Fallen die Züge unter 0, geht die Lampe aus"""
    braucht(_hat_warte())
    aus, _, wartet = _spiel(["warte 5"], zuege=3)
    erwarte(not wartet, "Mit oben zuege = 3: Nach warte 5 fragt das Spiel weiter.")
    erwarte(LAMPE_AUS in aus,
            "Mit oben zuege = 3 und warte 5 geht die Lampe nicht aus. Wie viele Züge sind danach übrig "
            "-- und was fragt ihr nach der Schleife?")


# ── Aufgabe 2 ★★★ · Bonus und Punkte pro Minute ─────────────────────────

def _zeile_spielzeit(aus):
    """Die Zeile „Spielzeit: …“ allein (nicht die Punkte pro Minute darunter)."""
    i = aus.find("Spielzeit")
    return aus[i:].split("\n")[0] if i >= 0 else ""


def pruefe_28_tor_bonus():
    """Aufgabe 2 ★★★ · Am Tor gibt es 2 Punkte für jeden übrigen Zug"""
    aus, _, _ = _spiel(["norden"], gegenstand2="torschlüssel")
    braucht(_spielzeit(aus) is not None)
    erwarte(re.search(r"\b58\b", _zeile_spielzeit(aus)) is not None,
            "Mit dem Torschlüssel gleich nach norden: 29 Züge übrig, also 58 Punkte -- die stehen nicht "
            "in der Zeile mit der Spielzeit.")
    # Zweite Probe mit anderen Zuegen und einem Fundstueck: faengt einen festen Bonus (+ 58) und
    # einen Bonus, der die Punkte ersetzt statt sie zu erhoehen (Reihensichtung 25.10.)
    aus, _, _ = _spiel(["nimm heft", "norden"], zuege=10, gegenstand2="torschlüssel")
    erwarte(re.search(r"\b26\b", _zeile_spielzeit(aus)) is not None,
            "Mit oben zuege = 10: nimm heft, dann durchs Tor -- 8 Züge übrig. Das sind 10 Punkte für das "
            "Heft und 16 Bonus, zusammen 26 -- die stehen nicht in der Zeile mit der Spielzeit. Hängt "
            "der Bonus an den übrigen Zügen?")


def pruefe_29_pro_minute():
    """Aufgabe 2 ★★★ · Punkte pro Minute, auf eine Stelle gerundet"""
    braucht("pro Minute" in ohne_kommentare())
    aus, _, _ = _spiel(["nimm heft", "nimm buch", "schau", "ende"])
    erwarte("6.7" in aus and "6.66" not in aus,
            "20 Punkte in 3 Minuten: Es müsste „6.7 Punkte pro Minute“ dastehen, auf eine Stelle gerundet.")


def pruefe_30_keine_minute():
    """Aufgabe 2 ★★★ · Nach weniger als einer Minute bricht nichts ab"""
    braucht("pro Minute" in ohne_kommentare())
    aus, abbruch, _ = _spiel(["ende"])
    erwarte(not abbruch,
            "Wer gleich ende tippt, hat 0 ganze Minuten gespielt -- und das Spiel bricht am Ende ab. Was "
            "fragt ihr, bevor ihr durch minuten teilt?")
    erwarte("pro Minute" not in aus, "Nach weniger als einer Minute stehen trotzdem Punkte pro Minute da.")


# ── Aufgabe 8 · Kuer: Das Schliessfach ──────────────────────────────────

def pruefe_80_schliessfach():
    """Aufgabe 8 ★★★★ · code mit der Quersumme 7 öffnet das Schließfach"""
    braucht('"code ' in ohne_kommentare() or "'code " in ohne_kommentare())
    code = _code()
    erwarte(re.search(r"%\s*10\b", code) is not None and re.search(r"//\s*10\b", code) is not None,
            "Im Code fehlen % 10 oder // 10 -- die Quersumme rechnet ihr mit der Zahl, nicht Zeichen für Zeichen.")
    aus, abbruch, _ = _spiel(["code 1213", "ende"])
    erwarte("Klack" in aus and not abbruch, "code 1213 (1 + 2 + 1 + 3 = 7): Das Spiel sagt nicht „Klack.“")
    aus, abbruch, _ = _spiel(["code 4711", "ende"])
    erwarte("Nichts" in aus and "Klack" not in aus and not abbruch,
            "code 4711 (Quersumme 13): Das Spiel sagt nicht „Nichts.“ -- oder trotzdem „Klack.“")
    aus, abbruch, _ = _spiel(["code 70", "ende"])
    erwarte("Klack" in aus and not abbruch, "code 70 (7 + 0 = 7): Das Spiel sagt nicht „Klack.“")
    aus, abbruch, _ = _spiel(["code abc", "ende"])
    erwarte(not abbruch and TREPPE in aus and "Klack" not in aus,
            "code abc bricht ab oder öffnet das Schließfach -- was fragt ihr, bevor ihr int() schreibt?")
