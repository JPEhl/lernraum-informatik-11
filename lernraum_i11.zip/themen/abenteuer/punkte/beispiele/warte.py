zuege = 10
eingabe = input("> ")
if eingabe.startswith("warte "):
    zahl = eingabe.replace("warte ", "")
    if zahl.isdigit():
        n = int(zahl)
        zuege = zuege - n
    else:
        print("Warten geht nur mit einer Zahl, zum Beispiel: warte 3")
print("Noch", zuege, "Züge.")
