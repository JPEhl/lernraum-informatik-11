gespielt = 9
sekunden = gespielt * 45
minuten = sekunden // 60
rest = sekunden % 60
print("Spielzeit:", minuten, "min", rest, "s")
