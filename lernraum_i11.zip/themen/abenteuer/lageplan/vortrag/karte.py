import tkinter as tk

raum = "flur"


def ziel(raum: str, richtung: str) -> str:
    if raum == "flur" and richtung == "norden":
        return "tor"
    if raum == "tor" and richtung == "süden":
        return "flur"
    return raum


def zeichne_raum(name: str, x: int, y: int) -> None:
    flaeche.create_rectangle(x, y, x + 160, y + 70)
    flaeche.create_text(x + 80, y + 35, text=name, font="Arial 28")


def schritt(richtung: str) -> None:
    global raum
    raum = ziel(raum, richtung)


def norden() -> None:
    schritt("norden")


def sueden() -> None:
    schritt("süden")


fenster = tk.Tk()
fenster.title("Die Karte")
fenster.option_add("*Font", "Arial 60")
flaeche = tk.Canvas(fenster, width=800, height=330)
flaeche.grid(row=0, column=0, columnspan=2)
knopf_norden = tk.Button(fenster, text="Norden", command=norden)
knopf_norden.grid(row=1, column=0)
knopf_sueden = tk.Button(fenster, text="Süden", command=sueden)
knopf_sueden.grid(row=1, column=1)
zeichne_raum("flur", 420, 130)
zeichne_raum("tor", 420, 20)
zeichne_raum("keller", 220, 130)
flaeche.create_line(500, 90, 500, 130, width=6)
flaeche.create_line(380, 165, 420, 165, width=6)
fenster.mainloop()
