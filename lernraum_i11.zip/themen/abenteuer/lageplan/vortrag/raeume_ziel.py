import tkinter as tk


def zeichne_raum(name: str, x: int, y: int) -> None:
    flaeche.create_rectangle(x, y, x + 160, y + 70)
    flaeche.create_text(x + 80, y + 35, text=name, font="Arial 28")


fenster = tk.Tk()
fenster.title("Die Karte")
flaeche = tk.Canvas(fenster, width=800, height=330)
flaeche.pack()

zeichne_raum("flur", 420, 130)
zeichne_raum("tor", 420, 20)
zeichne_raum("keller", 220, 130)
flaeche.create_line(500, 90, 500, 130, width=6)
flaeche.create_line(380, 165, 420, 165, width=6)

fenster.mainloop()
