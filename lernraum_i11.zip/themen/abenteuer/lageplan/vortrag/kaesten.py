import tkinter as tk

fenster = tk.Tk()
fenster.title("Die Karte")
flaeche = tk.Canvas(fenster, width=800, height=330)
flaeche.pack()

flaeche.create_rectangle(420, 130, 580, 200)
flaeche.create_rectangle(420, 20, 580, 90)
flaeche.create_rectangle(220, 130, 380, 200)

fenster.mainloop()
