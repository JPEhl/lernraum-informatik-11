"""Selbstcheck zu "Wo bin ich eigentlich?" -- prueft lageplan.py (Aufgabe 2, 3, 5 ★★, Vorrat 7, Kuer 8).

Das Spiel im Fenster mit Zeichenflaeche. Der Check oeffnet kein Fenster: pruefen.py baut es unsichtbar, klickt ueber
die Beschriftung und liest die Flaeche (flaeche, rechtecke, linien, raum_auf_karte, farbe_auf_karte, ist_rot --
LIESMICH „Zeichenfläche im Selbstcheck“). Geprueft wird die LAGE der Raeume zueinander, nie die genauen Zahlen: jedes
Paar plant den Lageplan selbst. Ein Raum ist das Rechteck, in dem sein Name steht.

Alle Pruefungen teilen ein Fenster; _neu() setzt vor jeder den Spielstand zurueck (wie in "Die Schule im Fenster") und
den Zufall fest auf „nie“. Damit Vorrat 7 (Karte erst mit dem Ding) und Kuer 8 (nur besuchte Raeume) die Pflicht nicht
verdecken, legt _neu() die Karte in den Rucksack und setzt eine Liste besucht -- falls es sie gibt -- auf alle Raeume;
die Pruefungen fuer Vorrat und Kuer stellen es selbst anders ein.
"""
import ast
import random

from pruefen import (erwarte, braucht, funktion, fenster, elemente, knopf, klick, tippe, ohne_kommentare, flaeche,
                     dinge, rechtecke, linien, raum_auf_karte, farbe_auf_karte, ist_rot, flaechentexte,
                     quelltext)

TITEL = "Wo bin ich eigentlich? · Selbstcheck"

# Was jede Funktion zurueckgibt -- der Hinweis prueft auch, ob der Type Hint stimmt (wie in zusammen;
# Reihensichtung Teil III, 27.10., Befund 7).
HINTS = {"beschreibung": "str", "ziel": "str", "ausgaenge": "list[str]", "tuer_offen": "bool",
         "dinge_im": "list[str]", "wert": "int", "erzaehle": "None", "aufzaehlen": "str", "zeige_raum": "None",
         "zeige_rucksack": "None", "befehle": "str", "hilfe": "None", "gehe": "str", "nimm": "int", "lege": "None",
         "kater": "None", "benutze": "int", "iss": "int", "sterne": "str", "zeichne_raum": "None",
         "zeichne_tuer": "None", "zeichne_karte": "None", "zeichne_reihe": "None", "zeige_stand": "None",
         "schritt": "None", "norden": "None", "osten": "None", "sueden": "None", "westen": "None", "los": "None",
         "nach_dem_zug": "None", "schluss": "None"}

RAEUME = ["tor", "keller", "flur", "informatikraum", "hausmeisterraum", "bibliothek", "lehrerzimmer"]
# je Paar: (Raum, Nachbar, wo der Nachbar liegt) -- die sechs Türen des Lageplans
TUEREN = [("flur", "tor", "oben"), ("flur", "keller", "links"), ("flur", "informatikraum", "rechts"),
          ("flur", "lehrerzimmer", "unten"), ("keller", "bibliothek", "unten"), ("bibliothek", "hausmeisterraum", "links")]
REIHE = ["101", "102", "103"]
_ANFANG = {}


def _g():
    """Die Kaestchen oben in lageplan.py -- dort, wo die Knopf-Funktionen sie lesen und aendern."""
    f = funktion("gehe") or funktion("zeige_stand")
    return f.__globals__ if f is not None else {}


def _neu(karte=True, alle=True):
    g = _g()
    if not _ANFANG:
        for name, wert in g.items():
            if name.startswith("dinge_") and isinstance(wert, list):
                _ANFANG[name] = list(wert)
    for name, wert in _ANFANG.items():
        g[name][:] = wert
    g["rucksack"][:] = ["lampe", "karte"] if karte else ["lampe"]
    if isinstance(g.get("besucht"), list):
        g["besucht"][:] = RAEUME + REIHE if alle else ["flur"]
    g.update(raum="flur", zuege=30, punkte=0, sekunden=0, ruhe=0)
    for w in elemente("Button") + elemente("Entry"):
        w.config(state="normal")
    for w in elemente("Text"):
        w.delete("1.0", "end")
    if elemente("Entry"):
        tippe("")
    random.randint = lambda a, b: b
    random.choice = lambda liste: liste[-1]


def _karte_neu(raum="flur"):
    """Die Karte neu zeichnen lassen, wie nach einem Zug -- falls es zeichne_karte schon gibt."""
    f = funktion("zeichne_karte")
    if f is not None:
        f(raum)


def _liegt(a, b, wo):
    """Liegt Rechteck b oben/unten/links/rechts von Rechteck a (ohne Ueberlappung, mit Ueberdeckung quer dazu)?"""
    quer_x = b[0] < a[2] and b[2] > a[0]
    quer_y = b[1] < a[3] and b[3] > a[1]
    return {"oben": b[3] <= a[1] and quer_x, "unten": b[1] >= a[3] and quer_x,
            "links": b[2] <= a[0] and quer_y, "rechts": b[0] >= a[2] and quer_y}[wo]


def _am(punkt, r, rand=8):
    return r[0] - rand <= punkt[0] <= r[2] + rand and r[1] - rand <= punkt[1] <= r[3] + rand


def _tuer_da(a, b):
    """Gibt es eine Linie, deren eines Ende an Raum a und deren anderes an Raum b liegt?"""
    for l in linien():
        p, q = (l[0], l[1]), (l[2], l[3])
        if _am(p, a) and _am(q, b) or _am(p, b) and _am(q, a):
            return True
    return False


def _flur():
    """Der Flur: mit Namen auf der Karte -- oder, solange es keine Namen gibt, der erste Kasten der Arbeitsdatei."""
    r = raum_auf_karte("flur")
    if r is not None:
        return r
    kaesten = rechtecke()
    return kaesten[0][:4] if kaesten else None


def _rumpf(name):
    """Der Quelltext der Funktion name (ohne Kommentare), sonst "" -- damit eine Vorbedingung nur dort sucht."""
    try:
        baum = ast.parse(ohne_kommentare())
    except SyntaxError:
        return ""
    for k in baum.body:
        if isinstance(k, ast.FunctionDef) and k.name == name:
            return ast.get_source_segment(ohne_kommentare(), k) or ""
    return ""


def _rot():
    return [n for n in RAEUME if ist_rot(farbe_auf_karte(n))]


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [k for k in ast.walk(baum) if isinstance(k, ast.FunctionDef)]


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_fenster():
    """Grundlage · Das Spiel steht im Fenster, darunter eine Zeichenfläche"""
    erwarte(fenster() is not None, "Das Programm baut kein Fenster -- steht fenster = tk.Tk() noch da?")
    fehlt = [r for r in ("Norden", "Osten", "Süden", "Westen", "Los") if knopf(r) is None]
    erwarte(not fehlt, "Diese Knöpfe fehlen: %s." % ", ".join(fehlt))
    erwarte(flaeche() is not None, "Im Fenster gibt es keine Zeichenfläche mehr -- steht flaeche = tk.Canvas(…) noch da?")


# ── Aufgabe 2 · Der vierte Kasten ────────────────────────────────────────

def pruefe_20_informatikraum():
    """Aufgabe 2 · Rechts vom Flur, auf seiner Höhe, liegt ein vierter Kasten"""
    _neu()
    _karte_neu()
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil III, 27.10., Befund 1: vorher „x von x passen“ ohne naechsten Schritt).
    erwarte(len(rechtecke()) >= 4, "Noch liegen drei Kästen auf der Zeichenfläche -- der vierte, der Informatikraum, fehlt.")
    flur = _flur()
    rechts = [r for r in rechtecke() if _liegt(flur, r[:4], "rechts")]
    erwarte(rechts, "Rechts vom Flur, auf seiner Höhe, liegt noch kein Kasten -- zuerst x, dann y?")


def pruefe_21_lehrerzimmer():
    """Aufgabe 2 ★★ · Unter dem Flur liegt ein Kasten"""
    _neu()
    _karte_neu()
    flur = _flur()
    braucht(flur is not None and len(rechtecke()) >= 5, "Noch kein fünfter Kasten.")
    unten = [r for r in rechtecke() if _liegt(flur, r[:4], "unten")]
    erwarte(unten, "Unter dem Flur liegt noch kein Kasten -- y wächst nach unten.")


# ── Aufgabe 3 · Die ganze Karte ──────────────────────────────────────────

def pruefe_30_sieben():
    """Aufgabe 3 · Sieben Räume mit Namen, wie im Lageplan"""
    braucht(funktion("zeichne_raum") is not None, "Noch keine Funktion zeichne_raum.")
    _neu()
    _karte_neu()
    fehlt = [n for n in RAEUME if raum_auf_karte(n) is None]
    erwarte(not fehlt, "Diese Räume stehen nicht mit Namen in einem Rechteck: %s." % ", ".join(fehlt))
    falsch = [b for a, b, wo in TUEREN if not _liegt(raum_auf_karte(a), raum_auf_karte(b), wo)]
    erwarte(not falsch, "Diese Räume liegen nicht wie im Lageplan: %s -- zuerst x, dann y?" % ", ".join(falsch))


def pruefe_31_tueren():
    """Aufgabe 3 ★★ · Sechs Türen verbinden die Räume"""
    braucht(funktion("zeichne_raum") is not None and linien(), "Noch keine Türen.")
    _neu()
    _karte_neu()
    braucht(all(raum_auf_karte(n) is not None for n in RAEUME), "Noch nicht alle Räume auf der Karte.")
    fehlt = ["%s–%s" % (a, b) for a, b, wo in TUEREN if not _tuer_da(raum_auf_karte(a), raum_auf_karte(b))]
    erwarte(not fehlt, "Diese Türen fehlen oder reichen nicht bis an beide Räume: %s." % ", ".join(fehlt))


def pruefe_32_folgt():
    """Aufgabe 3 ★★★ · Nach jedem Zug ist genau der Raum rot, in dem ihr steht"""
    braucht(funktion("zeichne_karte") is not None, "Noch keine Funktion zeichne_karte.")
    _neu()
    klick("Westen")
    rot = _rot()
    erwarte(rot == ["keller"], "Nach Westen sind rot: %s -- erwartet: nur der Keller. Wird die Karte nach jedem Zug neu "
                               "gezeichnet?" % (", ".join(rot) or "keiner"))
    vorher = dinge()
    klick("Süden")
    klick("Norden")
    rot = _rot()
    erwarte(rot == ["keller"], "Nach Westen, Süden, Norden sind rot: %s -- erwartet: nur der Keller."
            % (", ".join(rot) or "keiner"))
    nachher = dinge()
    erwarte(nachher == vorher, "Nach zwei Zügen liegen %d statt %d Dinge auf der Fläche -- das alte Bild bleibt liegen."
            % (nachher, vorher))


def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(funktion("zeichne_raum") is not None)
    ohne, falsch = [], []
    for k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, HINTS[k.name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 5 · Wie im Abitur: Ein Gang voller Räume ─────────────────────

def pruefe_52_reihe():
    """Aufgabe 5 ★★ · zeichne_reihe legt die Räume nebeneinander, jeden 200 weiter rechts"""
    f = funktion("zeichne_reihe")
    braucht(f is not None, "Noch keine Funktion zeichne_reihe.")
    _neu()
    flaeche().delete("all")
    try:
        f(list(REIHE), 20, 20)
    except TypeError as e:
        erwarte(False, "zeichne_reihe(namen, x, y) bricht ab: %s -- drei Parameter? und zeichne_raum mit „aktuell“?" % e)
    lagen = [raum_auf_karte(n) for n in REIHE]
    erwarte(None not in lagen, "Mit der Liste %s stehen nicht alle drei Räume auf der Fläche." % REIHE)
    xs = [r[0] for r in lagen]
    ys = [r[1] for r in lagen]
    erwarte(xs[0] == 20 and ys[0] == 20, "Der erste Raum liegt bei (%g, %g) -- erwartet: bei (x, y) = (20, 20)."
            % (xs[0], ys[0]))
    erwarte(xs[1] - xs[0] == 200 and xs[2] - xs[1] == 200 and len(set(ys)) == 1,
            "Die Räume liegen bei x = %s -- erwartet: jeder 200 weiter rechts, alle auf derselben Höhe."
            % ", ".join("%g" % x for x in xs))


# ── Aufgabe 7 · Vorrat: Erst mit der Karte ───────────────────────────────

def pruefe_72_ohne_karte():
    """Aufgabe 7 ★★ · Ohne die Karte im Rucksack bleibt die Fläche ohne Räume, mit ihr erscheint sie"""
    braucht("in rucksack" in _rumpf("zeichne_karte"), "Die Karte fragt noch nicht nach dem Rucksack.")
    _neu(karte=False)
    klick("Osten")
    erwarte(not rechtecke(), "Ohne Karte im Rucksack liegen nach Osten schon Räume auf der Fläche.")
    _g()["rucksack"].append("karte")
    klick("Westen")
    erwarte(raum_auf_karte("keller") is not None, "Mit der Karte im Rucksack erscheint die Karte nach einem Zug nicht.")


def pruefe_73_dunkel():
    """Aufgabe 7 ★★★ · Ohne Karte steht „Zu dunkel“ in der Mitte der Fläche"""
    braucht("Zu dunkel" in ohne_kommentare(), "Noch kein „Zu dunkel“.")
    _neu(karte=False)
    klick("Osten")
    texte = [t for t in flaechentexte() if "Zu dunkel" in t[0]]
    erwarte(texte, "Ohne Karte steht nach einem Zug kein „Zu dunkel …“ auf der Fläche.")
    breite, hoehe = float(flaeche().cget("width")), float(flaeche().cget("height"))
    x, y = texte[0][1], texte[0][2]
    erwarte(abs(x - breite / 2) <= 40 and abs(y - hoehe / 2) <= 40,
            "„Zu dunkel“ steht bei (%g, %g) -- die Mitte der Fläche ist (%g, %g)." % (x, y, breite / 2, hoehe / 2))


# ── Aufgabe 8 · Kür: Nur, wo du schon warst ──────────────────────────────

def pruefe_84_besucht():
    """Aufgabe 8 ★★★★ · Die Karte zeigt nur besuchte Räume und die Türen zwischen ihnen"""
    braucht(isinstance(_g().get("besucht"), list), "Noch keine Liste besucht.")
    _neu(alle=False)
    klick("Westen")
    da = [n for n in RAEUME if raum_auf_karte(n) is not None]
    erwarte(sorted(da) == ["flur", "keller"], "Nach Westen stehen auf der Karte: %s -- erwartet: flur und keller."
            % (", ".join(da) or "keine"))
    erwarte(len(linien()) == 1, "Nach Westen liegen %d Türen auf der Karte -- erwartet: eine (Keller–Flur)."
            % len(linien()))
    klick("Osten")
    klick("Osten")
    erwarte(raum_auf_karte("informatikraum") is not None and raum_auf_karte("tor") is None,
            "Nach Westen, Osten, Osten: Der Informatikraum fehlt, oder das Tor ist schon da.")
