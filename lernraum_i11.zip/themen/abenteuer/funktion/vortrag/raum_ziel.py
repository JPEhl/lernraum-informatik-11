# Zwei Räume, ein Blick
raum = "flur"
dinge_flur = ["kreide"]
dinge_keller = ["torschlüssel", "pausenbrot"]
hier = dinge_flur


def zeige_raum():
    if raum == "flur":
        print("Der Flur. Nur deine Lampe leuchtet.")
    else:
        print("Der Keller. Rohre, Staub. Irgendwo tropft es.")
    print("Hier liegt:")
    for ding in hier:
        print("  -", ding)


zeige_raum()
eingabe = ""
while eingabe != "ende":
    eingabe = input("> ")
    if eingabe == "schau":
        zeige_raum()
    elif eingabe == "westen" or eingabe == "osten":
        if eingabe == "westen":
            raum = "keller"
        else:
            raum = "flur"
        if raum == "flur":
            hier = dinge_flur
        else:
            hier = dinge_keller
        zeige_raum()
