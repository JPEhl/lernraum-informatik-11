# Zwei Räume, ein Blick
raum = "flur"
dinge_flur = ["kreide"]
dinge_keller = ["torschlüssel", "pausenbrot"]
hier = dinge_flur

print("Du stehst im", raum + ".")
eingabe = ""
while eingabe != "ende":
    if raum == "flur":
        hier = dinge_flur
    else:
        hier = dinge_keller
    eingabe = input("> ")
    if eingabe == "schau":
        if raum == "flur":
            print("Der Flur. Nur deine Lampe leuchtet.")
        else:
            print("Der Keller. Rohre, Staub. Irgendwo tropft es.")
        print("Hier liegt:")
        for ding in hier:
            print("  -", ding)
    elif eingabe == "westen" or eingabe == "osten":
        if eingabe == "westen":
            raum = "keller"
        else:
            raum = "flur"
        print("Du stehst jetzt im", raum + ".")
