# Die Hilfe -- ein kleines Spiel wie eures
raum = "flur"

print("DIE SCHULE BEI NACHT")
print("Befehle:")
print("  gehen: osten, westen")
print("  sonst: hilfe, ende")
print("Du stehst im", raum + ".")
eingabe = ""
while eingabe != "ende":
    eingabe = input("> ")
    if eingabe == "westen" or eingabe == "osten":
        if eingabe == "westen":
            raum = "keller"
        else:
            raum = "flur"
        print("Du stehst jetzt im", raum + ".")
    elif eingabe == "warte":
        print("Du wartest. Irgendwo tropft es.")
    elif eingabe == "hilfe":
        print("Befehle:")
        print("  gehen: osten, westen")
        print("  sonst: warte, hilfe, ende")
    elif eingabe != "ende":
        print("Das verstehe ich nicht.")
        print("Befehle:")
        print("  gehen: osten, westen")
        print("  sonst: hilfe, ende")
