raum = "flur"
dinge_flur = ["kreide"]
dinge_keller = ["torschlüssel", "pausenbrot"]


def zeige_raum():
    if raum == "flur":
        print("Der Flur. Nur deine Lampe leuchtet.")
    else:
        print("Der Keller. Rohre, Staub. Irgendwo tropft es.")
    print("Hier liegt:")
    for ding in hier:
        print("  -", ding)


hier = dinge_flur
zeige_raum()
raum = "keller"
zeige_raum()
hier = dinge_keller
zeige_raum()
