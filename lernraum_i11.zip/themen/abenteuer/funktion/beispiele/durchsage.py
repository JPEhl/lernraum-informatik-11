def durchsage():
    print("Achtung, Achtung.")
    print("Das Gebäude schließt.")
print("Der Hausmeister betritt den Flur.")
durchsage()
print("Der Hausmeister betritt den Keller.")
durchsage()
