def hilfe():
    print("Befehle:")
    print("  gehen: osten, westen")
    print("  sonst: warte, hilfe, ende")


print("DIE SCHULE BEI NACHT")
hilfe()
print("Viel Glück.")
hilfe()
