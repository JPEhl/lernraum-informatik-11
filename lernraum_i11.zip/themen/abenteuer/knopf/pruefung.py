"""Selbstcheck zu "Der Knopf, der sich selbst drückt" -- prueft wegweiser.py (Aufgabe 3, Vorrat 6, Kuer 7).

Das erste Thema mit Fenster (Teil III, 25.10.). Der Check oeffnet kein Fenster: pruefen.py baut es unsichtbar und
klickt die Knoepfe ueber ihre Beschriftung (klick, knopf, labeltexte -- LIESMICH „Fenster (tkinter) im Lernraum“).
klick() ist selbst ein Befund, wenn es den Knopf nicht gibt, wenn er mit command=f() keine Funktion bekommen hat
oder wenn die Funktion abbricht. Den Raum stellt der Check selbst ein (_raum): Wer fuer ★★ oben raum = "keller"
stehen laesst, besteht trotzdem ★.
"""
import ast
import re

from pruefen import erwarte, braucht, funktion, fenster, knopf, klick, labeltexte, ohne_kommentare, quelltext

TITEL = "Der Knopf, der sich selbst drückt · Selbstcheck"

# Was jede Funktion zurueckgibt -- der Hinweis prueft auch, ob der Type Hint stimmt (wie in zusammen;
# Reihensichtung Teil III, 27.10., Befund 7).
HINTS = {"ziel": "str", "dinge_im": "list[str]", "aufzaehlen": "str", "norden": "None", "osten": "None",
         "sueden": "None", "westen": "None", "was_liegt_hier": "None", "hilfe": "None", "licht": "None"}


def _raum(name):
    """Setzt das Kaestchen raum, das die Knopf-Funktionen lesen (ihre globalen Namen)."""
    f = funktion("ziel") or funktion("norden")
    if f is not None:
        f.__globals__["raum"] = name


def _anzeige():
    """Was nach dem letzten Klick im Fenster steht -- alle Labels zusammen."""
    return " | ".join(labeltexte())


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [k for k in baum.body if isinstance(k, ast.FunctionDef)]


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_fenster():
    """Grundlage · Das Programm baut ein Fenster mit den Knöpfen Norden und Osten"""
    erwarte(fenster() is not None, "Das Programm baut kein Fenster -- steht fenster = tk.Tk() noch da?")
    erwarte(knopf("Norden") is not None and knopf("Osten") is not None,
            "Die Knöpfe Norden und Osten aus der Vorlage fehlen.")
    _raum("flur")
    klick("Norden")
    erwarte("Tor" in _anzeige(), "Nach einem Klick auf Norden steht im Fenster nicht, dass dort das Tor liegt.")


# ── Aufgabe 3 · Der Wegweiser ────────────────────────────────────────────

def pruefe_30_vier():
    """Aufgabe 3 · Süden und Westen sagen, wohin es geht"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil III, 27.10., Befund 1: vorher „x von x passen“ ohne naechsten Schritt).
    erwarte(knopf("Süden") is not None or knopf("Westen") is not None,
            "Noch zeigt der Wegweiser nur Norden und Osten -- Süden und Westen fehlen.")
    _raum("flur")
    klick("Süden")
    erwarte("Lehrerzimmer" in _anzeige(), "Nach Süden steht nicht das Lehrerzimmer im Fenster (sondern: %s)." % _anzeige())
    klick("Westen")
    erwarte("Keller" in _anzeige(), "Nach Westen steht nicht der Keller im Fenster (sondern: %s)." % _anzeige())


def pruefe_31_wand():
    """Aufgabe 3 ★★ · An einer Wand sagt der Wegweiser „eine Wand“"""
    braucht("wand" in ohne_kommentare().lower(), "Noch kein Satz für die Wand.")
    braucht(knopf("Süden") is not None and knopf("Westen") is not None, "Erst alle vier Richtungen.")
    _raum("keller")
    for richtung, steht in (("Norden", "Wand"), ("Osten", "Flur"), ("Westen", "Wand"), ("Süden", "Bibliothek")):
        klick(richtung)
        jetzt = _anzeige()
        erwarte(steht in jetzt, "Im Keller nach %s steht „%s“ -- erwartet war: %s." % (richtung, jetzt, steht))
    _raum("informatikraum")
    klick("Norden")
    erwarte("Wand" in _anzeige(), "Im Informatikraum nach Norden fehlt die Wand.")


def pruefe_32_hier():
    """Aufgabe 3 ★★★ · Was liegt hier? zählt auf wie im Spiel"""
    braucht(knopf("Was liegt hier?") is not None, "Noch kein Knopf „Was liegt hier?“.")
    _raum("flur")
    klick("Was liegt hier?")
    erwarte("Hier liegt: Kreide." in _anzeige(), "Im Flur sollte „Hier liegt: Kreide.“ stehen (es steht: %s)." % _anzeige())
    _raum("informatikraum")
    klick("Was liegt hier?")
    erwarte("Hier liegt: Stick und Kreide." in _anzeige(),
            "Im Informatikraum sollte „Hier liegt: Stick und Kreide.“ stehen (es steht: %s)." % _anzeige())


def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(knopf("Süden") is not None or knopf("Westen") is not None)
    ohne, falsch = [], []
    for k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, HINTS[k.name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 6 · Vorrat: Hilfe und Ende ───────────────────────────────────

def pruefe_60_hilfe():
    """Aufgabe 6 ★★ · Ein Knopf Hilfe schreibt etwas ins Label"""
    braucht(knopf("Hilfe") is not None, "Noch kein Knopf „Hilfe“.")
    _raum("flur")
    klick("Norden")
    vorher = _anzeige()
    klick("Hilfe")
    erwarte(_anzeige() != vorher and _anzeige().strip() != "", "Nach einem Klick auf Hilfe steht im Fenster nichts Neues.")


def pruefe_61_ende():
    """Aufgabe 6 ★★★ · Ein Knopf Ende schließt das Fenster mit fenster.destroy"""
    braucht(knopf("Ende") is not None, "Noch kein Knopf „Ende“.")
    erwarte(str(knopf("Ende").cget("command")) != "", "Der Knopf Ende hat keine Funktion bekommen -- ein Klick tut nichts.")
    erwarte(re.search(r"command\s*=\s*fenster\.destroy\s*[,)]", ohne_kommentare()) is not None,
            "Der Knopf Ende ruft nicht fenster.destroy -- die fertige Funktion zum Schließen.")


# ── Aufgabe 7 · Kuer: Licht an, Licht aus ───────────────────────────────

def _dunkel():
    for w in fenster().winfo_children():
        if w.winfo_class() == "Label" and str(w.cget("bg")).lower() in ("black", "#000000", "#000"):
            return True
    return False


def pruefe_70_licht():
    """Aufgabe 7 ★★★★ · Licht aus macht das Label dunkel, Licht an wieder hell"""
    braucht(knopf("Licht aus") is not None or knopf("Licht an") is not None, "Noch kein Schalter.")
    erwarte(knopf("Licht aus") is not None, "Am Anfang sollte der Schalter „Licht aus“ heißen.")
    klick("Licht aus")
    erwarte(_dunkel(), "Nach Licht aus ist kein Label schwarz.")
    erwarte(knopf("Licht an") is not None, "Nach dem Klick sollte der Knopf „Licht an“ heißen.")
    klick("Licht an")
    erwarte(not _dunkel() and knopf("Licht aus") is not None, "Licht an schaltet nicht zurück.")
