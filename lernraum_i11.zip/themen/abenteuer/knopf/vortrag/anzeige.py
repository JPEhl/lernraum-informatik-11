import tkinter as tk


def norden() -> None:
    print("Im Norden liegt das Tor.")


fenster = tk.Tk()
fenster.title("Die Schule bei Nacht")
fenster.option_add("*Font", "Arial 60")
anzeige = tk.Label(fenster, text="Du stehst im Flur.")
anzeige.pack()
knopf_norden = tk.Button(fenster, text="Norden", command=norden)
knopf_norden.pack()
fenster.mainloop()
