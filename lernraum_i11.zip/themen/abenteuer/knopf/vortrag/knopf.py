import tkinter as tk

fenster = tk.Tk()
fenster.title("Die Schule bei Nacht")
fenster.option_add("*Font", "Arial 60")
fenster.mainloop()
