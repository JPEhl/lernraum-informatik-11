# Die Schule bei Nacht -- euer Spiel im Fenster.
# Stand nach „Die Schule im Fenster“: dasselbe
# Spiel, aber ohne Spielschleife. mainloop()
# wartet, jeder Knopf ruft eine Funktion. Was
# im Spiel print war, schreibt erzaehle() in
# die Textfläche; die Funktionen, die mit return
# antworten, sind dieselben wie vorher.

import random
import tkinter as tk


# ------------------------ die Welt

# Was wo liegt -- je Raum eine Liste. Der Schacht
# ist kein Raum, man kommt nur mit dem Seil an
# ihn heran.
dinge_flur = ["kreide"]
dinge_informatikraum = ["stick", "kreide"]
dinge_lehrerzimmer = ["seil", "apfel", "kreide"]
dinge_bibliothek = ["karte", "kreide"]
dinge_keller = ["pausenbrot", "kreide"]
dinge_schacht = ["hausmeisterschlüssel"]
dinge_hausmeisterraum = ["torschlüssel", "kreide"]
dinge_tor = []

rucksack = ["lampe"]


# ------------------------ die Räume

def beschreibung(raum: str) -> str:
    """Der Satz, der einen Raum beschreibt."""
    if raum == "flur":
        return "Der Flur. Nur deine Lampe leuchtet. Das Haupttor liegt im Norden, dahinter ist Nacht."
    elif raum == "informatikraum":
        return "Der Informatikraum. 24 Rechner schlafen. Einer blinkt, als hätte er etwas zu sagen."
    elif raum == "lehrerzimmer":
        return "Das Lehrerzimmer. Es riecht nach altem Kaffee. Die Kaffeemaschine beobachtet dich."
    elif raum == "bibliothek":
        return "Die Bibliothek. Ein Plakat sagt RUHE! Es ist sehr, sehr ruhig."
    elif raum == "keller":
        return "Der Keller. Rohre, Staub, ein Schacht im Boden. Irgendwo tropft es."
    elif raum == "hausmeisterraum":
        return "Der Hausmeisterraum. 300 Schlüssel an der Wand, einer davon ist sehr groß."
    elif raum == "tor":
        return "Das Haupttor. Draußen ist Nacht, Luft und ein Fahrrad, das deins ist."
    else:
        return "Ein Raum, den es nicht gibt."


def ziel(raum: str, richtung: str) -> str:
    """Welcher Raum liegt von raum aus in richtung? Leerer Text heißt: Wand."""
    if raum == "flur":
        if richtung == "norden":
            return "tor"
        elif richtung == "osten":
            return "informatikraum"
        elif richtung == "süden":
            return "lehrerzimmer"
        elif richtung == "westen":
            return "keller"
    elif raum == "informatikraum":
        if richtung == "westen":
            return "flur"
    elif raum == "lehrerzimmer":
        if richtung == "norden":
            return "flur"
    elif raum == "keller":
        if richtung == "osten":
            return "flur"
        elif richtung == "süden":
            return "bibliothek"
    elif raum == "bibliothek":
        if richtung == "norden":
            return "keller"
        elif richtung == "westen":
            return "hausmeisterraum"
    elif raum == "hausmeisterraum":
        if richtung == "osten":
            return "bibliothek"
    return ""


def ausgaenge(raum: str) -> list[str]:
    """Alle Richtungen, in denen es von raum aus weitergeht."""
    liste = []
    for richtung in ["norden", "osten", "süden", "westen"]:
        if ziel(raum, richtung) != "":
            liste.append(richtung)
    return liste


def tuer_offen(wohin: str) -> bool:
    """Darf man nach wohin? Manche Türen brauchen etwas aus dem Rucksack."""
    if wohin == "tor":
        return "torschlüssel" in rucksack
    elif wohin == "hausmeisterraum":
        return "hausmeisterschlüssel" in rucksack
    elif wohin == "keller":
        return "lampe" in rucksack
    else:
        return True


def dinge_im(raum: str) -> list[str]:
    """Die Liste der Dinge, die in raum liegen."""
    if raum == "flur":
        return dinge_flur
    elif raum == "informatikraum":
        return dinge_informatikraum
    elif raum == "lehrerzimmer":
        return dinge_lehrerzimmer
    elif raum == "bibliothek":
        return dinge_bibliothek
    elif raum == "keller":
        return dinge_keller
    elif raum == "hausmeisterraum":
        return dinge_hausmeisterraum
    else:
        return dinge_tor


def wert(ding: str) -> int:
    """Wie viele Punkte ein Fundstück bringt."""
    if ding == "stick":
        return 30
    elif ding == "hausmeisterschlüssel" or ding == "torschlüssel":
        return 20
    else:
        return 10


# ------------------------ anzeigen

def erzaehle(text: str) -> None:
    """Eine Zeile in die Textfläche -- im Fenster das, was im Spiel print war."""
    erzaehler.insert("end", text + "\n")
    erzaehler.see("end")


def aufzaehlen(liste: list[str]) -> str:
    """Zählt auf, wie ein Mensch es sagt: ["stick", "seil", "apfel"] -> "Stick, Seil und Apfel"."""
    text = ""
    for i in range(len(liste)):
        if i > 0 and i == len(liste) - 1:
            text = text + " und "
        elif i > 0:
            text = text + ", "
        text = text + liste[i].capitalize()
    return text


def zeige_raum(raum: str) -> None:
    erzaehle("")
    if "lampe" not in rucksack:
        erzaehle("Stockdunkel. Du siehst nicht einmal, wo du die Lampe hingelegt hast.")
    else:
        erzaehle(beschreibung(raum))
        hier = dinge_im(raum)
        if len(hier) > 0:
            erzaehle("Hier liegt: " + aufzaehlen(hier) + ".")
        if "karte" in rucksack:
            erzaehle("Ausgänge: " + aufzaehlen(ausgaenge(raum)) + ".")


def zeige_rucksack(punkte: int, zuege: int) -> None:
    if len(rucksack) == 0:
        erzaehle("Dein Rucksack ist leer.")
    else:
        erzaehle("Du trägst: " + aufzaehlen(rucksack) + ".")
    erzaehle("Punkte: " + str(punkte) + " - Züge übrig: " + str(zuege))


def befehle(raum: str) -> str:
    """Die Befehle, die gerade gehen -- steht vor jeder Eingabe."""
    if "karte" in rucksack:
        wege = ausgaenge(raum)
    else:
        wege = ["norden", "osten", "süden", "westen"]
    text = "Befehle:"
    for richtung in wege:
        text = text + " " + richtung + " ·"
    for ding in dinge_im(raum):
        text = text + " nimm " + ding + " ·"
    for ding in rucksack:
        text = text + " lege " + ding + " ·"
        if ding == "apfel" or ding == "pausenbrot":
            text = text + " iss " + ding + " ·"
    return text + " schau · zeige · hilfe (alle Befehle)"


def hilfe() -> None:
    erzaehle("Die vier Richtungen sind Knöpfe. Ins Feld tippst du: nimm <ding>, lege <ding>,")
    erzaehle("schau, zeige, karte, benutze <ding>, iss <ding>, warte <n>, hilfe, ende")


# ------------------------ handeln

def gehe(raum: str, richtung: str) -> str:
    """Gibt den neuen Raum zurück -- oder den alten, wenn es nicht weitergeht."""
    wohin = ziel(raum, richtung)
    if wohin == "":
        erzaehle("Da ist eine Wand. Eine sehr solide Wand.")
        return raum
    if not tuer_offen(wohin):
        if wohin == "keller":
            erzaehle("Da unten ist es stockdunkel. Ohne Lampe gehst du da nicht runter.")
        else:
            erzaehle("Abgeschlossen. Du rüttelst an der Tür. Die Tür rüttelt nicht zurück.")
        return raum
    return wohin


def nimm(ding: str, raum: str) -> int:
    """Nimmt ding aus dem Raum in den Rucksack. Gibt die Punkte dafür zurück."""
    hier = dinge_im(raum)
    if ding not in hier:
        erzaehle("Hier gibt es kein " + ding + ".")
        return 0
    if len(rucksack) >= 6:
        erzaehle("Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht. Leg etwas ab oder iss etwas.")
        return 0
    hier.remove(ding)
    rucksack.append(ding)
    erzaehle("Du nimmst: " + ding.capitalize() + ".")
    if ding == "stick":
        erzaehle("Dein USB-Stick. Der Grund für diese ganze Nacht.")
    if ding == "pausenbrot":
        erzaehle("Ein Pausenbrot von 2019. Es ist ... fest geworden.")
    return wert(ding)


def lege(ding: str, raum: str) -> None:
    if ding not in rucksack:
        erzaehle("Das hast du nicht.")
    else:
        rucksack.remove(ding)
        dinge_im(raum).append(ding)
        erzaehle("Du legst weg: " + ding.capitalize() + ".")
        if ding == "lampe":
            erzaehle("Es wird sehr dunkel. Das war vielleicht keine gute Idee.")


def kater(raum: str) -> None:
    """Byte schnappt sich ein Ding (nie die Lampe) und lässt es in raum fallen."""
    erzaehle("Der Schulkater Byte streicht um deine Beine.")
    zum_schnappen = []
    for ding in rucksack:
        if ding != "lampe":
            zum_schnappen.append(ding)
    if len(zum_schnappen) == 0:
        erzaehle("Er schnuppert an deiner Lampe und verliert das Interesse.")
    else:
        ding = random.choice(zum_schnappen)
        rucksack.remove(ding)
        dinge_im(raum).append(ding)
        erzaehle("Er schnappt sich " + ding + " und lässt es hier fallen.")


def benutze(ding: str, raum: str) -> int:
    """Gibt die Punkte zurück, die das bringt (meistens keine)."""
    if ding == "seil":
        if "seil" not in rucksack:
            erzaehle("Du hast kein Seil.")
        elif raum != "keller":
            erzaehle("Hier gibt es nichts, wo ein Seil hilft.")
        elif len(dinge_schacht) == 0:
            erzaehle("Der Schacht ist leer. Du hast schon alles geholt.")
        else:
            erzaehle("Du lässt das Seil in den Schacht. Unten liegt ein Schlüssel mit einem Anhänger: HM.")
            erzaehle("Du ziehst ihn hoch. Das Seil bleibt unten, es hat sich verhakt.")
            rucksack.remove("seil")
            rucksack.append("hausmeisterschlüssel")
            dinge_schacht.remove("hausmeisterschlüssel")
            return wert("hausmeisterschlüssel")
    elif ding == "kaffeemaschine":
        if raum != "lehrerzimmer":
            erzaehle("Hier steht keine Kaffeemaschine.")
        else:
            meldung = random.choice(["Fehler 418: Ich bin eine Teekanne.",
                                     "Bitte Wassertank füllen. Der Wassertank ist voll.",
                                     "Entkalken Sie mich. Jetzt.",
                                     "Kein Kaffee für Schüler nach 22 Uhr."])
            erzaehle("Die Kaffeemaschine sagt: " + meldung)
    elif ding == "lampe":
        erzaehle("Die Lampe leuchtet schon. Mehr kann sie nicht.")
    else:
        erzaehle("Damit kannst du hier nichts anfangen.")
    return 0


def iss(ding: str) -> int:
    """Gibt zurück, wie viele Züge das bringt -- auch negativ."""
    if ding not in rucksack:
        erzaehle("Das hast du nicht.")
        return 0
    elif ding == "apfel":
        rucksack.remove("apfel")
        erzaehle("Knackig. Du bist wieder wach: 3 Züge mehr.")
        return 3
    elif ding == "pausenbrot":
        rucksack.remove("pausenbrot")
        erzaehle("Du beißt ab. Du bereust es. Byte schaut dich mitleidig an. 3 Züge weniger.")
        return -3
    else:
        erzaehle("Das isst man nicht.")
        return 0


def sterne(punkte: int) -> str:
    """Ein Stern je 10 Punkte, als Text."""
    text = ""
    for i in range(punkte // 10):
        text = text + "*"
    return text


# ------------------------ das Spiel im Fenster

raum = "flur"
zuege = 30
punkte = 0
sekunden = 0
ruhe = 0


def zeige_stand(raum: str, zuege: int, punkte: int) -> None:
    """Die Kopfzeile über der Textfläche."""
    kopf.config(text=raum.capitalize() + "  ·  " + str(zuege) + " Züge  ·  " + str(punkte) + " Punkte")


def schritt(richtung: str) -> None:
    """Ein Zug in eine Richtung -- die vier Knöpfe rufen ihn auf."""
    global raum, zuege, sekunden, ruhe
    erzaehle("")
    erzaehle("> " + richtung)
    zuege = zuege - 1
    sekunden = sekunden + 45
    vorher = raum
    raum = gehe(raum, richtung)
    if raum != vorher:
        if raum == "bibliothek":
            ruhe = ruhe + 1
            laut = ""
            for i in range(ruhe):
                laut = laut + "RUHE! "
            erzaehle("Das Plakat hängt da. " + laut)
        if raum == "keller" and random.randint(1, 6) == 1:
            erzaehle("KLACK. Die Sicherung fliegt raus. Deine Lampe flackert. Das kostet dich 2 Züge.")
            zuege = zuege - 2
        if random.randint(1, 5) == 1:
            kater(raum)
        zeige_raum(raum)
    nach_dem_zug(richtung)


def norden() -> None:
    schritt("norden")


def osten() -> None:
    schritt("osten")


def sueden() -> None:
    schritt("süden")


def westen() -> None:
    schritt("westen")


def los() -> None:
    """Liest das Befehlsfeld und führt den Befehl aus -- wie ein Durchgang der Spielschleife."""
    global zuege, punkte, sekunden
    eingabe = feld.get().lower().strip()
    feld.delete(0, "end")
    if eingabe == "":
        erzaehle("Tippe zuerst einen Befehl.")
    elif eingabe in ["norden", "osten", "süden", "westen"] or eingabe.startswith("gehe "):
        schritt(eingabe.replace("gehe ", ""))
    else:
        erzaehle("")
        erzaehle("> " + eingabe)
        zuege = zuege - 1
        sekunden = sekunden + 45
        if eingabe == "ende":
            erzaehle("Du setzt dich auf die Treppe und wartest auf den Morgen.")
        elif eingabe == "hilfe":
            hilfe()
        elif eingabe == "schau":
            zeige_raum(raum)
        elif eingabe == "zeige":
            zeige_rucksack(punkte, zuege)
        elif eingabe == "karte":
            if "karte" in rucksack:
                erzaehle("Die Karte zeigt von hier: " + aufzaehlen(ausgaenge(raum)) + ".")
            else:
                erzaehle("Du hast keine Karte. In der Bibliothek gibt es alles, auch Karten.")
        elif eingabe.startswith("nimm "):
            punkte = punkte + nimm(eingabe.replace("nimm ", ""), raum)
        elif eingabe.startswith("warte "):
            zahl = eingabe.replace("warte ", "")
            if zahl.isdigit():
                n = int(zahl)
                zuege = zuege - n
                sekunden = sekunden + n * 45
                erzaehle("Du wartest " + str(n) + " Züge. Nichts passiert. Irgendwo tropft es.")
            else:
                erzaehle("Warten geht nur mit einer Zahl, zum Beispiel: warte 3")
        elif eingabe.startswith("lege "):
            lege(eingabe.replace("lege ", ""), raum)
        elif eingabe.startswith("benutze "):
            punkte = punkte + benutze(eingabe.replace("benutze ", ""), raum)
        elif eingabe.startswith("iss "):
            zuege = zuege + iss(eingabe.replace("iss ", ""))
        else:
            erzaehle("Das verstehe ich nicht. Tippe hilfe.")
        nach_dem_zug(eingabe)


def nach_dem_zug(eingabe: str) -> None:
    """Nach jedem Zug: Kopfzeile und Befehlszeile neu, am Ende der Schluss."""
    zeige_stand(raum, zuege, punkte)
    befehlszeile.config(text=befehle(raum))
    if raum == "tor" or zuege <= 0 or eingabe == "ende":
        schluss()


def schluss() -> None:
    """Das Ende wie im Spiel. Danach nimmt das Fenster keinen Befehl mehr an."""
    global punkte
    erzaehle("")
    if raum == "tor":
        punkte = punkte + zuege * 2
        erzaehle("Du schließt das Tor auf und stehst draußen. Die Nacht ist kalt und wunderbar.")
        if "stick" in rucksack:
            erzaehle("Und der Stick ist dabei. Morgen wird ein guter Tag.")
        else:
            erzaehle("Der Stick liegt noch im Informatikraum. Morgen wird ein langer Tag.")
    elif zuege <= 0:
        erzaehle("Die Lampe wird schwach, flackert und geht aus. Du sitzt im Dunkeln, bis der Hausmeister kommt.")

    minuten = sekunden // 60
    rest = sekunden % 60
    erzaehle("Spielzeit: " + str(minuten) + " min " + str(rest) + " s - " + str(punkte) + " Punkte")
    if minuten > 0:
        erzaehle("Das sind " + str(round(punkte / minuten, 1)) + " Punkte pro Minute.")
    erzaehle("Deine Sterne: " + sterne(punkte))
    zeige_stand(raum, zuege, punkte)
    for knopf in [knopf_norden, knopf_osten, knopf_sueden, knopf_westen, knopf_los]:
        knopf.config(state="disabled")
    feld.config(state="disabled")


fenster = tk.Tk()
fenster.title("Die Schule bei Nacht")
fenster.option_add("*Font", "Arial 20")
kopf = tk.Label(fenster, text="")
kopf.grid(row=0, column=0, columnspan=3)
erzaehler = tk.Text(fenster, height=12, width=64, wrap="word")
erzaehler.grid(row=1, column=0, columnspan=3)
knopf_norden = tk.Button(fenster, text="Norden", command=norden)
knopf_norden.grid(row=2, column=1)
knopf_westen = tk.Button(fenster, text="Westen", command=westen)
knopf_westen.grid(row=3, column=0)
knopf_osten = tk.Button(fenster, text="Osten", command=osten)
knopf_osten.grid(row=3, column=2)
knopf_sueden = tk.Button(fenster, text="Süden", command=sueden)
knopf_sueden.grid(row=4, column=1)
befehlszeile = tk.Label(fenster, text="", wraplength=900)
befehlszeile.grid(row=5, column=0, columnspan=3)
feld = tk.Entry(fenster, width=40)
feld.grid(row=6, column=0, columnspan=2)
knopf_los = tk.Button(fenster, text="Los", command=los)
knopf_los.grid(row=6, column=2)

erzaehle("DIE SCHULE BEI NACHT")
erzaehle("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
erzaehle("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
erzaehle("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
hilfe()
zeige_raum(raum)
zeige_stand(raum, zuege, punkte)
befehlszeile.config(text=befehle(raum))
fenster.mainloop()
