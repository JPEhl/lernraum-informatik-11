# Der Wegweiser -- ein Fenster im Flur.
# Ein Klick auf eine Richtung sagt, was dort liegt.
# Gehen kann man noch nicht. ziel, dinge_im und
# aufzaehlen sind aus dem Spiel kopiert.

import tkinter as tk

# ------------------------ die Welt

# Was wo liegt -- je Raum eine Liste. Der Schacht
# ist kein Raum, man kommt nur mit dem Seil an
# ihn heran.
dinge_flur = ["kreide"]
dinge_informatikraum = ["stick", "kreide"]
dinge_lehrerzimmer = ["seil", "apfel", "kreide"]
dinge_bibliothek = ["karte", "kreide"]
dinge_keller = ["pausenbrot", "kreide"]
dinge_schacht = ["hausmeisterschlüssel"]
dinge_hausmeisterraum = ["torschlüssel", "kreide"]
dinge_tor = []

# ------------------------ aus dem Spiel

def ziel(raum: str, richtung: str) -> str:
    """Welcher Raum liegt von raum aus in richtung? Leerer Text heißt: Wand."""
    if raum == "flur":
        if richtung == "norden":
            return "tor"
        elif richtung == "osten":
            return "informatikraum"
        elif richtung == "süden":
            return "lehrerzimmer"
        elif richtung == "westen":
            return "keller"
    elif raum == "informatikraum":
        if richtung == "westen":
            return "flur"
    elif raum == "lehrerzimmer":
        if richtung == "norden":
            return "flur"
    elif raum == "keller":
        if richtung == "osten":
            return "flur"
        elif richtung == "süden":
            return "bibliothek"
    elif raum == "bibliothek":
        if richtung == "norden":
            return "keller"
        elif richtung == "westen":
            return "hausmeisterraum"
    elif raum == "hausmeisterraum":
        if richtung == "osten":
            return "bibliothek"
    return ""


def dinge_im(raum: str) -> list[str]:
    """Die Liste der Dinge, die in raum liegen."""
    if raum == "flur":
        return dinge_flur
    elif raum == "informatikraum":
        return dinge_informatikraum
    elif raum == "lehrerzimmer":
        return dinge_lehrerzimmer
    elif raum == "bibliothek":
        return dinge_bibliothek
    elif raum == "keller":
        return dinge_keller
    elif raum == "hausmeisterraum":
        return dinge_hausmeisterraum
    else:
        return dinge_tor


def aufzaehlen(liste: list[str]) -> str:
    """Zählt auf, wie ein Mensch es sagt: ["stick", "seil", "apfel"] -> "Stick, Seil und Apfel"."""
    text = ""
    for i in range(len(liste)):
        if i > 0 and i == len(liste) - 1:
            text = text + " und "
        elif i > 0:
            text = text + ", "
        text = text + liste[i].capitalize()
    return text


# ------------------------ der Wegweiser

raum = "flur"


def norden() -> None:
    wohin = ziel(raum, "norden")
    anzeige.config(text="Im Norden: " + wohin.capitalize())


def osten() -> None:
    wohin = ziel(raum, "osten")
    anzeige.config(text="Im Osten: " + wohin.capitalize())


fenster = tk.Tk()
fenster.title("Der Wegweiser")
fenster.option_add("*Font", "Arial 30")
anzeige = tk.Label(fenster, text="Du stehst im Flur. Wohin führt welcher Weg?")
anzeige.pack()
knopf_norden = tk.Button(fenster, text="Norden", command=norden)
knopf_norden.pack()
knopf_osten = tk.Button(fenster, text="Osten", command=osten)
knopf_osten.pack()
fenster.mainloop()
