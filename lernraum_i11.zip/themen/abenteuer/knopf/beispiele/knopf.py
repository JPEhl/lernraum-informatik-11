import tkinter as tk


def norden() -> None:
    anzeige.config(text="Im Norden liegt das Tor.")


def osten() -> None:
    anzeige.config(text="Im Osten liegt der Informatikraum.")


fenster = tk.Tk()
fenster.title("Die Schule bei Nacht")
fenster.option_add("*Font", "Arial 30")
anzeige = tk.Label(fenster, text="Du stehst im Flur.")
anzeige.pack()
knopf_norden = tk.Button(fenster, text="Norden", command=norden)
knopf_norden.pack()
knopf_osten = tk.Button(fenster, text="Osten", command=osten)
knopf_osten.pack()
fenster.mainloop()
