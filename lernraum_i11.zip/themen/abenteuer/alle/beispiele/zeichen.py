passwort = "kaffee42"
ziffern = 0
for zeichen in passwort:
    if zeichen.isdigit():
        ziffern = ziffern + 1
print("Ziffern darin:", ziffern)
