rucksack = ["lampe", "stick", "kreide"]
print("Du trägst", len(rucksack), "Dinge:")
for ding in rucksack:
    print("  -", ding)
