namen = ["Hausmeister", "Kater", "Kaffeemaschine",
         "Gespenst", "Putzroboter"]
punkte = [85, 130, 70, 150, 105]
for i in range(5):
    print(i)
for i in range(len(namen)):
    print(namen[i], punkte[i])
