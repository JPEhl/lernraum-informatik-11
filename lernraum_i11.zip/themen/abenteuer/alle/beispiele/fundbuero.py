fundbuero = ["schal", "mütze", "handy"]
print("Im Fundbüro liegt:")
for ding in fundbuero:
    print("  -", ding)
print("Abholen bis zum Morgen.")
