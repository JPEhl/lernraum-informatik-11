"""Selbstcheck zu "Alle auf einmal" -- prueft alle.py (Aufgabe 2, 3 ★★, Vorrat 8 ★★ und Kuer 9).

Spielt das Spiel mit einer FOLGE von Befehlen an und setzt vorher oben andere Startwerte
(rucksack = [...], namen = [...], rekorde = [...]) -- so sieht der Check, ob das Spiel die
Listen wirklich fragt. Geprueft wird das Verhalten: Was zeigt zeige, was liegt wo, wer haelt
den Rekord, wie viele Sterne? Nicht der Wortlaut des Codes. Verraet keine Zeile, nur woran es
haengt.

Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile, die der Check hinter den Code haengt
(SCHLUSS, wie in "Der Rucksack"): Fehlt sie, ist es unterwegs abgebrochen -- anspielen()
schneidet die Fehlermeldung ab. Fragt das Spiel nach den Befehlen weiter, endet die Ausgabe
mit "> ".
"""
import re

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen

TITEL = "Alle auf einmal · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

DRAUSSEN = "kalt und wunderbar"
TREPPE = "wartest auf den Morgen"
VOLL = "Dein Rucksack ist voll"
KEIN = "Hier gibt es kein"
LEER = "Noch niemand war hier."
REKORD = "Den Rekord hält:"
NEU = "Neuer Rekord!"
SCHLUSS = "§SCHLUSS§"


def _spiel(befehle, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte (rucksack=[...]). Gibt
    (text, abbruch, ns): was nach dem Anfang in der Shell steht, ob das Programm unterwegs
    abgebrochen ist, und die Variablen, wie sie zuletzt standen."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q + "\nprint(%r)\n" % SCHLUSS
    try:
        aus, ns = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    abbruch = not fertig and not wartet
    marke = "leuchtet.\n"
    return (aus[aus.find(marke) + len(marke):] if marke in aus else aus), abbruch, ns


def _oben(name):
    """Steht oben (nicht eingerueckt) eine Liste name = [...]?"""
    return re.search(r"^%s[ \t]*=[ \t]*\[" % name, ohne_kommentare(), re.M) is not None


def _hier():
    """Gibt es ein Kaestchen hier = ... (die Liste des Raums)?"""
    return re.search(r"^[ \t]*hier[ \t]*=", ohne_kommentare(), re.M) is not None


def _liste(ns, name):
    w = ns.get(name)
    return w if isinstance(w, list) else []


def _zeige(aus):
    """Was zeige zuletzt gesagt hat: von „Du trägst“ bis vor „Punkte:“."""
    i = aus.rfind("Du trägst")
    if i < 0:
        return ""
    j = aus.find("Punkte:", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _hier_liegt(aus):
    """Was schau zuletzt aufgezaehlt hat: ab „Hier liegt:“ bis zur naechsten Eingabe."""
    i = aus.rfind("Hier liegt:")
    if i < 0:
        return ""
    j = aus.find(">", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _strichliste(text):
    """Die Dinge, die als „  - ding“ je Zeile dastehen."""
    return re.findall(r"^[ \t]*-[ \t]*(\S.*?)[ \t]*$", text, re.M)


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Der Rucksack“ konnte"""
    aus, abbruch, _ = _spiel(["warte 2", "ende"])
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Spielzeit" in aus, "Am Ende steht keine Spielzeit mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 ★ · zeige zaehlt auf ──────────────────────────────────────

def _zaehlt_auf():
    """zeige zaehlt einen Rucksack mit zwei Dingen ohne Klammern auf, ein Ding je Zeile (= pruefe_20 besteht).
    Erst dann sagen die anderen zwei Pruefungen zu zeige etwas -- im Startzustand steht nur die erste aus
    (Reihensichtung Teil II, #6)."""
    aus, abbruch, _ = _spiel(["zeige", "ende"], rucksack=["karte", "seil"])
    z = _zeige(aus)
    return not abbruch and "[" not in z and _strichliste(z) == ["karte", "seil"]


def pruefe_20_zeige():
    """Aufgabe 2 · zeige zählt den Rucksack auf, ein Ding je Zeile"""
    aus, abbruch, _ = _spiel(["zeige", "ende"], rucksack=["karte", "seil"])
    z = _zeige(aus)
    dinge = _strichliste(z)
    erwarte(not abbruch, "Bei zeige bricht das Spiel ab.")
    erwarte("[" not in z,
            "Mit oben rucksack = [\"karte\", \"seil\"] zeigt zeige noch die Liste mit Klammern.")
    erwarte(re.search(r"\b2 Dinge", z) is not None, "zeige sagt nicht mehr, wie viele Dinge ihr tragt (hier: 2 Dinge).")
    erwarte(dinge == ["karte", "seil"],
            "Mit oben rucksack = [\"karte\", \"seil\"] stehen nach „Du trägst“ nicht zwei Zeilen „- karte“ und „- seil“.")


def pruefe_21_zeige_leer():
    """Aufgabe 2 · zeige stimmt auch beim leeren Rucksack"""
    braucht(_zaehlt_auf())
    aus, abbruch, _ = _spiel(["zeige", "ende"], rucksack=[])
    z = _zeige(aus)
    erwarte(not abbruch and re.search(r"\b0 Dinge", z) is not None and not _strichliste(z) and "[" not in z,
            "Mit oben rucksack = [] bricht zeige ab, sagt nicht „0 Dinge“ oder zeigt noch Klammern.")


def pruefe_22_zeige_waechst():
    """Aufgabe 2 · zeige zählt auch auf, was gerade dazukam"""
    braucht(_zaehlt_auf())
    aus, abbruch, _ = _spiel(["nimm kreide", "zeige", "ende"])
    dinge = _strichliste(_zeige(aus))
    erwarte(not abbruch and dinge[-1:] == ["kreide"],
            "Nach nimm kreide steht die Kreide bei zeige nicht als letzte Zeile. Zählt zeige alles auf, was JETZT "
            "im Rucksack liegt -- auch wenn er länger geworden ist?")


# ── Aufgabe 2 ★★ · Jedes Ding an seinem Ort ─────────────────────────────

def pruefe_23_nur_hier():
    """Aufgabe 2 ★★ · nimm nimmt nur, was im Raum liegt"""
    braucht(_hier())
    aus, abbruch, ns = _spiel(["nimm seil", "ende"])
    erwarte(not abbruch, "Bei nimm seil im Flur bricht das Spiel ab.")
    erwarte("seil" not in _liste(ns, "rucksack"), "Im Flur liegt kein Seil -- nimm seil steckt es trotzdem ein.")
    erwarte(KEIN in aus, "Im Flur fehlt nach nimm seil der Satz „Hier gibt es kein seil.“")


def pruefe_24_im_raum():
    """Aufgabe 2 ★★ · Im Lehrerzimmer liegt das Seil"""
    braucht(_hier())
    aus, abbruch, ns = _spiel(["süden", "nimm seil", "ende"])
    erwarte(not abbruch and "seil" in _liste(ns, "rucksack"),
            "Im Lehrerzimmer lässt sich das Seil nicht nehmen. Bekommt hier in JEDEM Zug die Liste des Raums, "
            "in dem ihr steht -- oder nur einmal vor der Schleife?")


def pruefe_25_weg_aus_dem_raum():
    """Aufgabe 2 ★★ · Was ihr nehmt, liegt danach nicht mehr dort"""
    braucht(_hier())
    aus, abbruch, ns = _spiel(["süden", "nimm seil", "nimm seil", "ende"])
    zahl = _liste(ns, "rucksack").count("seil")
    erwarte(not abbruch and zahl == 1 and KEIN in aus,
            "Im Lehrerzimmer lässt sich das Seil zweimal nehmen -- es liegt danach noch im Raum.")


def pruefe_26_lege_hier():
    """Aufgabe 2 ★★ · lege legt das Ding in den Raum, in dem ihr steht"""
    braucht(_hier())
    aus, abbruch, ns = _spiel(["lege lampe", "osten", "nimm lampe", "westen", "nimm lampe", "ende"])
    erwarte(not abbruch, "Bei lege oder nimm bricht das Spiel ab.")
    erwarte(_liste(ns, "rucksack").count("lampe") == 1,
            "lege lampe im Flur, dann im Flur nimm lampe -- die Lampe kommt nicht zurück. Liegt sie nach lege im Raum?")
    erwarte(aus.count("Du nimmst: lampe") == 1,
            "Die Lampe liegt im Flur, aber im Informatikraum lässt sie sich auch nehmen.")


def pruefe_27_torschluessel():
    """Aufgabe 2 ★★ · Der Torschlüssel liegt im Keller -- und das Tor geht damit auf"""
    braucht(_hier())
    aus, abbruch, _ = _spiel(["nimm torschlüssel", "westen", "nimm torschlüssel", "osten", "norden"])
    erwarte(aus.count("Du nimmst: torschlüssel") == 1,
            "Den Torschlüssel gibt es nur im Keller -- im Flur lässt er sich trotzdem nehmen (oder im Keller nicht).")
    erwarte(not abbruch and DRAUSSEN in aus, "Mit dem Torschlüssel aus dem Keller geht das Tor nicht auf.")


def pruefe_28_voll():
    """Aufgabe 2 ★★ · Mit sechs Dingen ist der Rucksack weiter voll"""
    braucht(_hier())
    aus, abbruch, ns = _spiel(["nimm kreide", "ende"], rucksack=["lampe", "heft", "buch", "apfel", "seil", "stift"])
    erwarte(not abbruch and VOLL in aus and "kreide" not in _liste(ns, "rucksack"),
            "Mit sechs Dingen im Rucksack kommt die Kreide trotzdem hinein -- die Grenze aus „Der Rucksack“ fehlt.")


# ── Aufgabe 2 ★★★ · schau und die Sterne ────────────────────────────────

def pruefe_29_schau():
    """Aufgabe 2 ★★★ · schau zählt auf, was hier liegt"""
    braucht(_hier())
    aus, abbruch, _ = _spiel(["osten", "schau", "ende"])
    h = _hier_liegt(aus)
    erwarte(not abbruch, "Bei schau bricht das Spiel ab.")
    erwarte(h != "", "Im Informatikraum sagt schau nicht „Hier liegt:“.")
    erwarte(_strichliste(h) == ["stick", "kreide"] and "[" not in h,
            "Im Informatikraum stehen nach „Hier liegt:“ nicht zwei Zeilen „- stick“ und „- kreide“.")


def pruefe_2a_schau_danach():
    """Aufgabe 2 ★★★ · schau weiß, was schon weg ist"""
    braucht(_hier())
    braucht("Hier liegt" in ohne_kommentare())
    aus, abbruch, _ = _spiel(["nimm kreide", "schau", "ende"])
    erwarte(not abbruch and "kreide" not in _strichliste(_hier_liegt(aus)),
            "Nach nimm kreide zählt schau im Flur die Kreide noch auf.")


def pruefe_2b_sterne():
    """Aufgabe 2 ★★★ · Am Ende ein Sternchen je 10 Punkte"""
    braucht("Sterne" in ohne_kommentare())
    # die Punkte oben gesetzt -- so haengt die Pruefung nicht an nimm und den Raeumen
    aus, abbruch, _ = _spiel(["ende"], punkte=30)
    m = re.search(r"Deine Sterne:[ \t]*(\**)[ \t]*$", aus, re.M)
    zahl = len(m.group(1)) if m else -1
    erwarte(not abbruch and zahl == 3,
            "Mit oben punkte = 30 stehen am Ende nicht genau drei Sternchen hinter „Deine Sterne:“.")
    aus, abbruch, _ = _spiel(["ende"], punkte=0)
    m = re.search(r"Deine Sterne:[ \t]*(\**)[ \t]*$", aus, re.M)
    erwarte(not abbruch and m is not None and m.group(1) == "",
            "Mit oben punkte = 0 steht hinter „Deine Sterne:“ trotzdem etwas (oder die Zeile fehlt).")


# ── Aufgabe 3 ★★ · Wie im Abitur: Wer haelt den Rekord? ─────────────────

def _bestenliste():
    return _oben("namen") and _oben("rekorde")


def _rekord(namen, rekorde):
    aus, abbruch, _ = _spiel(["rekord", "ende"], namen=namen, rekorde=rekorde)
    m = re.search(r"^.*(%s.*|%s)[ \t]*$" % (re.escape(REKORD), re.escape(LEER)), aus, re.M)
    return (m.group(1).strip() if m else ""), abbruch


def pruefe_30_vorn():
    """Aufgabe 3 ★★ · rekord: der Beste steht ganz vorn"""
    braucht(_bestenliste())
    braucht('"rekord"' in ohne_kommentare() or "'rekord'" in ohne_kommentare())
    satz, abbruch = _rekord(["Hausmeister", "Kater", "Kaffeemaschine"], [140, 95, 120])
    erwarte(not abbruch and satz == REKORD + " Hausmeister",
            "Mit namen = [\"Hausmeister\", \"Kater\", \"Kaffeemaschine\"] und rekorde = [140, 95, 120] sagt rekord "
            "nicht „Den Rekord hält: Hausmeister“.")


def pruefe_31_hinten():
    """Aufgabe 3 ★★ · rekord: der Beste steht ganz hinten"""
    braucht(_bestenliste())
    braucht('"rekord"' in ohne_kommentare() or "'rekord'" in ohne_kommentare())
    satz, abbruch = _rekord(["Kater", "Gespenst", "Putzroboter"], [60, 95, 110])
    erwarte(not abbruch and satz == REKORD + " Putzroboter",
            "Mit namen = [\"Kater\", \"Gespenst\", \"Putzroboter\"] und rekorde = [60, 95, 110] sagt rekord "
            "nicht „Den Rekord hält: Putzroboter“.")


def pruefe_32_mitte():
    """Aufgabe 3 ★★ · rekord: der Beste steht in der Mitte"""
    braucht(_bestenliste())
    braucht('"rekord"' in ohne_kommentare() or "'rekord'" in ohne_kommentare())
    satz, abbruch = _rekord(["Gespenst", "Kater", "Hausmeister", "Putzroboter"], [60, 130, 95, 110])
    erwarte(not abbruch and satz == REKORD + " Kater",
            "Mit namen = [\"Gespenst\", \"Kater\", \"Hausmeister\", \"Putzroboter\"] und rekorde = [60, 130, 95, 110] "
            "sagt rekord nicht „Den Rekord hält: Kater“.")


def pruefe_33_leer():
    """Aufgabe 3 ★★ · rekord: Die Bestenliste ist leer"""
    braucht(_bestenliste())
    braucht('"rekord"' in ohne_kommentare() or "'rekord'" in ohne_kommentare())
    satz, abbruch = _rekord([], [])
    erwarte(not abbruch, "Mit namen = [] und rekorde = [] bricht rekord ab.")
    erwarte(satz == LEER, "Mit namen = [] und rekorde = [] sagt rekord nicht „Noch niemand war hier.“")


# ── Aufgabe 8 ★★ · Vorrat: Das Passwort ─────────────────────────────────

def pruefe_80_passwort():
    """Aufgabe 8 ★★ · passwort zählt die Ziffern im Wort"""
    braucht("passwort" in ohne_kommentare())
    aus, abbruch, _ = _spiel(["passwort kaffee42", "passwort kaffee", "passwort 2a4b6", "ende"])
    erwarte(not abbruch, "Bei passwort bricht das Spiel ab.")
    erwarte(re.search(r"Ziffern darin:\s*2\b", aus) is not None, "Bei passwort kaffee42 steht nicht „Angenommen. Ziffern darin: 2“.")
    erwarte("mindestens eine Ziffer" in aus, "Bei passwort kaffee fehlt „Zu einfach. Ein Passwort braucht mindestens eine Ziffer.“")
    erwarte(re.search(r"Ziffern darin:\s*3\b", aus) is not None,
            "Bei passwort 2a4b6 steht nicht „Ziffern darin: 3“ -- zählt ihr jedes Zeichen einzeln?")


# ── Aufgabe 9 ★★★★ · Kuer: Neuer Rekord? ────────────────────────────────

def _platz(rekorde):
    """Eine Kreide (10 Punkte), dann ende -- mit dieser Bestenliste. Gibt (letzte Zeile dazu, abbruch)."""
    namen = ["Gast%d" % (i + 1) for i in range(len(rekorde))]
    aus, abbruch, _ = _spiel(["nimm kreide", "ende"], namen=namen, rekorde=rekorde)
    m = re.findall(r"^.*(Neuer Rekord!.*|Platz\s+\d+.*)$", aus, re.M)
    return (m[-1].strip() if m else ""), abbruch


def pruefe_90_platz():
    """Aufgabe 9 ★★★★ · Am Ende der Platz in der Bestenliste"""
    braucht(_bestenliste())
    braucht(NEU in ohne_kommentare())
    satz, abbruch = _platz([140, 95, 120, 60, 110])
    erwarte(not abbruch and re.match(r"Platz\s+6\b", satz) is not None,
            "10 Punkte und fünf, die mehr haben -- am Ende steht nicht „Platz 6 der Bestenliste.“")
    satz, abbruch = _platz([5, 30, 3])
    erwarte(not abbruch and re.match(r"Platz\s+2\b", satz) is not None,
            "10 Punkte, und nur einer hat mehr -- am Ende steht nicht „Platz 2 der Bestenliste.“")


def pruefe_91_neuer_rekord():
    """Aufgabe 9 ★★★★ · Mehr als alle: ein neuer Rekord"""
    braucht(_bestenliste())
    braucht(NEU in ohne_kommentare())
    satz, abbruch = _platz([5, 3])
    erwarte(not abbruch and satz.startswith(NEU), "10 Punkte gegen 5 und 3 -- am Ende steht kein „Neuer Rekord!“")
    satz, abbruch = _platz([])
    erwarte(not abbruch and satz.startswith(NEU), "Mit einer leeren Bestenliste steht am Ende kein „Neuer Rekord!“ (oder es bricht ab).")


def pruefe_92_gleich_viele():
    """Aufgabe 9 ★★★★ · Gleich viele Punkte wie der Beste sind kein neuer Rekord"""
    braucht(_bestenliste())
    braucht(NEU in ohne_kommentare())
    satz, abbruch = _platz([10, 4])
    erwarte(not abbruch and re.match(r"Platz\s+1\b", satz) is not None,
            "10 Punkte, und der Beste hat auch 10 -- am Ende steht nicht „Platz 1 der Bestenliste.“")
