# Jedes Ding in eine eigene Zeile
rucksack = ["lampe", "stick", "kreide"]

i = 0
while i < len(rucksack):
    print("  -", rucksack[i])
    i = i + 1
# Probe 1 ohne i = i + 1: läuft endlos
# Probe 2 mit i <= len(rucksack): IndexError

print("Mit for:")
for ding in rucksack:
    print("  -", ding)
