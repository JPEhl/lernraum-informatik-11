# Die Schule bei Nacht -- euer Spiel.
# Stand nach Thema 9 (Der Rucksack):
# Statt drei Taschen eine Liste: rucksack.
# Anhängen, herausnehmen, nachsehen, zählen --
# sechs Dinge passen hinein, und das Tor fragt
# 'torschlüssel' in rucksack.

raum = "flur"
zuege = 30
punkte = 0

sekunden = 0
rucksack = ["lampe"]

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im", raum + ". Nur deine Lampe leuchtet.")

eingabe = ""
while zuege > 0 and raum != "tor" and eingabe != "ende":
    eingabe = input("> ").lower().strip()
    zuege = zuege - 1
    sekunden = sekunden + 45

    if eingabe == "ende":
        print("Du setzt dich auf die Treppe und wartest auf den Morgen.")
    elif eingabe == "norden" or eingabe == "osten" or eingabe == "süden" or eingabe == "westen":
        richtung = eingabe
        if raum == "flur":
            if richtung == "norden":
                if "torschlüssel" in rucksack:
                    raum = "tor"
                    print("Du schließt das Tor auf.")
                else:
                    print("Abgeschlossen. Du rüttelst an der Tür. Die Tür rüttelt nicht zurück.")
            elif richtung == "osten":
                raum = "informatikraum"
            elif richtung == "süden":
                raum = "lehrerzimmer"
            elif richtung == "westen":
                raum = "keller"
        elif raum == "informatikraum":
            if richtung == "westen":
                raum = "flur"
            else:
                print("Da ist eine Wand. Eine sehr solide Wand.")
        elif raum == "lehrerzimmer":
            if richtung == "norden":
                raum = "flur"
            else:
                print("Da ist eine Wand. Eine sehr solide Wand.")
        elif raum == "keller":
            if richtung == "osten":
                raum = "flur"
            else:
                print("Da ist eine Wand. Eine sehr solide Wand.")
        print("Du stehst jetzt im", raum + ".")
    elif eingabe.startswith("nimm "):
        ding = eingabe.replace("nimm ", "")
        if ding == "torschlüssel" and raum != "keller":
            print("Hier liegt kein Torschlüssel.")
        elif len(rucksack) >= 6:
            print("Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht. Leg etwas ab.")
        else:
            rucksack.append(ding)
            punkte = punkte + 10
            print("Du nimmst:", ding)
    elif eingabe.startswith("lege "):
        ding = eingabe.replace("lege ", "")
        if ding in rucksack:
            rucksack.remove(ding)
            print("Du legst weg:", ding)
        else:
            print("Das hast du nicht.")
    elif eingabe == "schau":
        if "lampe" in rucksack:
            if raum == "flur":
                print("Der Flur. Nur deine Lampe leuchtet. Das Haupttor liegt im Norden, dahinter ist Nacht.")
            elif raum == "informatikraum":
                print("Der Informatikraum. 24 Rechner schlafen. Einer blinkt, als hätte er etwas zu sagen.")
            elif raum == "lehrerzimmer":
                print("Das Lehrerzimmer. Es riecht nach altem Kaffee. Die Kaffeemaschine beobachtet dich.")
            elif raum == "keller":
                print("Der Keller. Rohre, Staub, ein Schacht im Boden. Irgendwo tropft es.")
            else:
                print("Das Haupttor. Draußen ist Nacht, Luft und ein Fahrrad, das deins ist.")
        else:
            print("Stockdunkel. Du siehst nicht einmal, wo du die Lampe hingelegt hast.")
    elif eingabe == "hilfe":
        print("Befehle: norden, osten, süden, westen, nimm <ding>, lege <ding>, schau, zeige, hilfe, ende")
    elif eingabe.startswith("warte "):
        zahl = eingabe.replace("warte ", "")
        if zahl.isdigit():
            n = int(zahl)
            zuege = zuege - n
            sekunden = sekunden + n * 45
            print("Du wartest", n, "Züge. Nichts passiert. Irgendwo tropft es.")
        else:
            print("Warten geht nur mit einer Zahl, zum Beispiel: warte 3")
    elif eingabe == "zeige":
        print("Du trägst", len(rucksack), "Dinge:", rucksack)
        print("Punkte:", punkte, "- Züge übrig:", zuege)
    else:
        print("Das verstehe ich nicht. Tippe hilfe.")

print()
if raum == "tor":
    punkte = punkte + zuege * 2
    print("Du schließt das Tor auf und stehst draußen. Die Nacht ist kalt und wunderbar.")
elif zuege <= 0:
    print("Die Lampe wird schwach, flackert und geht aus. Du sitzt im Dunkeln, bis der Hausmeister kommt.")

minuten = sekunden // 60
rest = sekunden % 60
print("Spielzeit:", minuten, "min", rest, "s -", punkte, "Punkte")
if minuten > 0:
    print("Das sind", round(punkte / minuten, 1), "Punkte pro Minute.")
