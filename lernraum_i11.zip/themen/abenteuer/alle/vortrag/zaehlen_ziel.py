# Die Bestenliste des Hausmeisters
punkte = [140, 95, 120, 60, 110]

anzahl = 0
for p in punkte:
    if p > 100:
        anzahl = anzahl + 1
print(anzahl, "Nächte mit mehr als 100 Punkten")
