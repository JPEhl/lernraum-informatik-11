# Jedes Ding in eine eigene Zeile
rucksack = ["lampe", "stick", "kreide"]
print(rucksack)
