# Die Bestenliste des Hausmeisters
punkte = [140, 95, 120, 60, 110]
