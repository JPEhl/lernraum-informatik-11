# Wer hat wie viele Punkte?
namen = ["Hausmeister", "Kater", "Kaffeemaschine", "Gespenst", "Putzroboter"]
punkte = [140, 95, 120, 60, 110]

for i in range(5):
    print(i)

for i in range(len(namen)):
    print(namen[i], punkte[i])
