# Wer hat wie viele Punkte?
punkte = [140, 95, 120, 60, 110]
