punkte = 30
def sterne() -> str:
    text = ""
    for i in range(punkte // 10):
        text = text + "*"
    return text
print("Punkte:", punkte, "- Sterne:", sterne())
print("Deine Sterne:", sterne())
