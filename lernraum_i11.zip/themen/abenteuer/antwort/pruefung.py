"""Selbstcheck zu "Das Tor, das nur redet" -- prueft antwort.py (Aufgabe 2, Aufgabe 3 ★★, Vorrat 8, Kuer 9).

Zwei Wege, wie in "Einmal schreiben, oft rufen":
- Das Spiel mit einer FOLGE von Befehlen anspielen und die Antwort auf jeden Befehl herausschneiden
  (_nach): Geht das Tor auf? Steht der Keller da? Stimmen die Sterne?
- Eine Funktion SELBST rufen (_rufen), mit eigenen Werten fuer die Variablen, die sie liest (raum,
  rucksack, punkte, schritte, sekunden): Was gibt sie zurueck -- und druckt sie dabei etwas? So sieht
  der Check den Unterschied, um den es geht: Eine Funktion, die druckt, liefert None.

Ob ein Block nur EINMAL dasteht, zaehlt er im Quelltext ohne Kommentare; wo etwas stehen muss (im
Rumpf einer Funktion, in einer Bedingung) und WO gerechnet wird (punkte // 10, sekunden // 60), liest
er mit ast -- ein Muster lehnte richtigen Code ab (range(0, punkte // 10), int(sekunden / 60)). Die Type Hints mahnt er an, bewertet sie
aber nicht (Drehbuch T12): Die Pruefung heisst "Hinweis · …" und gehoert zu keiner Aufgabe, also zu
keiner Stufe. Verraet keine Zeile, nur woran es haengt.

Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile, die der Check hinter den Code haengt
(SCHLUSS, wie in "Der Rucksack"): Fehlt sie, ist es unterwegs abgebrochen.
"""
import ast
import io
import re
import sys

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen, funktion, quelltext

TITEL = "Das Tor, das nur redet · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

DRAUSSEN = "kalt und wunderbar"
TREPPE = "wartest auf den Morgen"
AUF = "Du schließt das Tor auf."
ZU = "Abgeschlossen"
FLUR = "Der Flur."
KELLER = "Der Keller."
SCHLUSS = "§SCHLUSS§"

# Die Saetze, mit denen beschreibung() je Raum beginnen muss
RAEUME = [("flur", "Der Flur."), ("informatikraum", "Der Informatikraum."),
          ("lehrerzimmer", "Das Lehrerzimmer."), ("keller", "Der Keller."), ("tor", "Das Haupttor.")]

# Was hinter -> stehen soll, wo der Check es weiss (sonst: nur, dass etwas dasteht)
HINTS = {"hilfe": "None", "zeige_raum": "None", "zeige_rucksack": "None", "pruefe_tuer": "bool",
         "beschreibung": "str", "dinge_hier": "list[str]", "sterne": "str", "gib_durchschnitt": "float",
         "fehlende_sterne": "int", "spielminuten": "int", "spielzeit": "str"}

KEIN_WERT = object()


def _spiel(befehle, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte (punkte=30). Gibt
    (aus, abbruch): die ganze Ausgabe und ob das Programm unterwegs abgebrochen ist."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q + "\nprint(%r)\n" % SCHLUSS
    try:
        aus, _ = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet)


def _nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _strichliste(text):
    """Die Dinge, die als „  - ding“ je Zeile dastehen."""
    return re.findall(r"^[ \t]*-[ \t]*(\S.*?)[ \t]*$", text, re.M)


def _anzahl(muster):
    """Wie oft passt das Muster (regulaerer Ausdruck) im Quelltext ohne Kommentare?"""
    return len(re.findall(muster, ohne_kommentare()))


def _rufen(name, **werte):
    """Die Funktion `name` selbst rufen, vorher ihre Variablen setzen (raum="keller").
    Gibt (wert, gedruckt, fehler): was zurueckkam, was sie dabei gedruckt hat, ein Abbruch als Text."""
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    g = f.__globals__
    alt = {k: g.get(k, KEIN_WERT) for k in werte}
    g.update(werte)
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
        for k, v in alt.items():
            if v is KEIN_WERT:
                g.pop(k, None)
            else:
                g[k] = v
    return wert, puffer.getvalue(), fehler


def _baum():
    try:
        return ast.parse(quelltext())
    except SyntaxError:
        return None


def _defs():
    """Die Funktionen auf oberster Ebene: [(name, Knoten)]."""
    baum = _baum()
    return [] if baum is None else [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _im_rumpf(name, wort):
    """Steht `wort` im Rumpf der Funktion `name`?"""
    for n, k in _defs():
        if n == name:
            return wort in (ast.get_source_segment(quelltext(), k) or "")
    return False


def _ruft(name):
    """Die Namen, die die Funktion `name` in ihrem Rumpf aufruft."""
    gerufen = set()
    for n, k in _defs():
        if n == name:
            for c in ast.walk(k):
                if isinstance(c, ast.Call) and isinstance(c.func, ast.Name):
                    gerufen.add(c.func.id)
    return gerufen


def _in_bedingung(name):
    """Steht ein Aufruf von `name` in der Bedingung eines if (oder elif)?"""
    baum = _baum()
    if baum is None:
        return False
    for k in ast.walk(baum):
        if isinstance(k, ast.If):
            for c in ast.walk(k.test):
                if isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == name:
                    return True
    return False


def _rechnungen(name, zahl):
    """Wo rechnet das Programm mit `name` und der Zahl `zahl` (punkte // 10, sekunden % 60 …)?
    [(Rechenart, Funktion)] -- Rechenart „//“, „/“ oder „%“, Funktion None im Hauptprogramm. Gezaehlt
    wird mit ast, nicht mit einem Muster: range(0, punkte // 10) und int(sekunden / 60) zaehlen wie
    punkte // 10 und sekunden // 60 (Reihensichtung Teil II, #7: das Muster lehnte richtigen Code ab)."""
    baum = _baum()
    if baum is None:
        return []
    arten = {ast.FloorDiv: "//", ast.Div: "/", ast.Mod: "%"}
    gefunden = []
    for oben in baum.body:
        wo = oben.name if isinstance(oben, ast.FunctionDef) else None
        for k in ast.walk(oben):
            if isinstance(k, ast.BinOp) and type(k.op) in arten:
                seiten = (k.left, k.right)
                if any(isinstance(s, ast.Name) and s.id == name for s in seiten) and \
                        any(isinstance(s, ast.Constant) and s.value == zahl for s in seiten):
                    gefunden.append((arten[type(k.op)], wo))
    return gefunden


def _tuer_antwortet():
    """Gibt pruefe_tuer() True und False zurueck, ohne zu drucken?"""
    mit, d1, f1 = _rufen("pruefe_tuer", rucksack=["lampe", "torschlüssel"])
    ohne, d2, f2 = _rufen("pruefe_tuer", rucksack=["lampe"])
    return mit is True and ohne is False and not (d1 or d2 or f1 or f2)


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Einmal schreiben, oft rufen“ konnte"""
    aus, abbruch = _spiel(["warte 2", "ende"])
    erwarte(not (abbruch and "> " not in aus),
            "Das Spiel bricht schon vor der ersten Eingabe ab -- wird eine Funktion gerufen, bevor sie "
            "definiert ist?")
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Deine Sterne" in aus, "Am Ende steht „Deine Sterne:“ nicht mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 ★ · Das Tor antwortet ────────────────────────────────────

def pruefe_20_tuer_antwortet():
    """Aufgabe 2 · pruefe_tuer() antwortet True oder False"""
    braucht(funktion("pruefe_tuer") is not None, "Es gibt keine Funktion pruefe_tuer mehr.")
    mit, gedruckt_mit, fehler_mit = _rufen("pruefe_tuer", rucksack=["lampe", "torschlüssel"])
    ohne, gedruckt_ohne, fehler_ohne = _rufen("pruefe_tuer", rucksack=["lampe"])
    gedruckt = (gedruckt_mit or gedruckt_ohne).strip()
    fehler = fehler_mit or fehler_ohne
    erwarte(fehler is None, "pruefe_tuer() bricht ab: %s" % fehler)
    erwarte(not gedruckt,
            "pruefe_tuer() druckt noch „%s“ -- sie soll antworten, die Sätze druckt jetzt das "
            "Hauptprogramm." % gedruckt)
    erwarte(mit is not None or ohne is not None,
            "pruefe_tuer() gibt nichts zurück (None) -- was sie weiß, muss mit return heraus.")
    erwarte(mit is True, "Mit dem Torschlüssel im Rucksack antwortet pruefe_tuer() nicht True.")
    erwarte(ohne is False, "Ohne Torschlüssel antwortet pruefe_tuer() nicht False.")


def pruefe_21_tor():
    """Aufgabe 2 · Am Tor: abgeschlossen ohne Schlüssel, offen mit"""
    braucht(_tuer_antwortet())
    aus, abbruch = _spiel(["norden", "westen", "nimm torschlüssel", "osten", "norden"])
    erst, dann = _nach(aus, "norden"), _nach(aus, "norden", 2)
    erwarte(not abbruch, "Am Tor bricht das Spiel ab.")
    erwarte(ZU in erst, "Ohne Torschlüssel steht nach norden nicht „Abgeschlossen. …“.")
    erwarte(AUF in dann and ZU not in dann, "Mit dem Torschlüssel steht nach norden nicht „%s“." % AUF)
    erwarte(DRAUSSEN in aus, "Mit dem Torschlüssel kommt ihr nicht durchs Tor.")


def pruefe_22_einmal_gefragt():
    """Aufgabe 2 · Der Schlüssel wird nur einmal gefragt -- in pruefe_tuer()"""
    braucht(_tuer_antwortet())
    erwarte(_anzahl(r"""["']torschlüssel["']\s+in\s+rucksack""") == 1,
            "„torschlüssel“ in rucksack steht noch mehr als einmal im Programm -- das Hauptprogramm "
            "fragt die Funktion, nicht den Rucksack.")
    erwarte(_im_rumpf("pruefe_tuer", "torschlüssel"), "Die Frage nach dem Schlüssel steht nicht in pruefe_tuer().")
    erwarte(_in_bedingung("pruefe_tuer"), "pruefe_tuer() wird in keinem if gefragt.")
    erwarte(_anzahl(re.escape(AUF[:-1]) + r"\.[\"']") == 1 and not _im_rumpf("pruefe_tuer", "print"),
            "Die Sätze am Tor stehen noch in pruefe_tuer() oder doppelt im Programm.")


# ── Aufgabe 2 ★★ · Der Satz zum Raum und die Sterne ────────────────────

def pruefe_23_beschreibung():
    """Aufgabe 2 ★★ · beschreibung() liefert den Satz zum Raum"""
    braucht(funktion("beschreibung") is not None)
    for raum, anfang in RAEUME:
        wert, gedruckt, fehler = _rufen("beschreibung", raum=raum)
        erwarte(fehler is None, "beschreibung() bricht im Raum %s ab: %s" % (raum, fehler))
        erwarte(not gedruckt.strip(),
                "beschreibung() druckt den Satz, statt ihn zurückzugeben -- es kommt %r zurück." % (wert,))
        erwarte(isinstance(wert, str) and wert.startswith(anfang),
                "Mit raum = %r liefert beschreibung() nicht den Satz, der mit „%s“ beginnt." % (raum, anfang))


def pruefe_24_zeige_raum():
    """Aufgabe 2 ★★ · zeige_raum() druckt, was beschreibung() liefert"""
    braucht(funktion("beschreibung") is not None)
    aus, abbruch = _spiel(["westen", "schau", "ende"])
    erwarte(not abbruch, "Nach westen oder schau bricht das Spiel ab.")
    erwarte(KELLER in _nach(aus, "westen") and KELLER in _nach(aus, "schau"),
            "Im Keller steht nach westen oder schau nicht „Der Keller. …“.")
    erwarte(FLUR in aus[:aus.find("> ")], "Am Anfang steht nicht „Der Flur. …“.")
    erwarte("beschreibung" in _ruft("zeige_raum"), "zeige_raum() ruft beschreibung() nicht.")
    erwarte(_anzahl(r"Rohre, Staub") == 1, "Der Satz zum Keller steht mehr als einmal im Programm.")


def pruefe_25_sterne():
    """Aufgabe 2 ★★ · sterne() liefert die Sterne als Text"""
    braucht(funktion("sterne") is not None)
    for punkte, soll in ((30, "***"), (0, ""), (45, "****")):
        wert, gedruckt, fehler = _rufen("sterne", punkte=punkte)
        erwarte(fehler is None, "sterne() bricht ab: %s" % fehler)
        erwarte(not gedruckt.strip(),
                "sterne() druckt die Sterne, statt sie zurückzugeben -- es kommt %r zurück." % (wert,))
        erwarte(wert == soll, "Bei %d Punkten liefert sterne() nicht %r, sondern %r." % (punkte, soll, wert))


def pruefe_26_sterne_am_ende():
    """Aufgabe 2 ★★ · Am Ende stehen die Sterne -- ausgerechnet an einer Stelle"""
    braucht(funktion("sterne") is not None)
    aus, abbruch = _spiel(["ende"], punkte=30)
    erwarte(not abbruch, "Am Ende bricht das Spiel ab.")
    erwarte(re.search(r"Deine Sterne:\s*\*\*\*\s*$", aus, re.M) is not None,
            "Mit 30 Punkten steht am Ende nicht „Deine Sterne: ***“ -- wird sterne() mit Klammern gerufen?")
    rechnungen = _rechnungen("punkte", 10)
    erwarte(all(wo is not None for _, wo in rechnungen),
            "Das Hauptprogramm rechnet die Sterne noch selbst aus -- das soll nur sterne() tun.")
    erwarte(any(wo == "sterne" for _, wo in rechnungen),
            "In sterne() wird nicht aus den Punkten ausgerechnet, wie viele Sterne es sind.")


# ── Aufgabe 2 ★★★ · Die Dinge im Raum ──────────────────────────────────

def pruefe_27_dinge_hier():
    """Aufgabe 2 ★★★ · dinge_hier() liefert die Liste des Raums"""
    braucht(funktion("dinge_hier") is not None)
    for raum in ("flur", "informatikraum", "lehrerzimmer", "keller", "tor"):
        wert, gedruckt, fehler = _rufen("dinge_hier", raum=raum)
        liste = funktion("dinge_hier").__globals__.get("dinge_" + raum)
        erwarte(fehler is None, "dinge_hier() bricht im Raum %s ab: %s" % (raum, fehler))
        erwarte(not gedruckt.strip(), "dinge_hier() druckt etwas -- sie soll nur die Liste liefern.")
        erwarte(isinstance(wert, list) and wert is liste,
                "Mit raum = %r liefert dinge_hier() nicht die Liste dinge_%s." % (raum, raum))


def pruefe_28_nimm_lege():
    """Aufgabe 2 ★★★ · nimm und lege arbeiten mit dinge_hier()"""
    braucht(funktion("dinge_hier") is not None)
    aus, abbruch = _spiel(["osten", "nimm stick", "westen", "westen", "lege stick", "schau", "ende"])
    k = _strichliste(_nach(aus, "schau"))
    erwarte(not abbruch, "Bei nimm, lege oder schau bricht das Spiel ab.")
    erwarte("stick" in _nach(aus, "nimm stick") and "kein" not in _nach(aus, "nimm stick"),
            "Im Informatikraum lässt sich der Stick nicht nehmen.")
    erwarte(k == ["torschlüssel", "pausenbrot", "kreide", "stick"],
            "Nach lege stick im Keller zeigt schau nicht Torschlüssel, Pausenbrot, Kreide und Stick.")
    erwarte(_anzahl(r"\bdinge_keller\b") == 2 and _im_rumpf("dinge_hier", "dinge_keller"),
            "Die if-Kette, die hier setzt, steht noch im Hauptprogramm -- oder dinge_keller fehlt in dinge_hier().")


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_29_hints():
    """Hinweis · Jedes def mit Type Hint (kein Stern)"""
    braucht(_tuer_antwortet())
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None:
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint: %s -- hinter die Klammer gehört, was zurückkommt, -> None, wenn "
            "nichts. Es läuft auch ohne; vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 3 ★★ · Wie im Abitur: gib_durchschnitt() ──────────────────

def pruefe_30_durchschnitt():
    """Aufgabe 3 ★★ · gib_durchschnitt() liefert den Durchschnitt -- auch für andere Listen"""
    braucht(funktion("gib_durchschnitt") is not None)
    for liste, soll in (([4200, 3900, 5100, 4800], 4500), ([3000, 3000, 6000], 4000),
                        ([4000, 4001], 4000.5), ([7], 7)):
        wert, gedruckt, fehler = _rufen("gib_durchschnitt", schritte=list(liste))
        erwarte(fehler is None, "Mit schritte = %s bricht gib_durchschnitt() ab: %s" % (liste, fehler))
        erwarte(wert is not None,
                "gib_durchschnitt() gibt nichts zurück (None)%s." % (" -- sie druckt, statt zurückzugeben"
                                                                    if gedruckt.strip() else ""))
        zahl = isinstance(wert, (int, float)) and not isinstance(wert, bool)
        erwarte(zahl and abs(wert - soll) < 1e-9,
                "Mit schritte = %s liefert gib_durchschnitt() %r, nicht %r -- liest sie die Liste "
                "schritte, und teilt sie durch die Anzahl?" % (liste, wert, soll))


# ── Aufgabe 8 · Vorrat: Wie viele fehlen noch? ──────────────────────────

def pruefe_80_fehlende():
    """Aufgabe 8 ★★ · fehlende_sterne() rechnet mit der Antwort von sterne()"""
    braucht(funktion("fehlende_sterne") is not None)
    for punkte, soll in ((30, 7), (0, 10), (90, 1)):
        wert, gedruckt, fehler = _rufen("fehlende_sterne", punkte=punkte)
        erwarte(fehler is None, "fehlende_sterne() bricht ab: %s" % fehler)
        erwarte(wert == soll and isinstance(wert, int) and not isinstance(wert, bool),
                "Bei %d Punkten liefert fehlende_sterne() %r, nicht %d." % (punkte, wert, soll))
    erwarte("sterne" in _ruft("fehlende_sterne"), "fehlende_sterne() ruft sterne() nicht.")


def pruefe_81_zeige():
    """Aufgabe 8 ★★ · zeige sagt, wie viele Sterne noch fehlen"""
    braucht(funktion("fehlende_sterne") is not None)
    aus, abbruch = _spiel(["zeige", "ende"], punkte=30)
    erwarte(not abbruch, "Bei zeige bricht das Spiel ab.")
    erwarte(re.search(r"Noch\s+7\s+Sterne bis zum Rekord", _nach(aus, "zeige")) is not None,
            "Mit 30 Punkten steht nach zeige nicht „Noch 7 Sterne bis zum Rekord.“")


def pruefe_82_rekord():
    """Aufgabe 8 ★★★ · Mit zehn Sternen oder mehr sagt das Spiel etwas anderes"""
    braucht(funktion("fehlende_sterne") is not None)
    normal, _ = _spiel(["zeige", "ende"], punkte=30)
    zeilen = len(_nach(normal, "zeige").strip().splitlines())
    for punkte in (100, 130):
        aus, abbruch = _spiel(["zeige", "ende"], punkte=punkte)
        z = _nach(aus, "zeige")
        erwarte(not abbruch, "Mit %d Punkten bricht das Spiel bei zeige ab." % punkte)
        erwarte(re.search(r"Noch\s+-?\d", z) is None, "Mit %d Punkten steht nach zeige noch „Noch …“." % punkte)
        erwarte(len(z.strip().splitlines()) >= zeilen,
                "Mit %d Punkten sagt das Spiel bei zeige gar nichts zu den Sternen." % punkte)


# ── Aufgabe 9 ★★★★ · Kuer: Die Uhr antwortet ────────────────────────────
# Zwei Funktionen, die zusammenarbeiten (Reihensichtung Teil II, #8: die Kuer war leichter als die Pflicht):
# spielminuten() -> int und spielzeit() -> str, die mit der Antwort von spielminuten() weiterrechnet.

def _zeit_text(text):
    """„4 min 30 s“ -> (4, 30), sonst None -- Leerzeichen und Punkt am Ende egal."""
    m = re.fullmatch(r"\s*(\d+)\s*min\s+(\d+)\s*s\.?\s*", text) if isinstance(text, str) else None
    return (int(m.group(1)), int(m.group(2))) if m else None


def pruefe_90_spielminuten():
    """Aufgabe 9 ★★★★ · spielminuten() liefert die ganzen Minuten"""
    braucht(funktion("spielminuten") is not None)
    for sekunden, soll in ((150, 2), (59, 0), (225, 3)):
        wert, gedruckt, fehler = _rufen("spielminuten", sekunden=sekunden)
        erwarte(fehler is None, "spielminuten() bricht ab: %s" % fehler)
        erwarte(not gedruckt.strip(), "spielminuten() druckt etwas -- sie soll nur antworten.")
        erwarte(wert == soll and isinstance(wert, int) and not isinstance(wert, bool),
                "Bei %d Sekunden liefert spielminuten() %r, nicht %d." % (sekunden, wert, soll))


def pruefe_91_spielzeit():
    """Aufgabe 9 ★★★★ · spielzeit() liefert den Text und fragt spielminuten()"""
    braucht(funktion("spielzeit") is not None)
    for sekunden, soll in ((270, (4, 30)), (59, (0, 59)), (120, (2, 0))):
        wert, gedruckt, fehler = _rufen("spielzeit", sekunden=sekunden)
        erwarte(fehler is None, "spielzeit() bricht ab: %s" % fehler)
        erwarte(not gedruckt.strip(),
                "spielzeit() druckt etwas -- sie soll den Text zurückgeben, gedruckt wird im Hauptprogramm.")
        erwarte(_zeit_text(wert) == soll,
                "Bei %d Sekunden liefert spielzeit() %r, nicht den Text „%d min %d s“." % ((sekunden, wert) + soll))
    erwarte("spielminuten" in _ruft("spielzeit"),
            "spielzeit() fragt spielminuten() nicht -- die Minuten soll nur eine Funktion ausrechnen.")


def pruefe_92_einmal_gerechnet():
    """Aufgabe 9 ★★★★ · Aus Sekunden rechnen nur die Funktionen -- die Minuten einmal"""
    braucht(funktion("spielzeit") is not None)
    rechnungen = _rechnungen("sekunden", 60)
    erwarte(all(wo is not None for _, wo in rechnungen),
            "Das Hauptprogramm rechnet die Spielzeit noch selbst aus den Sekunden aus -- das sollen die "
            "Funktionen tun, das Hauptprogramm fragt sie.")
    erwarte(sum(1 for art, _ in rechnungen if art in ("//", "/")) == 1,
            "Die Minuten werden an mehr als einer Stelle aus den Sekunden ausgerechnet -- oder an keiner.")


def pruefe_93_uhr():
    """Aufgabe 9 ★★★★ · uhr zeigt die Spielzeit, mitten im Spiel"""
    braucht('"uhr"' in ohne_kommentare() or "'uhr'" in ohne_kommentare())
    aus, abbruch = _spiel(["uhr", "warte 3", "uhr", "ende"])
    erste, zweite = _nach(aus, "uhr"), _nach(aus, "uhr", 2)
    erwarte(not abbruch, "Bei uhr bricht das Spiel ab.")
    erwarte(re.search(r"Spielzeit:\s*0 min 45 s", erste) is not None,
            "Nach dem ersten uhr (ein Zug, 45 Sekunden) steht nicht „Spielzeit: 0 min 45 s“.")
    erwarte(re.search(r"Spielzeit:\s*4 min 30 s", zweite) is not None,
            "Nach uhr, warte 3 und uhr steht nicht „Spielzeit: 4 min 30 s“.")


def pruefe_94_am_ende():
    """Aufgabe 9 ★★★★ · Am Ende rechnet das Spiel mit den Antworten"""
    braucht(funktion("spielzeit") is not None)
    aus, abbruch = _spiel(["warte 3", "nimm kreide", "ende"])
    erwarte(not abbruch, "Am Ende bricht das Spiel ab.")
    erwarte(re.search(r"Spielzeit:\s*4 min 30 s\s*-\s*10 Punkte", aus) is not None,
            "Nach warte 3, nimm kreide und ende steht nicht „Spielzeit: 4 min 30 s - 10 Punkte“.")
    erwarte("Das sind 2.5 Punkte pro Minute" in aus,
            "Nach warte 3, nimm kreide und ende steht nicht „Das sind 2.5 Punkte pro Minute.“")
