# Das Tor allein -- gebaut wie im Spiel
rucksack = ["lampe", "torschlüssel"]
raum = "flur"


def pruefe_tuer() -> bool:
    return "torschlüssel" in rucksack


if pruefe_tuer():
    raum = "tor"
    print("Du schließt das Tor auf.")
else:
    print("Abgeschlossen. Du rüttelst an der Tür. Die Tür rüttelt nicht zurück.")
print("Raum:", raum)
