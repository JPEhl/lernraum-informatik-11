# Die Sterne -- ein kleines Spiel um Punkte
punkte = 0

eingabe = ""
while eingabe != "ende":
    eingabe = input("> ")
    if eingabe == "nimm":
        punkte = punkte + 10
        print("Du nimmst etwas. Punkte:", punkte)
    elif eingabe == "zeige":
        print("Punkte:", punkte)

text = ""
for i in range(punkte // 10):
    text = text + "*"
print("Deine Sterne:", text)
