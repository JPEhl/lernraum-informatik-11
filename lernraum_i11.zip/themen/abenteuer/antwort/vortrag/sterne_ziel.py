# Die Sterne -- ein kleines Spiel um Punkte
punkte = 0


def sterne() -> str:
    text = ""
    for i in range(punkte // 10):
        text = text + "*"
    return text


eingabe = ""
while eingabe != "ende":
    eingabe = input("> ")
    if eingabe == "nimm":
        punkte = punkte + 10
        print("Du nimmst etwas. Punkte:", punkte)
    elif eingabe == "zeige":
        print("Punkte:", punkte, "- Sterne:", sterne())

print("Deine Sterne:", sterne())
