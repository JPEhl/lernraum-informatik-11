# Das Tor allein -- gebaut wie im Spiel
rucksack = ["lampe", "torschlüssel"]
raum = "flur"


def pruefe_tuer():
    if "torschlüssel" in rucksack:
        print("Du schließt das Tor auf.")
    else:
        print("Abgeschlossen. Du rüttelst an der Tür. Die Tür rüttelt nicht zurück.")


pruefe_tuer()
if "torschlüssel" in rucksack:
    raum = "tor"
print("Raum:", raum)
