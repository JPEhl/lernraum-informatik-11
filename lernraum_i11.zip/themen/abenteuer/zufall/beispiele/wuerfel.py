import random


def wuerfel() -> int:
    return random.randint(1, 6)


print(wuerfel(), wuerfel(), wuerfel())

augen = wuerfel()
kleinste = augen
groesste = augen
for i in range(599):
    augen = wuerfel()
    if augen < kleinste:
        kleinste = augen
    if augen > groesste:
        groesste = augen
print("kleinste:", kleinste, "größte:", groesste)
