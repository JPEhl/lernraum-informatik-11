import random
raum = "keller"
zuege = 20
if raum == "keller" and random.randint(1, 6) == 1:
    print("KLACK. Die Sicherung fliegt raus.")
    zuege = zuege - 2
print("Züge übrig:", zuege)
