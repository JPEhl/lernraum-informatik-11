"""Selbstcheck zu "Der Kater kommt, wann er will" -- prueft zufall.py (Aufgabe 2, 3, Vorrat 7, Kuer 9).

Das Spiel wuerfelt jetzt. Damit der Check nicht selbst wuerfelt, stellt er den Zufall fest ein, solange er
das Spiel anspielt (_spiel(..., k=…, wahl=…, art=…)) -- dasselbe Mittel wie staende_testen.sh.

Fest auf k (Reihensichtung Teil II, 25.10., Befund 1): Vorher lieferte randint nur a oder nur b -- jede
Bedingung, die bei a zutrifft und bei b nicht, bestand (`<= 2` statt `== 1`, `randint(0, 6)`, der Kater an der
Wand). Jetzt laeuft das Spiel RUNDE = 60 Mal, Lauf k liefert randint(a, b) = a + k % (b - a + 1), random() den
k-ten Teil von 1 und choice das Element auf Platz k % len. Weil 60 durch 1 … 6 teilbar ist, kommt jeder Wert
eines Wuerfels gleich oft dran: „einer von sechs“ heisst genau 10 Treffer in 60 Laeufen, „einer von fuenf“
genau 12 -- gleich, ob jemand `== 1`, `== 6` oder `randint(1, 12) <= 2` schreibt. Wie oft es passiert, misst
der Check am Verhalten, nicht an Woertern im Quelltext.

Dazu: wahl="vorne"/"hinten" -- choice waehlt das erste bzw. letzte Element (der Kater nimmt ein bestimmtes
Ding); art="reihum" -- randint geht der Reihe nach durch a … b (600 Wuerfe: jede Augenzahl genau 100-mal);
art="doppelt" -- jeder Wert kommt zweimal hintereinander (die Kaffeemaschine darf sich nicht wiederholen);
ohne Angabe der echte Zufall mit fester Saat (zwei Wuerfel).

Wie in "Seil, Apfel und Kreide": die Antwort auf einen Befehl herausschneiden (_nach), eine Funktion selbst
rufen (_rufen). Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile hinter dem Code (SCHLUSS).
"""
import ast
import io
import random
import re
import sys

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen, funktion, quelltext

TITEL = "Der Kater kommt, wann er will · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

TREPPE = "wartest auf den Morgen"
KLACK = "KLACK"
KATER = "Byte"
SCHLUSS = "§SCHLUSS§"
KAFFEE = "benutze kaffeemaschine"
SAGT = "Die Kaffeemaschine sagt"

RUNDE = 60          # durch 1 … 6 teilbar: jeder Wuerfelwert gleich oft
SAAT = 14

HINTS = {"hilfe": "None", "zeige_raum": "None", "zeige_rucksack": "None", "pruefe_tuer": "bool",
         "beschreibung": "str", "dinge_im": "list[str]", "sterne": "str", "aufzaehlen": "str", "ziel": "str",
         "gehe": "str", "kater": "None", "haeufigkeit": "int", "balken": "str", "kaffee": "str"}

KEIN_WERT = object()
_ECHT = (random.randint, random.choice, random.random)


def _zufall_fest(k=None, wahl="", art=""):
    """Stellt randint/choice/random fest ein; gibt eine Funktion zurueck, die alles zuruecksetzt.
    k: Lauf k von RUNDE (siehe oben). wahl: "vorne"/"hinten" fuer choice. art: "reihum"/"doppelt" (ohne k)."""
    randint, choice, _ = _ECHT
    random.seed(SAAT)
    zaehler = {}
    teiler = 2 if art == "doppelt" else 1

    def naechster(schluessel):
        n = zaehler.get(schluessel, 0)
        zaehler[schluessel] = n + 1
        return n // teiler

    def breite(a, b):
        if b < a:
            randint(a, b)           # derselbe Fehler wie echt (ValueError: empty range)
        return b - a + 1
    if k is not None:
        random.randint = lambda a, b: a + k % breite(a, b)
        random.random = lambda: (k % RUNDE + 0.5) / RUNDE
    elif art in ("reihum", "doppelt"):
        random.randint = lambda a, b: a + naechster((a, b)) % breite(a, b)
    if wahl in ("vorne", "hinten"):
        random.choice = (lambda folge: folge[0]) if wahl == "vorne" else (lambda folge: folge[-1])
    elif k is not None:
        random.choice = lambda folge: folge[k % len(folge)] if len(folge) else choice(folge)
    elif art in ("reihum", "doppelt"):
        random.choice = lambda folge: folge[naechster(tuple(folge)) % len(folge)] if len(folge) else choice(folge)

    def zurueck():
        random.randint, random.choice, random.random = _ECHT
    return zurueck


def _spiel(befehle, k=None, wahl="", art=""):
    """Das Spiel mit diesen Befehlen, der Zufall fest eingestellt. Gibt (aus, abbruch)."""
    alt = pruefen._QUELLE
    pruefen._QUELLE = alt + "\nprint(%r)\n" % SCHLUSS
    zurueck = _zufall_fest(k, wahl, art)
    try:
        aus, _ = anspielen(befehle)
    finally:
        zurueck()
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet)


def _treffer(befehle, wort, befehl, n=1):
    """Alle RUNDE Laeufe: in welchen steht `wort` in der Antwort auf den n-ten `befehl`?
    Gibt (treffer, abbruch): die Liste der k mit Treffer, ob irgendein Lauf abbrach."""
    treffer, abbruch = [], False
    for k in range(RUNDE):
        aus, ab = _spiel(befehle, k=k)
        abbruch = abbruch or ab
        if wort in _nach(aus, befehl, n):
            treffer.append(k)
    return treffer, abbruch


def _erster(befehle, wort, befehl, wahl=""):
    """Der erste Lauf k, in dem `wort` in der Antwort auf `befehl` steht; None: in keinem."""
    for k in range(RUNDE):
        if wort in _nach(_spiel(befehle, k=k, wahl=wahl)[0], befehl):
            return k
    return None


def _nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _rufen(name, *argumente):
    """Die Funktion `name` mit diesen Argumenten rufen. Gibt (wert, gedruckt, fehler)."""
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
    return wert, puffer.getvalue(), fehler


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _random_da():
    return re.search(r"^\s*(import\s+random\b|from\s+random\s+import\b)", ohne_kommentare(), re.M) is not None


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Seil, Apfel und Kreide“ konnte"""
    aus, abbruch = _spiel(["warte 2", "ende"])
    erwarte(not (abbruch and "> " not in aus),
            "Das Spiel bricht schon vor der ersten Eingabe ab -- kennt Python jeden Namen, den das Programm "
            "oben braucht, und ist jede Funktion definiert, bevor sie gerufen wird?")
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Deine Sterne" in aus, "Am Ende steht „Deine Sterne:“ nicht mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 · Die Sicherung ───────────────────────────────────────────

def pruefe_20_sicherung():
    """Aufgabe 2 · Im Keller fliegt manchmal die Sicherung raus"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil II, 25.10., Befund 6: vorher „2 von 2 passen“ ohne naechsten Schritt).
    erwarte(KLACK in quelltext(), "Im Keller fliegt noch keine Sicherung raus -- das Spiel würfelt noch nicht.")
    erwarte(_random_da(), "Das Spiel holt die Bibliothek für den Zufall noch nicht.")
    treffer, abbruch = _treffer(["westen", "zeige", "ende"], KLACK, "westen")
    erwarte(not abbruch, "Bei westen oder zeige bricht das Spiel ab -- bei manchen Würfen.")
    erwarte(treffer, "Im Keller fliegt die Sicherung nie raus -- bei keinem der 60 festen Würfe.")
    erwarte(len(treffer) < RUNDE, "Die Sicherung fliegt bei jedem Betreten des Kellers -- sie soll nur manchmal fliegen.")
    erwarte(len(treffer) == RUNDE // 6,
            "Bei 60 festen Würfen fliegt die Sicherung %d-mal -- „einer von sechs“ wären 10." % len(treffer))
    aus, _ = _spiel(["westen", "zeige", "ende"], k=treffer[0])
    erwarte(re.search(r"Züge übrig:\s*26", _nach(aus, "zeige")) is not None,
            "Fliegt die Sicherung, steht nach westen und zeige nicht „Züge übrig: 26“ -- kostet sie 2 Züge?")
    erwarte(KLACK not in _spiel(["osten", "westen", "süden", "ende"], k=treffer[0])[0],
            "Die Sicherung fliegt auch außerhalb des Kellers.")


def pruefe_21_nur_betreten():
    """Aufgabe 2 ★★ · Die Sicherung fliegt nur beim Betreten, nicht an der Wand"""
    braucht(_random_da() and KLACK in quelltext())
    k = _erster(["westen", "ende"], KLACK, "westen")
    braucht(k is not None)
    aus, abbruch = _spiel(["westen", "westen", "westen", "ende"], k=k)
    erwarte(not abbruch, "Im Keller an der Wand bricht das Spiel ab.")
    erwarte(aus.count(KLACK) == 1, "Westen im Keller ist eine Wand -- die Sicherung fliegt dort noch einmal. "
            "Sie soll nur fliegen, wenn ihr den Keller betretet.")


# ── Aufgabe 3 · Der Kater ───────────────────────────────────────────────

def pruefe_30_kater():
    """Aufgabe 3 · Wer einen Raum betritt, trifft manchmal den Kater"""
    braucht(_random_da() and KATER in quelltext(), "Noch kein Kater im Spiel.")
    treffer, abbruch = _treffer(["osten", "ende"], KATER, "osten")
    erwarte(not abbruch, "Kommt der Kater, bricht das Spiel ab -- bei manchen Würfen.")
    erwarte(treffer, "Nach osten kommt der Kater nie -- bei keinem der 60 festen Würfe.")
    erwarte(len(treffer) < RUNDE, "Der Kater kommt jedes Mal -- er soll nur manchmal kommen.")
    erwarte(len(treffer) == RUNDE // 5,
            "Bei 60 festen Würfen kommt der Kater %d-mal -- „einer von fünf“ wären 12." % len(treffer))
    aus, _ = _spiel(["osten", "osten", "ende"], k=treffer[0])
    erwarte(KATER not in _nach(aus, "osten", 2),
            "Im Informatikraum führt osten gegen eine Wand -- und trotzdem kommt der Kater. Er soll nur kommen, "
            "wenn ihr einen Raum betretet.")


def pruefe_31_schnappen():
    """Aufgabe 3 ★★ · Der Kater schnappt sich ein Ding und lässt es im Raum fallen"""
    braucht(_random_da() and ("choice" in ohne_kommentare() or "schnappt" in quelltext()))
    # Kreide aus dem Flur nehmen, dann in den Informatikraum. Gesucht ist ein Lauf, in dem er die Kreide nimmt
    # (choice: das letzte Ding; wer selbst einen Platz wuerfelt, trifft sie in einem anderen Lauf) -- so besteht
    # auch, wer die Lampe noch nicht schuetzt; das prueft erst ★★★.
    befehle = ["nimm kreide", "osten", "zeige", "ende"]
    braucht(_erster(befehle, KATER, "osten", "hinten") is not None)
    k = None
    for kk in range(RUNDE):
        neu = _nach(_spiel(befehle, k=kk, wahl="hinten")[0], "osten")
        if KATER in neu and "kreide" in neu.split("Hier liegt")[0].lower():
            k = kk
            break
    erwarte(k is not None, "Der Kater sagt nicht, was er sich schnappt -- oder er nimmt nie die Kreide, auch wenn "
            "sie neben der Lampe euer einziges Ding ist.")
    aus, abbruch = _spiel(befehle, k=k, wahl="hinten")
    erwarte(not abbruch, "Wenn der Kater kommt, bricht das Spiel ab.")
    neu = _nach(aus, "osten")
    erwarte("kreide" not in _nach(aus, "zeige").lower(), "Nach dem Kater steckt die Kreide noch im Rucksack.")
    hier = next((z for z in neu.splitlines() if z.startswith("Hier liegt")), "")
    erwarte(hier.lower().count("kreide") == 2,
            "Im Informatikraum liegt danach nicht zweimal Kreide (die eigene und eure) -- lässt der Kater sie im neuen Raum "
            "fallen? (gesehen: %s)" % (hier or "keine Zeile „Hier liegt“"))


def pruefe_32_nicht_die_lampe():
    """Aufgabe 3 ★★★ · Die Lampe lässt er liegen -- und mit leerem Rucksack bricht nichts ab"""
    braucht(_random_da() and ("choice" in ohne_kommentare() or "schnappt" in quelltext()))
    treffer, _ = _treffer(["osten", "ende"], KATER, "osten")
    braucht(treffer)
    lampe_weg = nur_lampe = leer = False
    for k in treffer:
        for wahl in ("vorne", "hinten"):
            # vorne: choice nimmt das erste Ding -- ohne Schutz waere das die Lampe
            aus, abbruch = _spiel(["westen", "nimm pausenbrot", "osten", "zeige", "ende"], k=k, wahl=wahl)
            lampe_weg = lampe_weg or abbruch or "lampe" not in _nach(aus, "zeige").lower()
        aus, abbruch = _spiel(["osten", "zeige", "ende"], k=k, wahl="vorne")
        nur_lampe = nur_lampe or abbruch or "lampe" not in _nach(aus, "zeige").lower()
        leer = leer or _spiel(["lege lampe", "osten", "westen", "ende"], k=k, wahl="vorne")[1]
    erwarte(not lampe_weg, "Der Kater hat die Lampe genommen -- die soll er liegen lassen (oder das Spiel bricht ab).")
    erwarte(not nur_lampe, "Trägt ihr nur die Lampe, nimmt der Kater sie -- oder das Spiel bricht ab.")
    erwarte(not leer, "Mit leerem Rucksack bricht das Spiel ab, wenn der Kater kommt -- aus nichts lässt sich "
            "nichts wählen.")


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(_random_da())
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 7 · Vorrat: Die Würfelmaschine ──────────────────────────────

def _balken_zeilen(aus, von, bis):
    """Je Zahl von..bis: die Zahl der # in ihrer Zeile, None, wenn die Zeile fehlt."""
    werte = {}
    for z in aus.splitlines():
        m = re.match(r"\s*(?:> )?\s*(\d+)\s+(#*)\s*$", z)
        if m and von <= int(m.group(1)) <= bis:
            werte[int(m.group(1))] = len(m.group(2))
    return [werte.get(n) for n in range(von, bis + 1)]


def pruefe_70_haeufigkeit():
    """Aufgabe 7 ★★ · haeufigkeit(augen, wuerfe) zählt -- und würfeln zeigt sechs Balken"""
    braucht(funktion("haeufigkeit") is not None)
    for augen, wuerfe, soll in ((6, [6, 1, 6, 3], 2), (1, [2, 3], 0), (3, [], 0), (2, [2, 2, 2], 3)):
        wert, gedruckt, fehler = _rufen("haeufigkeit", augen, list(wuerfe))
        erwarte(fehler is None, "haeufigkeit(%r, %r) bricht ab: %s" % (augen, wuerfe, fehler))
        erwarte(wert == soll, "haeufigkeit(%r, %r) liefert %r, nicht %d." % (augen, wuerfe, wert, soll))
    # reihum: Der Wuerfel geht der Reihe nach durch alle Augenzahlen -- 600 Wuerfe sind genau 100 je Zahl, also
    # zehn # je Zeile (vorher echter Zufall und 5 … 16 #: zu weit, Befund 1)
    aus, abbruch = _spiel(["würfeln", "ende"], art="reihum")
    zeilen = _balken_zeilen(_nach(aus, "würfeln"), 0, 7)
    erwarte(not abbruch, "Bei würfeln bricht das Spiel ab.")
    fehlt = [str(n) for n, x in zip(range(1, 7), zeilen[1:7]) if x is None]
    erwarte(not fehlt, "Nach würfeln fehlt die Zeile mit Balken für: %s." % ", ".join(fehlt))
    erwarte(zeilen[0] is None and zeilen[7] is None,
            "Nach würfeln steht auch eine Zeile für 0 oder 7 -- ein Würfel zeigt 1 bis 6.")
    erwarte(all(9 <= x <= 11 for x in zeilen[1:7]),
            "Kommt jede Augenzahl gleich oft, sind die Balken nicht je zehn # lang -- 600 Würfe, ein # je zehn, "
            "und jede Augenzahl dabei? (gemessen: %s)" % ", ".join(str(x) for x in zeilen[1:7]))


def pruefe_71_zwei():
    """Aufgabe 7 ★★★ · zwei würfel: die Summen 2 bis 12, die 7 am längsten"""
    braucht(funktion("haeufigkeit") is not None and "zwei würfel" in quelltext())
    aus, abbruch = _spiel(["zwei würfel", "ende"])
    zeilen = _balken_zeilen(_nach(aus, "zwei würfel"), 2, 12)
    erwarte(not abbruch, "Bei zwei würfel bricht das Spiel ab.")
    fehlt = [str(n) for n, x in zip(range(2, 13), zeilen) if x is None]
    erwarte(not fehlt, "Nach zwei würfel fehlt die Zeile für: %s." % ", ".join(fehlt))
    erwarte(not fehlt and zeilen[5] >= max(zeilen[0], zeilen[10]) + 4,
            "Die 7 ist nicht deutlich länger als die 2 und die 12 -- würfelt ihr wirklich zwei Würfel und addiert?")


# ── Aufgabe 9 ★★★★ · Kuer: Die Kaffeemaschine ───────────────────────────

def _meldung(aus, n=1):
    """Was die Kaffeemaschine beim n-ten Benutzen sagt (ohne „Die Kaffeemaschine sagt“), sonst None."""
    teil = _nach(aus, KAFFEE, n)
    if SAGT not in teil:
        return None
    return teil.split(SAGT, 1)[1].lstrip(": ").splitlines()[0].strip()


def pruefe_90_kaffeemaschine():
    """Aufgabe 9 ★★★★ · benutze kaffeemaschine: zufällig, nur im Lehrerzimmer, nie zweimal dasselbe"""
    braucht("kaffeemaschine" in ohne_kommentare().replace("Die Kaffeemaschine beobachtet dich", ""))
    vorne, abbruch = _spiel(["süden", KAFFEE, "ende"], k=0, wahl="vorne")
    hinten, _ = _spiel(["süden", KAFFEE, "ende"], k=RUNDE - 1, wahl="hinten")
    erwarte(not abbruch, "Bei benutze kaffeemaschine bricht das Spiel ab.")
    erwarte(_meldung(vorne) is not None,
            "Im Lehrerzimmer steht nach benutze kaffeemaschine nicht „Die Kaffeemaschine sagt: …“.")
    erwarte(_meldung(vorne) != _meldung(hinten),
            "Die Kaffeemaschine sagt immer dasselbe -- kommt die Meldung aus dem Zufall?")
    flur, _ = _spiel([KAFFEE, "ende"], k=0, wahl="vorne")
    erwarte("keine Kaffeemaschine" in _nach(flur, KAFFEE),
            "Im Flur steht nach benutze kaffeemaschine nicht „Hier steht keine Kaffeemaschine.“")
    # doppelt: Jeder Zufallswert kommt zweimal hintereinander -- wer nur wuerfelt, wiederholt sich; wer die letzte
    # Meldung ausschliesst (oder neu wuerfelt, bis es eine andere ist), nicht (Befund 8: Kuer eine Stufe schwerer)
    aus, abbruch = _spiel(["süden", KAFFEE, KAFFEE, KAFFEE, KAFFEE, "ende"], art="doppelt")
    folge = [_meldung(aus, n) for n in range(1, 5)]
    erwarte(not abbruch and None not in folge,
            "Viermal hintereinander benutzt, sagt die Kaffeemaschine nicht jedes Mal „Die Kaffeemaschine sagt: …“ "
            "-- oder das Spiel bricht ab.")
    gleich = [folge[i] for i in range(3) if folge[i] == folge[i + 1]]
    erwarte(not gleich, "Die Kaffeemaschine sagt zweimal hintereinander dasselbe (%s) -- sie soll jedes Mal "
            "etwas anderes sagen als eben." % (gleich[0] if gleich else ""))
