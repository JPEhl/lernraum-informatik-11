# Der Kater -- klein, gebaut wie im Spiel
import random

rucksack = ["lampe", "seil", "apfel", "kreide"]
hier = ["stick"]

ding = random.choice(rucksack)
rucksack.remove(ding)
hier.append(ding)
print("Byte schnappt sich:", ding)
print("Du trägst:", rucksack)
print("Hier liegt:", hier)
