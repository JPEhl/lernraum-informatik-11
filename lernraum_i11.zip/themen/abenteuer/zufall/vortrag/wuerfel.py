# Ein Würfel -- klein, für sich
