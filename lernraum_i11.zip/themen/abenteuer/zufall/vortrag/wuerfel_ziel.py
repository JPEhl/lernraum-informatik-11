# Ein Würfel -- klein, für sich
import random


def wuerfel() -> int:
    return random.randint(1, 6)


print(wuerfel(), wuerfel(), wuerfel())

kleinste = 100
groesste = 0
for i in range(600):
    augen = wuerfel()
    if augen < kleinste:
        kleinste = augen
    if augen > groesste:
        groesste = augen
print("kleinste:", kleinste, "größte:", groesste)
