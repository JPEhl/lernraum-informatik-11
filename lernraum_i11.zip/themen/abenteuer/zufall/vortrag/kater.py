# Der Kater -- klein, gebaut wie im Spiel
import random

rucksack = ["lampe", "seil", "apfel", "kreide"]
hier = ["stick"]
