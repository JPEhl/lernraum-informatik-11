"""Selbstcheck zu "Die Schule im Fenster" -- prueft fenster.py (Aufgabe 2, 3, 4, Vorrat 6, Kuer 8).

Vorrat 7 *Zu frueh, zu spaet* ist ein Fall; ihn prueft die Seite.

Das ganze Spiel im Fenster. Der Check oeffnet kein Fenster: pruefen.py baut es unsichtbar und klickt ueber die
Beschriftung (klick, knopf, tippe, labeltexte, textflaeche -- LIESMICH „Fenster (tkinter) im Lernraum“). Weil alle
Pruefungen dasselbe Fenster benutzen, setzt _neu() vor jeder den Spielstand zurueck: die Kaestchen oben (raum,
zuege, punkte …), Rucksack und Dinglisten, Textflaeche und Feld, und es gibt Knoepfe und Feld wieder frei (der
Vorrat sperrt sie). Den Zufall stellt _neu() fest auf „nie“ (randint liefert b: keine Sicherung, kein Kater),
_fest() fuer ★★★ auf „immer“ (randint liefert a, choice das erste) -- wie staende_testen.sh.
"""
import ast
import random
import re

from pruefen import (erwarte, braucht, funktion, fenster, elemente, knopf, klick, tippe, labeltexte, textflaeche,
                     ohne_kommentare, quelltext)

TITEL = "Die Schule im Fenster · Selbstcheck"

# Was jede Funktion zurueckgibt -- der Hinweis prueft auch, ob der Type Hint stimmt (wie in zusammen;
# Reihensichtung Teil III, 27.10., Befund 7).
HINTS = {"beschreibung": "str", "ziel": "str", "ausgaenge": "list[str]", "tuer_offen": "bool",
         "dinge_im": "list[str]", "wert": "int", "erzaehle": "None", "aufzaehlen": "str", "zeige_raum": "None",
         "zeige_rucksack": "None", "befehle": "str", "hilfe": "None", "gehe": "str", "nimm": "int", "lege": "None",
         "kater": "None", "benutze": "int", "iss": "int", "sterne": "str", "zeige_stand": "None", "schritt": "None",
         "norden": "None", "osten": "None", "sueden": "None", "westen": "None", "los": "None", "essen": "None",
         "taste": "None", "nach_dem_zug": "None", "schluss": "None"}

NOCH_NICHTS = "tut noch nichts"
_ANFANG = {}


def _g():
    """Die Kaestchen oben in fenster.py -- dort, wo die Knopf-Funktionen sie lesen und aendern."""
    f = funktion("gehe") or funktion("zeige_stand")
    return f.__globals__ if f is not None else {}


def _neu():
    g = _g()
    if not _ANFANG:
        for name, wert in g.items():
            if name.startswith("dinge_") and isinstance(wert, list):
                _ANFANG[name] = list(wert)
    for name, wert in _ANFANG.items():
        g[name][:] = wert
    g["rucksack"][:] = ["lampe"]
    g.update(raum="flur", zuege=30, punkte=0, sekunden=0, ruhe=0)
    for w in elemente("Button") + elemente("Entry"):
        w.config(state="normal")
    for w in elemente("Text"):
        w.delete("1.0", "end")
    if elemente("Entry"):
        tippe("")
    random.randint = lambda a, b: b
    random.choice = lambda liste: liste[-1]


def _fest():
    random.randint = lambda a, b: a
    random.choice = lambda liste: liste[0]


def _kopf():
    """Die Kopfzeile -- das Label mit den Zuegen."""
    for t in labeltexte():
        if "Züge" in t:
            return t
    return ""


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [k for k in baum.body if isinstance(k, ast.FunctionDef)]


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_fenster():
    """Grundlage · Das Spiel steht im Fenster: vier Knöpfe, Kopfzeile, Textfläche"""
    erwarte(fenster() is not None, "Das Programm baut kein Fenster -- steht fenster = tk.Tk() noch da?")
    fehlt = [r for r in ("Norden", "Osten", "Süden", "Westen") if knopf(r) is None]
    erwarte(not fehlt, "Diese Knöpfe fehlen: %s." % ", ".join(fehlt))
    erwarte("Flur" in _kopf(), "Die Kopfzeile zeigt den Raum nicht mehr.")
    erwarte("DIE SCHULE BEI NACHT" in textflaeche(), "Am Anfang steht der Anfang des Spiels nicht in der Textfläche.")


# ── Aufgabe 2 · Die Knöpfe gehen ─────────────────────────────────────────

def pruefe_20_gehen():
    """Aufgabe 2 · Osten geht in den Informatikraum, Norden stößt ans Tor"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil III, 27.10., Befund 1: vorher „x von x passen“ ohne naechsten Schritt).
    erwarte("global" in ohne_kommentare(), "Noch ändert kein Knopf den Spielstand -- ein Klick auf Osten "
            "soll den Raum wirklich wechseln.")
    _neu()
    klick("Osten")
    g = _g()
    raum = g.get("raum")
    erwarte(raum == "informatikraum", "Nach Osten ist raum „%s“ -- erwartet: informatikraum." % raum)
    erwarte("Informatikraum" in textflaeche(), "Nach Osten zeigt die Textfläche den Informatikraum nicht.")
    erwarte(g.get("zuege") == 29, "Nach einem Zug sollten es 29 Züge sein, es sind %s." % g.get("zuege"))
    _neu()
    klick("Norden")
    erwarte(_g().get("raum") == "flur" and "Abgeschlossen" in textflaeche(),
            "Nach Norden ohne Torschlüssel sollte das Tor zu sein und raum flur bleiben.")


def pruefe_21_alle_vier():
    """Aufgabe 2 ★★ · Alle vier Richtungen, die Kopfzeile zeigt den Stand"""
    _neu()
    klick("Süden")
    braucht(NOCH_NICHTS not in textflaeche(), "Süden tut noch nichts.")
    erwarte(_g().get("raum") == "lehrerzimmer", "Nach Süden ist raum nicht das Lehrerzimmer.")
    erwarte("Lehrerzimmer" in _kopf() and "29 Züge" in _kopf(),
            "Nach Süden zeigt die Kopfzeile „%s“ -- erwartet: Lehrerzimmer und 29 Züge." % _kopf())
    klick("Norden")
    klick("Westen")
    erwarte(NOCH_NICHTS not in textflaeche(), "Westen tut noch nichts.")
    erwarte(_g().get("raum") == "keller" and "Keller" in _kopf() and "27 Züge" in _kopf(),
            "Nach Süden, Norden, Westen zeigt die Kopfzeile „%s“ -- erwartet: Keller und 27 Züge." % _kopf())


def pruefe_22_wie_im_spiel():
    """Aufgabe 2 ★★★ · Sicherung, Kater und Plakat -- nur beim Betreten"""
    aufruf = re.search(r"^\s+kater\(raum\)", ohne_kommentare(), re.M) is not None
    braucht("KLACK" in ohne_kommentare() or aufruf, "Noch keine Sicherung, kein Kater.")
    _neu()
    _g()["rucksack"].append("kreide")
    _fest()
    klick("Westen")
    t = textflaeche()
    erwarte("KLACK" in t, "Beim Betreten des Kellers fliegt die Sicherung nie raus.")
    erwarte("Byte" in t, "Beim Betreten eines Raums kommt der Kater nie.")
    zuege = _g().get("zuege")
    erwarte(zuege == 27, "Westen mit Sicherung: erwartet 27 Züge (einer für den Zug, zwei für die Sicherung), "
                         "es sind %s." % zuege)
    klick("Westen")
    erwarte(textflaeche().count("KLACK") == 1, "An der Wand im Keller fliegt die Sicherung noch einmal -- dort betritt "
                                               "man keinen Raum.")
    klick("Süden")
    erwarte("RUHE!" in textflaeche(), "In der Bibliothek hängt das Plakat nicht.")


# ── Aufgabe 3 · Das Befehlsfeld ──────────────────────────────────────────

def pruefe_30_feld():
    """Aufgabe 3 · Feld und Los: leeres Feld, schau, hilfe"""
    braucht(knopf("Los") is not None and elemente("Entry"), "Noch kein Feld mit einem Knopf Los.")
    _neu()
    tippe("")
    klick("Los")
    erwarte("Tippe zuerst einen Befehl." in textflaeche(), "Ein leeres Feld sagt nicht „Tippe zuerst einen Befehl.“")
    tippe("schau")
    klick("Los")
    erwarte("Der Flur." in textflaeche(), "Nach schau zeigt die Textfläche den Flur nicht.")
    tippe("  HILFE ")
    klick("Los")
    erwarte("Ins Feld tippst du" in textflaeche(), "Nach „  HILFE “ steht die Hilfe nicht da -- klein und ohne Leerzeichen?")


def pruefe_31_nehmen():
    """Aufgabe 3 ★★ · nimm und lege mit Punkten und Zügen"""
    braucht(knopf("Los") is not None and "nimm(" in ohne_kommentare().split("def nimm")[-1], "Noch kein nimm im Feld.")
    _neu()
    tippe("nimm kreide")
    klick("Los")
    g = _g()
    erwarte("Du nimmst: Kreide." in textflaeche(), "Nach nimm kreide fehlt „Du nimmst: Kreide.“")
    erwarte(g.get("punkte") == 10 and g.get("zuege") == 29,
            "Nach nimm kreide: erwartet 10 Punkte und 29 Züge, es sind %s und %s." % (g.get("punkte"), g.get("zuege")))
    erwarte("10 Punkte" in _kopf(), "Die Kopfzeile zeigt die Punkte nicht: „%s“." % _kopf())
    tippe("lege kreide")
    klick("Los")
    erwarte("Du legst weg: Kreide." in textflaeche() and "kreide" not in _g()["rucksack"], "lege kreide legt nichts ab.")


def pruefe_32_aufgeraeumt():
    """Aufgabe 3 ★★★ · Das Feld ist danach leer, die Befehlszeile zeigt, was geht"""
    braucht(knopf("Los") is not None and any(t.startswith("Befehle:") for t in labeltexte()), "Noch keine Befehlszeile.")
    _neu()
    tippe("schau")
    klick("Los")
    erwarte(elemente("Entry")[0].get() == "", "Nach Los steht der Befehl noch im Feld.")
    zeile = [t for t in labeltexte() if t.startswith("Befehle:")]
    erwarte(zeile and "nimm kreide" in zeile[0], "Die Befehlszeile im Flur nennt „nimm kreide“ nicht.")
    klick("Osten")
    zeile = [t for t in labeltexte() if t.startswith("Befehle:")]
    erwarte(zeile and "nimm stick" in zeile[0], "Nach Osten nennt die Befehlszeile „nimm stick“ nicht -- wird sie nach "
                                                "jedem Zug neu gesetzt?")


# ── Aufgabe 4 · Wie im Abitur: Der Knopf Essen ───────────────────────────

def pruefe_40_essen():
    """Aufgabe 4 · Ein Knopf Essen ruft iss mit dem, was im Feld steht"""
    braucht(knopf("Essen") is not None, "Noch kein Knopf Essen.")
    _neu()
    _g()["rucksack"].append("apfel")
    tippe("apfel")
    klick("Essen")
    erwarte("Knackig" in textflaeche(), "Nach apfel und Essen fehlt „Knackig. …“ -- ruft essen() iss mit dem Feld?")


def pruefe_41_zuege():
    """Aufgabe 4 ★★ · Die Züge stimmen: Apfel zwei mehr, Pausenbrot vier weniger"""
    braucht(knopf("Essen") is not None, "Noch kein Knopf Essen.")
    _neu()
    _g()["rucksack"].append("apfel")
    tippe("apfel")
    klick("Essen")
    z = _g().get("zuege")
    erwarte(z == 32, "Nach dem Apfel: erwartet 32 Züge (drei mehr, einer für das Essen), es sind %s." % z)
    erwarte("32 Züge" in _kopf(), "Die Kopfzeile zeigt nach dem Essen nicht den neuen Stand: „%s“." % _kopf())
    _g()["rucksack"].append("pausenbrot")
    tippe("pausenbrot")
    klick("Essen")
    z = _g().get("zuege")
    erwarte(z == 28, "Nach dem Pausenbrot: erwartet 28 Züge (drei weniger, einer für das Essen), es sind %s." % z)


def pruefe_42_leer():
    """Aufgabe 4 ★★★ · Ein leeres Feld kostet nichts, das Feld ist danach leer"""
    braucht(knopf("Essen") is not None and "essen willst" in ohne_kommentare(), "Noch keine Antwort auf ein leeres Feld.")
    _neu()
    tippe("")
    klick("Essen")
    erwarte("Tippe zuerst, was du essen willst." in textflaeche(), "Ein leeres Feld sagt nicht „Tippe zuerst, was du "
                                                                  "essen willst.“")
    erwarte(_g().get("zuege") == 30, "Ein leeres Feld kostet einen Zug -- es sollte keinen kosten.")
    _g()["rucksack"].append("apfel")
    tippe("apfel")
    klick("Essen")
    erwarte(elemente("Entry")[0].get() == "", "Nach Essen steht noch etwas im Feld.")


def pruefe_49_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht("global" in ohne_kommentare())
    ohne, falsch = [], []
    for k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, HINTS[k.name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 6 · Vorrat: Das Spielende ────────────────────────────────────

def pruefe_60_schluss():
    """Aufgabe 6 ★★ · Am Tor und nach ende steht der Schluss mit den Sternen"""
    braucht("Deine Sterne" in ohne_kommentare().split("def sterne")[-1], "Noch kein Schluss im Fenster.")
    _neu()
    _g()["rucksack"].append("torschlüssel")
    klick("Norden")
    erwarte("Du schließt das Tor auf" in textflaeche() and "Deine Sterne:" in textflaeche(),
            "Mit dem Torschlüssel nach Norden: Der Schluss mit „Deine Sterne:“ fehlt.")
    if knopf("Los") is not None:
        _neu()
        tippe("ende")
        klick("Los")
        erwarte("wartest auf den Morgen" in textflaeche() and "Deine Sterne:" in textflaeche(),
                "Nach ende fehlt der Schluss mit „Deine Sterne:“.")


def pruefe_61_gesperrt():
    """Aufgabe 6 ★★★ · Nach dem Schluss sind Knöpfe und Feld gesperrt"""
    braucht("disabled" in ohne_kommentare(), "Noch nichts gesperrt.")
    _neu()
    _g()["rucksack"].append("torschlüssel")
    klick("Norden")
    offen = [b.cget("text") for b in elemente("Button") if str(b.cget("state")) != "disabled"]
    erwarte(not offen, "Nach dem Schluss nehmen diese Knöpfe noch etwas an: %s." % ", ".join(offen))
    erwarte(all(str(e.cget("state")) == "disabled" for e in elemente("Entry")), "Nach dem Schluss nimmt das Feld noch "
                                                                                "etwas an.")


# ── Aufgabe 8 · Kuer: Enter statt Los ────────────────────────────────────

def pruefe_70_enter():
    """Aufgabe 8 ★★★★ · Enter im Feld wirkt wie Los"""
    m = re.search(r"\.bind\(\s*[\"']<Return>[\"']\s*,\s*(\w+)\s*\)", ohne_kommentare())
    braucht(m is not None, "Noch kein bind für Enter.")
    f = funktion(m.group(1))
    erwarte(f is not None, "bind ruft „%s“ -- diese Funktion gibt es nicht." % m.group(1))
    _neu()
    tippe("schau")
    try:
        f(object())
    except TypeError:
        erwarte(False, "„%s“ nimmt das Ereignis nicht an, das bind mitgibt -- beim Enter bricht es ab." % m.group(1))
    erwarte("Der Flur." in textflaeche(), "Nach schau und Enter zeigt die Textfläche den Flur nicht.")
