import tkinter as tk


def los() -> None:
    eingabe = feld.get().lower().strip()
    if eingabe == "":
        anzeige.config(text="Tippe zuerst einen Befehl.")
    else:
        anzeige.config(text="Befehl: " + eingabe)


fenster = tk.Tk()
fenster.title("Die Schule bei Nacht")
fenster.option_add("*Font", "Arial 30")
anzeige = tk.Label(fenster, text="Du stehst im Flur.")
anzeige.grid(row=0, column=0, columnspan=3)
knopf_norden = tk.Button(fenster, text="Norden")
knopf_norden.grid(row=1, column=1)
knopf_westen = tk.Button(fenster, text="Westen")
knopf_westen.grid(row=2, column=0)
knopf_osten = tk.Button(fenster, text="Osten")
knopf_osten.grid(row=2, column=2)
knopf_sueden = tk.Button(fenster, text="Süden")
knopf_sueden.grid(row=3, column=1)
feld = tk.Entry(fenster, width=16)
feld.grid(row=4, column=0, columnspan=2)
knopf_los = tk.Button(fenster, text="Los", command=los)
knopf_los.grid(row=4, column=2)
fenster.mainloop()
