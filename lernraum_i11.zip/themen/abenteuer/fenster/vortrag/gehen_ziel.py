import tkinter as tk

raum = "flur"


def ziel(raum: str, richtung: str) -> str:
    if raum == "flur" and richtung == "norden":
        return "lehrerzimmer"
    if raum == "lehrerzimmer" and richtung == "süden":
        return "flur"
    return raum


def norden() -> None:
    global raum
    raum = ziel(raum, "norden")
    anzeige.config(text="Du bist hier: " + raum)


def sueden() -> None:
    global raum
    raum = ziel(raum, "süden")
    anzeige.config(text="Du bist hier: " + raum)


fenster = tk.Tk()
fenster.title("Die Schule bei Nacht")
fenster.option_add("*Font", "Arial 60")
anzeige = tk.Label(fenster, text="Du bist hier: flur")
anzeige.pack()
knopf_norden = tk.Button(fenster, text="Norden", command=norden)
knopf_norden.pack()
knopf_sueden = tk.Button(fenster, text="Süden", command=sueden)
knopf_sueden.pack()
fenster.mainloop()
