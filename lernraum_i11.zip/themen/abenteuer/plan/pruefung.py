"""Selbstcheck zu "Struktogramme" -- prueft plan.py (Aufgabe 2, unter Mehr die Aufgaben 9 und 10).

Spielt das Programm mit EINEM Befehl an und setzt vorher oben andere Startwerte
(Raum, Taschen) -- so, wie die Aufgaben es der Klasse vorschlagen ("ohne Lampe
probiert ihr, indem ihr oben eine Tasche leert"). Geprueft wird, was in der
Shell steht, nicht der Wortlaut des Codes. Verraet keine Verzweigung, nur woran
es haengt -- und bewertet nichts.

Aufgabe 10 (Expertenaufgabe, Lauf i11): Die Auflage "hoechstens zwei Fragen an zuege" wird am Verhalten
gemessen -- oben steht dann eine Zahl, die jeden Vergleich mitschreibt (wie in "Die for-Schleife", Aufgabe 10).
"""
import re

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen

TITEL = "Struktogramme · Selbstcheck"

# Gross und mit Rand -- das Spiel raeumt den Befehl zuerst auf (Thema Eingabe und Text)
EINGABEN = ["  Schau "]

_FEHLT = object()
# je Raum ein Wort, das in seinem Satz steht (nicht der ganze Satz: Tippfehler
# im Satz sind kein Fehler im Plan)
RAEUME = (("flur", "Flur"), ("informatikraum", "Rechner"), ("lehrerzimmer", "Kaffee"),
          ("keller", "Keller"), ("tor", "Haupttor"))


def _code():
    """Der Code ohne Kommentare und ohne Text in Anfuehrungszeichen."""
    return re.sub(r'"[^"]*"|\'[^\']*\'', '""', ohne_kommentare())


def _zug(befehl, **start):
    """Ein Zug mit diesem Befehl, oben vorher andere Startwerte.
    Gibt zurueck, was nach dem Befehl in der Shell steht."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q
    try:
        aus, _ = anspielen([befehl])
    finally:
        pruefen._QUELLE = alt
    marke = befehl + "\n"
    return aus[aus.find(marke) + len(marke):] if marke in aus else aus


def _hat_schau():
    """Kennt das Spiel schau schon? Die Startdatei antwortet: Das verstehe ich nicht."""
    return "verstehe" not in _zug("schau")


def _dunkel(text):
    return "stockdunkel" in text.lower()


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_gehen():
    """Grundlage · Das Spiel geht noch wie in „Verzweigung mit if“"""
    alt = pruefen._QUELLE
    pruefen._QUELLE = re.sub(r"^raum[ \t]*=.*$", 'raum = "flur"', alt, count=1, flags=re.M)
    try:
        _, ns = anspielen(["osten"])
    finally:
        pruefen._QUELLE = alt
    wo = ns.get("raum", _FEHLT)
    erwarte(wo == "informatikraum",
            "Vom Flur nach osten steht ihr nicht mehr im Informatikraum -- ist beim Einfügen "
            "etwas vom Gehen verrutscht?")


# ── Aufgabe 2 · ein Blick im Dunkeln ─────────────────────────────────────

def pruefe_20_schau_raeume():
    """Aufgabe 2 · schau beschreibt jeden Raum"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den
    # naechsten Schritt (Reihensichtung Teil I, 25.10.: vorher zeigte der Start keinen).
    erwarte(_hat_schau(),
            "Bei schau sagt das Spiel noch „Das verstehe ich nicht.“ -- mit Lampe soll schau "
            "beschreiben, wo ihr steht.")
    falsch = [(raum, wort) for raum, wort in RAEUME if wort.lower() not in _zug("schau", raum=raum).lower()]
    raum, wort = falsch[0] if falsch else ("", "")
    erwarte(not falsch,
            "Im Raum %s sagt schau nicht, wo ihr seid (erwartet ist der Satz mit „%s“)." % (raum, wort))


def pruefe_21_schau_dunkel():
    """Aufgabe 2 · Ohne Lampe ist es stockdunkel"""
    braucht(_hat_schau())
    ohne = _zug("schau", raum="keller", gegenstand1="")
    erwarte(_dunkel(ohne),
            "Ohne Lampe in einer Tasche (oben gegenstand1 = \"\") zeigt schau im Keller etwas anderes "
            "als Stockdunkel.")
    erwarte("Keller" not in ohne,
            "Ohne Lampe ist es stockdunkel -- und trotzdem beschreibt schau den Keller. Steht der Satz "
            "im richtigen Zweig?")
    mit = _zug("schau", raum="keller")
    erwarte(not _dunkel(mit), "Mit der Lampe in Tasche 1 ist es bei schau stockdunkel.")


def pruefe_22_lampe_tasche():
    """Aufgabe 2 · Die Lampe darf in jeder Tasche sein"""
    braucht(_hat_schau() and _dunkel(_zug("schau", raum="keller", gegenstand1="")))
    dunkel_bei = [k for k in (2, 3)
                  if _dunkel(_zug("schau", raum="keller", gegenstand1="", **{"gegenstand%d" % k: "lampe"}))]
    erste = dunkel_bei[0] if dunkel_bei else 0
    erwarte(not dunkel_bei,
            "Liegt die Lampe in Tasche %d, ist es bei schau stockdunkel. Fragt die Bedingung alle "
            "drei Taschen?" % erste)


def pruefe_23_hilfe():
    """Aufgabe 2 ★★ · hilfe zeigt die Befehle"""
    braucht(re.search(r"\bhilfe\b", pruefen._QUELLE) is not None and "Befehle" in pruefen._QUELLE)
    aus = _zug("hilfe")
    fehlt = [w for w in ("norden", "nimm", "schau", "hilfe", "ende") if w not in aus]
    erster = fehlt[0] if fehlt else ""
    erwarte(not fehlt, "Bei hilfe fehlt in der Shell der Befehl: %s." % erster)


def pruefe_24_unsinn():
    """Aufgabe 2 ★★ · Bei Unsinn ein Hinweis auf hilfe"""
    braucht("Befehle" in pruefen._QUELLE)
    aus = _zug("tanze")
    erwarte("hilfe" in aus.lower(),
            "Bei tanze sagt das Spiel nicht, dass es hilfe gibt (Das verstehe ich nicht. Tippe hilfe.).")


# ── Aufgabe 9 · Mehr: der Keller verrät etwas ────────────────────────────

def pruefe_90_schluessel():
    """Aufgabe 9 ★★★★ · Der Torschlüssel glänzt -- nur, solange keine Tasche ihn trägt"""
    braucht("glänzt" in pruefen._QUELLE and _hat_schau())
    # Ist schau im Keller trotz Lampe dunkel, haengt es an Aufgabe 2 -- dort wird es rot, nicht hier
    braucht(not _dunkel(_zug("schau", raum="keller")))
    erwarte("orschlüssel" in _zug("schau", raum="keller"),
            "Im Keller mit Lampe und ohne Torschlüssel in den Taschen glänzt nichts.")
    getragen = [k for k in (1, 2, 3)
                if "glänzt" in _zug("schau", raum="keller",
                                     **dict({"gegenstand%d" % k: "torschlüssel"},
                                            **({"gegenstand2": "lampe"} if k == 1 else {})))]
    erste = getragen[0] if getragen else 0
    erwarte(not getragen,
            "Liegt der Torschlüssel in Tasche %d, glänzt er im Keller trotzdem noch." % erste)
    erwarte("glänzt" not in _zug("schau", raum="flur"), "Im Flur glänzt ein Torschlüssel -- er liegt im Keller.")
    dunkel = _zug("schau", raum="keller", gegenstand1="")
    erwarte("glänzt" not in dunkel, "Ohne Lampe glänzt der Torschlüssel im Keller -- im Dunkeln sieht man nichts.")


# ── Aufgabe 10 ★★★★ · Mehr: die Akku-Anzeige mit hoechstens zwei Fragen ───

# Eine Zahl, die jeden Vergleich mitschreibt: Unterklasse von int, deshalb rechnet und druckt sie wie eine Zahl
# (str(zuege) im Anfang des Spiels geht weiter). Auch 10 <= zuege zaehlt -- Python fragt bei einer Unterklasse
# rechts zuerst deren Methode.
ZAEHLER = """class _Z(int):
    n = 0
    def __lt__(a, b):
        _Z.n += 1
        return int(a) < int(b)
    def __gt__(a, b):
        _Z.n += 1
        return int(a) > int(b)
    def __le__(a, b):
        _Z.n += 1
        return int(a) <= int(b)
    def __ge__(a, b):
        _Z.n += 1
        return int(a) >= int(b)
    def __eq__(a, b):
        _Z.n += 1
        return int(a) == int(b)
    def __ne__(a, b):
        _Z.n += 1
        return int(a) != int(b)
    __hash__ = int.__hash__
"""
ZAEHLEN = "§VERGLEICHE§"
# jede Grenze von beiden Seiten, dazu ein Wert aus der Mitte jeder Stufe
AKKU = ((0, "leer"), (1, "fast leer"), (5, "fast leer"), (9, "fast leer"), (10, "halb"), (12, "halb"),
        (19, "halb"), (20, "voll"), (25, "voll"), (30, "voll"))


def _kennt_akku():
    """Steht der Befehl akku als Text im Code? (Das Wort Akku im Anfang des Spiels zaehlt nicht.)"""
    return re.search(r'["\']akku["\']', ohne_kommentare()) is not None


def _akku(wert):
    """akku mit oben zuege = wert. Gibt (was nach dem Befehl in der Shell steht, Zahl der Vergleiche mit zuege);
    die Zahl ist None, wenn das Programm vorher abbricht."""
    alt = pruefen._QUELLE
    q = re.sub(r"^zuege[ \t]*=.*$", "zuege = _Z(%d)" % wert, alt, count=1, flags=re.M)
    pruefen._QUELLE = ZAEHLER + q + "\nprint(%r, _Z.n)\n" % ZAEHLEN
    try:
        aus, _ = anspielen(["akku"])
    finally:
        pruefen._QUELLE = alt
    marke = "akku\n"
    nach = aus[aus.find(marke) + len(marke):] if marke in aus else aus
    m = re.search(r"%s\s+(\d+)" % re.escape(ZAEHLEN), nach)
    if m:
        nach = nach[:m.start()]
    return nach, (int(m.group(1)) if m else None)


def _akku_stimmt(wert, stufe):
    nach, _ = _akku(wert)
    return re.search(r"Akku:\s*%s\s*$" % re.escape(stufe), nach.strip()) is not None


def pruefe_a0_akku():
    """Aufgabe 10 ★★★★ · akku zeigt die richtige Stufe -- auch genau an den Grenzen"""
    braucht(_kennt_akku())
    falsch = [(wert, stufe) for wert, stufe in AKKU if not _akku_stimmt(wert, stufe)]
    wert, stufe = falsch[0] if falsch else (0, "")
    erwarte(not falsch,
            "Mit oben zuege = %d ist die Antwort auf akku nicht genau die Zeile „Akku: %s“." % (wert, stufe))


def pruefe_a1_fragen():
    """Aufgabe 10 ★★★★ · … mit höchstens zwei Fragen an zuege"""
    braucht(_kennt_akku())
    braucht(all(_akku_stimmt(wert, stufe) for wert, stufe in AKKU))
    zahlen = [(wert, _akku(wert)[1]) for wert, _ in AKKU]
    zu_viel = [(wert, n) for wert, n in zahlen if n is None or n > 2]
    wert, n = zu_viel[0] if zu_viel else (0, 0)
    erwarte(not zu_viel,
            "Mit oben zuege = %d stellt das Spiel %s Fragen an zuege, bevor es antwortet -- erlaubt sind "
            "höchstens 2." % (wert, "?" if n is None else n))
