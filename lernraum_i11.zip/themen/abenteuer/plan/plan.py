# Die Schule bei Nacht -- euer Spiel.
# Daran arbeitet ihr in diesem Thema.
#
# Das Spiel entscheidet schon: vier Räume,
# ein Tor mit Schlüssel, drei Taschen.
# Neu kommen schau und hilfe dazu --
# erst als Plan, dann als Code.
# Aufgabe 2 sagt, wie.

raum = "flur"
zuege = 30
punkte = 0

gegenstand1 = "lampe"
gegenstand2 = ""
gegenstand3 = ""

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im", raum + ". Nur deine Lampe leuchtet.")
print("Punkte:", punkte)

eingabe = input("> ").lower().strip()

if eingabe == "norden" or eingabe == "osten" or eingabe == "süden" or eingabe == "westen":
    richtung = eingabe
    if raum == "flur":
        if richtung == "norden":
            if gegenstand1 == "torschlüssel" or gegenstand2 == "torschlüssel" or gegenstand3 == "torschlüssel":
                raum = "tor"
                print("Du schließt das Tor auf.")
            else:
                print("Abgeschlossen. Du rüttelst an der Tür. Die Tür rüttelt nicht zurück.")
        elif richtung == "osten":
            raum = "informatikraum"
        elif richtung == "süden":
            raum = "lehrerzimmer"
        elif richtung == "westen":
            raum = "keller"
    elif raum == "informatikraum":
        if richtung == "westen":
            raum = "flur"
        else:
            print("Da ist eine Wand. Eine sehr solide Wand.")
    elif raum == "lehrerzimmer":
        if richtung == "norden":
            raum = "flur"
        else:
            print("Da ist eine Wand. Eine sehr solide Wand.")
    elif raum == "keller":
        if richtung == "osten":
            raum = "flur"
        else:
            print("Da ist eine Wand. Eine sehr solide Wand.")
    print("Du stehst jetzt im", raum + ".")
elif eingabe.startswith("nimm "):
    ding = eingabe.replace("nimm ", "")
    if ding == "torschlüssel" and raum != "keller":
        print("Hier liegt kein Torschlüssel.")
    elif gegenstand1 == "":
        gegenstand1 = ding
        print("Du nimmst:", ding)
    elif gegenstand2 == "":
        gegenstand2 = ding
        print("Du nimmst:", ding)
    elif gegenstand3 == "":
        gegenstand3 = ding
        print("Du nimmst:", ding)
    else:
        print("Kein Platz mehr.")
elif eingabe.startswith("lege "):
    ding = eingabe.replace("lege ", "")
    if gegenstand1 == ding:
        gegenstand1 = ""
        print("Du legst weg:", ding)
    elif gegenstand2 == ding:
        gegenstand2 = ""
        print("Du legst weg:", ding)
    elif gegenstand3 == ding:
        gegenstand3 = ""
        print("Du legst weg:", ding)
    else:
        print("Das hast du nicht.")
elif eingabe == "zeige":
    print("Du trägst:", gegenstand1, gegenstand2, gegenstand3)
else:
    print("Das verstehe ich nicht.")
