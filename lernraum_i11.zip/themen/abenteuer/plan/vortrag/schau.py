# schau -- erst der Plan, dann der Code.
raum = "keller"
gegenstand1 = "lampe"
gegenstand2 = ""
gegenstand3 = ""

eingabe = "schau"
