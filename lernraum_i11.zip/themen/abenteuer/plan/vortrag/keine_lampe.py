# Andersherum gefragt: wenn KEINE Tasche die Lampe hat.
raum = "keller"
gegenstand1 = "lampe"
gegenstand2 = ""
gegenstand3 = ""

if gegenstand1 == "lampe" or gegenstand2 == "lampe" or gegenstand3 == "lampe":
    print("Der Keller.")
else:
    print("Stockdunkel.")
