# Ausschnitt aus eurem Spiel: die drei Taschen
# (aus "Das Spiel entscheidet").
gegenstand1 = "lampe"
gegenstand2 = "stick"
gegenstand3 = ""
eingabe = "nimm seil"

ding = eingabe.replace("nimm ", "")
if gegenstand1 == "":
    gegenstand1 = ding
elif gegenstand2 == "":
    gegenstand2 = ding
elif gegenstand3 == "":
    gegenstand3 = ding
else:
    print("Kein Platz mehr.")
print("Taschen:", gegenstand1, gegenstand2, gegenstand3)
