# schau -- erst der Plan, dann der Code.
raum = "keller"
gegenstand1 = "lampe"
gegenstand2 = ""
gegenstand3 = ""

eingabe = "schau"

if eingabe == "schau":
    if gegenstand1 == "lampe" or gegenstand2 == "lampe" or gegenstand3 == "lampe":
        if raum == "flur":
            print("Der Flur.")
        elif raum == "informatikraum":
            print("Der Informatikraum.")
        elif raum == "lehrerzimmer":
            print("Das Lehrerzimmer.")
        elif raum == "keller":
            print("Der Keller.")
        else:
            print("Das Haupttor.")
    else:
        print("Stockdunkel.")
