# Andersherum gefragt: wenn KEINE Tasche die Lampe hat.
raum = "keller"
gegenstand1 = "lampe"
gegenstand2 = ""
gegenstand3 = ""

# ConcepTest, so zuerst getippt:
# if gegenstand1 != "lampe" or gegenstand2 != "lampe" or gegenstand3 != "lampe":
if gegenstand1 != "lampe" and gegenstand2 != "lampe" and gegenstand3 != "lampe":
    print("Stockdunkel.")
else:
    print("Der Keller.")
