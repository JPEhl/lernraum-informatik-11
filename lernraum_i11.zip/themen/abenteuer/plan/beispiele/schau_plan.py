raum = "keller"
gegenstand1 = "lampe"
gegenstand2 = ""
gegenstand3 = ""
if gegenstand1 == "lampe" or gegenstand2 == "lampe" or gegenstand3 == "lampe":
    if raum == "flur":
        print("Der Flur.")
    elif raum == "keller":
        print("Der Keller.")
    else:
        print("Ein anderer Raum.")
else:
    print("Stockdunkel.")
