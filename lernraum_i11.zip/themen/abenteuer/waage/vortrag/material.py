# Material 2: die Waage. gewicht(ding) ist gegeben --
# wie wert(ding) im Spiel.

def gewicht(ding: str) -> int:
    """Wie viele Kilogramm ein Ding wiegt."""
    if ding == "seil":
        return 4
    elif ding == "torschlüssel":
        return 3
    elif ding == "lampe" or ding == "pausenbrot":
        return 2
    else:
        return 1


print(gewicht("seil"))
print(gewicht("kreide"))
