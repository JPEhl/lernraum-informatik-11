"""Selbstcheck zu "Der Morgen kommt" -- prueft waage.py (Aufgabe 3, 4, Vorrat 8, Kuer 9).

Das Spiel im Fenster mit Karte und Waage. Der Check oeffnet kein Fenster: pruefen.py baut es unsichtbar, klickt ueber
die Beschriftung und liest Textflaeche, Labels und Zeichenflaeche. schwerstes und last ruft er mit eigenen Listen,
nimm spielt er am Fenster an (tippen, Los).

Alle Pruefungen teilen ein Fenster; _neu() setzt vor jeder den Spielstand zurueck (wie in "Wo bin ich eigentlich?") und
den Zufall fest auf „nie“. Die Kuer (der Rucksack legt selbst ab) ersetzt die Meldung „Zu schwer“ der Pflicht -- die
Pruefung von Aufgabe 4 ★★ laesst darum beides gelten, solange danach hoechstens 10 kg im Rucksack sind.
"""
import ast
import random

from pruefen import erwarte, braucht, funktion, fenster, elemente, knopf, klick, tippe, textflaeche, labeltexte, \
    rechtecke, flaechentexte, ist_rot, ohne_kommentare, quelltext

TITEL = "Der Morgen kommt · Selbstcheck"

# Was jede Funktion zurueckgibt -- der Hinweis prueft auch, ob der Type Hint stimmt (wie in zusammen;
# Reihensichtung Teil III, 27.10., Befund 7).
HINTS = {"beschreibung": "str", "ziel": "str", "ausgaenge": "list[str]", "tuer_offen": "bool",
         "dinge_im": "list[str]", "wert": "int", "gewicht": "int", "last": "int", "schwerstes": "str",
         "erzaehle": "None", "aufzaehlen": "str", "zeige_raum": "None", "zeige_rucksack": "None", "befehle": "str",
         "hilfe": "None", "gehe": "str", "nimm": "int", "lege": "None", "kater": "None", "benutze": "int",
         "iss": "int", "sterne": "str", "zeichne_raum": "None", "zeichne_karte": "None", "zeige_stand": "None",
         "schritt": "None", "norden": "None", "osten": "None", "sueden": "None", "westen": "None", "los": "None",
         "nach_dem_zug": "None", "schluss": "None"}

RAEUME = ["tor", "keller", "flur", "informatikraum", "hausmeisterraum", "bibliothek", "lehrerzimmer"]
GEWICHT = {"seil": 4, "torschlüssel": 3, "lampe": 2, "pausenbrot": 2}
# genau 10 kg: Lampe 2, Seil 4, Apfel 1, dreimal Kreide 1 -- der Probierweg aus Aufgabe 4
ZEHN = ["Süden", "nimm seil", "nimm apfel", "nimm kreide", "Norden", "nimm kreide", "Osten", "nimm kreide"]
_ANFANG = {}


def _kg(liste):
    summe = 0
    for ding in liste:
        summe = summe + GEWICHT.get(ding, 1)
    return summe


def _g():
    """Die Kaestchen oben in waage.py -- dort, wo die Knopf-Funktionen sie lesen und aendern."""
    f = funktion("gehe") or funktion("zeige_stand")
    return f.__globals__ if f is not None else {}


def _neu():
    g = _g()
    if not _ANFANG:
        for name, wert in g.items():
            if name.startswith("dinge_") and isinstance(wert, list):
                _ANFANG[name] = list(wert)
    for name, wert in _ANFANG.items():
        g[name][:] = wert
    g["rucksack"][:] = ["lampe"]
    g.update(raum="flur", zuege=30, punkte=0, sekunden=0, ruhe=0)
    for w in elemente("Button") + elemente("Entry"):
        w.config(state="normal")
    for w in elemente("Text"):
        w.delete("1.0", "end")
    if elemente("Entry"):
        tippe("")
    random.randint = lambda a, b: b
    random.choice = lambda liste: liste[-1]


def _spiele(zuege):
    """Knoepfe klicken oder Befehle ins Feld tippen und Los -- wie die Klasse."""
    for z in zuege:
        if z.startswith("nimm "):
            tippe(z)
            klick("Los")
        else:
            klick(z)


def _rufen(name, liste):
    """Ruft name(liste) mit einer Kopie; bei einem Abbruch (None, Meldung)."""
    try:
        return funktion(name)(list(liste)), ""
    except Exception as e:
        return None, "%s(%s) bricht ab: %s: %s" % (name, liste, type(e).__name__, e)


def _balken():
    """Die Rechtecke auf der Flaeche, in denen kein Raumname steht."""
    namen = [(x, y) for t, x, y in flaechentexte() if t in RAEUME]
    return [r for r in rechtecke() if not any(r[0] <= x <= r[2] and r[1] <= y <= r[3] for x, y in namen)]


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [k for k in ast.walk(baum) if isinstance(k, ast.FunctionDef)]


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_fenster():
    """Grundlage · Das Spiel steht im Fenster, die Waage gewicht ist da"""
    erwarte(fenster() is not None, "Das Programm baut kein Fenster -- steht fenster = tk.Tk() noch da?")
    fehlt = [r for r in ("Norden", "Osten", "Süden", "Westen", "Los") if knopf(r) is None]
    erwarte(not fehlt, "Diese Knöpfe fehlen: %s." % ", ".join(fehlt))
    erwarte(funktion("gewicht") is not None, "Die Funktion gewicht (Material 2) fehlt -- sie stand oben in waage.py.")


# ── Aufgabe 3 · Wie im Abitur: Das schwerste Ding ────────────────────────

def pruefe_30_schwerstes():
    """Aufgabe 3 · schwerstes gibt das schwerste Ding zurück, leer den leeren Text, bei Gleichstand das erste"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil III, 27.10., Befund 1: vorher „x von x passen“ ohne naechsten Schritt).
    erwarte(funktion("schwerstes") is not None, "Noch gibt es keine Funktion schwerstes -- erst das Struktogramm auf Papier, dann Python.")
    for liste, soll in ((["kreide", "seil", "lampe"], "seil"), (["lampe", "apfel", "torschlüssel"], "torschlüssel"),
                        (["torschlüssel"], "torschlüssel")):
        ist, fehler = _rufen("schwerstes", liste)
        erwarte(not fehler, fehler)
        erwarte(not isinstance(ist, int), "schwerstes(%s) gibt %r zurück -- das Gewicht statt des Dings?" % (liste, ist))
        erwarte(ist == soll, "schwerstes(%s) gibt %r zurück -- erwartet: %r." % (liste, ist, soll))
    ist, fehler = _rufen("schwerstes", [])
    erwarte(not fehler, fehler + " -- was passiert mit einem leeren Rucksack?")
    erwarte(ist == "", "schwerstes([]) gibt %r zurück -- erwartet: den leeren Text \"\"." % (ist,))
    ist, fehler = _rufen("schwerstes", ["lampe", "pausenbrot", "kreide"])
    erwarte(not fehler, fehler)
    erwarte(ist == "lampe", "Lampe und Pausenbrot wiegen beide 2 kg: schwerstes gibt %r zurück -- erwartet: das erste, "
                            "\"lampe\". > oder >=?" % (ist,))


# ── Aufgabe 4 · Wie im Abitur: Der Rucksack reißt ────────────────────────

def pruefe_40_last():
    """Aufgabe 4 · last gibt zurück, was alles im Rucksack zusammen wiegt"""
    braucht(funktion("last") is not None, "Noch keine Funktion last.")
    for liste in (["lampe", "seil", "kreide"], [], ["seil", "seil"], ["torschlüssel", "apfel"]):
        ist, fehler = _rufen("last", liste)
        erwarte(not fehler, fehler)
        soll = _kg(liste)
        erwarte(ist == soll, "last(%s) gibt %r zurück -- erwartet: %d." % (liste, ist, soll))


def pruefe_41_zehn():
    """Aufgabe 4 ★★ · nimm nimmt bis höchstens 10 kg, sonst „Zu schwer. Am meisten wiegt: …“"""
    braucht("len(rucksack) >= 6" not in ohne_kommentare(), "nimm zählt noch sechs Dinge.")
    _neu()
    _spiele(ZEHN)
    trage = list(_g()["rucksack"])
    erwarte(trage.count("kreide") == 3, "Auf dem Weg zu genau 10 kg fehlt eine Kreide (Rucksack: %s) -- genau 10 kg "
                                        "darf noch hinein: höchstens heißt <=." % ", ".join(trage))
    for w in elemente("Text"):
        w.delete("1.0", "end")
    _spiele(["nimm stick"])
    trage = list(_g()["rucksack"])
    erwarte(_kg(trage) <= 10, "Nach nimm stick wiegt der Rucksack %d kg (%s) -- erwartet: höchstens 10."
            % (_kg(trage), ", ".join(trage)))
    if "stick" not in trage:
        text = textflaeche().lower()
        erwarte("zu schwer" in text and "seil" in text, "Der Stick bleibt liegen, aber das Spiel sagt nicht „Zu schwer. "
                                                         "Am meisten wiegt: Seil.“")


def pruefe_49_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(funktion("schwerstes") is not None)
    ohne, falsch = [], []
    for k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, HINTS[k.name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 8 · Vorrat: Die Waage im Fenster ─────────────────────────────

def pruefe_82_kopfzeile():
    """Aufgabe 8 ★★ · Die Kopfzeile zeigt, was der Rucksack wiegt"""
    braucht(any("von 10 kg" in t for t in labeltexte()) or "von 10 kg" in ohne_kommentare(),
            "Die Kopfzeile zeigt noch kein Gewicht.")
    _neu()
    _spiele(["Süden", "nimm seil"])
    erwarte(any("6 von 10 kg" in t for t in labeltexte()),
            "Mit Lampe und Seil steht in keiner Zeile „6 von 10 kg“ -- da stehen: %s" % " | ".join(labeltexte()[:2]))


def pruefe_83_balken():
    """Aufgabe 8 ★★★ · Unten ein Balken, so lang wie das Gewicht, rot ab 9 kg"""
    # zwei create_rectangle stehen schon in zeichne_raum -- ein drittes ist der Balken (die Flaeche allein zu lesen
    # hiesse: ein Balken, der vor dem Loeschen gezeichnet wird, waere „noch nicht dran“ statt ein Befund)
    braucht(ohne_kommentare().count("create_rectangle") >= 3, "Noch kein Balken.")
    _neu()
    _spiele(["Osten"])
    erwarte(_balken(), "Nach einem Zug liegt kein Balken auf der Fläche -- wird er nach dem Löschen gezeichnet?")
    b = _balken()[-1]
    zwei = b[2] - b[0]
    erwarte(not ist_rot(b[4]), "Bei 2 kg ist der Balken schon rot.")
    _g()["rucksack"][:] = ["lampe", "seil", "torschlüssel", "kreide"]
    _spiele(["Westen"])
    erwarte(_balken(), "Nach einem weiteren Zug ist der Balken weg -- wird er nach dem Löschen neu gezeichnet?")
    b = _balken()[-1]
    zehn = b[2] - b[0]
    erwarte(zwei > 0 and abs(zehn / zwei - 5) < 0.3, "Bei 2 kg ist der Balken %g breit, bei 10 kg %g -- erwartet: fünfmal "
                                                    "so breit." % (zwei, zehn))
    erwarte(ist_rot(b[4]), "Bei 10 kg ist der Balken nicht rot.")


# ── Aufgabe 9 · Kür: Der Rucksack entscheidet selbst ─────────────────────

def pruefe_94_ablegen():
    """Aufgabe 9 ★★★★ · Ist es zu schwer, legt das Spiel das Schwerste ab, bis das neue passt"""
    braucht("legst ab" in ohne_kommentare(), "Noch kein „Du legst ab“.")
    _neu()
    g = _g()
    g["rucksack"][:] = ["lampe", "seil", "torschlüssel", "kreide"]
    g["dinge_lehrerzimmer"][:] = ["apfel"]
    g["raum"] = "lehrerzimmer"
    _spiele(["nimm apfel"])
    trage = list(g["rucksack"])
    erwarte("apfel" in trage, "Mit 10 kg im Rucksack bleibt der Apfel liegen -- erwartet: erst ablegen, dann nehmen.")
    erwarte("seil" not in trage and "torschlüssel" in trage, "Abgelegt ist nicht (nur) das Seil -- im Rucksack: %s."
            % ", ".join(trage))
    erwarte("seil" in g["dinge_lehrerzimmer"], "Das Seil ist aus der Welt verschwunden -- es gehört in den Raum.")
    erwarte("legst ab: seil" in textflaeche().lower(), "Das Spiel sagt nicht „Du legst ab: Seil.“")
    # zweimal ablegen: Lampe und Pausenbrot wiegen je 2 kg, das Seil braucht 4 -- ein if legte nur eines ab
    _neu()
    g["rucksack"][:] = ["lampe", "pausenbrot"] + ["kreide"] * 6
    g["dinge_lehrerzimmer"][:] = ["seil"]
    g["raum"] = "lehrerzimmer"
    _spiele(["nimm seil"])
    trage = list(g["rucksack"])
    erwarte("seil" in trage and _kg(trage) <= 10, "Mit Lampe, Pausenbrot und sechs Kreiden (10 kg) und dann dem Seil: im "
                                                 "Rucksack %s, %d kg -- muss es mehr als einmal ablegen?"
            % (", ".join(trage), _kg(trage)))
    erwarte("lampe" in g["dinge_lehrerzimmer"] and "pausenbrot" in g["dinge_lehrerzimmer"],
            "Lampe und Pausenbrot liegen nicht beide im Raum -- abgelegt wird, bis es passt.")
