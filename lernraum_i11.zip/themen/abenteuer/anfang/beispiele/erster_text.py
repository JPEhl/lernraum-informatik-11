print("DIE SCHULE BEI NACHT")
print("Du stehst im Flur.")
print()
print("Nur deine Lampe", "leuchtet.")
