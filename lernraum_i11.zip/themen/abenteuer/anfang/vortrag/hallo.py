# Die ersten Zeilen des Spiels. Jede Zeile, die das Spiel sagen soll, ist ein print.
