# Die ersten Zeilen des Spiels. Jede Zeile, die das Spiel sagen soll, ist ein print.
print("DIE SCHULE BEI NACHT")
print("Du stehst im Flur.")
print("Nur deine Lampe leuchtet.")
# print(Flur) -- so sah der Fehler aus: ohne Anführungszeichen ist Flur ein Name, den Python nicht kennt.
