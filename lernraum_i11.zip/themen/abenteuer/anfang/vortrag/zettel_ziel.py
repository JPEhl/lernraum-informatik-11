# Das Verfahren für: nimm <ding>
# Ich bin das Programm. Ich tue genau, was hier steht -- nicht mehr.
#
# 1. Lies das Wort hinter nimm -- das ist das Ding.
# 2. Sieh nach, ob das Ding in diesem Raum liegt.
# 3. Wenn nicht: Sage "Hier gibt es kein ..." und hör auf.
# 4. Wenn der Rucksack schon sechs Dinge trägt: Sage "Dein Rucksack ist voll." und hör auf.
# 5. Sonst: Nimm das Ding aus dem Raum und leg es in den Rucksack.
# 6. Sage "Du nimmst:" und das Ding.
