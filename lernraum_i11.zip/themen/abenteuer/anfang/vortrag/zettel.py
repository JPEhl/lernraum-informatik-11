# Das Verfahren für: nimm <ding>
# Ich bin das Programm. Ich tue genau, was hier steht -- nicht mehr.
