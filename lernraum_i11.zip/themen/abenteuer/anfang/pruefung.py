"""Selbstcheck zu "Die Schule bei Nacht" -- prueft anfang.py (Aufgabe 4).

Das Programm braucht keine Eingaben; es wird einmal ausgeführt, dann wird
die Ausgabe angesehen. Der Check verrät keine Sätze, nur woran es hängt.

Die Pflicht (Aufgabe 4) liest nur den ANFANG der Ausgabe -- bis zur ersten
Zeile der Karte (Kür). Sonst deckten die print() und das [Flur] der Karte
einen Pflichtfehler zu (Reihensichtung Teil I, 25.10.: Giftproben „leere
Zeile fehlt“ und „Ortssatz fehlt“ blieben mit Kür grün).
"""
from pruefen import erwarte, braucht, quelltext, ohne_kommentare, ausgabe

TITEL = "Die Schule bei Nacht · Selbstcheck"
EINGABEN = []

RAEUME = ("Tor", "Bibliothek", "Lehrerzimmer", "Flur", "Informatikraum", "Keller", "Hausmeisterraum")


def _prints():
    return [z for z in ohne_kommentare().splitlines() if z.strip().startswith("print(")]


def _kartenzeile(z):
    """Gehört die Zeile zur Karte der Kür? Ein Raum in eckigen Klammern oder nur Wegzeichen."""
    return any("[" + r + "]" in z for r in RAEUME) or (z.strip() != "" and set(z.strip()) <= set("|-+ "))


def _anfang():
    """Die Zeilen der Ausgabe bis zur ersten Zeile der Karte, ohne Leerzeilen am Ende --
    das ist, was Aufgabe 4 erzählt."""
    zeilen = []
    for z in ausgabe().splitlines():
        if _kartenzeile(z):
            break
        zeilen.append(z)
    while zeilen and not zeilen[-1].strip():
        zeilen.pop()
    return zeilen


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


# ── Aufgabe 4 · die ersten Zeilen ─────────────────────────────────────────

def pruefe_30_ueberschrift():
    """Aufgabe 4 · Die Überschrift erscheint in der Shell"""
    erwarte(any("DIE SCHULE BEI NACHT" in z for z in _anfang()),
            "In der Shell steht keine Zeile DIE SCHULE BEI NACHT. Die erste "
            "Zeile des Programms zeigt die Überschrift an -- in Anführungszeichen.")


def pruefe_31_fuenf_zeilen():
    """Aufgabe 4 · Mindestens fünf Zeilen: Überschrift, zwei Sätze, leere Zeile, Ort"""
    braucht(any("DIE SCHULE BEI NACHT" in z for z in _anfang()))
    erwarte(len(_anfang()) >= 5,
            "Der Anfang hat erst %d Zeilen. Jede Zeile, die das Spiel anzeigen soll, ist ein "
            "eigener print-Befehl." % len(_anfang()))


def pruefe_32_leere_zeile():
    """Aufgabe 4 · Eine leere Zeile trennt Geschichte und Ort"""
    braucht(len(_anfang()) >= 3)
    erwarte(any(not z.strip() for z in _anfang()),
            "In der Shell erscheint keine leere Zeile. print() ohne Inhalt "
            "zeigt eine an.")


def pruefe_33_flur_und_lampe():
    """Aufgabe 4 · Der letzte Satz sagt, wo du stehst"""
    braucht(len(_anfang()) >= 3)
    aus = "\n".join(_anfang()).lower()
    erwarte("flur" in aus and "lampe" in aus,
            "Der Satz, wo die Spielerin steht, fehlt noch: Flur und Lampe "
            "kommen in der Shell nicht beide vor.")


def pruefe_34_alles_in_anfuehrungszeichen():
    """Aufgabe 4 · Jeder Text steht in Anführungszeichen"""
    braucht(len(_prints()) >= 1)
    ohne = [z for z in _prints() if z.strip() != "print()" and '"' not in z and "'" not in z]
    # Die Meldung wird VOR der Pruefung ausgewertet (LIESMICH) -- kein ohne[0] hinein,
    # wenn die Liste leer sein kann.
    erster = ohne[0].strip() if ohne else ""
    erwarte(not ohne,
            "Eine print-Zeile hat keine Anführungszeichen: %s -- Python hält "
            "den Text dann für einen Namen (NameError)." % erster)



# ── Aufgabe 7 · Kür: die Karte der Schule ────────────────────────────────


def _karte():
    """Wo jeder Raum in der Ausgabe steht: {Name: (Zeile, Spalte der Mitte)}."""
    orte = {}
    for nr, z in enumerate(ausgabe().splitlines()):
        for raum in RAEUME:
            i = z.find("[" + raum + "]")
            if i >= 0 and raum not in orte:
                orte[raum] = (nr, i + len(raum) / 2)
    return orte


def pruefe_70_karte():
    """Aufgabe 7 ★★★ · Die Karte: alle sieben Räume, jeder richtig zu seinen Nachbarn"""
    orte = _karte()
    braucht("[Flur]" in ausgabe() and len(orte) >= 3)
    fehlt = [r for r in RAEUME if r not in orte]
    erwarte(not fehlt, "Auf der Karte fehlt noch: %s -- in eckigen Klammern, so wie das Spiel "
            "den Raum nennt." % ", ".join(fehlt))
    # die Karte der Schule (Lehrer 22.10.): Keller im Westen, Lehrerzimmer im Süden, Bibliothek unter dem Keller,
    # Hausmeisterraum westlich daneben
    f, k, i, b = orte["Flur"], orte["Keller"], orte["Informatikraum"], orte["Bibliothek"]
    lagen = [("Tor", orte["Tor"][0] < f[0], "nördlich vom Flur (eine Zeile darüber)"),
             ("Keller", k[0] == f[0] and k[1] < f[1], "westlich vom Flur (links, in derselben Zeile)"),
             ("Lehrerzimmer", orte["Lehrerzimmer"][0] > f[0], "südlich vom Flur (darunter)"),
             ("Informatikraum", i[0] == f[0] and i[1] > f[1], "östlich vom Flur (rechts, in derselben Zeile)"),
             ("Bibliothek", b[0] > k[0], "südlich vom Keller (darunter)"),
             ("Hausmeisterraum", orte["Hausmeisterraum"][0] == b[0] and orte["Hausmeisterraum"][1] < b[1], "westlich von der Bibliothek")]
    falsch = [(r, wo) for r, ok, wo in lagen if not ok]
    erster = "%s liegt im Spiel %s" % falsch[0] if falsch else ""
    erwarte(not falsch, "Noch nicht ganz: %s." % erster)
