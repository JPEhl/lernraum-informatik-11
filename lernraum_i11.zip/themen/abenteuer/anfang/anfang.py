# Die Schule bei Nacht -- euer Spiel. Daran arbeitet ihr in diesem Thema.
#
# Noch ist die Datei leer. Aufgabe 4 sagt, was hier hinein soll:
# der Anfang des Spiels, Zeile für Zeile, jede ein print.
