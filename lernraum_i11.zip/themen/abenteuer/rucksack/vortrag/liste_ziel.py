# Ein Name für alle Dinge im Rucksack
rucksack = ["lampe", "karte", "seil", "kreide"]
print(rucksack)
print(rucksack[2])
print(rucksack[0])
print(len(rucksack))
# print(rucksack[4])  -- IndexError
print(rucksack[len(rucksack) - 1])
