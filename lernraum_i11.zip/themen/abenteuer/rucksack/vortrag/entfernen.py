# Verändern und nachsehen
rucksack = ["lampe", "karte", "seil"]
print(rucksack)
