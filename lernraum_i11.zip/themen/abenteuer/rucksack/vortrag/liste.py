# Ein Name für alle Dinge im Rucksack
