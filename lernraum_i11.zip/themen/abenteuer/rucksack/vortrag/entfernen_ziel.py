# Verändern und nachsehen
rucksack = ["lampe", "karte", "seil"]
rucksack.append("kreide")
print(rucksack)
rucksack.remove("lampe")
print(rucksack)
print(rucksack[0])
print("torschlüssel" in rucksack)
if "torschlüssel" in rucksack:
    print("Du schließt das Tor auf.")
else:
    print("Abgeschlossen.")
if "lampe" not in rucksack:
    print("Stockdunkel.")
# rucksack.remove("lampe")  -- ValueError
