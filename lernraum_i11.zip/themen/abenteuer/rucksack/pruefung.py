"""Selbstcheck zu "Der Rucksack" -- prueft rucksack.py (Aufgabe 2, 4 und Kuer 9).

Spielt das Spiel mit einer FOLGE von Befehlen an und setzt vorher oben einen anderen
Rucksack (rucksack = [...]) -- so sieht der Check, ob das Spiel wirklich die Liste
fragt und nicht noch die drei Taschen. Geprueft wird das Verhalten: Wer kommt durchs
Tor, was liegt nach lege noch im Rucksack, was sagt zeige, wann ist er voll? Nicht der
Wortlaut des Codes. Verraet keine Zeile, nur woran es haengt.

Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile, die der Check hinter den Code
haengt (SCHLUSS, wie in "Zuege und Punkte"): Fehlt sie, ist es unterwegs abgebrochen --
anspielen() schneidet die Fehlermeldung ab. Fragt das Spiel nach den Befehlen weiter,
endet die Ausgabe mit "> ".
"""
import re

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen

TITEL = "Der Rucksack · Selbstcheck"

# So spielt der Check das Programm an (wie in Aufgabe 2 ★): in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

DRAUSSEN = "kalt und wunderbar"
TREPPE = "wartest auf den Morgen"
VOLL = "Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht. Leg etwas ab."
SCHLUSS = "§SCHLUSS§"


def _spiel(befehle, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte (rucksack=[...]). Gibt
    (text, abbruch, ns): was nach dem Anfang in der Shell steht, ob das Programm unterwegs
    abgebrochen ist, und die Variablen, wie sie zuletzt standen."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q + "\nprint(%r)\n" % SCHLUSS
    try:
        aus, ns = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    abbruch = not fertig and not wartet
    marke = "leuchtet.\n"
    return (aus[aus.find(marke) + len(marke):] if marke in aus else aus), abbruch, ns


def _hat_liste():
    """Oben steht ein Rucksack als Liste (nicht eingerueckt)."""
    return re.search(r"^rucksack[ \t]*=[ \t]*\[", ohne_kommentare(), re.M) is not None


def _in_schleife():
    """Steht eine Liste rucksack = [...] eingerueckt -- in der Schleife faengt er jeden Zug von vorn an."""
    return re.search(r"^[ \t]+rucksack[ \t]*=[ \t]*\[", ohne_kommentare(), re.M) is not None


def _liste_ok():
    """Oben die Liste, und keine zweite in der Schleife -- erst dann sagen die anderen Pruefungen etwas."""
    return _hat_liste() and not _in_schleife()


def _taschen():
    """Steht im Code noch eine der drei Taschen?"""
    return re.search(r"\bgegenstand[123]\b", ohne_kommentare()) is not None


def _punkte_am_ende(aus):
    """Die Punkte aus der Zeile „Spielzeit: … - n Punkte“, sonst None."""
    m = re.search(r"Spielzeit:.*?(\d+)\s*Punkte", aus)
    return int(m.group(1)) if m else None


def _als_text(r):
    """Eine Liste so, wie sie oben im Code stuende: ["lampe", "karte"]."""
    return "[" + ", ".join('"%s"' % d for d in r) + "]"


def _zeige(aus):
    """Was zeige zuletzt gesagt hat: alles ab dem letzten „Du trägst“."""
    i = aus.rfind("Du trägst")
    return aus[i:] if i >= 0 else ""


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Züge und Punkte“ konnte"""
    aus, abbruch, _ = _spiel(["warte 2", "ende"])
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Spielzeit" in aus, "Am Ende steht keine Spielzeit mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 ★ · Liste, nimm und Tor ────────────────────────────────────

def pruefe_20_liste():
    """Aufgabe 2 · Oben steht der Rucksack als Liste, darin die Lampe"""
    erwarte(_hat_liste(), "Oben steht noch keine Liste rucksack = [...] -- und zwar ganz links, vor der Schleife.")
    erwarte(not _in_schleife(),
            "rucksack = [...] steht eingerückt, in der Schleife -- dann fängt der Rucksack in jedem Zug von vorn "
            "an. Er gehört nach oben, vor die Schleife.")
    _, _, ns = _spiel(["ende"])
    r = ns.get("rucksack")
    erwarte(isinstance(r, list) and "lampe" in r, "Am Anfang liegt keine Lampe im Rucksack.")


def pruefe_21_nimm():
    """Aufgabe 2 · nimm hängt an -- vier Dinge passen, jedes bringt 10 Punkte"""
    braucht(_liste_ok())
    aus, abbruch, ns = _spiel(["nimm karte", "nimm seil", "nimm kreide", "nimm heft", "ende"])
    erwarte("Kein Platz" not in aus, "Beim vierten Ding sagt das Spiel noch „Kein Platz mehr.“ -- fragt nimm noch die drei Taschen?")
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    erwarte("heft" in r and "karte" in r,
            "Nach nimm karte … nimm heft liegen Karte und Heft nicht im Rucksack. Hängt nimm das Ding an die Liste an?")
    punkte = _punkte_am_ende(aus)
    erwarte(not abbruch and punkte == 40,
            "Vier Dinge sind 40 Punkte -- in der Zeile mit der Spielzeit steht etwas anderes (oder sie fehlt).")


# Der Torschluessel auf wechselnden Plaetzen (Reihensichtung Teil II, #7): Lag er im Test immer auf
# Platz 1, bestand auch ein Tor, das nur rucksack[1] fragt. Vorn, hinten, in der Mitte -- je einmal.
MIT_SCHLUESSEL = [["lampe", "torschlüssel"], ["torschlüssel"], ["karte", "torschlüssel", "seil", "lampe"]]
OHNE_SCHLUESSEL = [["lampe"], ["karte", "seil", "lampe", "kreide"], []]


def pruefe_22_tor():
    """Aufgabe 2 · Das Tor fragt den Rucksack"""
    braucht(_liste_ok())
    for r in MIT_SCHLUESSEL:
        aus, _, _ = _spiel(["norden", "ende"], rucksack=r)
        erwarte(DRAUSSEN in aus,
                "Mit oben rucksack = %s geht das Tor nicht auf. Fragt das Tor den ganzen Rucksack -- egal, auf "
                "welchem Platz der Schlüssel liegt?" % _als_text(r))
    for r in OHNE_SCHLUESSEL:
        aus, _, _ = _spiel(["norden", "ende"], rucksack=r)
        erwarte(DRAUSSEN not in aus, "Mit oben rucksack = %s, ohne Torschlüssel, geht das Tor trotzdem auf." % _als_text(r))


def pruefe_23_keller():
    """Aufgabe 2 · Den Torschlüssel gibt es nur im Keller"""
    braucht(_liste_ok())
    aus, _, ns = _spiel(["nimm torschlüssel", "ende"])
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    erwarte("Hier liegt kein Torschlüssel" in aus and "torschlüssel" not in r,
            "Im Flur steckt nimm torschlüssel den Schlüssel trotzdem ein -- der Satz „Hier liegt kein Torschlüssel.“ gehört weiter davor.")


# ── Aufgabe 2 ★★ · lege und schau ───────────────────────────────────────

def pruefe_24_lege():
    """Aufgabe 2 ★★ · lege nimmt heraus -- aber nur, was da ist"""
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["lege karte", "lege karte", "ende"], rucksack=["lampe", "karte"])
    erwarte("Du legst weg: karte" in aus, "Mit oben rucksack = [\"lampe\", \"karte\"] legt lege karte die Karte nicht weg.")
    erwarte(not abbruch,
            "Beim zweiten lege karte bricht das Spiel ab. Was fragt ihr, bevor ihr remove schreibt?")
    erwarte("Das hast du nicht" in aus, "Beim zweiten lege karte fehlt „Das hast du nicht.“")


def pruefe_25_vergisst_nicht():
    """Aufgabe 2 ★★ · Der Rucksack vergisst nichts zwischen zwei Zügen"""
    braucht(_hat_liste())
    braucht("remove" in ohne_kommentare())
    aus, _, _ = _spiel(["nimm karte", "lege karte", "ende"])
    erwarte("Du legst weg: karte" in aus,
            "Erst nimm karte, dann lege karte -- und das Spiel sagt, ihr habt sie nicht. Fängt der Rucksack "
            "in jedem Durchlauf der Schleife von vorn an?")


def pruefe_26_schau():
    """Aufgabe 2 ★★ · schau fragt, ob die Lampe im Rucksack ist"""
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["schau", "ende"], rucksack=["karte"])
    erwarte(not abbruch, "Bei schau bricht das Spiel ab -- steht dort noch eine der drei Taschen?")
    erwarte("Stockdunkel" in aus, "Mit oben rucksack = [\"karte\"] (ohne Lampe) ist es bei schau nicht stockdunkel.")
    aus, _, _ = _spiel(["westen", "schau", "ende"], rucksack=["karte", "lampe"])
    erwarte("Der Keller" in aus, "Mit der Lampe im Rucksack beschreibt schau im Keller den Raum nicht.")


# ── Aufgabe 2 ★★★ · zeige ───────────────────────────────────────────────

def pruefe_27_zeige():
    """Aufgabe 2 ★★★ · zeige sagt Anzahl und Liste"""
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["zeige", "ende"], rucksack=["karte", "seil"])
    z = _zeige(aus)
    erwarte(not abbruch, "Bei zeige bricht das Spiel ab -- steht dort noch eine der drei Taschen?")
    erwarte(re.search(r"\b2 Dinge", z) is not None and "'karte', 'seil'" in z,
            "Mit oben rucksack = [\"karte\", \"seil\"] sagt zeige nicht „Du trägst 2 Dinge: ['karte', 'seil']“.")


def pruefe_28_zeige_leer():
    """Aufgabe 2 ★★★ · zeige stimmt auch beim leeren Rucksack"""
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["zeige", "ende"], rucksack=[])
    erwarte(not abbruch and re.search(r"\b0 Dinge", _zeige(aus)) is not None,
            "Mit oben rucksack = [] bricht zeige ab oder sagt nicht „0 Dinge“.")


def pruefe_29_keine_taschen():
    """Aufgabe 2 ★★★ · Die drei Taschen sind ganz weg"""
    braucht(_liste_ok())
    erwarte(not _taschen(), "Im Code steht noch gegenstand1, gegenstand2 oder gegenstand3 -- sucht mit Strg+F (Mac ⌘+F).")


# ── Aufgabe 4 · Wie im Abitur: Der volle Rucksack ────────────────────────

SECHS = ["nimm heft", "nimm buch", "nimm apfel", "nimm seil", "nimm kreide", "nimm stift"]


def pruefe_40_voll():
    """Aufgabe 4 · Mit sechs Dingen ist der Rucksack voll"""
    braucht(_liste_ok())
    aus, abbruch, ns = _spiel(SECHS + ["ende"])
    braucht(not abbruch)
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    erwarte(len(r) == 6,
            "Lampe und sechsmal nimm: Im Rucksack liegen %d Dinge, nicht sechs. Das sechste nimm muss liegen bleiben." % len(r))
    erwarte(VOLL in aus, "Beim siebten Ding sagt das Spiel nicht „%s“" % VOLL)
    erwarte(aus.count("Du nimmst:") == 5, "Ein Ding, das nicht mehr hineinpasst, wird trotzdem „genommen“.")


def pruefe_41_punkte():
    """Aufgabe 4 · Punkte nur für Dinge, die wirklich mitkommen"""
    braucht(_liste_ok())
    braucht(VOLL in ohne_kommentare())
    aus, _, _ = _spiel(SECHS + ["ende"])
    punkte = _punkte_am_ende(aus)
    erwarte(punkte == 50,
            "Fünf Dinge kommen in den Rucksack, das sind 50 Punkte -- am Ende stehen %s. Gibt es Punkte für das "
            "Ding, das liegen bleibt?" % punkte)


def pruefe_42_wieder_platz():
    """Aufgabe 4 · Wer etwas ablegt, hat wieder Platz"""
    braucht(_liste_ok())
    braucht(VOLL in ohne_kommentare())
    aus, abbruch, ns = _spiel(SECHS[:5] + ["lege heft", "nimm stift", "ende"])
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    erwarte(not abbruch and "stift" in r and VOLL not in aus,
            "Lampe und fünf Dinge, dann lege heft und nimm stift -- der Stift kommt nicht hinein. Steht die Grenze "
            "bei nimm und fragt sie, wie viele Dinge JETZT im Rucksack sind?")


# ── Aufgabe 9 · Kuer: Wirf! ──────────────────────────────────────────────

def pruefe_90_wirf():
    """Aufgabe 9 ★★★★ · wirf wirft das zuletzt genommene Ding weg"""
    braucht('"wirf' in ohne_kommentare() or "'wirf" in ohne_kommentare())
    braucht(_liste_ok())
    aus, abbruch, ns = _spiel(["nimm karte", "nimm seil", "wirf", "ende"])
    r = ns.get("rucksack") if isinstance(ns.get("rucksack"), list) else []
    nimm = "Du nimmst: seil"
    danach = aus[aus.rfind(nimm) + len(nimm):] if nimm in aus else ""
    erwarte(not abbruch, "Bei wirf bricht das Spiel ab.")
    erwarte("seil" not in r and "karte" in r,
            "Nach nimm karte, nimm seil, wirf liegt nicht genau das Seil weg -- das zuletzt genommene Ding.")
    erwarte("seil" in danach, "wirf sagt nicht, welches Ding es weggeworfen hat.")


def pruefe_91_wirf_leer():
    """Aufgabe 9 ★★★★ · wirf beim leeren Rucksack bricht nicht ab"""
    braucht('"wirf' in ohne_kommentare() or "'wirf" in ohne_kommentare())
    braucht(_liste_ok())
    aus, abbruch, _ = _spiel(["wirf", "ende"], rucksack=[])
    erwarte(not abbruch and TREPPE in aus,
            "Mit oben rucksack = [] bricht wirf ab -- was fragt ihr, bevor ihr etwas herausnehmt?")
    erwarte("nichts zum Werfen" in aus, "Beim leeren Rucksack fehlt „Du hast nichts zum Werfen.“")
