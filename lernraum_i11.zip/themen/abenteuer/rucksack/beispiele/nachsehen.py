rucksack = ["lampe", "karte", "seil"]
rucksack.append("kreide")
rucksack.remove("lampe")
print(rucksack)
print(rucksack[0])
if "torschlüssel" in rucksack:
    print("Du schließt das Tor auf.")
else:
    print("Abgeschlossen.")
