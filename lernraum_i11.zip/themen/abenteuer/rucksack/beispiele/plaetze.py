rucksack = ["lampe", "karte", "seil", "kreide"]
print(rucksack)
print(rucksack[2])
print(len(rucksack))
print(rucksack[len(rucksack) - 1])
