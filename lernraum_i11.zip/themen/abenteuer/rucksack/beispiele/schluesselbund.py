bund = ["tor", "keller", "turnhalle"]
abgeben = "keller"
if abgeben in bund:
    bund.remove(abgeben)
    print("Abgegeben:", abgeben)
else:
    print("Den hat er nicht.")
