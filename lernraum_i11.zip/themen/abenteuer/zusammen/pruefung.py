"""Selbstcheck zu "Die passende Struktur wählen" (Die ganze Schule) -- prueft zusammen.py
(Pflicht: Aufgabe 2 und 5; Mehr: Aufgabe 7, 8, 9 und 10).

Das Spiel wuerfelt seit "Zufall und Bibliotheken" (Sicherung, Kater). Der Check stellt den Zufall fest ein,
solange er anspielt (_zufall_fest: randint liefert immer b -- weder Sicherung noch Kater), wie in zufall/pruefung.py.

Die Pflicht (Aufgabe 2) laesst den Torschluessel im Keller und die Tuer offen; Aufgabe 7 (Mehr) schliesst sie und
legt ihn in den Hausmeisterraum. Darum fragt Aufgabe 2 die Funktionen selbst (ziel, beschreibung, dinge_im) und nimmt
im Spiel beides hin: den Hausmeisterraum oder "Abgeschlossen".

Nummern seit dem Umbau (Lauf i11, 17.11.2026): 4 -> 5 (tuer_offen), 6 -> 7, 7 -> 8, 8 -> 9; neu Aufgabe 10 ★★★★
(bester_wert, die Expertenaufgabe: am Verhalten geprueft, mit eigenen Listen).
"""
import ast
import io
import random
import re
import sys

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen, funktion, quelltext

TITEL = "Die passende Struktur wählen · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, nach Sueden -- ohne etwas zu nehmen (die Listen der Raeume
# sind danach die, die _rufen("dinge_im", …) sieht; ein "nimm karte" hier liess Aufgabe 2 ★★★ die Karte vermissen)
EINGABEN = ["westen", "süden", "zeige", "ende"]

TREPPE = "wartest auf den Morgen"
DRAUSSEN = "kalt und wunderbar"
ZU = "Abgeschlossen"
SCHLUSS = "§SCHLUSS§"
WEG = ["süden", "nimm seil", "norden", "westen", "benutze seil", "süden", "westen", "nimm torschlüssel",
       "osten", "norden", "osten", "norden"]

HINTS = {"hilfe": "None", "zeige_raum": "None", "zeige_rucksack": "None", "pruefe_tuer": "bool", "beschreibung": "str",
         "dinge_im": "list[str]", "sterne": "str", "aufzaehlen": "str", "ziel": "str", "gehe": "str", "kater": "None",
         "tuer_offen": "bool", "iss": "int", "ausgaenge": "list[str]", "befehle": "str", "wert": "int", "nimm": "int",
         "lege": "None", "benutze": "int", "bester_wert": "int"}

KEIN_WERT = object()


def _spiel(befehle):
    """Das Spiel mit diesen Befehlen, Zufall fest (keine Sicherung, kein Kater). Gibt (aus, abbruch)."""
    alt_q, alt_r = pruefen._QUELLE, (random.randint, random.choice)
    pruefen._QUELLE = alt_q + "\nprint(%r)\n" % SCHLUSS
    random.randint = lambda a, b: b
    try:
        aus, _ = anspielen(befehle)
    finally:
        random.randint, random.choice = alt_r
        pruefen._QUELLE = alt_q
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet)


def _nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _rufen(name, *argumente, **werte):
    """Die Funktion `name` mit diesen Argumenten rufen, vorher Variablen draussen setzen (rucksack=[…])."""
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    g = f.__globals__
    alt = {k: g.get(k, KEIN_WERT) for k in werte}
    g.update(werte)
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
        for k, v in alt.items():
            if v is KEIN_WERT:
                g.pop(k, None)
            else:
                g[k] = v
    return wert, puffer.getvalue(), fehler


def _ziel(raum, richtung):
    wert, _, fehler = _rufen("ziel", raum, richtung)
    return None if fehler else wert


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _dinge(raum):
    wert, _, fehler = _rufen("dinge_im", raum)
    return [] if fehler or not isinstance(wert, list) else list(wert)


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Zufall und Bibliotheken“ konnte"""
    aus, abbruch = _spiel(["warte 2", "ende"])
    erwarte(not (abbruch and "> " not in aus),
            "Das Spiel bricht schon vor der ersten Eingabe ab -- fehlt ein Komma in einer Liste, oder ein Raumname?")
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Deine Sterne" in aus, "Am Ende steht „Deine Sterne:“ nicht mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 · Zwei Räume mehr ─────────────────────────────────────────

def pruefe_20_bibliothek():
    """Aufgabe 2 · Die Bibliothek: vom Keller nach Süden und zurück"""
    # erwarte, nicht braucht: Im Startzustand steht genau diese erste Pflichtpruefung aus, mit dem naechsten Schritt
    # (Reihensichtung Teil II, Befund 6)
    erwarte(_ziel("keller", "süden") not in (None, ""),
            "Vom Keller nach Süden ist noch eine Wand. Die Bibliothek braucht einen Weg hinein -- in ziel.")
    erwarte(_ziel("keller", "süden") == "bibliothek",
            "ziel(\"keller\", \"süden\") liefert %r, nicht \"bibliothek\"." % (_ziel("keller", "süden"),))
    erwarte(_ziel("bibliothek", "norden") == "keller",
            "Von der Bibliothek nach Norden geht es nicht zurück in den Keller -- der Weg muss in beide Richtungen gehen.")
    wert, _, fehler = _rufen("beschreibung", "bibliothek")
    erwarte(fehler is None and isinstance(wert, str) and wert.startswith("Die Bibliothek."),
            "beschreibung(\"bibliothek\") beginnt nicht mit „Die Bibliothek.“")
    aus, abbruch = _spiel(["westen", "süden", "norden", "ende"])
    erwarte(not abbruch, "Auf dem Weg in die Bibliothek bricht das Spiel ab.")
    erwarte("Die Bibliothek." in _nach(aus, "süden"), "Nach westen und süden steht nicht „Die Bibliothek. …“.")
    erwarte("Der Keller." in _nach(aus, "norden"), "Von der Bibliothek nach norden kommt ihr nicht in den Keller.")


def pruefe_21_hausmeisterraum():
    """Aufgabe 2 ★★ · Der Hausmeisterraum: von der Bibliothek nach Westen und zurück"""
    braucht(_ziel("bibliothek", "westen") not in (None, ""))
    erwarte(_ziel("bibliothek", "westen") == "hausmeisterraum",
            "ziel(\"bibliothek\", \"westen\") liefert %r, nicht \"hausmeisterraum\"." % (_ziel("bibliothek", "westen"),))
    erwarte(_ziel("hausmeisterraum", "osten") == "bibliothek", "Vom Hausmeisterraum nach Osten geht es nicht zurück.")
    wert, _, fehler = _rufen("beschreibung", "hausmeisterraum")
    erwarte(fehler is None and isinstance(wert, str) and wert.startswith("Der Hausmeisterraum."),
            "beschreibung(\"hausmeisterraum\") beginnt nicht mit „Der Hausmeisterraum.“")
    aus, abbruch = _spiel(["westen", "süden", "westen", "ende"])
    dort = _nach(aus, "westen", 2)
    erwarte(not abbruch, "Auf dem Weg in den Hausmeisterraum bricht das Spiel ab.")
    erwarte("Der Hausmeisterraum." in dort or ZU in dort,
            "Von der Bibliothek nach westen steht weder „Der Hausmeisterraum. …“ noch „Abgeschlossen“.")


def pruefe_22_dinge():
    """Aufgabe 2 ★★★ · In den neuen Räumen liegen Dinge, die man nehmen kann"""
    braucht(_ziel("keller", "süden") == "bibliothek" and _ziel("bibliothek", "westen") == "hausmeisterraum")
    erwarte("karte" in _dinge("bibliothek") and "kreide" in _dinge("bibliothek"),
            "dinge_im(\"bibliothek\") liefert %r -- Karte und Kreide fehlen. Steht die Liste in dinge_im?"
            % (_dinge("bibliothek"),))
    erwarte("kreide" in _dinge("hausmeisterraum"),
            "dinge_im(\"hausmeisterraum\") liefert %r -- die Kreide fehlt." % (_dinge("hausmeisterraum"),))
    aus, abbruch = _spiel(["westen", "süden", "nimm karte", "zeige", "ende"])
    erwarte(not abbruch, "Beim Nehmen in der Bibliothek bricht das Spiel ab.")
    erwarte("karte" in _nach(aus, "zeige").lower(), "Nach nimm karte in der Bibliothek steht die Karte nicht im Rucksack.")


# ── Aufgabe 5 · Wie im Abitur: tuer_offen(wohin) ────────────────────────

def pruefe_50_tuer_offen():
    """Aufgabe 5 · tuer_offen(wohin) antwortet für Tor, Hausmeisterraum und alle anderen Türen"""
    braucht(funktion("tuer_offen") is not None, "Es gibt noch keine Funktion tuer_offen.")
    # Der Kreuzfall (Reihensichtung Teil II, Befund 7): jede Tuer nur mit IHREM Schluessel -- sonst besteht
    # "Tor oder Hausmeisterraum mit einem der beiden Schluessel"
    for wohin, rs, soll in (("tor", ["lampe"], False), ("tor", ["lampe", "torschlüssel"], True),
                            ("hausmeisterraum", ["lampe"], False), ("hausmeisterraum", ["hausmeisterschlüssel"], True),
                            ("tor", ["lampe", "hausmeisterschlüssel"], False),
                            ("hausmeisterraum", ["torschlüssel", "lampe"], False),
                            ("flur", [], True), ("bibliothek", ["lampe"], True), ("informatikraum", [], True)):
        wert, gedruckt, fehler = _rufen("tuer_offen", wohin, rucksack=list(rs))
        erwarte(fehler is None, "tuer_offen(%r) bricht ab: %s" % (wohin, fehler))
        erwarte(wert is not None, "tuer_offen(%r) gibt nichts zurück (None) -- fehlt ein return?" % wohin)
        erwarte(wert is soll, "tuer_offen(%r) mit dem Rucksack %r liefert %r, nicht %r." % (wohin, rs, wert, soll))


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(_ziel("keller", "süden") not in (None, ""))
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 7 (Mehr) · Die Tür und das Seil ─────────────────────────────

def pruefe_70_tuer_zu():
    """Aufgabe 7 ★★ · Der Hausmeisterraum ist zu ohne Hausmeisterschlüssel"""
    braucht(funktion("tuer_offen") is not None and _ziel("bibliothek", "westen") == "hausmeisterraum"
            and "tuer_offen(" in re.sub(r"def tuer_offen\(", "", ohne_kommentare()))
    aus, abbruch = _spiel(["westen", "süden", "westen", "schau", "ende"])
    erwarte(not abbruch, "Vor der Tür des Hausmeisterraums bricht das Spiel ab.")
    erwarte(ZU in _nach(aus, "westen", 2), "Ohne Hausmeisterschlüssel steht vor dem Hausmeisterraum nicht „Abgeschlossen. …“.")
    erwarte("Die Bibliothek." in _nach(aus, "schau"), "Nach der verschlossenen Tür steht ihr nicht mehr in der Bibliothek.")


def pruefe_71_seil():
    """Aufgabe 7 ★★★ · Das Seil holt den Hausmeisterschlüssel, der Torschlüssel liegt im Hausmeisterraum"""
    # Der Rueckweg aus der Bibliothek gehoert zu Aufgabe 2 -- fehlt er, wartet diese Pruefung (ein Fehler faerbt
    # nur seine eigene Pruefung, LC3; Giftprobe 17.11.2026: vorher wurden Aufgabe 2, 7 und 9 zugleich rot)
    braucht(funktion("tuer_offen") is not None and "dinge_schacht" in ohne_kommentare()
            and _ziel("bibliothek", "norden") == "keller")
    aus, abbruch = _spiel(WEG)
    erwarte(not abbruch, "Auf dem Weg aus Aufgabe 6 bricht das Spiel ab.")
    erwarte("hausmeisterschlüssel" in _nach(aus, "benutze seil").lower(),
            "Nach benutze seil im Keller ist vom Hausmeisterschlüssel keine Rede.")
    erwarte(DRAUSSEN in aus, "Mit den 12 Befehlen aus Aufgabe 6 kommt ihr nicht nach draußen.")
    keller, _ = _spiel(["westen", "nimm torschlüssel", "ende"])
    erwarte("torschlüssel" not in _nach(keller, "nimm torschlüssel").lower().replace("kein torschlüssel", ""),
            "Im Keller liegt noch der Torschlüssel -- er gehört jetzt in den Hausmeisterraum.")


# ── Aufgabe 8 (Mehr) · Essen ─────────────────────────────────────────────

def pruefe_80_iss():
    """Aufgabe 8 ★★ · iss(ding): Apfel 3 Züge mehr, Pausenbrot 3 weniger"""
    braucht(funktion("iss") is not None)
    for ding, soll in (("apfel", 3), ("pausenbrot", -3)):
        wert, _, fehler = _rufen("iss", ding, rucksack=["lampe", ding])
        erwarte(fehler is None, "iss(%r) bricht ab: %s" % (ding, fehler))
        erwarte(wert == soll, "iss(%r) liefert %r, nicht %d -- gibt sie die Züge zurück?" % (ding, wert, soll))
    aus, abbruch = _spiel(["süden", "nimm apfel", "iss apfel", "zeige", "ende"])
    erwarte(not abbruch, "Beim Essen bricht das Spiel ab.")
    erwarte(re.search(r"Züge übrig:\s*29\b", _nach(aus, "zeige")) is not None,
            "Nach süden, nimm apfel, iss apfel und zeige steht nicht „Züge übrig: 29“ -- zählt das Hauptprogramm die Züge?")


def pruefe_81_nur_was_da_ist():
    """Aufgabe 8 ★★★ · Gegessen wird nur, was im Rucksack ist; der volle Rucksack nennt das Essen"""
    braucht(funktion("iss") is not None)
    wert, _, fehler = _rufen("iss", "apfel", rucksack=["lampe"])
    erwarte(fehler is None and wert == 0, "iss(\"apfel\") ohne Apfel im Rucksack liefert %r, nicht 0." % (wert,))
    rs = ["lampe", "apfel"]
    _rufen("iss", "apfel", rucksack=rs)
    erwarte("apfel" not in rs, "Nach dem Essen ist der Apfel noch im Rucksack.")
    erwarte("oder iss etwas" in ohne_kommentare(), "Der volle Rucksack sagt noch nicht „Leg etwas ab oder iss etwas.“")


# ── Aufgabe 9 (Mehr) ★★★★ · Die Schule bei Nacht, fertig ───────────────

def pruefe_90_fertig():
    """Aufgabe 9 ★★★★ · Zwei von dreien: Karte, Plakat, Befehlszeile"""
    braucht(_ziel("keller", "süden") == "bibliothek" and _ziel("bibliothek", "norden") == "keller"
            and re.search(r"def ausgaenge|def befehle|\bruhe\b|eingabe == \"karte\"", ohne_kommentare()) is not None)
    karte, _ = _spiel(["westen", "süden", "nimm karte", "karte", "ende"])
    plakat, _ = _spiel(["westen", "süden", "norden", "süden", "ende"])
    zeile, _ = _spiel(["westen", "ende"])
    hat = {"die Karte": "Norden und Westen" in _nach(karte, "karte"),
           "das Plakat": "RUHE! RUHE!" in _nach(plakat, "süden", 2),
           "die Befehlszeile": re.search(r"Befehle: \w+ · ", _nach(zeile, "westen")) is not None}
    da = [k for k, v in hat.items() if v]
    erwarte(len(da) >= 2, "Erst %d von dreien (%s) -- die Karte zeigt die Ausgänge, das Plakat wird lauter, die "
            "Befehlszeile steht nach jedem Gehen." % (len(da), ", ".join(da) or "keine"))


# ── Aufgabe 10 (Mehr) ★★★★ · Für Expert*innen: Der volle Koffer ─────────
# Die Auflage ist "fuer jede Liste": Der Check ruft bester_wert selbst, mit eigenen Listen (LU6: frei im Weg,
# geprueft am Verhalten). Die Sollwerte sind mit Durchprobieren aller Auswahlen nachgerechnet (17.11.2026). Bei
# [4, 3, 3] / [10, 7, 7] / 6 und beim Sechser liegen beide gierigen Regeln aus ★★ daneben (10 statt 14; 100 und 85
# statt 102); [10] / [7] / 10 trennt <= von <, die leere Liste und "nichts passt" den Startwert.
KOFFER = (([6, 5, 5, 2, 1], [48, 45, 45, 20, 4], 10, 90),
          ([4, 3, 3], [10, 7, 7], 6, 14),
          ([5, 6, 3, 6, 4, 6], [41, 43, 28, 57, 33, 27], 12, 102),
          ([1, 2, 3], [5, 6, 7], 10, 18),
          ([10], [7], 10, 7),
          ([11, 12], [5, 6], 10, 0),
          ([], [], 10, 0))


def pruefe_a0_bester_wert():
    """Aufgabe 10 ★★★★ · bester_wert findet für jede Liste den größten Wert, der in den Koffer passt"""
    braucht(funktion("bester_wert") is not None)
    for gewichte, werte, grenze, soll in KOFFER:
        aufruf = "bester_wert(%r, %r, %d)" % (gewichte, werte, grenze)
        wert, _, fehler = _rufen("bester_wert", list(gewichte), list(werte), grenze)
        erwarte(fehler is None, "%s bricht ab: %s" % (aufruf, fehler))
        erwarte(wert is not None, "%s gibt nichts zurück (None) -- fehlt ein return?" % aufruf)
        zahl = isinstance(wert, int) and not isinstance(wert, bool)
        erwarte(zahl, "%s liefert %r -- erwartet ist eine ganze Zahl, der Wert." % (aufruf, wert))
        erwarte(wert <= soll, "%s liefert %r -- so viel passt in diesen Koffer nicht hinein. Zählt das Gewicht "
                "jeder Auswahl mit?" % (aufruf, wert))
        erwarte(wert >= soll, "%s liefert %r -- in diesen Koffer passt mehr. Legt die Dinge von Hand hinein: "
                "Welche Auswahl hat eure Funktion nicht angesehen?" % (aufruf, wert))
