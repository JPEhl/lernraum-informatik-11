"""Selbstcheck zu "Die ganze Schule" -- prueft zusammen.py (Aufgabe 2, 4, Vorrat 6, 7, Kuer 8).

Das Spiel wuerfelt seit "Der Kater kommt, wann er will" (Sicherung, Kater). Der Check stellt den Zufall fest ein,
solange er anspielt (_zufall_fest: randint liefert immer b -- weder Sicherung noch Kater), wie in zufall/pruefung.py.

Die Pflicht (Aufgabe 2) laesst den Torschluessel im Keller und die Tuer offen; Vorrat 6 schliesst sie und legt ihn in
den Hausmeisterraum. Darum fragt Aufgabe 2 die Funktionen selbst (ziel, beschreibung, dinge_im) und nimmt im Spiel
beides hin: den Hausmeisterraum oder "Abgeschlossen".
"""
import ast
import io
import random
import re
import sys

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen, funktion, quelltext

TITEL = "Die ganze Schule · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, nach Sueden -- ohne etwas zu nehmen (die Listen der Raeume
# sind danach die, die _rufen("dinge_im", …) sieht; ein "nimm karte" hier liess Aufgabe 2 ★★★ die Karte vermissen)
EINGABEN = ["westen", "süden", "zeige", "ende"]

TREPPE = "wartest auf den Morgen"
DRAUSSEN = "kalt und wunderbar"
ZU = "Abgeschlossen"
SCHLUSS = "§SCHLUSS§"
WEG = ["süden", "nimm seil", "norden", "westen", "benutze seil", "süden", "westen", "nimm torschlüssel",
       "osten", "norden", "osten", "norden"]

HINTS = {"hilfe": "None", "zeige_raum": "None", "zeige_rucksack": "None", "pruefe_tuer": "bool", "beschreibung": "str",
         "dinge_im": "list[str]", "sterne": "str", "aufzaehlen": "str", "ziel": "str", "gehe": "str", "kater": "None",
         "tuer_offen": "bool", "iss": "int", "ausgaenge": "list[str]", "befehle": "str", "wert": "int", "nimm": "int",
         "lege": "None", "benutze": "int"}

KEIN_WERT = object()


def _spiel(befehle):
    """Das Spiel mit diesen Befehlen, Zufall fest (keine Sicherung, kein Kater). Gibt (aus, abbruch)."""
    alt_q, alt_r = pruefen._QUELLE, (random.randint, random.choice)
    pruefen._QUELLE = alt_q + "\nprint(%r)\n" % SCHLUSS
    random.randint = lambda a, b: b
    try:
        aus, _ = anspielen(befehle)
    finally:
        random.randint, random.choice = alt_r
        pruefen._QUELLE = alt_q
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet)


def _nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _rufen(name, *argumente, **werte):
    """Die Funktion `name` mit diesen Argumenten rufen, vorher Variablen draussen setzen (rucksack=[…])."""
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    g = f.__globals__
    alt = {k: g.get(k, KEIN_WERT) for k in werte}
    g.update(werte)
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
        for k, v in alt.items():
            if v is KEIN_WERT:
                g.pop(k, None)
            else:
                g[k] = v
    return wert, puffer.getvalue(), fehler


def _ziel(raum, richtung):
    wert, _, fehler = _rufen("ziel", raum, richtung)
    return None if fehler else wert


def _defs():
    try:
        baum = ast.parse(quelltext())
    except SyntaxError:
        return []
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _dinge(raum):
    wert, _, fehler = _rufen("dinge_im", raum)
    return [] if fehler or not isinstance(wert, list) else list(wert)


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Der Kater kommt, wann er will“ konnte"""
    aus, abbruch = _spiel(["warte 2", "ende"])
    erwarte(not (abbruch and "> " not in aus),
            "Das Spiel bricht schon vor der ersten Eingabe ab -- fehlt ein Komma in einer Liste, oder ein Raumname?")
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Deine Sterne" in aus, "Am Ende steht „Deine Sterne:“ nicht mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 · Zwei Räume mehr ─────────────────────────────────────────

def pruefe_20_bibliothek():
    """Aufgabe 2 · Die Bibliothek: vom Keller nach Süden und zurück"""
    # erwarte, nicht braucht: Im Startzustand steht genau diese erste Pflichtpruefung aus, mit dem naechsten Schritt
    # (Reihensichtung Teil II, Befund 6)
    erwarte(_ziel("keller", "süden") not in (None, ""),
            "Vom Keller nach Süden ist noch eine Wand. Die Bibliothek braucht einen Weg hinein -- in ziel.")
    erwarte(_ziel("keller", "süden") == "bibliothek",
            "ziel(\"keller\", \"süden\") liefert %r, nicht \"bibliothek\"." % (_ziel("keller", "süden"),))
    erwarte(_ziel("bibliothek", "norden") == "keller",
            "Von der Bibliothek nach Norden geht es nicht zurück in den Keller -- der Weg muss in beide Richtungen gehen.")
    wert, _, fehler = _rufen("beschreibung", "bibliothek")
    erwarte(fehler is None and isinstance(wert, str) and wert.startswith("Die Bibliothek."),
            "beschreibung(\"bibliothek\") beginnt nicht mit „Die Bibliothek.“")
    aus, abbruch = _spiel(["westen", "süden", "norden", "ende"])
    erwarte(not abbruch, "Auf dem Weg in die Bibliothek bricht das Spiel ab.")
    erwarte("Die Bibliothek." in _nach(aus, "süden"), "Nach westen und süden steht nicht „Die Bibliothek. …“.")
    erwarte("Der Keller." in _nach(aus, "norden"), "Von der Bibliothek nach norden kommt ihr nicht in den Keller.")


def pruefe_21_hausmeisterraum():
    """Aufgabe 2 ★★ · Der Hausmeisterraum: von der Bibliothek nach Westen und zurück"""
    braucht(_ziel("bibliothek", "westen") not in (None, ""))
    erwarte(_ziel("bibliothek", "westen") == "hausmeisterraum",
            "ziel(\"bibliothek\", \"westen\") liefert %r, nicht \"hausmeisterraum\"." % (_ziel("bibliothek", "westen"),))
    erwarte(_ziel("hausmeisterraum", "osten") == "bibliothek", "Vom Hausmeisterraum nach Osten geht es nicht zurück.")
    wert, _, fehler = _rufen("beschreibung", "hausmeisterraum")
    erwarte(fehler is None and isinstance(wert, str) and wert.startswith("Der Hausmeisterraum."),
            "beschreibung(\"hausmeisterraum\") beginnt nicht mit „Der Hausmeisterraum.“")
    aus, abbruch = _spiel(["westen", "süden", "westen", "ende"])
    dort = _nach(aus, "westen", 2)
    erwarte(not abbruch, "Auf dem Weg in den Hausmeisterraum bricht das Spiel ab.")
    erwarte("Der Hausmeisterraum." in dort or ZU in dort,
            "Von der Bibliothek nach westen steht weder „Der Hausmeisterraum. …“ noch „Abgeschlossen“.")


def pruefe_22_dinge():
    """Aufgabe 2 ★★★ · In den neuen Räumen liegen Dinge, die man nehmen kann"""
    braucht(_ziel("keller", "süden") == "bibliothek" and _ziel("bibliothek", "westen") == "hausmeisterraum")
    erwarte("karte" in _dinge("bibliothek") and "kreide" in _dinge("bibliothek"),
            "dinge_im(\"bibliothek\") liefert %r -- Karte und Kreide fehlen. Steht die Liste in dinge_im?"
            % (_dinge("bibliothek"),))
    erwarte("kreide" in _dinge("hausmeisterraum"),
            "dinge_im(\"hausmeisterraum\") liefert %r -- die Kreide fehlt." % (_dinge("hausmeisterraum"),))
    aus, abbruch = _spiel(["westen", "süden", "nimm karte", "zeige", "ende"])
    erwarte(not abbruch, "Beim Nehmen in der Bibliothek bricht das Spiel ab.")
    erwarte("karte" in _nach(aus, "zeige").lower(), "Nach nimm karte in der Bibliothek steht die Karte nicht im Rucksack.")


# ── Aufgabe 4 · Wie im Abitur: tuer_offen(wohin) ────────────────────────

def pruefe_40_tuer_offen():
    """Aufgabe 4 · tuer_offen(wohin) antwortet für Tor, Hausmeisterraum und alle anderen Türen"""
    braucht(funktion("tuer_offen") is not None, "Es gibt noch keine Funktion tuer_offen.")
    # Der Kreuzfall (Reihensichtung Teil II, Befund 7): jede Tuer nur mit IHREM Schluessel -- sonst besteht
    # "Tor oder Hausmeisterraum mit einem der beiden Schluessel"
    for wohin, rs, soll in (("tor", ["lampe"], False), ("tor", ["lampe", "torschlüssel"], True),
                            ("hausmeisterraum", ["lampe"], False), ("hausmeisterraum", ["hausmeisterschlüssel"], True),
                            ("tor", ["lampe", "hausmeisterschlüssel"], False),
                            ("hausmeisterraum", ["torschlüssel", "lampe"], False),
                            ("flur", [], True), ("bibliothek", ["lampe"], True), ("informatikraum", [], True)):
        wert, gedruckt, fehler = _rufen("tuer_offen", wohin, rucksack=list(rs))
        erwarte(fehler is None, "tuer_offen(%r) bricht ab: %s" % (wohin, fehler))
        erwarte(wert is not None, "tuer_offen(%r) gibt nichts zurück (None) -- fehlt ein return?" % wohin)
        erwarte(wert is soll, "tuer_offen(%r) mit dem Rucksack %r liefert %r, nicht %r." % (wohin, rs, wert, soll))


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(_ziel("keller", "süden") not in (None, ""))
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Vorrat 6 · Die Tür und das Seil ─────────────────────────────────────

def pruefe_60_tuer_zu():
    """Aufgabe 6 ★★ · Der Hausmeisterraum ist zu ohne Hausmeisterschlüssel"""
    braucht(funktion("tuer_offen") is not None and _ziel("bibliothek", "westen") == "hausmeisterraum"
            and "tuer_offen(" in re.sub(r"def tuer_offen\(", "", ohne_kommentare()))
    aus, abbruch = _spiel(["westen", "süden", "westen", "schau", "ende"])
    erwarte(not abbruch, "Vor der Tür des Hausmeisterraums bricht das Spiel ab.")
    erwarte(ZU in _nach(aus, "westen", 2), "Ohne Hausmeisterschlüssel steht vor dem Hausmeisterraum nicht „Abgeschlossen. …“.")
    erwarte("Die Bibliothek." in _nach(aus, "schau"), "Nach der verschlossenen Tür steht ihr nicht mehr in der Bibliothek.")


def pruefe_61_seil():
    """Aufgabe 6 ★★★ · Das Seil holt den Hausmeisterschlüssel, der Torschlüssel liegt im Hausmeisterraum"""
    braucht(funktion("tuer_offen") is not None and "dinge_schacht" in ohne_kommentare())
    aus, abbruch = _spiel(WEG)
    erwarte(not abbruch, "Auf dem Weg aus Aufgabe 3 bricht das Spiel ab.")
    erwarte("hausmeisterschlüssel" in _nach(aus, "benutze seil").lower(),
            "Nach benutze seil im Keller ist vom Hausmeisterschlüssel keine Rede.")
    erwarte(DRAUSSEN in aus, "Mit den 12 Befehlen aus Aufgabe 3 kommt ihr nicht nach draußen.")
    keller, _ = _spiel(["westen", "nimm torschlüssel", "ende"])
    erwarte("torschlüssel" not in _nach(keller, "nimm torschlüssel").lower().replace("kein torschlüssel", ""),
            "Im Keller liegt noch der Torschlüssel -- er gehört jetzt in den Hausmeisterraum.")


# ── Vorrat 7 · Essen ─────────────────────────────────────────────────────

def pruefe_70_iss():
    """Aufgabe 7 ★★ · iss(ding): Apfel 3 Züge mehr, Pausenbrot 3 weniger"""
    braucht(funktion("iss") is not None)
    for ding, soll in (("apfel", 3), ("pausenbrot", -3)):
        wert, _, fehler = _rufen("iss", ding, rucksack=["lampe", ding])
        erwarte(fehler is None, "iss(%r) bricht ab: %s" % (ding, fehler))
        erwarte(wert == soll, "iss(%r) liefert %r, nicht %d -- gibt sie die Züge zurück?" % (ding, wert, soll))
    aus, abbruch = _spiel(["süden", "nimm apfel", "iss apfel", "zeige", "ende"])
    erwarte(not abbruch, "Beim Essen bricht das Spiel ab.")
    erwarte(re.search(r"Züge übrig:\s*29\b", _nach(aus, "zeige")) is not None,
            "Nach süden, nimm apfel, iss apfel und zeige steht nicht „Züge übrig: 29“ -- zählt das Hauptprogramm die Züge?")


def pruefe_71_nur_was_da_ist():
    """Aufgabe 7 ★★★ · Gegessen wird nur, was im Rucksack ist; der volle Rucksack nennt das Essen"""
    braucht(funktion("iss") is not None)
    wert, _, fehler = _rufen("iss", "apfel", rucksack=["lampe"])
    erwarte(fehler is None and wert == 0, "iss(\"apfel\") ohne Apfel im Rucksack liefert %r, nicht 0." % (wert,))
    rs = ["lampe", "apfel"]
    _rufen("iss", "apfel", rucksack=rs)
    erwarte("apfel" not in rs, "Nach dem Essen ist der Apfel noch im Rucksack.")
    erwarte("oder iss etwas" in ohne_kommentare(), "Der volle Rucksack sagt noch nicht „Leg etwas ab oder iss etwas.“")


# ── Kür 8 ★★★★ · Die Schule bei Nacht, fertig ──────────────────────────

def pruefe_80_fertig():
    """Aufgabe 8 ★★★★ · Zwei von dreien: Karte, Plakat, Befehlszeile"""
    braucht(_ziel("keller", "süden") == "bibliothek"
            and re.search(r"def ausgaenge|def befehle|\bruhe\b|eingabe == \"karte\"", ohne_kommentare()) is not None)
    karte, _ = _spiel(["westen", "süden", "nimm karte", "karte", "ende"])
    plakat, _ = _spiel(["westen", "süden", "norden", "süden", "ende"])
    zeile, _ = _spiel(["westen", "ende"])
    hat = {"die Karte": "Norden und Westen" in _nach(karte, "karte"),
           "das Plakat": "RUHE! RUHE!" in _nach(plakat, "süden", 2),
           "die Befehlszeile": re.search(r"Befehle: \w+ · ", _nach(zeile, "westen")) is not None}
    da = [k for k, v in hat.items() if v]
    erwarte(len(da) >= 2, "Erst %d von dreien (%s) -- die Karte zeigt die Ausgänge, das Plakat wird lauter, die "
            "Befehlszeile steht nach jedem Gehen." % (len(da), ", ".join(da) or "keine"))
