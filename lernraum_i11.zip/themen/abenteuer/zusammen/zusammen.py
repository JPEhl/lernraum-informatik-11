# Die Schule bei Nacht -- euer Spiel.
# Daran arbeitet ihr in diesem Thema.
#
# Das fertige Spiel aus dem ersten Thema hat sieben
# Räume, eine verschlossene Tür, ein Seil, Essen und
# eine Karte. Eures hat fünf Räume. Erst die Struktur
# wählen, dann bauen.
#
# Befehle: norden, osten, süden, westen,
# nimm <ding>, lege <ding>, schau, zeige,
# warte <n>, hilfe, ende

import random

rucksack = ["lampe"]
dinge_flur = ["kreide"]
dinge_informatikraum = ["stick", "kreide"]
dinge_lehrerzimmer = ["seil", "apfel", "kreide"]
dinge_keller = ["torschlüssel", "pausenbrot", "kreide"]
dinge_tor = []

def hilfe() -> None:
    print("Befehle: norden, osten, süden, westen, nimm <ding>, lege <ding>, schau, zeige, warte <n>, hilfe, ende")


def beschreibung(raum: str) -> str:
    """Der Satz, der einen Raum beschreibt."""
    if raum == "flur":
        return "Der Flur. Nur deine Lampe leuchtet. Das Haupttor liegt im Norden, dahinter ist Nacht."
    elif raum == "informatikraum":
        return "Der Informatikraum. 24 Rechner schlafen. Einer blinkt, als hätte er etwas zu sagen."
    elif raum == "lehrerzimmer":
        return "Das Lehrerzimmer. Es riecht nach altem Kaffee. Die Kaffeemaschine beobachtet dich."
    elif raum == "keller":
        return "Der Keller. Rohre, Staub, ein Schacht im Boden. Irgendwo tropft es."
    else:
        return "Das Haupttor. Draußen ist Nacht, Luft und ein Fahrrad, das deins ist."


def dinge_im(raum: str) -> list[str]:
    """Die Liste der Dinge, die in raum liegen."""
    if raum == "flur":
        return dinge_flur
    elif raum == "informatikraum":
        return dinge_informatikraum
    elif raum == "lehrerzimmer":
        return dinge_lehrerzimmer
    elif raum == "keller":
        return dinge_keller
    else:
        return dinge_tor


def aufzaehlen(liste: list[str]) -> str:
    """Zählt auf, wie ein Mensch es sagt: Seil, Apfel und Kreide."""
    text = ""
    for i in range(len(liste)):
        if i > 0 and i == len(liste) - 1:
            text = text + " und "
        elif i > 0:
            text = text + ", "
        text = text + liste[i].capitalize()
    return text


def zeige_raum(raum: str) -> None:
    if "lampe" in rucksack:
        print(beschreibung(raum))
        hier = dinge_im(raum)
        if len(hier) > 0:
            print("Hier liegt:", aufzaehlen(hier) + ".")
    else:
        print("Stockdunkel. Du siehst nicht einmal, wo du die Lampe hingelegt hast.")


def zeige_rucksack(punkte: int, zuege: int) -> None:
    if len(rucksack) == 0:
        print("Dein Rucksack ist leer.")
    else:
        print("Du trägst:", aufzaehlen(rucksack) + ".")
    print("Punkte:", punkte, "- Züge übrig:", zuege)


def pruefe_tuer() -> bool:
    """Antwortet, ob das Tor aufgeht -- gedruckt wird woanders."""
    return "torschlüssel" in rucksack


def ziel(raum: str, richtung: str) -> str:
    """Welcher Raum liegt von raum aus in richtung? Leerer Text heißt: Wand."""
    if raum == "flur":
        if richtung == "norden":
            return "tor"
        elif richtung == "osten":
            return "informatikraum"
        elif richtung == "süden":
            return "lehrerzimmer"
        elif richtung == "westen":
            return "keller"
    elif raum == "informatikraum":
        if richtung == "westen":
            return "flur"
    elif raum == "lehrerzimmer":
        if richtung == "norden":
            return "flur"
    elif raum == "keller":
        if richtung == "osten":
            return "flur"
    return ""


def gehe(raum: str, richtung: str) -> str:
    """Gibt den neuen Raum zurück -- oder den alten, wenn es nicht weitergeht."""
    wohin = ziel(raum, richtung)
    if wohin == "":
        print("Da ist eine Wand. Eine sehr solide Wand.")
        return raum
    if wohin == "tor":
        if pruefe_tuer():
            print("Du schließt das Tor auf.")
        else:
            print("Abgeschlossen. Du rüttelst an der Tür. Die Tür rüttelt nicht zurück.")
            return raum
    return wohin


def kater(raum: str) -> None:
    """Byte schnappt sich ein Ding (nie die Lampe) und lässt es in raum fallen."""
    print("Der Schulkater Byte streicht um deine Beine.")
    zum_schnappen = []
    for ding in rucksack:
        if ding != "lampe":
            zum_schnappen.append(ding)
    if len(zum_schnappen) == 0:
        print("Er schnuppert an deiner Lampe und verliert das Interesse.")
    else:
        ding = random.choice(zum_schnappen)
        rucksack.remove(ding)
        dinge_im(raum).append(ding)
        print("Er schnappt sich", ding, "und lässt es hier fallen.")


def sterne(punkte: int) -> str:
    """Ein Stern je 10 Punkte, als Text."""
    text = ""
    for i in range(punkte // 10):
        text = text + "*"
    return text

raum = "flur"
zuege = 30
punkte = 0
sekunden = 0
print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
hilfe()
print()
zeige_raum(raum)

eingabe = ""
while zuege > 0 and raum != "tor" and eingabe != "ende":
    eingabe = input("> ").lower().strip()
    zuege = zuege - 1
    sekunden = sekunden + 45

    if eingabe == "ende":
        print("Du setzt dich auf die Treppe und wartest auf den Morgen.")
    elif eingabe == "hilfe":
        hilfe()
    elif eingabe == "schau":
        zeige_raum(raum)
    elif eingabe == "zeige":
        zeige_rucksack(punkte, zuege)
    elif eingabe == "norden" or eingabe == "osten" or eingabe == "süden" or eingabe == "westen":
        vorher = raum
        raum = gehe(raum, eingabe)
        if raum != vorher:
            if raum == "keller" and random.randint(1, 6) == 1:
                print("KLACK. Die Sicherung fliegt raus. Deine Lampe flackert. Das kostet dich 2 Züge.")
                zuege = zuege - 2
            if random.randint(1, 5) == 1:
                kater(raum)
        zeige_raum(raum)
    elif eingabe.startswith("nimm "):
        ding = eingabe.replace("nimm ", "")
        hier = dinge_im(raum)
        if ding not in hier:
            print("Hier gibt es kein", ding + ".")
        elif len(rucksack) >= 6:
            print("Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht. Leg etwas ab.")
        else:
            hier.remove(ding)
            rucksack.append(ding)
            punkte = punkte + 10
            print("Du nimmst:", ding)
    elif eingabe.startswith("lege "):
        ding = eingabe.replace("lege ", "")
        if ding in rucksack:
            rucksack.remove(ding)
            dinge_im(raum).append(ding)
            print("Du legst weg:", ding)
        else:
            print("Das hast du nicht.")
    elif eingabe.startswith("warte "):
        zahl = eingabe.replace("warte ", "")
        if zahl.isdigit():
            n = int(zahl)
            zuege = zuege - n
            sekunden = sekunden + n * 45
            print("Du wartest", n, "Züge. Nichts passiert. Irgendwo tropft es.")
        else:
            print("Warten geht nur mit einer Zahl, zum Beispiel: warte 3")
    else:
        print("Das verstehe ich nicht. Tippe hilfe.")

print()
if raum == "tor":
    punkte = punkte + zuege * 2
    print("Du schließt das Tor auf und stehst draußen. Die Nacht ist kalt und wunderbar.")
elif zuege <= 0:
    print("Die Lampe wird schwach, flackert und geht aus. Du sitzt im Dunkeln, bis der Hausmeister kommt.")

minuten = sekunden // 60
rest = sekunden % 60
print("Spielzeit:", minuten, "min", rest, "s -", punkte, "Punkte")
if minuten > 0:
    print("Das sind", round(punkte / minuten, 1), "Punkte pro Minute.")
print("Deine Sterne:", sterne(punkte))
