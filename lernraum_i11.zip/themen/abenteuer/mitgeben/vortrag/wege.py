# Wohin führt der Weg? -- klein, zwei Räume
# Vom Flur: westen -> Keller, osten -> Informatikraum.
# Vom Keller: osten -> Flur. Sonst überall: Wand.
