# Wohin führt der Weg? -- klein, zwei Räume
# Vom Flur: westen -> Keller, osten -> Informatikraum.
# Vom Keller: osten -> Flur. Sonst überall: Wand.


def ziel(raum: str, richtung: str) -> str:
    """Wohin führt der Weg? Leerer Text heißt: Wand."""
    if raum == "flur":
        if richtung == "westen":
            return "keller"
        elif richtung == "osten":
            return "informatikraum"
    elif raum == "keller":
        if richtung == "osten":
            return "flur"
    return ""


print("Vom Flur nach Westen:", ziel("flur", "westen"))
print("Vom Keller nach Osten:", ziel("keller", "osten"))
print("Vom Keller nach Norden:", ziel("keller", "norden"))
print("Vom Flur nach Westen?", ziel("westen", "flur"))
