# Aufzählen -- klein, gebaut wie im Spiel
rucksack = ["lampe", "seil", "apfel"]
hier = ["stick", "kreide"]

print("Du trägst:")
for ding in rucksack:
    print("  -", ding)
print("Hier liegt:")
for ding in hier:
    print("  -", ding)
