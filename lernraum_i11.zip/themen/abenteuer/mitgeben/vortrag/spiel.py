# Die Schule bei Nacht -- euer Spiel.
# Stand nach Thema 12 (Funktionen mit Rückgabewert):
# Funktionen antworten jetzt mit return:
# pruefe_tuer() sagt True oder False,
# beschreibung() liefert den Satz, dinge_hier()
# die Liste, sterne() den Text. Das Hauptprogramm
# entscheidet, was damit passiert.

rucksack = ["lampe"]
dinge_flur = ["kreide"]
dinge_informatikraum = ["stick", "kreide"]
dinge_lehrerzimmer = ["seil", "apfel", "kreide"]
dinge_keller = ["torschlüssel", "pausenbrot", "kreide"]
dinge_tor = []

def hilfe() -> None:
    print("Befehle: norden, osten, süden, westen, nimm <ding>, lege <ding>, schau, zeige, warte <n>, hilfe, ende")


def beschreibung() -> str:
    """Der Satz, der den aktuellen Raum beschreibt."""
    if raum == "flur":
        return "Der Flur. Nur deine Lampe leuchtet. Das Haupttor liegt im Norden, dahinter ist Nacht."
    elif raum == "informatikraum":
        return "Der Informatikraum. 24 Rechner schlafen. Einer blinkt, als hätte er etwas zu sagen."
    elif raum == "lehrerzimmer":
        return "Das Lehrerzimmer. Es riecht nach altem Kaffee. Die Kaffeemaschine beobachtet dich."
    elif raum == "keller":
        return "Der Keller. Rohre, Staub, ein Schacht im Boden. Irgendwo tropft es."
    else:
        return "Das Haupttor. Draußen ist Nacht, Luft und ein Fahrrad, das deins ist."


def dinge_hier() -> list[str]:
    """Die Liste der Dinge im aktuellen Raum."""
    if raum == "flur":
        return dinge_flur
    elif raum == "informatikraum":
        return dinge_informatikraum
    elif raum == "lehrerzimmer":
        return dinge_lehrerzimmer
    elif raum == "keller":
        return dinge_keller
    else:
        return dinge_tor


def zeige_raum() -> None:
    if "lampe" in rucksack:
        print(beschreibung())
        print("Hier liegt:")
        for ding in dinge_hier():
            print("  -", ding)
    else:
        print("Stockdunkel. Du siehst nicht einmal, wo du die Lampe hingelegt hast.")


def zeige_rucksack() -> None:
    print("Du trägst", len(rucksack), "Dinge:")
    for ding in rucksack:
        print("  -", ding)
    print("Punkte:", punkte, "- Züge übrig:", zuege)


def pruefe_tuer() -> bool:
    """Antwortet, ob das Tor aufgeht -- gedruckt wird woanders."""
    return "torschlüssel" in rucksack


def sterne() -> str:
    """Ein Stern je 10 Punkte, als Text."""
    text = ""
    for i in range(punkte // 10):
        text = text + "*"
    return text

raum = "flur"
zuege = 30
punkte = 0
sekunden = 0
print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
hilfe()
print()
zeige_raum()

eingabe = ""
while zuege > 0 and raum != "tor" and eingabe != "ende":
    eingabe = input("> ").lower().strip()
    zuege = zuege - 1
    sekunden = sekunden + 45

    if eingabe == "ende":
        print("Du setzt dich auf die Treppe und wartest auf den Morgen.")
    elif eingabe == "hilfe":
        hilfe()
    elif eingabe == "schau":
        zeige_raum()
    elif eingabe == "zeige":
        zeige_rucksack()
    elif eingabe == "norden" or eingabe == "osten" or eingabe == "süden" or eingabe == "westen":
        richtung = eingabe
        if raum == "flur":
            if richtung == "norden":
                if pruefe_tuer():
                    raum = "tor"
                    print("Du schließt das Tor auf.")
                else:
                    print("Abgeschlossen. Du rüttelst an der Tür. Die Tür rüttelt nicht zurück.")
            elif richtung == "osten":
                raum = "informatikraum"
            elif richtung == "süden":
                raum = "lehrerzimmer"
            elif richtung == "westen":
                raum = "keller"
        elif raum == "informatikraum":
            if richtung == "westen":
                raum = "flur"
            else:
                print("Da ist eine Wand. Eine sehr solide Wand.")
        elif raum == "lehrerzimmer":
            if richtung == "norden":
                raum = "flur"
            else:
                print("Da ist eine Wand. Eine sehr solide Wand.")
        elif raum == "keller":
            if richtung == "osten":
                raum = "flur"
            else:
                print("Da ist eine Wand. Eine sehr solide Wand.")
        zeige_raum()
    elif eingabe.startswith("nimm "):
        ding = eingabe.replace("nimm ", "")
        hier = dinge_hier()
        if ding not in hier:
            print("Hier gibt es kein", ding + ".")
        elif len(rucksack) >= 6:
            print("Dein Rucksack ist voll. Sechs Dinge, mehr passt nicht. Leg etwas ab.")
        else:
            hier.remove(ding)
            rucksack.append(ding)
            punkte = punkte + 10
            print("Du nimmst:", ding)
    elif eingabe.startswith("lege "):
        ding = eingabe.replace("lege ", "")
        if ding in rucksack:
            rucksack.remove(ding)
            dinge_hier().append(ding)
            print("Du legst weg:", ding)
        else:
            print("Das hast du nicht.")
    elif eingabe.startswith("warte "):
        zahl = eingabe.replace("warte ", "")
        if zahl.isdigit():
            n = int(zahl)
            zuege = zuege - n
            sekunden = sekunden + n * 45
            print("Du wartest", n, "Züge. Nichts passiert. Irgendwo tropft es.")
        else:
            print("Warten geht nur mit einer Zahl, zum Beispiel: warte 3")
    else:
        print("Das verstehe ich nicht. Tippe hilfe.")

print()
if raum == "tor":
    punkte = punkte + zuege * 2
    print("Du schließt das Tor auf und stehst draußen. Die Nacht ist kalt und wunderbar.")
elif zuege <= 0:
    print("Die Lampe wird schwach, flackert und geht aus. Du sitzt im Dunkeln, bis der Hausmeister kommt.")

minuten = sekunden // 60
rest = sekunden % 60
print("Spielzeit:", minuten, "min", rest, "s -", punkte, "Punkte")
if minuten > 0:
    print("Das sind", round(punkte / minuten, 1), "Punkte pro Minute.")
print("Deine Sterne:", sterne())
