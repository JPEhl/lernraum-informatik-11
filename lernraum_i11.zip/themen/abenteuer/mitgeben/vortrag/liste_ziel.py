# Aufzählen -- klein, gebaut wie im Spiel
rucksack = ["lampe", "seil", "apfel"]
hier = ["stick", "kreide"]


def aufzaehlen(liste: list[str]) -> str:
    text = ""
    for ding in liste:
        if text != "":
            text = text + ", "
        text = text + ding
    return text


print("Du trägst:", aufzaehlen(rucksack) + ".")
print("Hier liegt:", aufzaehlen(hier) + ".")
