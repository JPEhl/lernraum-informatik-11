rucksack = ["lampe", "seil"]
def aufzaehlen(liste: list[str]) -> str:
    text = ""
    for ding in liste:
        if text != "":
            text = text + ", "
        text = text + ding
    return text
print("Du trägst:", aufzaehlen(rucksack) + ".")
