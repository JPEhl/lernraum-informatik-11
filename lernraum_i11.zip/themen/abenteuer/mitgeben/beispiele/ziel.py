def ziel(raum: str, richtung: str) -> str:
    """Wohin führt der Weg? Leerer Text heißt: Wand."""
    if raum == "flur":
        if richtung == "westen":
            return "keller"
        elif richtung == "osten":
            return "informatikraum"
    elif raum == "keller":
        if richtung == "osten":
            return "flur"
    return ""


print("Vom Flur nach Westen:", ziel("flur", "westen"))
print("Vom Keller nach Osten:", ziel("keller", "osten"))
print("Vom Flur nach Westen?", ziel("westen", "flur"))
