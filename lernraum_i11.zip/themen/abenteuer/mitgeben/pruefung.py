"""Selbstcheck zu "Seil, Apfel und Kreide" -- prueft mitgeben.py (Aufgabe 2, 3, 4 ★★, Vorrat 8, Kuer 9).

Zwei Wege, wie in "Das Tor, das nur redet":
- Das Spiel mit einer FOLGE von Befehlen anspielen und die Antwort auf jeden Befehl herausschneiden
  (_nach): Steht der Raum in einem Satz da? Kommt man in den Keller?
- Eine Funktion SELBST rufen (_rufen), jetzt mit ARGUMENTEN: aufzaehlen(["seil", "apfel"]),
  ziel("flur", "westen"). Mit eigenen Listen faellt auf, wer im Rumpf noch `rucksack` statt des
  Parameters liest -- beim Rucksack selbst waere es richtig (Fall in Aufgabe 7).

Ob eine Funktion von draussen liest (Aufgabe 3 ★★★), sagt ast: Welche der Namen raum, punkte, zuege
werden im Rumpf gelesen, ohne Parameter oder dort zugewiesen zu sein? Die Type Hints (auch an den
Parametern) mahnt der Check an, bewertet sie aber nicht ("Hinweis · …", keine Stufe).

Ob das Spiel bis zum Ende kam, zeigt eine Schlusszeile, die der Check hinter den Code haengt (SCHLUSS).
"""
import ast
import io
import re
import sys

import pruefen
from pruefen import erwarte, braucht, ohne_kommentare, anspielen, funktion, quelltext

TITEL = "Seil, Apfel und Kreide · Selbstcheck"

# So spielt der Check das Programm an: in den Keller, Schluessel, raus
EINGABEN = ["westen", "nimm torschlüssel", "osten", "norden"]

DRAUSSEN = "kalt und wunderbar"
TREPPE = "wartest auf den Morgen"
WAND = "Da ist eine Wand"
ZU = "Abgeschlossen"
AUF = "Du schließt das Tor auf."
KELLER = "Der Keller."
SCHLUSS = "§SCHLUSS§"

# Der Lageplan: (raum, richtung) -> ziel; alles andere ist Wand ("")
WEGE = {("flur", "norden"): "tor", ("flur", "osten"): "informatikraum", ("flur", "süden"): "lehrerzimmer",
        ("flur", "westen"): "keller", ("informatikraum", "westen"): "flur", ("lehrerzimmer", "norden"): "flur",
        ("keller", "osten"): "flur"}
RAEUME = ["flur", "informatikraum", "lehrerzimmer", "keller"]
RICHTUNGEN = ["norden", "osten", "süden", "westen"]
SAETZE = [("flur", "Der Flur."), ("informatikraum", "Der Informatikraum."),
          ("lehrerzimmer", "Das Lehrerzimmer."), ("keller", "Der Keller."), ("tor", "Das Haupttor.")]

# Was hinter -> stehen soll, wo der Check es weiss
HINTS = {"hilfe": "None", "zeige_raum": "None", "zeige_rucksack": "None", "pruefe_tuer": "bool",
         "beschreibung": "str", "dinge_im": "list[str]", "dinge_hier": "list[str]", "sterne": "str",
         "aufzaehlen": "str", "ziel": "str", "gehe": "str", "wie_oft": "int", "schaltjahr": "bool",
         "wert": "int", "nimm": "int"}
VON_DRAUSSEN = ("raum", "punkte", "zuege")

KEIN_WERT = object()


def _spiel(befehle, **start):
    """Das Spiel mit diesen Befehlen, oben vorher andere Startwerte. Gibt (aus, abbruch)."""
    alt = pruefen._QUELLE
    q = alt
    for name, wert in start.items():
        q = re.sub(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                   q, count=1, flags=re.M)
    pruefen._QUELLE = q + "\nprint(%r)\n" % SCHLUSS
    try:
        aus, _ = anspielen(befehle)
    finally:
        pruefen._QUELLE = alt
    fertig = SCHLUSS in aus
    wartet = not fertig and aus.endswith("> ")
    return aus, (not fertig and not wartet)


def _nach(aus, befehl, n=1):
    """Die Antwort auf den n-ten Befehl `befehl`: von „> befehl“ bis zur naechsten Eingabe."""
    marke = "> %s\n" % befehl
    i = -1
    for _ in range(n):
        i = aus.find(marke, i + 1)
        if i < 0:
            return ""
    i += len(marke)
    j = aus.find("> ", i)
    return aus[i:j] if j >= 0 else aus[i:]


def _zeile(text, anfang):
    """Die Zeile, die mit `anfang` beginnt (ohne den Anfang), sonst None."""
    for z in text.splitlines():
        if z.strip().startswith(anfang):
            return z.strip()[len(anfang):].strip()
    return None


def _anzahl(muster):
    """Wie oft passt das Muster (regulaerer Ausdruck) im Quelltext ohne Kommentare?"""
    return len(re.findall(muster, ohne_kommentare()))


def _rufen(name, *argumente, **werte):
    """Die Funktion `name` mit diesen Argumenten rufen, vorher Variablen draussen setzen (rucksack=[…]).
    Gibt (wert, gedruckt, fehler): was zurueckkam, was sie dabei gedruckt hat, ein Abbruch als Text."""
    f = funktion(name)
    if f is None:
        return KEIN_WERT, "", "Es gibt keine Funktion %s." % name
    g = f.__globals__
    alt = {k: g.get(k, KEIN_WERT) for k in werte}
    g.update(werte)
    puffer, vorher = io.StringIO(), sys.stdout
    sys.stdout = puffer
    try:
        wert, fehler = f(*argumente), None
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        wert, fehler = KEIN_WERT, "%s: %s" % (type(e).__name__, e)
    finally:
        sys.stdout = vorher
        for k, v in alt.items():
            if v is KEIN_WERT:
                g.pop(k, None)
            else:
                g[k] = v
    return wert, puffer.getvalue(), fehler


def _baum():
    try:
        return ast.parse(quelltext())
    except SyntaxError:
        return None


def _defs():
    """Die Funktionen auf oberster Ebene: [(name, Knoten)]."""
    baum = _baum()
    return [] if baum is None else [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def _parameter(name):
    """Die Parameter der Funktion `name` (Namen), None, wenn es sie nicht gibt."""
    for n, k in _defs():
        if n == name:
            return [a.arg for a in k.args.args]
    return None


def _ruft(name):
    """Die Namen, die die Funktion `name` in ihrem Rumpf aufruft."""
    gerufen = set()
    for n, k in _defs():
        if n == name:
            for c in ast.walk(k):
                if isinstance(c, ast.Call) and isinstance(c.func, ast.Name):
                    gerufen.add(c.func.id)
    return gerufen


def _gerufen_ausser(name):
    """Wird `name` irgendwo ausserhalb seiner eigenen Definition gerufen (Spielschleife oder andere Funktion)?"""
    baum = _baum()
    if baum is None:
        return False
    for k in baum.body:
        if isinstance(k, ast.FunctionDef) and k.name == name:
            continue
        for c in ast.walk(k):
            if isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == name:
                return True
    return False


def _liest_draussen():
    """[(funktion, name)]: raum/punkte/zuege im Rumpf gelesen, aber weder Parameter noch dort zugewiesen."""
    funde = []
    for n, k in _defs():
        params = {a.arg for a in k.args.args}
        gelesen, gesetzt = set(), set()
        for c in ast.walk(k):
            if isinstance(c, ast.Name):
                (gelesen if isinstance(c.ctx, ast.Load) else gesetzt).add(c.id)
        for v in VON_DRAUSSEN:
            if v in gelesen and v not in params and v not in gesetzt:
                funde.append((n, v))
    return funde


def _aufzaehlen_da():
    return _parameter("aufzaehlen") is not None and len(_parameter("aufzaehlen")) == 1


def _ziel_da():
    return _parameter("ziel") is not None and len(_parameter("ziel")) == 2


def _gehe_da():
    return _parameter("gehe") is not None and len(_parameter("gehe")) == 2


def _komma_form(text):
    """„Seil, Apfel und Kreide“ und „seil, apfel, kreide“ als dieselbe Folge: [seil, apfel, kreide]."""
    t = str(text).lower().replace(" und ", ", ")
    return [x.strip() for x in t.split(",")] if t.strip() else []


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


def pruefe_01_wie_vorher():
    """Grundlage · Das Spiel kann noch, was es in „Das Tor, das nur redet“ konnte"""
    aus, abbruch = _spiel(["warte 2", "ende"])
    erwarte(not (abbruch and "> " not in aus),
            "Das Spiel bricht schon vor der ersten Eingabe ab -- fehlt einem Aufruf ein Argument, oder wird "
            "eine Funktion gerufen, bevor sie definiert ist?")
    erwarte(not abbruch, "Nach warte 2 und ende bricht das Spiel ab, bevor es fertig ist.")
    erwarte(TREPPE in aus, "Nach ende fehlt der Satz für ende.")
    erwarte("Deine Sterne" in aus, "Am Ende steht „Deine Sterne:“ nicht mehr -- ist etwas verrutscht?")


# ── Aufgabe 2 · Das Spiel zählt auf ─────────────────────────────────────

def pruefe_20_aufzaehlen():
    """Aufgabe 2 · aufzaehlen(liste) liefert die Dinge in einem Satz -- für jede Liste"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den naechsten Schritt
    # (Reihensichtung Teil II, 25.10., Befund 6: vorher „2 von 2 passen“ ohne naechsten Schritt).
    erwarte(_aufzaehlen_da(), "Noch zählen zwei Funktionen je ihre Liste auf -- es gibt keine Funktion aufzaehlen, "
            "die die Liste mitbekommt.")
    for liste in (["seil", "apfel", "kreide"], ["lampe", "stick"], ["pausenbrot"]):
        wert, gedruckt, fehler = _rufen("aufzaehlen", list(liste), rucksack=["lampe"])
        erwarte(fehler is None, "aufzaehlen(%r) bricht ab: %s" % (liste, fehler))
        erwarte(not gedruckt.strip(),
                "aufzaehlen() druckt die Dinge, statt den Satz zurückzugeben -- es kommt %r zurück." % (wert,))
        erwarte(isinstance(wert, str),
                "aufzaehlen(%r) gibt keinen Text zurück, sondern %r." % (liste, wert))
        erwarte(_komma_form(wert) == liste,
                "aufzaehlen(%r) liefert %r -- läuft die Schleife über den Parameter? Mit dem Rucksack "
                "allein fällt es nicht auf." % (liste, wert))


def pruefe_21_im_spiel():
    """Aufgabe 2 · Raum und Rucksack stehen in einem Satz -- mit derselben Funktion"""
    braucht(_aufzaehlen_da())
    aus, abbruch = _spiel(["süden", "nimm seil", "zeige", "ende"])
    hier, traegt = _zeile(_nach(aus, "süden"), "Hier liegt:"), _zeile(_nach(aus, "zeige"), "Du trägst")
    erwarte(not abbruch, "Bei süden, nimm oder zeige bricht das Spiel ab.")
    erwarte(hier is not None and _komma_form(hier.rstrip(".")) == ["seil", "apfel", "kreide"],
            "Im Lehrerzimmer steht nicht „Hier liegt: seil, apfel, kreide.“ in einer Zeile.")
    erwarte(traegt is not None and _komma_form(traegt.lstrip(":").strip().rstrip(".")) == ["lampe", "seil"],
            "Nach nimm seil und zeige steht nicht „Du trägst: lampe, seil.“ in einer Zeile.")
    erwarte("aufzaehlen" in _ruft("zeige_raum") and "aufzaehlen" in _ruft("zeige_rucksack"),
            "zeige_raum() und zeige_rucksack() rufen nicht beide aufzaehlen().")
    erwarte(_anzahl(r"""print\(\s*["']\s+-["']""") == 0, "Eine Schleife druckt die Dinge noch mit Strich untereinander.")


def pruefe_22_wie_ein_mensch():
    """Aufgabe 2 ★★ · aufzaehlen() zählt auf wie ein Mensch"""
    braucht(_aufzaehlen_da())
    for liste, soll in ((["seil", "apfel", "kreide"], "Seil, Apfel und Kreide"), (["lampe", "stick"], "Lampe und Stick"),
                        (["lampe"], "Lampe"), (["a", "b", "c", "d"], "A, B, C und D")):
        wert, _, fehler = _rufen("aufzaehlen", list(liste), rucksack=["lampe"])
        erwarte(fehler is None, "aufzaehlen(%r) bricht ab: %s" % (liste, fehler))
        erwarte(wert == soll, "aufzaehlen(%r) liefert %r, nicht %r." % (liste, wert, soll))
    aus, abbruch = _spiel(["süden", "ende"])
    erwarte("Hier liegt: Seil, Apfel und Kreide." in _nach(aus, "süden"),
            "Im Lehrerzimmer steht nicht „Hier liegt: Seil, Apfel und Kreide.“")


def pruefe_23_leer():
    """Aufgabe 2 ★★★ · Leere Listen: kein „Hier liegt: .“, ein leerer Rucksack sagt es"""
    braucht(_aufzaehlen_da())
    wert, _, fehler = _rufen("aufzaehlen", [], rucksack=["lampe"])
    erwarte(fehler is None, "aufzaehlen([]) bricht ab: %s" % fehler)
    erwarte(wert == "", "aufzaehlen([]) liefert %r, nicht den leeren Text." % (wert,))
    aus, abbruch = _spiel(["nimm kreide", "schau", "lege kreide", "lege lampe", "zeige", "ende"])
    erwarte(not abbruch, "Bei schau oder zeige mit leeren Listen bricht das Spiel ab.")
    erwarte("Hier liegt" not in _nach(aus, "schau"),
            "Im leeren Flur steht nach schau noch eine Zeile „Hier liegt …“.")
    erwarte("Dein Rucksack ist leer." in _nach(aus, "zeige"),
            "Mit leerem Rucksack (nach lege kreide und lege lampe) steht nach zeige nicht "
            "„Dein Rucksack ist leer.“")


# ── Aufgabe 3 · Ein Weg für alle Richtungen ─────────────────────────────

def pruefe_30_ziel():
    """Aufgabe 3 · ziel(raum, richtung) kennt den ganzen Lageplan"""
    braucht(_ziel_da(), "Es gibt noch keine Funktion ziel mit zwei Parametern.")
    for raum in RAEUME:
        for richtung in RICHTUNGEN:
            soll = WEGE.get((raum, richtung), "")
            wert, gedruckt, fehler = _rufen("ziel", raum, richtung, rucksack=["lampe"])
            erwarte(fehler is None, "ziel(%r, %r) bricht ab: %s" % (raum, richtung, fehler))
            erwarte(not gedruckt.strip(), "ziel() druckt etwas -- sie soll nur den Raum zurückgeben.")
            erwarte(wert is not None, "ziel(%r, %r) liefert None -- fehlt unten return \"\"?" % (raum, richtung))
            erwarte(wert == soll, "ziel(%r, %r) liefert %r, nicht %r." % (raum, richtung, wert, soll))


def pruefe_31_ziel_im_spiel():
    """Aufgabe 3 · Im Spiel führen die Wege, wohin ziel() sagt"""
    braucht(_ziel_da())
    aus, abbruch = _spiel(["westen", "osten", "osten", "osten", "ende"])
    erwarte(not abbruch, "Beim Gehen bricht das Spiel ab.")
    erwarte(KELLER in _nach(aus, "westen"), "Nach westen steht nicht „Der Keller. …“.")
    erwarte("Der Informatikraum." in _nach(aus, "osten", 2), "Vom Flur nach osten kommt ihr nicht in den Informatikraum.")
    erwarte(WAND in _nach(aus, "osten", 3), "Im Informatikraum nach osten steht nicht der Wand-Satz.")
    erwarte(_gerufen_ausser("ziel"), "Niemand fragt ziel() -- weder die Spielschleife noch eine andere Funktion.")


def pruefe_32_gehe():
    """Aufgabe 3 ★★ · gehe(raum, richtung) gibt den neuen Raum zurück"""
    braucht(_gehe_da())
    for raum, richtung, rs, soll, satz in (("flur", "osten", ["lampe"], "informatikraum", ""),
                                           ("informatikraum", "osten", ["lampe"], "informatikraum", WAND),
                                           ("flur", "norden", ["lampe"], "flur", ZU),
                                           ("flur", "norden", ["lampe", "torschlüssel"], "tor", AUF)):
        wert, gedruckt, fehler = _rufen("gehe", raum, richtung, rucksack=rs)
        erwarte(fehler is None, "gehe(%r, %r) bricht ab: %s" % (raum, richtung, fehler))
        erwarte(wert == soll, "gehe(%r, %r)%s liefert %r, nicht %r -- gibt sie den neuen Raum zurück?"
                % (raum, richtung, " mit Torschlüssel" if "torschlüssel" in rs else "", wert, soll))
        erwarte(not satz or satz in gedruckt, "gehe(%r, %r) sagt nicht „%s …“." % (raum, richtung, satz))


def pruefe_33_gehe_im_spiel():
    """Aufgabe 3 ★★ · Die Spielschleife geht mit einer Zeile: raum = gehe(…)"""
    braucht(_gehe_da())
    aus, abbruch = _spiel(["norden", "westen", "nimm torschlüssel", "osten", "norden"])
    erwarte(not abbruch, "Am Tor bricht das Spiel ab.")
    erwarte(ZU in _nach(aus, "norden"), "Ohne Torschlüssel steht nach norden nicht „Abgeschlossen. …“.")
    erwarte(DRAUSSEN in aus, "Mit dem Torschlüssel kommt ihr nicht durchs Tor.")
    erwarte(re.search(r"\braum\s*=\s*gehe\(", ohne_kommentare()) is not None,
            "In der Spielschleife steht nicht raum = gehe(…) -- die Antwort von gehe() muss ins Kästchen raum.")
    erwarte(_anzahl(r'\braum\s*=\s*"(keller|lehrerzimmer|informatikraum)"') == 0,
            "In der Spielschleife steht noch die alte Kette mit raum = \"keller\" …")


def pruefe_34_nicht_von_draussen():
    """Aufgabe 3 ★★★ · Keine Funktion liest raum, punkte oder zuege von draußen"""
    braucht(_gehe_da() and _parameter("beschreibung") not in (None, []))
    for raum, anfang in SAETZE:
        wert, _, fehler = _rufen("beschreibung", raum)
        erwarte(fehler is None, "beschreibung(%r) bricht ab: %s" % (raum, fehler))
        erwarte(isinstance(wert, str) and wert.startswith(anfang),
                "beschreibung(%r) liefert nicht den Satz, der mit „%s“ beginnt." % (raum, anfang))
    erwarte(_parameter("dinge_im") is not None, "Es gibt keine Funktion dinge_im(raum).")
    funde = _liest_draussen()
    erwarte(not funde, "Diese Funktionen lesen noch von draußen: %s -- gebt den Wert als Parameter mit."
            % ", ".join("%s liest %s" % f for f in funde))
    aus, abbruch = _spiel(["westen", "nimm pausenbrot", "zeige", "nimm torschlüssel", "osten", "norden"])
    erwarte(not abbruch and DRAUSSEN in aus, "Das ganze Spiel bis zum Tor läuft nicht mehr durch.")
    erwarte(re.search(r"Punkte:\s*10\s*-\s*Züge übrig:\s*27", _nach(aus, "zeige")) is not None,
            "Nach westen, nimm pausenbrot und zeige steht nicht „Punkte: 10 - Züge übrig: 27“.")


# ── Hinweis: Type Hints (angemahnt, nicht bewertet) ──────────────────────

def pruefe_39_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    braucht(_aufzaehlen_da())
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))


# ── Aufgabe 4 ★★ · Wie im Abitur: wie_oft(ding, liste) ─────────────────

def pruefe_40_wie_oft():
    """Aufgabe 4 ★★ · wie_oft(ding, liste) zählt -- für jedes Ding und jede Liste"""
    braucht(funktion("wie_oft") is not None)
    for ding, liste, soll in (("handschuh", ["handschuh", "schal", "handschuh", "mütze", "handschuh"], 3),
                              ("mütze", ["mütze", "schal", "mütze"], 2), ("schal", ["handschuh", "mütze"], 0),
                              ("kreide", [], 0)):
        wert, gedruckt, fehler = _rufen("wie_oft", ding, list(liste))
        erwarte(fehler is None, "wie_oft(%r, %r) bricht ab: %s" % (ding, liste, fehler))
        erwarte(wert is not None, "wie_oft() gibt nichts zurück (None)%s."
                % (" -- sie druckt, statt zurückzugeben" if gedruckt.strip() else ""))
        erwarte(wert == soll and isinstance(wert, int) and not isinstance(wert, bool),
                "wie_oft(%r, %r) liefert %r, nicht %d%s" % (ding, liste, wert, soll, _warum_wie_oft(wert, soll, ding)))


def _warum_wie_oft(wert, soll, ding):
    """Der Satz hinter der Meldung -- nach dem, was herauskam (Befund 7: vorher hiess es bei jedem Fehler
    „vergleicht sie mit dem Parameter ding?“, auch wenn ein return IN der Schleife zu frueh antwortete)."""
    if not isinstance(wert, int) or isinstance(wert, bool):
        return " -- sie gibt keine ganze Zahl zurück."
    if 0 < wert < soll:
        return " -- antwortet sie, bevor die ganze Liste durchgezählt ist?"
    if ding != "handschuh":
        return " -- zählt sie, was als ding mitkommt, oder etwas Festes?"
    if wert < soll:
        return " -- antwortet sie, bevor die ganze Liste durchgezählt ist?"
    return "."


# ── Aufgabe 8 · Vorrat: Schaltjahr ───────────────────────────────────────

def pruefe_80_schaltjahr():
    """Aufgabe 8 ★★ · schaltjahr(jahr): durch 4 teilbar"""
    braucht(funktion("schaltjahr") is not None)
    for jahr, soll in ((2024, True), (2026, False), (2023, False), (2028, True)):
        wert, gedruckt, fehler = _rufen("schaltjahr", jahr)
        erwarte(fehler is None, "schaltjahr(%d) bricht ab: %s" % (jahr, fehler))
        erwarte(not gedruckt.strip(), "schaltjahr() druckt etwas -- sie soll nur antworten.")
        erwarte(wert is soll, "schaltjahr(%d) liefert %r, nicht %r." % (jahr, wert, soll))


def pruefe_81_ausnahme():
    """Aufgabe 8 ★★★ · schaltjahr(jahr): die Ausnahme mit 100 und 400"""
    braucht(funktion("schaltjahr") is not None)
    for jahr, soll in ((1900, False), (2000, True), (2100, False), (2024, True)):
        wert, _, fehler = _rufen("schaltjahr", jahr)
        erwarte(fehler is None, "schaltjahr(%d) bricht ab: %s" % (jahr, fehler))
        erwarte(wert is soll, "schaltjahr(%d) liefert %r, nicht %r." % (jahr, wert, soll))


# ── Aufgabe 9 ★★★★ · Kuer: Was ein Fund wert ist ────────────────────────

def pruefe_90_wert():
    """Aufgabe 9 ★★★★ · wert(ding): Stick 30, Torschlüssel 20, sonst 10"""
    braucht(funktion("wert") is not None and funktion("nimm") is not None)
    for ding, soll in (("stick", 30), ("torschlüssel", 20), ("seil", 10), ("kreide", 10)):
        wert, _, fehler = _rufen("wert", ding)
        erwarte(fehler is None, "wert(%r) bricht ab: %s" % (ding, fehler))
        erwarte(wert == soll, "wert(%r) liefert %r, nicht %d." % (ding, wert, soll))


def pruefe_91_nimm():
    """Aufgabe 9 ★★★★ · nimm(ding, raum) gibt die Punkte zurück -- das Hauptprogramm zählt"""
    braucht(funktion("wert") is not None and funktion("nimm") is not None)
    aus, abbruch = _spiel(["osten", "nimm stick", "nimm seil", "zeige", "westen", "westen",
                           "nimm torschlüssel", "zeige", "ende"])
    erwarte(not abbruch, "Beim Nehmen bricht das Spiel ab.")
    erwarte("kein seil" in _nach(aus, "nimm seil"), "Im Informatikraum sagt nimm seil nicht „Hier gibt es kein seil.“")
    erwarte(re.search(r"Punkte:\s*30\b", _nach(aus, "zeige")) is not None,
            "Nach nimm stick und nimm seil (das nicht da ist) steht bei zeige nicht „Punkte: 30“.")
    erwarte(re.search(r"Punkte:\s*50\b", _nach(aus, "zeige", 2)) is not None,
            "Nach dem Torschlüssel steht bei zeige nicht „Punkte: 50“.")
    voll, _ = _spiel(["nimm kreide", "osten", "nimm stick", "nimm kreide", "westen", "süden", "nimm seil",
                      "nimm apfel", "nimm kreide", "zeige", "ende"])
    erwarte("voll" in _nach(voll, "nimm kreide", 3) and re.search(r"Punkte:\s*70\b", _nach(voll, "zeige")),
            "Mit vollem Rucksack bringt nimm noch Punkte -- oder sagt nicht, dass er voll ist.")
    erwarte(re.search(r"\bpunkte\s*=\s*punkte\s*\+\s*nimm\(", ohne_kommentare()) is not None,
            "Im Hauptprogramm steht nicht punkte = punkte + nimm(…).")
