# Die Tabelle für den Flur -- als Programm.
raum = "flur"
eingabe = "osten"
