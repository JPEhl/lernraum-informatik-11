# Die Schule bei Nacht -- euer Spiel.
# Stand nach Thema 4 (Wahr oder falsch):
# Jede Frage an den Befehl ist ein Wert: True oder
# False. Mit and, or, not werden daraus die Regeln
# des Spiels -- entscheiden kann das Programm noch
# nicht.

raum = "flur"
zuege = 30
punkte = 0

hat_torschluessel = False

print("DIE SCHULE BEI NACHT")
print("Nach dem Informatikunterricht merkst du: Dein Stick steckt noch im Informatikraum.")
print("Als du zurückkommst, hat der Hausmeister abgeschlossen. Du hast eine Lampe.")
print("Ihr Akku reicht für " + str(zuege) + " Züge. Finde den Weg nach draußen.")
print()
print("Du stehst im", raum + ". Nur deine Lampe leuchtet.")
print("Punkte:", punkte)

eingabe = input("> ").lower().strip()
print("Du hast getippt:", eingabe)
print("Das sind", len(eingabe), "Zeichen. Das erste ist", eingabe[0] + ".")
ding = eingabe.replace("nimm ", "")
print("Ohne das Wort nimm bleibt:", ding)
print("Fängt der Befehl mit nimm an?", eingabe.startswith("nimm "))
print("Steckt ein Leerzeichen drin?", " " in eingabe)

ist_richtung = eingabe == "norden" or eingabe == "osten" or eingabe == "süden" or eingabe == "westen"
print("Ist das eine Richtung?", ist_richtung)
will_zum_tor = eingabe == "norden" and raum == "flur"
tor_offen = will_zum_tor and hat_torschluessel
print("Willst du zum Tor?", will_zum_tor)
print("Geht das Tor auf?", tor_offen)
print("Bleibt es zu?", not tor_offen)
