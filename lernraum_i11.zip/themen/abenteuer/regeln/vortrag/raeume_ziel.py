# Vier Räume: erst der Raum, dann die Richtung.
raum = "keller"
eingabe = "osten"

if raum == "flur":
    if eingabe == "norden":
        print("Abgeschlossen.")
    elif eingabe == "osten":
        raum = "informatikraum"
    elif eingabe == "süden":
        raum = "lehrerzimmer"
    elif eingabe == "westen":
        raum = "keller"
    else:
        print("Das verstehe ich nicht.")
elif raum == "keller":
    if eingabe == "osten":
        raum = "flur"
    else:
        print("Da ist eine Wand.")
print("Du stehst jetzt im", raum + ".")

# Erst vorhersagen: raum = "flur", eingabe = "westen", und aus dem elif wird kurz ein if --
#     if raum == "keller":
# Warum meldet das Spiel dann eine Wand? Danach wieder elif.
