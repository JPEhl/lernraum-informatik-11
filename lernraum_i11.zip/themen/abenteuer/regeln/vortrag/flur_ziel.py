# Die Tabelle für den Flur -- als Programm.
raum = "flur"
eingabe = "osten"

# genau eine Zeile der Tabelle gilt
if eingabe == "norden":
    print("Abgeschlossen.")
elif eingabe == "osten":
    raum = "informatikraum"
elif eingabe == "süden":
    raum = "lehrerzimmer"
elif eingabe == "westen":
    raum = "keller"
else:
    print("Das verstehe ich nicht.")
print("Du stehst jetzt im", raum + ".")

# Erst vorhersagen: eingabe = "norden", und aus dem letzten elif wird kurz ein if --
#     if eingabe == "westen":
# Was zeigt die Shell? Danach wieder elif.
