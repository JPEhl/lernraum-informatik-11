"""Selbstcheck zu "Das Spiel entscheidet" -- prueft regeln.py (Aufgabe 2, 3 und Kuer).

Spielt das Programm Zug fuer Zug an -- je Probe ein Befehl, und vorher oben andere
Startwerte (raum, Taschen, Schluessel, Blick), so wie die Aufgaben es der Klasse
vorschlagen ("probiert andere Startraeume, indem ihr oben raum = ... aendert").
Geprueft wird, wo man danach steht und was in den Taschen liegt -- nicht der
Wortlaut der Saetze. Verraet keine Verzweigung, nur woran es haengt -- und
bewertet nichts.
"""
import re

import pruefen
from pruefen import erwarte, braucht, arbeit, ohne_kommentare, anspielen

TITEL = "Das Spiel entscheidet · Selbstcheck"

# Groß und mit Rand -- das Spiel räumt den Befehl zuerst auf (Thema Den Befehl lesen)
EINGABEN = ["  Osten "]

_FEHLT = object()
WAND = {"informatikraum": "norden", "lehrerzimmer": "süden", "keller": "norden"}


def _wert(name):
    return getattr(arbeit(), name, _FEHLT)


def _code():
    """Der Code ohne Kommentare und ohne Text in Anführungszeichen."""
    return re.sub(r'"[^"]*"|\'[^\']*\'', '""', ohne_kommentare())


def _hat_if():
    """Hat das Spiel schon eine Verzweigung? Die Startdatei hat keine."""
    return re.search(r"^\s*if\b", _code(), re.M) is not None


def _zug(befehl, **start):
    """Ein Zug: das Spiel mit diesem Befehl, oben vorher andere Startwerte.
    Gibt (was nach dem Befehl in der Shell steht, Kästchen danach, alle Startwerte gesetzt?)."""
    alt = pruefen._QUELLE
    q, gesetzt = alt, True
    for name, wert in start.items():
        q, n = re.subn(r"^%s[ \t]*=.*$" % name, lambda m, name=name, wert=wert: "%s = %r" % (name, wert),
                       q, count=1, flags=re.M)
        gesetzt = gesetzt and n == 1
    pruefen._QUELLE = q
    try:
        aus, ns = anspielen([befehl])
    finally:
        pruefen._QUELLE = alt
    marke = befehl + "\n"
    nach = aus[aus.find(marke) + len(marke):] if marke in aus else aus
    return nach, ns, gesetzt


def _raum(befehl, **start):
    nach, ns, _ = _zug(befehl, **start)
    return ns.get("raum", _FEHLT)


def _mit_schluessel(befehl):
    """Der Schlüssel, wo immer das Spiel ihn sucht: im Kästchen oder in der ersten Tasche."""
    start = {"raum": "flur"}
    if re.search(r"^hat_torschluessel[ \t]*=", pruefen._QUELLE, re.M):
        start["hat_torschluessel"] = True
    if re.search(r"^gegenstand1[ \t]*=", pruefen._QUELLE, re.M):
        start["gegenstand1"] = "torschlüssel"
    return _raum(befehl, **start), len(start) > 1


def _zeige(w):
    return "nichts" if w is _FEHLT else str(w)


def _zeilen(text):
    return len([z for z in text.splitlines() if z.strip()])


def _taschen(ns):
    return [ns.get("gegenstand%d" % k, _FEHLT) for k in (1, 2, 3)]


def _flur_geht():
    return _raum("osten", raum="flur") == "informatikraum"


def _nimm_geht():
    _, ns, _ = _zug("nimm seil")
    return _taschen(ns) == ["lampe", "seil", ""]


# ── Grundlage ────────────────────────────────────────────────────────────

def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft ohne rote Meldung"""
    erwarte(True, "")


# ── Aufgabe 2 · ein echter Zug ───────────────────────────────────────────

def pruefe_20_flur():
    """Aufgabe 2 · Vom Flur aus: Osten, Westen, Süden"""
    # Die ERSTE Pflichtpruefung -- ohne braucht(): Im Startzustand steht sie aus und zeigt den
    # naechsten Schritt (Reihensichtung Teil I, 25.10.: vorher zeigte der Start auf Aufgabe 3).
    erwarte(re.search(r"^raum[ \t]*=", pruefen._QUELLE, re.M) is not None,
            "Oben steht kein raum = … mehr -- ohne Startraum weiß das Spiel nicht, wo ihr seid.")
    falsch = []
    for befehl, soll in (("osten", "informatikraum"), ("süden", "lehrerzimmer"), ("westen", "keller")):
        nach, ns, _ = _zug(befehl, raum="flur")
        ist = ns.get("raum", _FEHLT)
        if ist != soll:
            falsch.append((befehl, _zeige(ist), soll, ""))
        elif soll not in nach:
            falsch.append((befehl, _zeige(ist), soll, "zeigt"))
    b, ist, soll, art = falsch[0] if falsch else ("", "", "", "")
    erwarte(not falsch or art,
            "Vom Flur nach %s steht ihr danach im %s -- laut Tabelle im %s." % (b, ist, soll))
    erwarte(not falsch,
            "Vom Flur nach %s seid ihr im %s, aber das Spiel zeigt es nicht an "
            "(Du stehst jetzt im …)." % (b, soll))


def pruefe_21_tor():
    """Aufgabe 2 · Norden: das Tor nur mit Schlüssel"""
    braucht(_hat_if() and _flur_geht())
    nach, ns, _ = _zug("norden", raum="flur")
    ohne = ns.get("raum", _FEHLT)
    erwarte(ohne == "flur",
            "Ohne Schlüssel steht ihr nach norden im %s. Das Tor ist abgeschlossen -- ihr "
            "bleibt im Flur." % _zeige(ohne))
    erwarte(nach.strip() != "",
            "Ohne Schlüssel sagt das Spiel bei norden nichts. Es soll sagen, dass das Tor "
            "abgeschlossen ist.")
    mit, gibt_es = _mit_schluessel("norden")
    erwarte(gibt_es,
            "Oben gibt es weder hat_torschluessel noch Taschen -- woran erkennt das Tor den Schlüssel?")
    erwarte(mit == "tor",
            "Mit Torschlüssel steht ihr nach norden im %s -- dann soll raum zu \"tor\" werden."
            % _zeige(mit))


def pruefe_22_raeume():
    """Aufgabe 2 ★★ · Alle vier Räume: eine Tür zurück, sonst Wand"""
    braucht(_hat_if() and _flur_geht())
    proben = (("informatikraum", "westen", "flur"), ("lehrerzimmer", "norden", "flur"),
              ("keller", "osten", "flur"), ("informatikraum", "norden", "informatikraum"),
              ("lehrerzimmer", "süden", "lehrerzimmer"), ("keller", "norden", "keller"))
    falsch, stumm = [], []
    for raum, befehl, soll in proben:
        nach, ns, _ = _zug(befehl, raum=raum)
        ist = ns.get("raum", _FEHLT)
        if ist != soll:
            falsch.append((raum, befehl, _zeige(ist), soll))
        elif soll == raum and not nach.strip():
            stumm.append((raum, befehl))
    r, b, ist, soll = falsch[0] if falsch else ("", "", "", "")
    erwarte(not falsch,
            "Im %s nach %s steht ihr danach im %s -- laut Tabelle im %s." % (r, b, ist, soll))
    r, b = stumm[0] if stumm else ("", "")
    erwarte(not stumm,
            "Im %s nach %s sagt das Spiel nichts. Dort ist eine Wand -- das soll es sagen." % (r, b))


def pruefe_23_ein_weg():
    """Aufgabe 2 ★★ · Nach dem Gehen fragt kein zweites if"""
    braucht(_hat_if() and _raum("osten", raum="keller") == "flur")
    zuege = (("flur", "süden"), ("flur", "osten"), ("flur", "westen"),
             ("keller", "osten"), ("informatikraum", "westen"), ("lehrerzimmer", "norden"))
    zahl = [(r, b, _zeilen(_zug(b, raum=r)[0])) for r, b in zuege]
    wenigste = min(n for _, _, n in zahl)
    mehr = [(r, b) for r, b, n in zahl if n > wenigste]
    r, b = mehr[0] if mehr else ("", "")
    erwarte(not mehr,
            "Vom %s nach %s zeigt das Spiel mehr Zeilen als bei anderen Zügen. Fragt nach dem "
            "Gehen noch ein zweites if -- im Raum, in dem ihr gerade angekommen seid?" % (r, b))


def pruefe_24_keine_richtung():
    """Aufgabe 2 ★★★ · Was keine Richtung ist: in jedem Raum"""
    braucht(_raum("osten", raum="keller") == "flur" and _raum("westen", raum="informatikraum") == "flur")
    falsch = []
    for raum, wand in sorted(WAND.items()):
        unsinn, ns, _ = _zug("tanze", raum=raum)
        mauer = _zug(wand, raum=raum)[0]
        # verglichen wird die ERSTE Zeile: Die Wand-Antwort zeigt danach noch „Du stehst jetzt im …“ --
        # ein tanze, das nur die Wand meldet, war sonst nicht gleich und kam durch (Giftprobe 25.10.)
        erste_unsinn = (unsinn.strip().splitlines() or [""])[0]
        erste_mauer = (mauer.strip().splitlines() or [""])[0]
        if ns.get("raum") != raum or not unsinn.strip() or erste_unsinn == erste_mauer:
            falsch.append(raum)
    erster = falsch[0] if falsch else ""
    erwarte(not falsch,
            "Im %s sagt das Spiel bei tanze dasselbe wie vor einer Wand -- oder gar nichts. "
            "tanze ist keine Richtung: Das Spiel versteht es nicht." % erster)


# ── Aufgabe 3 · drei Taschen ─────────────────────────────────────────────

def pruefe_30_taschen():
    """Aufgabe 3 · Drei Taschen: gegenstand1 bis gegenstand3"""
    t = [_wert("gegenstand%d" % k) for k in (1, 2, 3)]
    # dran, sobald der Flur geht (Aufgabe 2 ★) -- oder sobald eine Tasche oben steht
    braucht(_flur_geht() or any(w is not _FEHLT for w in t))
    fehlt = ["gegenstand%d" % k for k, w in zip((1, 2, 3), t) if w is _FEHLT]
    erster = fehlt[0] if fehlt else ""
    erwarte(not fehlt,
            "Es gibt noch kein Kästchen %s. Die drei Taschen kommen nach oben zu raum, "
            "zuege und punkte." % erster)
    erwarte(t == ["lampe", "", ""],
            "In den Taschen liegt zu Beginn %s, %s und %s -- die Lampe tragt ihr, die anderen "
            "zwei sind frei (leerer Text)." % tuple(repr(w) for w in t))


def pruefe_31_nimm():
    """Aufgabe 3 · nimm: in die erste freie Tasche"""
    braucht(_taschen(arbeit().__dict__) == ["lampe", "", ""])
    nach, ns, _ = _zug("nimm seil")
    t = _taschen(ns)
    wie_oft = t.count("seil")
    erwarte(wie_oft <= 1,
            "Bei nimm seil liegt das Seil in %d Taschen. Nur die erste freie soll es "
            "bekommen." % wie_oft)
    erwarte(t == ["lampe", "seil", ""],
            "Bei nimm seil liegt in den Taschen %s, %s und %s -- das Seil gehört in die erste "
            "freie." % tuple(repr(w) for w in t))
    erwarte("seil" in nach,
            "Das Seil liegt in der Tasche, aber das Spiel sagt es nicht (Du nimmst: …).")
    _, ns, _ = _zug("nimm seil", gegenstand2="kreide")
    t = _taschen(ns)
    erwarte(t == ["lampe", "kreide", "seil"],
            "Wenn schon Kreide in Tasche 2 liegt, liegt nach nimm seil in den Taschen %s, %s "
            "und %s." % tuple(repr(w) for w in t))
    nach, ns, _ = _zug("nimm seil", gegenstand2="kreide", gegenstand3="apfel")
    t = _taschen(ns)
    erwarte(t == ["lampe", "kreide", "apfel"] and nach.strip() != "",
            "Sind alle drei Taschen voll, soll nimm seil nichts ändern und sagen, dass kein "
            "Platz mehr ist.")


def pruefe_32_lege():
    """Aufgabe 3 ★★ · lege: die Tasche wird wieder frei"""
    braucht(_nimm_geht())
    _, ns, _ = _zug("lege lampe")
    t = _taschen(ns)
    erwarte(t == ["", "", ""],
            "Nach lege lampe liegt in den Taschen %s, %s und %s -- die Tasche der Lampe soll "
            "frei sein." % tuple(repr(w) for w in t))
    _, ns, _ = _zug("lege seil", gegenstand2="seil")
    t = _taschen(ns)
    erwarte(t == ["lampe", "", ""],
            "Liegt das Seil in Tasche 2, liegt nach lege seil in den Taschen %s, %s und %s."
            % tuple(repr(w) for w in t))
    nach, ns, _ = _zug("lege kreide")
    t = _taschen(ns)
    erwarte(t == ["lampe", "", ""] and nach.strip() != "",
            "Bei lege kreide (ihr habt keine) soll sich nichts ändern -- und das Spiel sagt, "
            "dass ihr sie nicht habt.")


def pruefe_33_zeige():
    """Aufgabe 3 ★★ · zeige: alle drei Taschen"""
    braucht(_nimm_geht())
    nach, _, _ = _zug("zeige", gegenstand2="seil", gegenstand3="kreide")
    fehlt = [d for d in ("lampe", "seil", "kreide") if d not in nach]
    erster = fehlt[0] if fehlt else ""
    erwarte(not fehlt,
            "Bei zeige mit Lampe, Seil und Kreide in den Taschen fehlt in der Shell: %s." % erster)


def pruefe_34_schluessel_im_keller():
    """Aufgabe 3 ★★★ · Der Torschlüssel liegt nur im Keller"""
    braucht(_nimm_geht())
    _, ns, _ = _zug("nimm torschlüssel", raum="flur")
    erwarte("torschlüssel" not in _taschen(ns),
            "Im Flur nehmt ihr den Torschlüssel einfach mit. Er liegt nur im Keller.")
    _, ns, _ = _zug("nimm torschlüssel", raum="keller")
    erwarte("torschlüssel" in _taschen(ns),
            "Im Keller lässt sich der Torschlüssel nicht nehmen -- dort liegt er doch.")


def pruefe_35_tor_fragt_taschen():
    """Aufgabe 3 ★★★ · Das Tor fragt die drei Taschen"""
    braucht(_nimm_geht() and _flur_geht())
    zu = []
    for k in (1, 2, 3):
        start = {"raum": "flur", "gegenstand%d" % k: "torschlüssel"}
        if re.search(r"^hat_torschluessel[ \t]*=", pruefen._QUELLE, re.M):
            start["hat_torschluessel"] = False
        if _raum("norden", **start) != "tor":
            zu.append(k)
    erste = zu[0] if zu else 0
    erwarte(not zu,
            "Mit dem Torschlüssel in Tasche %d bleibt das Tor zu. Fragt das Tor alle drei "
            "Taschen?" % erste)
    ohne = _raum("norden", raum="flur")
    erwarte(ohne == "flur",
            "Ohne Torschlüssel in einer Tasche steht ihr nach norden im %s." % _zeige(ohne))


# ── Aufgabe 8 · Kür: ohne Kompass ────────────────────────────────────────

def pruefe_80_kompass():
    """Aufgabe 8 ★★★★ · Ohne Kompass -- bei jeder Blickrichtung"""
    braucht(re.search(r"^blick[ \t]*=", pruefen._QUELLE, re.M) is not None and _flur_geht())
    proben = (("norden", "flur", "rechts", "informatikraum"), ("norden", "flur", "links", "keller"),
              ("norden", "flur", "zurück", "lehrerzimmer"), ("osten", "flur", "rechts", "lehrerzimmer"),
              ("osten", "flur", "zurück", "keller"), ("osten", "flur", "geradeaus", "informatikraum"),
              ("süden", "flur", "links", "informatikraum"), ("süden", "flur", "geradeaus", "lehrerzimmer"),
              ("westen", "keller", "zurück", "flur"), ("westen", "flur", "links", "lehrerzimmer"),
              ("westen", "flur", "geradeaus", "keller"), ("westen", "flur", "zurück", "informatikraum"),
              ("norden", "flur", "osten", "informatikraum"))
    falsch = [(blick, raum, wort, _zeige(ist), soll) for blick, raum, wort, soll in proben
              for ist in [_raum(wort, raum=raum, blick=blick)] if ist != soll]
    blick, raum, wort, ist, soll = falsch[0] if falsch else ("", "", "", "", "")
    erwarte(not falsch,
            "Mit Blick nach %s im %s bei %s steht ihr danach im %s -- laut Tabelle im %s."
            % (blick, raum, wort, ist, soll))
