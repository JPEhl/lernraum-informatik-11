raum = "flur"
eingabe = "osten"
if eingabe == "norden":
    print("Abgeschlossen.")
elif eingabe == "osten":
    raum = "informatikraum"
elif eingabe == "süden":
    raum = "lehrerzimmer"
elif eingabe == "westen":
    raum = "keller"
else:
    print("Das verstehe ich nicht.")
print("Du stehst jetzt im", raum + ".")
