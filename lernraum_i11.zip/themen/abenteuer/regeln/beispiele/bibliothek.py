raum = "keller"
eingabe = "süden"
if raum == "keller":
    if eingabe == "süden":
        raum = "bibliothek"
    elif eingabe == "osten":
        raum = "flur"
    else:
        print("Da ist eine Wand. Eine sehr solide Wand.")
elif raum == "bibliothek":
    if eingabe == "norden":
        raum = "keller"
    else:
        print("Regale. Nur Regale.")
print("Neuer Raum:", raum)
