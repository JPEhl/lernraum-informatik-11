hat_torschluessel = False
if hat_torschluessel:
    print("Du schließt das Tor auf.")
else:
    print("Abgeschlossen.")
print("Die Nacht ist lang.")
