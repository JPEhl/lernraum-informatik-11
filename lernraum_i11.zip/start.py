# start.py -- oeffnet die Arbeitsseite dieses Lernraums.
#
# So geht es: diese Datei in Thonny oeffnen und F5 druecken. Es startet ein
# kleiner Server NUR auf diesem Rechner (127.0.0.1), und der Browser geht
# von selbst auf. Mehr ist nicht zu tun.
#
# Falls kein Browser aufgeht: die Adresse, die unten in der Shell steht,
# in einen Browser kopieren. Sie gilt nur, solange dieses Programm laeuft.
#
#     python3 start.py                 (ohne Thonny, aus einem Terminal)
#     python3 start.py --ohne-browser  (nur den Server starten)
#
# Braucht Python 3.10 oder neuer und sonst nichts -- nur die
# Standardbibliothek. Diese Datei nicht veraendern.
import pathlib
import sys

# Kein __pycache__ neben den Dateien (Block 3, 16.10.2026): Das Lehrerpult wohnt in OneDrive,
# und jede .pyc waere eine Datei mehr, die zwischen Schule und zu Hause hin- und hersynchronisiert.
sys.dont_write_bytecode = True

if sys.version_info < (3, 10):
    # Zu alt -- vielleicht gibt es auf dem Rechner ein neueres Python
    # (Homebrew, python.org, Thonny). Dann damit neu starten, sonst sagen.
    import os
    import shutil
    import subprocess
    KANDIDATEN = ["python3.13", "python3.12", "python3.11", "python3.10", "py",
                  "/opt/homebrew/bin/python3.12", "/opt/homebrew/bin/python3.11",
                  "/Applications/Thonny.app/Contents/Frameworks/Python.framework/Versions/3.10/bin/python3.10",
                  "/usr/local/bin/python3.12", "/usr/local/bin/python3.11"]
    if not os.environ.get("LERNRAUM_NEUSTART"):
        # Erst ein Python MIT tkinter (Fenster!), zur Not eins ohne.
        for probe in ("import sys,tkinter;print(sys.version_info>=(3,10))",
                      "import sys;print(sys.version_info>=(3,10))"):
          for k in KANDIDATEN:
            pfad = shutil.which(k) if "/" not in k else (k if os.path.exists(k) else None)
            if not pfad or pfad == sys.executable:
                continue
            try:
                v = subprocess.run([pfad, "-c", probe], capture_output=True, text=True, timeout=10).stdout.strip()
            except (OSError, subprocess.TimeoutExpired):
                continue
            if v == "True":
                print("Python", sys.version.split()[0], "ist zu alt -- starte mit", pfad)
                sys.stdout.flush()
                os.environ["LERNRAUM_NEUSTART"] = "1"
                sys.exit(subprocess.call([pfad, __file__] + sys.argv[1:]))
    print("Dieser Lernraum braucht Python 3.10 oder neuer.")
    print("Hier laeuft Python", sys.version.split()[0] + ".")
    print("In Thonny 4 ist ein passendes Python schon dabei: start.py dort oeffnen, F5.")
    sys.exit(1)

WURZEL = pathlib.Path(__file__).resolve().parent


def _abgebrochene_aktualisierung_zurueckrollen():
    """Stand eine Aktualisierung mitten im Tauschen still (Rechner aus, Stick
    gezogen), liegt _aktualisierung/laeuft.json noch da. Dann zuerst alles
    zurueck -- BEVOR der Server geladen wird, denn der koennte halb neu sein.
    Dieselbe Logik wie kursserver/aktualisieren.py, Format {"zurueck", "weg"}."""
    import json
    import shutil
    a = WURZEL / "_aktualisierung"
    j = a / "laeuft.json"
    if not j.exists():
        return
    p = json.loads(j.read_text("utf-8"))
    for rel in p.get("weg", []):
        if (WURZEL / rel).is_file():
            (WURZEL / rel).unlink()
    for rel in p.get("zurueck", []):
        q = a / "alt" / rel
        if q.is_file():
            (WURZEL / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(q, WURZEL / rel)
    j.unlink()
    shutil.rmtree(a / "neu", ignore_errors=True)
    shutil.rmtree(a / "alt", ignore_errors=True)
    print("Eine abgebrochene Aktualisierung wurde zurueckgerollt -- alles ist wie vorher.")


_abgebrochene_aktualisierung_zurueckrollen()
sys.path.insert(0, str(WURZEL / "_system"))

from kursserver.server import starten  # noqa: E402

if __name__ == "__main__":
    starten(WURZEL, sys.argv[1:])
